# Tutorial de instalação deste configurador de servidor - Martinho Caeiro, 23917 & Paulo Abade, 23919 - ESTIG
## Neste tutorial, vão ser identificados os comandos necessários para obter o configurar facilmente.
## Execute o comando na pasta que deseja guardar o configurador
## O configurador está intuitivo e dá dicas do que deve ser feito em cada passo.


## É de extrema recomendação utilizar o PuTTy para inserir isto no servidor a partir do Copy&Paste
 curl -L -o scripts.zip "https://drive.google.com/uc?export=download&id=1bMbGlB6DpoxzM2PE6t2OHWx3M8TblZ4Q" && yum install unzip -y &&unzip scripts.zip && chmod +x menu.sh && ./menu.sh
