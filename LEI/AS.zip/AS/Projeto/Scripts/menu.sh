#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script menu para administração de sistemas, que irá chamar outros scripts para configurar os serviços pedidos

# Caminho dos scripts
SCRIPTS_DIR="./scripts"  

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Forçar desativação do firewalld, se estiver ativo
if systemctl is-active --quiet firewalld; then
    echo -e "${YELLOW}O firewalld está ativo. A desativar...${RESET}"
    sudo systemctl stop firewalld
    sudo systemctl disable firewalld
    sudo yum install -y nano
    if systemctl is-active --quiet firewalld; then
        echo -e "${RED}Falha ao desativar o firewalld. Saindo...${RESET}"
        exit 1
    else
        echo -e "${GREEN}firewalld desativado com sucesso.${RESET}"
    fi
fi

# Verificação do estado do SELinux
SELINUX_STATUS=$(getenforce 2>/dev/null)
if [[ "$SELINUX_STATUS" != "Disabled" ]]; then
    echo -e "${RED}Erro: O SELinux está ativo (${SELINUX_STATUS}). Por favor, desative-o antes de continuar.${RESET}"
    echo -e "${YELLOW}Edite o ficheiro /etc/selinux/config e defina: SELINUX=disabled${RESET}"
    echo -e "${YELLOW}Reinicie o sistema após alterar a configuração.${RESET}"
    exit 1
fi

# Verifica se a diretoria de scripts existe
if [[ ! -d "$SCRIPTS_DIR" ]]; then
    echo -e "${RED}Diretório de scripts '$SCRIPTS_DIR' não encontrado.${RESET}"
    exit 1
fi

# Dá permissão de execução a todos os scripts
chmod +x "$SCRIPTS_DIR"/*.sh 2>/dev/null

# Menu principal
menu() {
    clear
    echo -e "${BLUE}========== MENU PRINCIPAL - ADMINISTRAÇÃO DE SISTEMAS ==========${RESET}"
    echo "1 - DNS"
    echo "2 - Virtual Hosts"
    echo "3 - SAMBA"
    echo "4 - NFS"
    echo "5 - Backup"
    echo "6 - RAID"
    echo "7 - Fail2Ban"
    echo "8 - Port Knocking"
    echo "0 - Sair"
    echo -e "${BLUE}================================================================${RESET}"
    read -p "Escolha uma opção: " OPCAO

    case $OPCAO in
        1) correr_script "dns.sh" ;;
        2) correr_script "virtualhosts.sh" ;;
        3) correr_script "samba.sh" ;;
        4) correr_script "nfs.sh" ;;
        5) correr_script "backup.sh" ;;
        6) correr_script "raid.sh" ;;
        7) correr_script "fail2ban.sh" ;;
        8) correr_script "portknock.sh" ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}"; sleep 1 ;;
    esac
}

# Correndo o script selecionado
function correr_script() {
    SCRIPT="$SCRIPTS_DIR/$1"
    echo

    if [[ -f "$SCRIPT" ]]; then
        echo -e "${GREEN}Executando $1...${RESET}"
        bash "$SCRIPT"
        echo -e "${YELLOW}Pressione Enter para voltar ao menu...${RESET}"
        read
    else
        echo -e "${RED}Script '$1' não encontrado em $SCRIPTS_DIR.${RESET}"
        sleep 2
    fi
}

# Loop principal
while true; do
    menu
done
