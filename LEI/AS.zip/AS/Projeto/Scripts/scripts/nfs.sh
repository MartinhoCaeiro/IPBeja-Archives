#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração do NFS

# Configurações 
EXPORTS="/etc/exports"
NIS_DOMAIN_FILE="/etc/sysconfig/network"
NIS_DOMAIN_NAME="meuNIS"
YP_MAKE_CMD="/usr/libexec/yp/ypinit -m"

# Cores 
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package nfs-utils
check_package ypserv
check_package yp-tools

systemctl enable --now nfs-server rpcbind

# Criar partilha NFS 
create_nfs_share() {
    read -p "Diretório a partilhar (ex: /nfs/publico): " DIR

    mkdir -p "$DIR"
    chown -R nobody:nogroup "$DIR"
    chmod 755 "$DIR"

    echo "$DIR *(rw,sync,no_subtree_check,no_root_squash)" >> "$EXPORTS"
    exportfs -a
    systemctl restart nfs-server
    SERVER_IP=$(hostname -I | awk '{print $1}')
    echo -e "${GREEN}Partilha criada: $DIR → $CLIENTE${RESET}"
    echo -e "${BLUE}Para montar na máquina cliente:${RESET}"
    echo -e "${YELLOW}Instalar o pacote nfs-utils na máquina cliente.${RESET}"
    echo -e "${YELLOW}mount -t nfs ${SERVER_IP}:$DIR $DIR${RESET}"
}

# Remover partilha NFS
remove_nfs_share() {
    read -p "Diretório da partilha a remover: " DIR
    if grep -q "^$DIR " "$EXPORTS"; then
        sed -i "\|^$DIR |d" "$EXPORTS"
        exportfs -a
        systemctl restart nfs-server
        echo -e "${GREEN}Partilha $DIR removida.${RESET}"
    else
        echo -e "${RED}Partilha não encontrada.${RESET}"
    fi
}

# Desativar partilha NFS
deactivate_nfs_share() {
    read -p "Diretório da partilha a desativar: " DIR
    if grep -q "^$DIR " "$EXPORTS"; then
        sed -i "s|^$DIR |#$DIR |" "$EXPORTS"
        exportfs -a
        systemctl restart nfs-server
        echo -e "${YELLOW}Partilha $DIR desativada (comentada em /etc/exports).${RESET}"
    else
        echo -e "${RED}Partilha não encontrada.${RESET}"
    fi
}

# Alterar partilha NFS
change_nfs_share() {
    read -p "Diretório atual da partilha: " DIR_ANTIGO
    if grep -q "^$DIR_ANTIGO " "$EXPORTS"; then
        LINE=$(grep "^$DIR_ANTIGO " "$EXPORTS")
        read -p "Nova diretoria da partilha: " DIR_NOVO
        sed -i "\|^$DIR_ANTIGO |d" "$EXPORTS"
        echo "${LINE/$DIR_ANTIGO/$DIR_NOVO}" >> "$EXPORTS"

        mkdir -p "$DIR_NOVO"
        chown -R nobody:nogroup "$DIR_NOVO"
        chmod 755 "$DIR_NOVO"

        exportfs -a
        systemctl restart nfs-server
        echo -e "${GREEN}Partilha alterada de $DIR_ANTIGO para $DIR_NOVO.${RESET}"
    else
        echo -e "${RED}Partilha não encontrada.${RESET}"
    fi
}


# Menu principal 
menu() {
    echo
    echo -e "${BLUE}======== MENU NFS =========${RESET}"
    echo "1 - Criar partilha NFS"
    echo "2 - Alterar partilha NFS"
    echo "3 - Remover partilha NFS"
    echo "4 - Desativar partilha NFS"
    echo "0 - Sair"
    echo -e "${BLUE}===========================${RESET}"
    read -p "Opção: " OP

    case "$OP" in
        1) create_nfs_share ;;
        2) change_nfs_share ;;
        3) remove_nfs_share ;;
        4) deactivate_nfs_share ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}" ;;
    esac
}

# Loop principal 
while true; do
    menu
done
