#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração dos Virtual Hosts

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Configurações
SERVER_IP=$(ip route get 1 | awk '{print $7; exit}')
NAMED_CONF="/etc/named.conf"
HTTPD_CONF="/etc/httpd/conf/httpd.conf"

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package httpd
check_package bind
check_package bind-utils

# Garantir listen-on e allow-query com any no named.conf
if ! grep -q "listen-on port 53 { any; };" "$NAMED_CONF"; then
    sed -i 's/listen-on port 53 {[^}]*}/listen-on port 53 { any; }/' "$NAMED_CONF"
fi
if ! grep -q "allow-query { any; };" "$NAMED_CONF"; then
    sed -i 's/allow-query {[^}]*}/allow-query { any; }/' "$NAMED_CONF"
fi

# Criar zona DNS
create_dns_zone() {
    local DOMAIN="$1"
    local ZONE_FILE="/var/named/${DOMAIN}.hosts"

    if grep -q "zone \"$DOMAIN\"" "$NAMED_CONF"; then
        echo -e "${YELLOW}A zona DNS para $DOMAIN já existe.${RESET}"
        return
    fi

    cat <<-EOF > "$ZONE_FILE"
\$TTL 38400
@ IN SOA	serverproj.as.pt. mail.as.com. (
		$(date +%Y%m%d%H)
		10800
		3600
		604800
		38400 )
    IN	NS	serverproj.as.pt.
    IN	A	$SERVER_IP
www	IN	A	$SERVER_IP
EOF

    chown named:named "$ZONE_FILE"
    chmod 640 "$ZONE_FILE"

    cat <<EOF >> "$NAMED_CONF"

zone "$DOMAIN" IN {
    type master;
    file "$ZONE_FILE";
    allow-update { none; };
};
EOF
}

# Adicionar VirtualHost
add_vhost() {
    read -p "Digite o domínio (ex: exemplo.com): " DOMAIN
    USERNAME="$DOMAIN"
    HOME_DIR="/home/$USERNAME"
    DOC_ROOT="$HOME_DIR/public_html"

    useradd -m -d "$HOME_DIR" -s /sbin/nologin "$USERNAME"
    mkdir -p "$DOC_ROOT"

    cat <<HTML > "$DOC_ROOT/index.html"
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Bem-vindo a $DOMAIN</title>
</head>
<body>
    <h1>Site de $DOMAIN</h1>
    <p>Servidor Apache ativo. IP: $SERVER_IP</p>
</body>
</html>
HTML

    chown -R "$USERNAME:$USERNAME" "$HOME_DIR"
    chmod -R 755 "$HOME_DIR"

    if ! grep -q "NameVirtualHost $SERVER_IP:80" "$HTTPD_CONF"; then
        echo "NameVirtualHost $SERVER_IP:80" >> "$HTTPD_CONF"
    fi

    if grep -q "ServerName $DOMAIN" "$HTTPD_CONF"; then
        echo -e "${YELLOW}VirtualHost já existe para $DOMAIN.${RESET}"
        return
    fi

    cat <<EOF >> "$HTTPD_CONF"

<VirtualHost $SERVER_IP:80>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN
    DocumentRoot "$DOC_ROOT"

    <Directory "$DOC_ROOT">
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog /var/log/httpd/${DOMAIN}_error.log
    CustomLog /var/log/httpd/${DOMAIN}_access.log combined
</VirtualHost>
EOF

    create_dns_zone "$DOMAIN"
    systemctl restart httpd
    systemctl restart named

    if dig @"$SERVER_IP" "$DOMAIN" +short | grep -q "$SERVER_IP"; then
        echo -e "${GREEN}VirtualHost e DNS configurados para $DOMAIN.${RESET}"
    else
        echo -e "${RED}Problema com resolução DNS para $DOMAIN.${RESET}"
    fi
}

# Remover VirtualHost
remove_vhost() {
    read -p "Digite o domínio a remover: " DOMAIN
    USERNAME="$DOMAIN"
    HOME_DIR="/home/$USERNAME"
    ZONE_FILE="/var/named/${DOMAIN}.hosts"

    rm -rf "$HOME_DIR" "$ZONE_FILE"
    userdel -r "$USERNAME" &>/dev/null
    sed -i "/zone \"$DOMAIN\"/,/^[[:space:]]*};/d" "$NAMED_CONF"
    sed -i "/<VirtualHost $SERVER_IP:80>/,/<\/VirtualHost>/ {/ServerName $DOMAIN/!b;d;}" "$HTTPD_CONF"

    systemctl restart httpd
    systemctl restart named

    echo -e "${RED}VirtualHost e zona DNS para $DOMAIN removidos.${RESET}"
}

# Menu principal
menu() {
    echo -e "${BLUE}========= MENU VIRTUAL HOSTS =========${RESET}"
    echo "1 - Adicionar VirtualHost + DNS"
    echo "2 - Remover VirtualHost + DNS"
    echo "0 - Sair"
    echo -e "${BLUE}======================================${RESET}"
    read -p "Escolha uma opção: " OPCAO

    case "$OPCAO" in
        1) add_vhost ;;
        2) remove_vhost ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}" ;;
    esac
}

# Loop principal
while true; do
    menu
done