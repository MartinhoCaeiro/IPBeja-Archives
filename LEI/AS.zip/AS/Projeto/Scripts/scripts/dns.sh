#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração do DNS

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Configurações
SERVER_IP=$(ip route get 1 | awk '{print $7; exit}')
NAMED_CONF="/etc/named.conf"
NAMED_DIR="/var/named"

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package bind

# Garantir listen-on e allow-query com any no named.conf
if ! grep -q "listen-on port 53 { any; };" "$NAMED_CONF"; then
    sed -i 's/listen-on port 53 {[^}]*}/listen-on port 53 { any; }/' "$NAMED_CONF"
fi
if grep -q "allow-query" "$NAMED_CONF"; then
    sed -i 's/allow-query\s*{[^}]*};/allow-query { any; };/' "$NAMED_CONF"
else
    # Adiciona a diretiva dentro do bloco "options"
    sed -i '/^options\s*{/,/^}/s/^}/    allow-query { any; };\n}/' "$NAMED_CONF"
fi

# Criar zona DNS
create_dns_zone() {
    local DOMAIN="$1"
    local ZONE_FILE="$NAMED_DIR/${DOMAIN}.hosts"

    if ! grep -q "zone \"$DOMAIN\"" "$NAMED_CONF"; then
        cat <<-EOF >> "$NAMED_CONF"

zone "$DOMAIN" IN {
    type master;
    file "$ZONE_FILE";
    allow-update { none; };
};
EOF
    fi

    cat <<-EOF > "$ZONE_FILE"
\$TTL 38400
@ IN SOA serverproj.as.pt. mail.as.com. (
    $(date +%Y%m%d%H)
    10800
    3600
    604800
    38400 )
    IN NS serverproj.as.pt.
    IN A $SERVER_IP
www IN A $SERVER_IP
EOF

    chown named:named "$ZONE_FILE"
    chmod 640 "$ZONE_FILE"

    create_reverse_zone "$SERVER_IP" "$DOMAIN"
    systemctl restart named

    echo -e "${GREEN}Zona DNS criada para $DOMAIN.${RESET}"
}

# Criar zona reverse
create_reverse_zone() {
    local IP="$1"
    local HOSTNAME="$2"

    local OCT1=$(echo $IP | cut -d. -f1)
    local OCT2=$(echo $IP | cut -d. -f2)
    local OCT3=$(echo $IP | cut -d. -f3)
    local OCT4=$(echo $IP | cut -d. -f4)

    local REVERSE_ZONE="$OCT3.$OCT2.$OCT1.in-addr.arpa"
    local REVERSE_FILE="$NAMED_DIR/$OCT3.$OCT2.$OCT1.rev"

    if ! grep -q "zone \"$REVERSE_ZONE\"" "$NAMED_CONF"; then
        cat <<EOF >> "$NAMED_CONF"

zone "$REVERSE_ZONE" IN {
    type master;
    file "$REVERSE_FILE";
    allow-update { none; };
};
EOF
    fi

    if [[ ! -f "$REVERSE_FILE" ]]; then
        cat <<-EOF > "$REVERSE_FILE"
\$TTL 38400
@ IN SOA serverproj.as.pt. mail.as.com. (
    $(date +%Y%m%d%H)
    10800
    3600
    604800
    38400 )
    IN NS serverproj.as.pt.
EOF
    fi

    echo "$OCT4 IN PTR $HOSTNAME." >> "$REVERSE_FILE"
    chown named:named "$REVERSE_FILE"
    chmod 640 "$REVERSE_FILE"
}

# Remover zona DNS
remove_dns_zone() {
    read -p "Digite o domínio a remover: " DOMAIN
    ZONE_FILE="$NAMED_DIR/${DOMAIN}.hosts"

    rm -f "$ZONE_FILE"
    sed -i "/zone \"$DOMAIN\"/,/^[[:space:]]*};/d" "$NAMED_CONF"

    systemctl restart named
    echo -e "${RED}Zona DNS para $DOMAIN removida.${RESET}"
}

# Adicionar registo DNS (A ou MX)
add_dns_record() {
    read -p "Digite o domínio: " DOMAIN
    ZONE_FILE="$NAMED_DIR/${DOMAIN}.hosts"
    [[ ! -f "$ZONE_FILE" ]] && echo -e "${RED}Zona não encontrada.${RESET}" && return

    read -p "Tipo de registo (A ou MX): " TYPE
    read -p "Nome (ex: mail ou @): " NAME
    read -p "Valor (IP ou hostname): " VALUE

    if [[ "$TYPE" == "A" ]]; then
        echo "$NAME IN A $VALUE" >> "$ZONE_FILE"
        create_reverse_zone "$VALUE" "$NAME.$DOMAIN"
    elif [[ "$TYPE" == "MX" ]]; then
        read -p "Prioridade (ex: 10): " PRIORITY
        echo "$NAME IN MX $PRIORITY $VALUE" >> "$ZONE_FILE"
    else
        echo -e "${RED}Tipo inválido.${RESET}"
        return
    fi

    systemctl restart named
    echo -e "${GREEN}Registo $TYPE adicionado com sucesso.${RESET}"
}

menu() {
    echo -e "${BLUE}=========== MENU DNS ==========${RESET}"
    echo "1 - Criar zona DNS (com reverse)"
    echo "2 - Remover zona DNS"
    echo "3 - Adicionar registo DNS (A ou MX)"
    echo "0 - Sair"
    echo -e "${BLUE}===============================${RESET}"
    read -p "Escolha uma opção: " OPCAO

    case "$OPCAO" in
        1) read -p "Digite o domínio: " DOM; create_dns_zone "$DOM" ;;
        2) remove_dns_zone ;;
        3) add_dns_record ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}" ;;
    esac
}

# Loop principal
while true; do
    menu
done