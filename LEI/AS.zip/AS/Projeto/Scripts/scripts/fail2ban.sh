#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração do Fail2Ban

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package epel-release
check_package fail2ban

# Configuração do Fail2Ban
configure_fail2ban_ssh() {
    echo -e "${BLUE}Configurando o Fail2Ban para o SSH...${RESET}"
    
    read -p "Tempo de bloqueio (bantime) em segundos [ex: 600]: " bantime
    read -p "Janela de deteção (findtime) em segundos [ex: 600]: " findtime
    read -p "Número máximo de tentativas (maxretry) [ex: 3]: " maxretry

    # Usar valores padrão se o utilizador não preencher
    bantime=${bantime:-600}
    findtime=${findtime:-600}
    maxretry=${maxretry:-3}

    # Cria ou edita o arquivo de configuração local
    cat <<EOF > /etc/fail2ban/jail.local
    [DEFAULT]
    bantime = $bantime
    findtime = $findtime
    maxretry = $maxretry
    backend = systemd
    banaction = iptables-multiport

    [sshd]
    enabled = true
    port = ssh
    logpath = /var/log/secure
EOF

    systemctl restart fail2ban
    systemctl enable fail2ban

    echo -e "${GREEN}Fail2Ban configurado para o serviço SSH.${RESET}"
}

# Exibir IPs bloqueados
show_blocked_ips() {
    echo -e "${BLUE}IPs bloqueados atualmente:${RESET}"
    fail2ban-client status sshd | grep "Banned IP list"
}

# Desbloquear IP especifico
unban_ip() {
    read -p "Digite o IP que deseja desbloquear: " IP
    fail2ban-client set sshd unbanip "$IP"
    if [[ $? -eq 0 ]]; then
        echo -e "${GREEN}IP $IP desbloqueado com sucesso.${RESET}"
    else
        echo -e "${RED}Falha ao desbloquear o IP $IP.${RESET}"
    fi
}

# Menu principal
menu() {
    echo -e "${BLUE}======= MENU FAIL2BAN =======${RESET}"
    echo "1 - Configurar Fail2Ban para SSH"
    echo "2 - Exibir IPs bloqueados"
    echo "3 - Desbloquear IP"
    echo "0 - Sair"
    echo -e "${BLUE}=============================${RESET}"
    read -p "Escolha uma opção: " OPCAO

    case $OPCAO in
        1) configure_fail2ban_ssh ;;
        2) show_blocked_ips ;;
        3) unban_ip ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}" ;;
    esac
}

# Loop principal
while true; do
    menu
done
