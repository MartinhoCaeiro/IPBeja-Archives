#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração dos Backups

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package rsync
check_package tar


# Configurações
BACKUP_BASE="/backup"
FULL_BACKUP_DIR="$BACKUP_BASE/sistema"
INCREMENTAL_DIR="$BACKUP_BASE/utilizadores"
DATE=$(date +%F_%H-%M)

mkdir -p "$FULL_BACKUP_DIR" "$INCREMENTAL_DIR"

# Backup completo do sistema
echo -e "${BLUE}Iniciando backup completo do sistema...${RESET}"

tar -czpf "$FULL_BACKUP_DIR/backup_sistema_$DATE.tar.gz" \
    /etc/passwd \
    /etc/group \
    /etc/shadow \
    /etc/gshadow \
    /etc

if [[ $? -eq 0 ]]; then
    echo -e "${GREEN}Backup completo do sistema criado em:${RESET} $FULL_BACKUP_DIR/backup_sistema_$DATE.tar.gz"
else
    echo -e "${RED}Erro ao criar backup do sistema.${RESET}"
fi

# Backup incremental dos utilizadores
echo -e "${BLUE}Iniciando backup incremental dos utilizadores (/home)...${RESET}"

# Cria diretoria de destino com a data atual
DEST="$INCREMENTAL_DIR/$DATE"
mkdir -p "$DEST"

# Verifica se existe um backup anterior para usar como referência
LINK_DEST=$(find "$INCREMENTAL_DIR" -mindepth 1 -maxdepth 1 -type d | sort | tail -n 1)

# Executa o rsync com ou sem --link-dest
if [[ -d "$LINK_DEST" && "$LINK_DEST" != "$DEST" ]]; then
    rsync -a --delete --link-dest="$LINK_DEST" /home/ "$DEST"
else
    rsync -a --delete /home/ "$DEST"
fi

if [[ $? -eq 0 ]]; then
    echo -e "${GREEN}Backup incremental dos utilizadores salvo em:${RESET} $DEST"
else
    echo -e "${RED}Erro no backup incremental dos utilizadores.${RESET}"
fi
