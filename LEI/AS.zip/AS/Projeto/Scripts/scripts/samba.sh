#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração do Samba

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Verifica se systemctl está disponível
command -v systemctl &>/dev/null || {
    echo -e "${RED}systemctl não encontrado. Este script requer systemd.${RESET}"
    exit 1
}

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package "samba"
check_package "samba-client"
check_package "samba-common"

SMB_CONF="/etc/samba/smb.conf"
cp "$SMB_CONF" "${SMB_CONF}.bak_$(date +%F_%T)"

# Adicionar partilha
add_samba_share() {
    read -p "Nome do compartilhamento: " SHARE_NAME
    grep -q "^\[$SHARE_NAME\]" "$SMB_CONF" && {
        echo -e "${RED}Compartilhamento $SHARE_NAME já existe.${RESET}"
        return
    }

    read -p "Diretório local: " SHARE_DIR
    read -p "Utilizador do Samba: " USER

    if ! id "$USER" &>/dev/null; then
        echo -e "${RED}O Utilizador $USER não existe.${RESET}"
        return
    fi

    [[ ! -d "$SHARE_DIR" ]] && {
        echo -e "${YELLOW}Criando diretório $SHARE_DIR...${RESET}"
        mkdir -p "$SHARE_DIR"
        chown "$USER:$USER" "$SHARE_DIR"
        chmod 755 "$SHARE_DIR"
    }

    cat <<EOF >> "$SMB_CONF"

[$SHARE_NAME]
    path = $SHARE_DIR
    available = yes
    valid users = $USER
    read only = no
    browseable = yes
    public = no
EOF

    smbpasswd -a "$USER"
    systemctl restart smb && echo -e "${GREEN}Compartilhamento $SHARE_NAME criado com sucesso.${RESET}"
}

# Remover partilha
remove_samba_share() {
    read -p "Nome do compartilhamento a remover: " SHARE_NAME
    sed -i "/\[$SHARE_NAME\]/,/^$/d" "$SMB_CONF"
    systemctl restart smb && echo -e "${GREEN}Compartilhamento $SHARE_NAME removido.${RESET}"
}

# Alterar partilha (só diretoria, para simplificar)
change_samba_share() {
    read -p "Nome do compartilhamento a alterar: " SHARE_NAME
    if ! grep -q "^\[$SHARE_NAME\]" "$SMB_CONF"; then
        echo -e "${RED}Compartilhamento não encontrado.${RESET}"
        return
    fi

    read -p "Novo diretório: " NEW_PATH

    sed -i "/\[$SHARE_NAME\]/,/^$/s|^\( *path *= *\).*|\1$NEW_PATH|" "$SMB_CONF"

    systemctl restart smb && echo -e "${GREEN}Compartilhamento $SHARE_NAME atualizado.${RESET}"
}

# Ativar/Desativar partilha (comenta bloco)
toggle_samba_share() {
    read -p "Nome do compartilhamento: " SHARE_NAME
    if ! grep -q "^\[$SHARE_NAME\]" "$SMB_CONF"; then
        echo -e "${RED}Compartilhamento não encontrado.${RESET}"
        return
    fi

    read -p "Ativar (a) ou Desativar (d)? " ACTION
    if [[ "$ACTION" =~ ^[Aa]$ ]]; then
        sed -i "/^#\[$SHARE_NAME\]/,/^$/ s/^#//" "$SMB_CONF"
        echo -e "${GREEN}Compartilhamento $SHARE_NAME ativado.${RESET}"
    elif [[ "$ACTION" =~ ^[Dd]$ ]]; then
        sed -i "/\[$SHARE_NAME\]/,/^$/ s/^/#/" "$SMB_CONF"
        echo -e "${YELLOW}Compartilhamento $SHARE_NAME desativado.${RESET}"
    else
        echo -e "${RED}Opção inválida.${RESET}"
        return
    fi

    systemctl restart smb
}

# Adicionar Utilizador Samba
add_samba_user() {
    read -p "Utilizador: " USER
    if ! id "$USER" &>/dev/null; then
        echo -e "${YELLOW}Utilizador $USER não existe no sistema. Criando...${RESET}"
        useradd "$USER"
    fi
    smbpasswd -a "$USER"
    echo -e "${GREEN}Utilizador $USER adicionado ao Samba.${RESET}"
}

# Remover Utilizador Samba
remove_samba_user() {
    read -p "Utilizador: " USER
    smbpasswd -x "$USER"
    echo -e "${GREEN}Utilizador $USER removido do Samba.${RESET}"
}

# Montar partilha Windows no Linux
mount_windows_share() {
    read -p "Endereço da partilha Windows (ex: //192.168.1.100/comp): " WIN_SHARE
    read -p "Ponto de montagem local (ex: /mnt/win): " MOUNT_POINT
    read -p "Utilizador da partilha Windows: " USER
    read -s -p "Senha do Utilizador: " PASS
    echo

    [[ ! -d "$MOUNT_POINT" ]] && mkdir -p "$MOUNT_POINT"

    echo -e "username=$USER\npassword=$PASS" > /tmp/.smbcred
    chmod 600 /tmp/.smbcred

    mount -t cifs "$WIN_SHARE" "$MOUNT_POINT" -o credentials=/tmp/.smbcred

    if [[ $? -eq 0 ]]; then
        echo -e "${GREEN}Partilha montada em $MOUNT_POINT${RESET}"
    else
        echo -e "${RED}Erro ao montar partilha.${RESET}"
    fi

    rm -f /tmp/.smbcred
}

# Menu principal
menu() {
    echo -e "${BLUE}===== MENU SAMBA =====${RESET}"
    echo "1 - Adicionar partilha Samba"
    echo "2 - Remover partilha Samba"
    echo "3 - Alterar partilha Samba"
    echo "4 - Ativar/Desativar partilha Samba"
    echo "5 - Adicionar utilizador Samba"
    echo "6 - Remover utilizador Samba"
    echo "7 - Montar partilha Windows no Linux"
    echo "0 - Sair"
    echo -e "${BLUE}======================${RESET}"
    read -p "Opção: " OPCAO

    case "$OPCAO" in
        1) add_samba_share ;;
        2) remove_samba_share ;;
        3) change_samba_share ;;
        4) toggle_samba_share ;;
        5) add_samba_user ;;
        6) remove_samba_user ;;
        7) mount_windows_share ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}" ;;
    esac
}

# Loop principal
while true; do
    menu
done