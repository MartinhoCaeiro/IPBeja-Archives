#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração do Port Knocking

# Cores
BLUE="\e[34m"
YELLOW="\e[33m"
RED="\e[31m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package knock
check_package knock-server
check_package iptables-services

# Ativar port knocking
activate_port_knock() {
    echo -e "${YELLOW}Ativando port knocking...${RESET}"

    read -p "Digite a sequência de portas para ABRIR o SSH (ex: 7000,8000,9000): " seq_abrir
    read -p "Digite a sequência de portas para FECHAR o SSH (ex: 9000,8000,7000): " seq_fechar
    read -p "Digite o tempo máximo entre os knocks (em segundos): " seq_timeout

    if ! [[ "$seq_timeout" =~ ^[0-9]+$ ]]; then
        echo -e "${RED}Tempo inválido! Usando valor padrão de 5 segundos.${RESET}"
        seq_timeout=5
    fi

    # Bloqueia a porta 22 para todos
    sudo iptables -I INPUT -p tcp --dport 22 -j DROP

    # Cria ou sobrescreve o arquivo de configuração do knockd
    sudo tee /etc/knockd.conf > /dev/null <<EOF
[options]
    logfile = /var/log/knockd.log
    interface = enp0s3

[openSSH]
    sequence = $seq_abrir
    seq_timeout = $seq_timeout
    command = /sbin/iptables -I INPUT -s %IP% -p tcp --dport 22 -j ACCEPT
    tcpflags = syn

[closeSSH]
    sequence = $seq_fechar
    seq_timeout = $seq_timeout
    command = /sbin/iptables -D INPUT -s %IP% -p tcp --dport 22 -j ACCEPT
    tcpflags = syn
EOF

    # Ativa o knockd com systemd
    sudo systemctl daemon-reexec
    sudo systemctl enable --now knockd

    echo -e "${BLUE}Port knocking ativado com sucesso.${RESET}"
}

# Desativar port knocking
deactivate_port_knock() {
    echo -e "${YELLOW}Desativando port knocking...${RESET}"

    sudo systemctl stop knockd
    sudo systemctl disable knockd

    sudo iptables -D INPUT -p tcp --dport 22 -j ACCEPT 2>/dev/null
    sudo iptables -D INPUT -p tcp --dport 22 -j DROP 2>/dev/null

    echo -e "${BLUE}Port knocking desativado.${RESET}"
}

# Menu principal
menu() {
    echo -e "\n${BLUE}========= MENU PORT KNOCKING =========${RESET}"
    echo "1 - Ativar port knocking (knockd)"
    echo "2 - Desativar port knocking"
    echo "0 - Sair"
    echo -e "${BLUE}======================================${RESET}"
    read -p "Escolha uma opção: " OPCAO

    case "$OPCAO" in
        1) activate_port_knock ;;
        2) deactivate_port_knock ;;
        0) echo -e "${YELLOW}A sair...${RESET}"; exit 0 ;;
        *) echo -e "${RED}Opção inválida.${RESET}" ;;
    esac
}

# Loop principal
while true; do
    menu
done
