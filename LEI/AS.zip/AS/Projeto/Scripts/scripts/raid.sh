#!/bin/bash

# Martinho Caeiro, 23917 & Paulo Abade, 23919
# 2025-05-23
# Script de configuração do RAID 5

# Cores
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[94m"
RESET="\e[0m"

# Verifica se é root
if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}Este script precisa de permissões de root.${RESET}"
    exit 1
fi

# Verificação de pacotes
check_package() {
    PACKAGE=$1
    if ! rpm -q "$PACKAGE" &>/dev/null; then
        echo -e "${YELLOW}Pacote $PACKAGE não encontrado.${RESET}"
        read -p "Deseja instalar $PACKAGE? (s/n): " INSTALL
        if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
            yum install -y "$PACKAGE"
            systemctl enable --now "$PACKAGE"
        else
            echo -e "${RED}$PACKAGE é necessário. A sair...${RESET}"
            exit 1
        fi
    fi
}

check_package mdadm

echo -e "${BLUE}========= CRIADOR DE RAID 5 =========${RESET}"

# Identifica discos disponíveis (sem partição ou uso) com 5 GB
echo -e "${BLUE}Verificando discos disponíveis com 5GB...${RESET}"
DISCOS=$(lsblk -dnbo NAME,SIZE | awk '$2==5368709120 {print "/dev/"$1}')

if (( $(echo "$DISCOS" | wc -l) < 3 )); then
    echo -e "${RED}São necessários no mínimo 3 discos de 5GB. Adicione-os no VirtualBox.${RESET}"
    exit 1
fi

echo -e "${GREEN}Discos elegíveis:${RESET}"
echo "$DISCOS"
read -p "Usar estes discos para criar RAID 5? (s/n): " CONFIRMA
[[ "$CONFIRMA" =~ ^[Ss]$ ]] || exit 1

# Nome do ponto de montagem
read -p "Digite o caminho da diretoria para montar o RAID (ex: /mnt/armazenamento): " MOUNT_POINT
mkdir -p "$MOUNT_POINT"

# Criação do RAID
RAID_DISCOS=$(echo "$DISCOS" | xargs)
echo -e "${YELLOW}Criando RAID 5 com os discos: $RAID_DISCOS${RESET}"
mdadm --create --verbose /dev/md0 --level=5 --raid-devices=3 $RAID_DISCOS

echo -e "${BLUE}Aguarde inicialização do RAID...${RESET}"
sleep 5

# Verifica status
cat /proc/mdstat

# Cria o mdadm.conf
echo -e "${YELLOW}Salvando configuração do RAID...${RESET}"
mkdir -p /etc/mdadm
mdadm --detail --scan >> /etc/mdadm/mdadm.conf

# Formata e monta
mkfs.ext4 /dev/md0
mount /dev/md0 "$MOUNT_POINT"
echo "/dev/md0  $MOUNT_POINT  ext4  defaults  0 0" >> /etc/fstab

# Mostra sucesso
echo -e "${GREEN}RAID 5 criado, montado em $MOUNT_POINT e persistente no fstab!${RESET}"
