M=[1 0 1 0;
   0 1 1 1;
   1 1 1 0;
   0 1 0 1];

S=[];
U=[];

[nClt, nS]= size(M);

for i=1: nS
    U=[U,i];
end

w=zeros(1, nS);

while (isempty(U)==false)
    
    sU=size(U,2);

    for j=1:sU
     cj(j)=0;
     for i=1:nClt
         cj(j)=cj(j)+M(i, U(j));
     end
    end
end

jEsc=U(find(cj==min(cj), 1));

alfa=[];

for i=1:nClt
    if(M(i, jEsc)==1)
        alfa=[alfa, i];
    end
end

alfaC= setdiff(alfa, S);

salfaC= size(alfaC, 2);

for i = 1:salfaC
    ci(i)=0;
    for j=1:nS
        ci(i)=ci(i)+M(alfaC(i), j);
    end
    ci(i)=1/ci(i);
end

iEsc= alfaC(find(ci==min(ci), 1));

S=[S, iEsc];

beta=[];

for j=1:nS
    if(M(iEsc, j)==1)
        beta=[beta, j];
    end
end

U=setdiff(U, beta);