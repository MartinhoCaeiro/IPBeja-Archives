try
    ficheiro = uigetfile('*.*', 'Selecione um Ficheiro'); % Abre uma janela para selecionar o ficheiro
catch error
    fprintf('Erro ao ler o ficheiro %s\n',ficheiro); % Erro de leitura do ficheiro
end

dados = dlmread(ficheiro); % Leitura do ficheiro

Serv = dados(1); % A primeira linha contem o 'Serv'

% As restantes linhas contem a Matriz dos Custos
custoServLoc = dados(2:end, :);
[~, nLoc] = size(custoServLoc);

tic % Inicio do Tempo de CPU
    
X = []; % Passo 1: Começar com o X vazio
Xmin = X; % Passo 2
custoXmin = Inf; % Deste modo a primeira melhoria irá sempre acontecer

% Passo 5: Se |X| < 2, repetir
while size(X ,2) < Serv  
   
   % Passo 3: Para cada local 'di' que não esteja em X
   for i = (setdiff(1:nLoc , X)) 
            Xlinha = union(X, i); % a) Avaliar Xlinha
            custoXlinha = sum(min(custoServLoc(:, Xlinha), [], 2));
           
            % b) Se o custoXlinha for menor que custoXmin o Xmin é igual ao Xlinha 
            if custoXlinha <= custoXmin
                Xmin = Xlinha;
                custoXmin = custoXlinha;
            end
   end

    X = Xmin; % Passo 4
end

toc % Fim do Tempo de CPU

% Mostra os servidores escolhidos
disp('Servidores escolhidos:');
disp(Xmin);

% Escreve num ficheiro .csv os resultados
[~, nomeBase, ~] = fileparts(ficheiro);
nomeFicheiro = ['Resultados_Greedy_' nomeBase '.csv'];
writematrix(Xmin, nomeFicheiro)
