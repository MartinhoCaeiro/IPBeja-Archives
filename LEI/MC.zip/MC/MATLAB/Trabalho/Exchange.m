try
    ficheiro = uigetfile('*.*', 'Selecione um Ficheiro'); % Abre uma janela para selecionar o ficheiro
catch error
    fprintf('Erro ao ler o ficheiro %s\n',ficheiro); % Erro de leitura do ficheiro
end

dados = dlmread(ficheiro); % Leitura do ficheiro

Serv = dados(1); % A primeira linha contem o 'Serv'

% As restantes linhas contem a Matriz dos Custos
custoServLoc = dados(2:end, :);
[~, nLoc] = size(custoServLoc);

tic % Inicio do Tempo de CPU

X = randperm(nLoc, Serv); % Passo 1
Xmin = X; % Passo 2

loop = true; % Começa o loop de melhoria

% Loop de Melhoria 
while loop
    for j = 1:Serv
        % Passo 3: Para cada servidor 'xj' em X
        servRestantes = setdiff(1:nLoc, X);

        for k = 1:length(servRestantes)
            % a) Para cada local 'xk' que não esteja em X
            % Xlinha é igual a X menos o servidor 'xj' mais o local 'xk'  
            Xlinha = setdiff(X, X(j));
            Xlinha = union(Xlinha, servRestantes(k));

            % Se custoServLoc(Xlinha) < custoServLoc(Xmin), atualizar o Xmin
            if sum(min(custoServLoc(:, Xlinha), [], 2)) < sum(min(custoServLoc(:, Xmin), [], 2))
                Xmin = Xlinha;
            end
        end
    end

    % Passo 4: Parar loop se X for igual a Xmin
    if isequal(X, Xmin)
        loop = false;
    else
        % Passo 5: Caso contrário, X = Xmin, repetir a partir do passo 3
        X = Xmin;
        loop = true;
    end
end

toc % Fim do Tempo de CPU

% Mostra os servidores escolhidos
disp('Servidores escolhidos:');
disp(Xmin);

% Escreve num ficheiro .csv os resultados
[~, nomeBase, ~] = fileparts(ficheiro);
nomeFicheiro = ['Resultados_Exchange_' nomeBase '.csv'];
writematrix(Xmin, nomeFicheiro)
