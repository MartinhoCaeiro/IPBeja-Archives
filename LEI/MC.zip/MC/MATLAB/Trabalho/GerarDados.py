import random

nMat = input("Quantas matrizes quer criar? ")
numeroFicheiro = 0
nVar = int(input("Quantos vértices vai ter esta matriz? "))

while numeroFicheiro < int(nMat):
    
    nLoc = int(input("Quantos servidores vai ter esta matriz? "))
    nClt = nVar - nLoc
    Serv = int(input("Dos servidores escolhidos, quantos deseja abertos? "))
    matriz = str(Serv) + "\n"
    matrizCompleta = "["
    for i in range(1, nClt + 1):
        matrizCompleta += "["
        for j in range(1, nLoc + 1):
            valorRandom = str(random.randint(1, 100)) # Números aleatórios entre 1 e 100
            matriz += valorRandom

            if j == nLoc and i != nClt:
                matriz += "\n"
            elif j != nLoc:
                matriz += " "
            matrizCompleta += valorRandom

            if j == nLoc:
                    matrizCompleta += "],"
            else:
                    matrizCompleta += ", "
                    
        if i == nClt:
            matrizCompleta = matrizCompleta[:-1]  # Remove a última vírgula da última linha
            matrizCompleta += "]"
        else:
            matrizCompleta += "\n"

            
    #Diretorias para os ficheiros

    with open("C:/Users/Marti/Documents/Python/python/MC/matrizML"+str(nVar)+ "_" + str(numeroFicheiro + 1) + ".dat", 'w') as fileVMatLab:
        fileVMatLab.write(str(matriz))

    with open("C:/Users/Marti/Documents/Python/python/MC/matrizCPLEX"+str(nVar)+ "_" + str(numeroFicheiro + 1) + ".dat", 'w') as fileVCPLEX:
        fileVCPLEX.write("Serv=" + str(Serv) + ";\n")
        fileVCPLEX.write("nLoc=" + str(nLoc) + ";\n")
        fileVCPLEX.write("nClt=" + str(nClt) + ";\n")

        fileVCPLEX.write("custoCltLoc=" + matrizCompleta + ";\n")

    numeroFicheiro += 1