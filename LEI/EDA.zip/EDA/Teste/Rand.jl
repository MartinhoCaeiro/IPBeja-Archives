"""
EDA 2024
Rand.jl
Martinho Caeiro
20/02/2024

Média e Desvio Padrão
"""

using Random  # Importa o módulo Random para gerar números aleatórios
N = 10000  # Define o tamanho da amostra

# Função para calcular a média de uma amostra de números
function media(x)
    m = sum(x) / N  # Calcula a média como a soma dos números dividida pelo tamanho da amostra
end

# Função para calcular o desvio padrão de uma amostra de números
function desvio_padrao(x)
    m = media(x)  # Calcula a média dos números
    v = sum((x .- m).^2 / N)  # Calcula a variância como a média dos quadrados das diferenças entre cada número e a média
    sqrt(v)  # Retorna a raiz quadrada da variância, que é o desvio padrão
end

# Função principal
function main()
    rng = MersenneTwister(1234)  # Inicializa um gerador de números aleatórios
    numeros = randn(rng, Float64, N)  # Gera uma amostra de N números aleatórios com distribuição normal
    m = media(numeros)  # Calcula a média da amostra
    d = desvio_padrao(numeros)  # Calcula o desvio padrão da amostra

    # Imprime os resultados
    println("A média de ", N, " números aleatórios: $m")
    println("O desvio padrão de ", N, " números aleatórios: $d")
end

main()  # Chama a função principal para executar o código
