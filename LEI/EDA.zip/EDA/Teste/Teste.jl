"""
EDA 2024
Teste.jl
Martinho Caeiro
20/02/2024

Treino Julia
"""

# Definição de uma função simples que calcula o seno de um vetor
function f1(x)
    y = sin.(x)
end

# Definição de uma estrutura imutável (struct) chamada Bebida
struct Bebida
    teor
    nome
    precoaolitro
end

# Definição de uma estrutura mutável (mutable struct) chamada BebidaMutavel
mutable struct BebidaMutavel
    teor
    nome
    precoaolitro
end

# Função principal
function main()
    println("Teste")

    # Exemplo de uso da função f1
    x = ones(10)
    y = f1(x)

    # Exemplo de operações com vetores
    a = rand(Float64, 10)
    b = rand(Float64, 10)
    c = a + b

    # Exemplo de interpolação de string
    d = "teste"
    println("Este é um $d", c[1])

    # Exemplo de estruturas condicionais
    n = 5
    if n < 10
        println("OI")
    else
        println("NOI")
    end

    # Exemplo de loop while
    k = 1
    while k < 10
        println("O valor de k = $k")
        k += 1
    end
    
    # Exemplo de loop for
    for k = 20:-3:1
        println("O valor de k no ciclo for é = $k")  
    end

    # Exemplo de loop for usando elementos de um vetor
    for x in a
        println("O valor de a é $x")
    end

    # Exemplo de uso de uma estrutura imutável
    rum = Bebida(14, "rum", 10)
    println("Nome bebida: ", rum.nome)

    # Exemplo de uso de uma estrutura mutável
    rummut = BebidaMutavel(14, "rum", 10)
    rummut.nome = "Rum da Jamaica"
    println("Nome bebida: ", rummut.nome)

    # Modificando um vetor
    z = [1, 2, 3]
    push!(z, 10)
end

# Chama a função principal para executar o código
main()
