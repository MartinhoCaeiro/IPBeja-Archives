struct Foto
    autor::String
    titulo::String
    data::String
end

# Função merge ajustada para ordenar fotos
function merge!(fotos::Vector{Foto}, p::Int, q::Int, r::Int)
    n1 = q - p + 1
    n2 = r - q

    L = Vector{Foto}(undef, n1 + 1)
    R = Vector{Foto}(undef, n2 + 1)

    for i in 1:n1
        L[i] = fotos[p + i - 1]
    end

    for j in 1:n2
        R[j] = fotos[q + j]
    end

    # Sentinelas no final dos arrays L e R
    L[n1 + 1] = Foto("zzzzzzzzzzzz", "", "") # valor que vai garantir a comparação correta
    R[n2 + 1] = Foto("zzzzzzzzzzzz", "", "")

    i, j = 1, 1

    for k in p:r
        # Comparar autores ignorando aqueles que têm 'e'
        if (!occursin('e', L[i].autor) && occursin('e', R[j].autor)) || 
           (!occursin('e', L[i].autor) && !occursin('e', R[j].autor) && length(L[i].autor) <= length(R[j].autor))
            fotos[k] = L[i]
            i += 1
        else
            fotos[k] = R[j]
            j += 1
        end
    end
end

# Função mergesort ajustada para chamar merge!
function mergesort!(fotos::Vector{Foto}, p::Int = 1, r::Int = -1)
    if r == -1
        r = length(fotos)
    end

    if p < r
        q = div(p + r, 2)
        mergesort!(fotos, p, q)
        mergesort!(fotos, q + 1, r)
        merge!(fotos, p, q, r)
    end
    return fotos
end

function sort_fotos(fotos::Vector{Foto})
    mergesort!(fotos, 1, length(fotos))
    return fotos
end

function print_fotos(fotos::Vector{Foto})
    for foto in fotos
        println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Data: ", foto.data)
    end
end

function main()
    fotos = [
        Foto("Alice", "Foto 1", "2023-06-01"),
        Foto("Bob", "Foto 2", "2023-06-02"),
        Foto("Eve", "Foto 3", "2023-06-03"),
        Foto("Oscar", "Foto 4", "2023-06-04"),
        Foto("Charlie", "Foto 5", "2023-06-05"),
        Foto("Mallory", "Foto 6", "2023-06-06"),
        Foto("Trent", "Foto 7", "2023-06-07"),
        Foto("David", "Foto 8", "2023-06-08"),
        Foto("Bob", "Foto 9", "2023-06-09"),
        Foto("Ivan", "Foto 10", "2023-06-10")
    ]

    println("Fotos antes da ordenação:")
    print_fotos(fotos)

    sorted_fotos = sort_fotos(fotos)

    println("\nFotos após a ordenação:")
    println("Fotos ignoradas (contêm 'e' no autor):")
    for foto in sorted_fotos
        if occursin('e', foto.autor)
            println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Data: ", foto.data)
        end
    end

    println("\nFotos ordenadas (não contêm 'e' no autor):")
    for foto in sorted_fotos
        if !occursin('e', foto.autor)
            println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Data: ", foto.data)
        end
    end
end

main()
