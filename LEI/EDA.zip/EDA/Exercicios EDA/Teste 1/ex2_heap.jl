
struct Foto
    autor::String
    titulo::String
    data::String
end

function left(i)
    return 2i
end

function right(i)
    return 2i + 1
end


function maxheapify!(fotos::Vector{Foto}, i, heapSize)
    l = left(i)
    r = right(i)
    largest = i

    if l <= heapSize && length(fotos[l].autor) > length(fotos[i].autor)
        largest = l
    end

    if r <= heapSize && length(fotos[r].autor) > length(fotos[largest].autor)
        largest = r
    end

    if largest != i
        temp = fotos[i]
        fotos[i] = fotos[largest]
        fotos[largest] = temp
        maxheapify!(fotos, largest, heapSize)
    end
end

function buildmaxheap!(fotos::Vector{Foto})
    heapSize = length(fotos)
    for i = div(length(fotos), 2):-1:1
        maxheapify!(fotos, i, heapSize)
    end
    heapSize
end

function heapsort!(fotos::Vector{Foto})
    heapSize = buildmaxheap!(fotos)
    for i = length(fotos):-1:2
        temp = fotos[1]
        fotos[1] = fotos[i]
        fotos[i] = temp
        heapSize -= 1
        maxheapify!(fotos, 1, heapSize)
    end
    fotos
end

function main()
    fotos = [
        Foto("Alice", "Foto 1", "2023-06-01"),
        Foto("Bob", "Foto 2", "2023-06-02"),
        Foto("Eve", "Foto 3", "2023-06-03"),
        Foto("Oscar", "Foto 4", "2023-06-04"),
        Foto("Charlie", "Foto 5", "2023-06-05"),
        Foto("Mallory", "Foto 6", "2023-06-06"),
        Foto("Trent", "Foto 7", "2023-06-07"),
        Foto("David", "Foto 8", "2023-06-08"),
        Foto("Bob", "Foto 9", "2023-06-09"),
        Foto("Ivan", "Foto 10", "2023-06-10")
    ]

    println("Fotos antes da ordenação:")
    println(fotos)

    sorted_fotos = heapsort!(fotos)

    println("\nFotos após a ordenação:")
    println("Fotos ignoradas (contêm 'e' no autor):")
    for foto in sorted_fotos
        if occursin('e', foto.autor)
            println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Data: ", foto.data)
        end
    end

    println("\nFotos ordenadas (não contêm 'e' no autor):")
    for foto in sorted_fotos
        if !occursin('e', foto.autor)
            println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Data: ", foto.data)
        end
    end
end

main()