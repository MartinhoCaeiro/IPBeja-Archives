function xpto(nomecompleto::String)
    s = 0
    for char in nomecompleto
        valor = Int(char)
        if valor % 2 == 0
            s += valor * 2
        else
            s += valor * 3
        end
    end
    return s % 5
end

function main()
    nomecompleto = "RafaelConceicaoNarciso"
    resultado = xpto(nomecompleto)
    println(resultado)
end


main()