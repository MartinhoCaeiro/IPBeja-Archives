using Random

@enum NodeColor begin
    red
    black
end

mutable struct RBNode
    key::Int
    p::Int
    left::Int
    right::Int
    color::NodeColor
end

function initrbtree(n)
    rbtree = Array{RBNode}(undef, n)
    nil = 1
    for i = 1:n
        node = RBNode(0, nil, nil, nil, black)
        rbtree[i] = node
    end
    rbtree
end

function placenoderb(rbtree, index, key, p, left, right, color)
    rbtree[index] = RBNode(key, p, left, right, color)
end

function printrbtree(rbtree)
    println("node, key, parent, left, right, color")
    for i in firstindex(rbtree):lastindex(rbtree)
        key = rbtree[i].key
        p = rbtree[i].p
        left = rbtree[i].left
        right = rbtree[i].right
        color = rbtree[i].color
        println("$i | $key | $p | $left | $right | $color")
    end
end

function right_rotate!(rbtree, x)
    y = rbtree[x].left
    rbtree[x].left = rbtree[y].right
    if rbtree[y].right != 1
        rbtree[rbtree[y].right].p = x
    end
    rbtree[y].p = rbtree[x].p
    if rbtree[x].p == 1
        # x is root
    else
        if x == rbtree[rbtree[x].p].right
            rbtree[rbtree[x].p].right = y
        else
            rbtree[rbtree[x].p].left = y
        end
    end
    rbtree[y].right = x
    rbtree[x].p = y
end

function main()
    # Step 1: Generate a list of 20 random natural numbers
    random_numbers = rand(1:100, 20)
    println("Random numbers: ", random_numbers)
    
    # Step 2: Initialize the red-black tree
    n = 20
    rbtree = initrbtree(n)
    
    # Step 3: Insert the numbers into the tree (simplified, not actual RB tree insertions)
    for i in 1:n
        key = random_numbers[i]
        p = i == 1 ? 1 : div(i, 2)
        left = 2*i <= n ? 2*i : 1
        right = 2*i+1 <= n ? 2*i+1 : 1
        color = i % 2 == 0 ? red : black  # Alternate colors for simplicity
        placenoderb(rbtree, i, key, p, left, right, color)
    end
    
    println("Before right rotation:")
    printrbtree(rbtree)
    
    # Step 4: Apply right rotation to the node with index 3
    right_rotate!(rbtree, 3)
    
    println("After right rotation:")
    printrbtree(rbtree)
end

main()
