using Random
using Statistics
using Dates

# Definindo a estrutura Foto
struct Foto
    autor::String
    titulo::String
    data::String
end

# Função para gerar um nome aleatório
function generate_random_name(length::Int)
    letters = 'a':'z'
    return String([rand(letters) for _ in 1:length])
end

# Função para gerar uma lista de fotos com autores aleatórios
function generate_random_fotos(n::Int)
    fotos = Vector{Foto}()
    for i in 1:n
        autor_length = rand(3:10)
        autor = generate_random_name(autor_length)
        push!(fotos, Foto(autor, "Foto $i", string(Date(2023, rand(1:12), rand(1:28)))))
    end
    return fotos
end

# Função partition! para quicksort modificado
function partition!(fotos::Vector{Foto}, low::Int, high::Int)
    pivot = fotos[high]
    i = low - 1
    
    for j in low:high-1
        if !(occursin("e", fotos[j].autor))
            if occursin("e", pivot.autor) || length(fotos[j].autor) < length(pivot.autor)
                i += 1
                fotos[i], fotos[j] = fotos[j], fotos[i]
            end
        end
    end
    
    fotos[i+1], fotos[high] = fotos[high], fotos[i+1]
    return i + 1
end

# Função quicksort! modificada
function quicksort!(fotos::Vector{Foto}, low::Int, high::Int)
    if low < high
        pi = partition!(fotos, low, high)
        quicksort!(fotos, low, pi - 1)
        quicksort!(fotos, pi + 1, high)
    end
end

# Função sort_fotos para chamar quicksort!
function sort_fotos(fotos::Vector{Foto})
    quicksort!(fotos, 1, length(fotos))
    return fotos
end

# Função para medir o tempo de execução
function measure_sort_time(n::Int)
    fotos = generate_random_fotos(n)
    start_time = time()
    sort_fotos(fotos)
    end_time = time()
    return end_time - start_time
end

# Função para calcular a mediana dos tempos de execução
function median_execution_time(n::Int, m::Int)
    times = [measure_sort_time(n) for _ in 1:m]
    return median(times)
end

# Função principal para demonstrar o funcionamento
function main()
    n = 10000  # Ajuste este valor para que o tempo de execução seja pelo menos 15 segundos
    m = 30
    println("Calculando a mediana dos tempos de execução para $n elementos com $m amostras...")
    med_time = median_execution_time(n, m)
    println("Mediana dos tempos de execução: $med_time segundos")
end

main()
