struct Militar
    numero_mecanografico::Int
    nome_completo::String
    patente::String
end

mutable struct Queue
    Q::Vector{Militar}
    head::Int
    tail::Int
    length::Int
    Queue() = new(Vector{Militar}(undef, 10), 1, 1, 10)
end



function enQueue(Q::Queue, x::Militar)
    Q.Q[Q.tail] = x
    if Q.tail == Q.length
        Q.tail = 1
    else
        Q.tail += 1
    end
end

function deQueue(Q::Queue)::Militar
    x = Q.Q[Q.head]
    if Q.head == Q.length
        Q.head = 1
    else
        Q.head += 1
    end
    return x
end

function isEmpty(Q::Queue)::Bool
    return Q.head == Q.tail
end

# Criando uma fila de espera de militares
fila_militares = Queue()

# Adicionando militares à fila
enQueue(fila_militares, Militar(12345, "João Silva", "Soldado"))
enQueue(fila_militares, Militar(67890, "Maria Oliveira", "Cabo"))
enQueue(fila_militares, Militar(11223, "Carlos Souza", "Sargento"))
println(fila_militares)

# Removendo um militar da fila e imprimindo seus dados
println("Removendo um militar da fila:")
militar_removido = deQueue(fila_militares)
println("Militar removido:")
println("Número Mecanográfico: ", militar_removido.numero_mecanografico)
println("Nome Completo: ", militar_removido.nome_completo)
println("Patente: ", militar_removido.patente)
println()

# Verificando se a fila está vazia
println("A fila está vazia? ", isEmpty(fila_militares))
