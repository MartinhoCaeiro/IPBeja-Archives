struct Foto
    autor::String
    titulo::String
    data::Int
end

function bubblesort!(fotos::Vector{Foto})
    n = length(fotos)
    for i in 1:n-1
        for j in n:-1:i+1
            if !occursin('e', fotos[j].autor) && !occursin('e', fotos[j-1].autor)
                if length(fotos[j].autor) < length(fotos[j-1].autor)
                    fotos[j], fotos[j-1] = fotos[j-1], fotos[j]
                end
            end
        end
    end
    return fotos
end

function ordenar_fotos!(fotos::Vector{Foto})
    return bubblesort!(fotos)
end

function main()
    fotos = [
        Foto("Rafael", "Titulo1", 2020),
        Foto("Ana", "Titulo2", 2021),
        Foto("Carlos", "Titulo3", 2019),
        Foto("Beto", "Titulo4", 2018),
        Foto("Diana", "Titulo5", 2017),
        Foto("Elena", "Titulo6", 2022),
        Foto("Fábio", "Titulo7", 2016),
        Foto("Gustavo", "Titulo8", 2015),
        Foto("Heitor", "Titulo9", 2014),
        Foto("Iris", "Titulo10", 2013)
    ]

    fotos_ordenadas = ordenar_fotos!(fotos)

    println("Fotos ordenadas:")
    for foto in fotos_ordenadas
        if !occursin('e', foto.autor)
            println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Ano: ", foto.data)
        end
    end

    println("\nFotos ignoradas:")
    for foto in fotos
        if occursin('e', foto.autor)
            println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Ano: ", foto.data)
        end
    end

    println("\nMatriz Organizada : ",fotos_ordenadas)
end

main()
