# Definição da estrutura Foto
struct Foto
    autor::String
    titulo::String
    data::Int
end

# Função de ordenação Insertion Sort
function insertionsort!(fotos::Vector{Foto})
    for j in 2:length(fotos)
        key = fotos[j]
        i = j - 1
        while i > 0 && length(fotos[i].autor) > length(key.autor)
            fotos[i + 1] = fotos[i]
            i -= 1
        end
        fotos[i + 1] = key
    end
    return fotos
end

# Filtrar fotos cujo autor não contenha a vogal 'e'
function filtrar_fotos(fotos::Vector{Foto})
    return filter(foto -> !occursin("e", foto.autor), fotos)
end

# Função principal para ordenar fotos conforme as regras especificadas
function ordenar_fotos!(fotos::Vector{Foto})
    fotos_filtradas = filtrar_fotos(fotos)
    insertionsort!(fotos_filtradas)
    return fotos_filtradas
end

# Teste com 10 exemplos de fotos diferentes
function main()
    fotos = [
        Foto("Rafael", "Titulo1", 2020),
        Foto("Ana", "Titulo2", 2021),
        Foto("Carlos", "Titulo3", 2019),
        Foto("Beto", "Titulo4", 2018),
        Foto("Diana", "Titulo5", 2017),
        Foto("Elena", "Titulo6", 2022),
        Foto("Fábio", "Titulo7", 2016),
        Foto("Gustavo", "Titulo8", 2015),
        Foto("Heitor", "Titulo9", 2014),
        Foto("Iris", "Titulo10", 2013)
    ]

    fotos_ordenadas = ordenar_fotos!(fotos)

    for foto in fotos_ordenadas
        println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Ano: ", foto.data)
    end
end

main()
