struct Foto
    autor::String
    titulo::String
    data::String
end


function quicksort!(fotos::Vector{Foto}, p, r) where T
    if p < r
        q = partition!(fotos, p, r)
        quicksort!(fotos, p, q-1) # sort the left side
        quicksort!(fotos, q+1, r) # sort the right side
    end
end



# p = low r = high

function partition!(fotos::Vector{Foto}, p, r) where T
    x = fotos[r] # pivot
    i = p - 1
    for j = p : r - 1 # run trough the array

        if !(occursin("e",fotos[j].autor))
            if(occursin("e",x.autor) || length(fotos[j].autor) < length(x.autor) )  
            i = i + 1 # marks the first big element
            temp = fotos[i]
            fotos[i] = fotos[j]
            fotos[j] = temp
        end
    end
    end
    temp = fotos[i + 1]
    fotos[i + 1] = fotos[r]
    fotos[r] = temp
    return i + 1    
end
function sort_fotos(fotos::Vector{Foto})
    quicksort!(fotos, 1, length(fotos))
    return fotos
end
function print_fotos(fotos::Vector{Foto})
    for foto in fotos
        println("Autor: ", foto.autor, ", Título: ", foto.titulo, ", Data: ", foto.data)
    end
end
function main()
    fotos = [
        Foto("Alice", "Foto 1", "2023-06-01"),
        Foto("Bob", "Foto 2", "2023-06-02"),
        Foto("Eve", "Foto 3", "2023-06-03"),
        Foto("Oscar", "Foto 4", "2023-06-04"),
        Foto("Charlie", "Foto 5", "2023-06-05"),
        Foto("Mallory", "Foto 6", "2023-06-06"),
        Foto("Trent", "Foto 7", "2023-06-07"),
        Foto("David", "Foto 8", "2023-06-08"),
        Foto("Bob", "Foto 9", "2023-06-09"),
        Foto("Ivan", "Foto 10", "2023-06-10")
    ]

    println("Fotos antes da ordenação:")
    print_fotos(fotos)
    sorted_fotos = sort_fotos(fotos)
    println("\nFotos após a ordenação:")
    print_fotos(sorted_fotos)
end


main()