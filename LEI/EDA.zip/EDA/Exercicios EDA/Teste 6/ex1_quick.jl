using Random
using Statistics
function quick_sort_ponto!(A::Vector{Float64}, p::Int, r::Int)
    if p < r
        q = partition(A, p, r)
        quick_sort_ponto!(A, p, q - 1)
        quick_sort_ponto!(A, q + 1, r)
    end
end

function partition(A::Vector{Float64}, p::Int, r::Int)
    pivot = A[r]
    i = p - 1
    for j in p:r-1
        if A[j] ≤ pivot
            i += 1
            A[i], A[j] = A[j], A[i]
        end
    end
    A[i+1], A[r] = A[r], A[i+1]
    return i + 1
end

function sort_ponto(A::Vector{Float64})
    quick_sort_ponto!(A, 1, length(A))
    return A
end

function tempo_medio_execucao(n::Int, m::Int)
    tempos = Float64[]
    for _ in 1:m
        numeros = calculo()
        tempo = @elapsed sort_ponto(numeros)
        push!(tempos, tempo)
    end
    return mean(tempos), std(tempos)
end

function calculo()
    lista_numeros = Float64[]
    for _ in 1:100
        x::Float64 = rand(0:100)
        y::Float64 = rand(0:100)
        resultado = abs(x+y)^2+ abs(x)^0.5 + abs(y)^0.8
        push!(lista_numeros, resultado)
    end
    return lista_numeros
end

function main()
    # Ordenação dos números gerados pela função calculo()
    n = 100
    m = 30
    media_tempo, desvio_padrao = tempo_medio_execucao(n, m)
    println("\nTempo médio de execução para n = $n e m = $m amostras: $media_tempo segundos")
    println("Desvio padrão do tempo de execução: $desvio_padrao segundos")
end

main()
