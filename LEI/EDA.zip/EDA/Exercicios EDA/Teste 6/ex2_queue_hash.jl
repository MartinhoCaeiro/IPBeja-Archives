mutable struct Cidade
    nome::String
    numero_habitantes::Int
end

mutable struct Queue
    Q::Vector{Cidade}
    head::Int
    tail::Int
    length::Int
    Queue() = new(Vector{Cidade}(undef, 10), 1, 1, 0)
end

function enQueue(Q::Queue, x::Cidade)
    Q.Q[Q.tail] = x
    Q.length += 1
    if Q.tail == length(Q.Q)
        Q.tail = 1
    else
        Q.tail += 1
    end
end

function deQueue(Q::Queue)::Cidade
    x = Q.Q[Q.head]
    Q.length -= 1
    if Q.head == length(Q.Q)
        Q.head = 1
    else
        Q.head += 1
    end
    return x
end

function isEmpty(Q::Queue)::Bool
    return Q.head == Q.tail
end
function hash_multiplication(k::Int, m::Int, A::Float64)
    return floor(m * (k * A % 1))
end

# Função de hash usando o método da divisão
function hash_division(k::Int, m::Int)
    return k % m
end

# Testando as funções de hash
function test_hash_functions()
    println("Testando função de hash usando o método da multiplicação:")
    for k in 20:511
        hashed_value = hash_multiplication(k, 5, 0.61803398875) # 10 é o tamanho da tabela hash, e 0.61803398875 é um valor próximo a phi
        println("Chave: $k => Valor hash: $hashed_value")
    end
    
    println("\nTestando função de hash usando o método da divisão:")
    for k in 20:511
        hashed_value = hash_division(k, 5) # 10 é o tamanho da tabela hash
        println("Chave: $k => Valor hash: $hashed_value")
    end
end

# Função para pesquisar cidades com um número de habitantes superior a um valor específico
function pesquisa_cidades_superiores(fila::Queue, habitantes_minimos::Int)
    println("Cidades com mais de ", habitantes_minimos, " habitantes:")
    # Definindo corretamente os limites para percorrer a fila
    for i in fila.head:(fila.head + fila.length - 1) % length(fila.Q) + 1
        cidade = fila.Q[i]
        if cidade.numero_habitantes > habitantes_minimos
            println(cidade.nome, ": ", cidade.numero_habitantes, " habitantes")
        end
    end
end

# Criando uma fila de cidades
fila_cidades = Queue()

# Adicionando cidades à fila
enQueue(fila_cidades, Cidade("Joaquim da Terra", 4))
enQueue(fila_cidades, Cidade("Terra do primo ze", 1))
enQueue(fila_cidades, Cidade("Beja dos betos", 60))
enQueue(fila_cidades, Cidade("Alternismo em cidade", 50000))
enQueue(fila_cidades, Cidade("Favorite Gas Station Jewish", 6000000))

# Realizando a pesquisa por cidades com mais de 10 habitantes
#pesquisa_cidades_superiores(fila_cidades, 10)

test_hash_functions()