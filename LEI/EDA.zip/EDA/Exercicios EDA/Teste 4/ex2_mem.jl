const NIL = 0

struct CartaoCidadao
    numero::Int
    nome::String
    naturalidade::String
end

mutable struct Stack
    S::Vector{Int}
    top::Int
    Stack(n) = new(Vector{Int}(undef, n), 0)
end

mutable struct MemoryDoubleLinkedList
    key::Vector{CartaoCidadao}
    prev::Vector{Int}
    next::Vector{Int}
    free::Stack
    NIL::Int
end

mutable struct DoubleLinkedList
    mem::MemoryDoubleLinkedList
    head::Int
    DoubleLinkedList(mem::MemoryDoubleLinkedList) = new(mem, NIL)
end

function stack_empty(S::Stack)
    return S.top == 0
end

function push!(S::Stack, x::Int)
    S.top += 1
    S.S[S.top] = x
end

function pop!(S::Stack)
    if stack_empty(S)
        println("error underflow")
        return NIL
    else
        x = S.S[S.top]
        S.top -= 1
        return x
    end
end

function MemoryDoubleLinkedList(n)
    S = Stack(n)
    for x in 1:n
        push!(S, x)
    end
    MemoryDoubleLinkedList(Vector{CartaoCidadao}(undef, n),
                           zeros(Int, n),
                           zeros(Int, n),
                           S,
                           NIL)
end

function list_insert!(l::DoubleLinkedList, key::CartaoCidadao)
    x = allocate_object!(l.mem)
    l.mem.key[x] = key
    l.mem.next[x] = l.head
    if l.head != NIL
        l.mem.prev[l.head] = x
    end
    l.head = x
    l.mem.prev[x] = NIL
end

function list_delete!(l::DoubleLinkedList, x::Int)
    if l.mem.prev[x] != NIL
        l.mem.next[l.mem.prev[x]] = l.mem.next[x]
    else
        l.head = l.mem.next[x]
    end
    if l.mem.next[x] != NIL
        l.mem.prev[l.mem.next[x]] = l.mem.prev[x]
    end
    free_object!(l.mem, x)
end

function list_search(l::DoubleLinkedList, key::CartaoCidadao)
    x = l.head
    while x != NIL && (l.mem.key[x].numero != key.numero || l.mem.key[x].nome != key.nome || l.mem.key[x].naturalidade != key.naturalidade)
        x = l.mem.next[x]
    end
    return x
end

function allocate_object!(mem::MemoryDoubleLinkedList)
    return pop!(mem.free)
end

function free_object!(mem::MemoryDoubleLinkedList, x::Int)
    push!(mem.free, x)
end

function print_list(l::DoubleLinkedList)
    x = l.head
    while x != NIL
        println("CartaoCidadao: ", l.mem.key[x])
        x = l.mem.next[x]
    end
end

function main()
    # Inicialização do gestor de memória e da lista duplamente ligada
    mem = MemoryDoubleLinkedList(5)
    list = DoubleLinkedList(mem)

    # Criação de 5 registros de CartaoCidadao
    cc1 = CartaoCidadao(1, "João Silva", "Portugues")
    cc2 = CartaoCidadao(2, "Maria Oliveira", "Cabo Verdiano")
    cc3 = CartaoCidadao(3, "Carlos Souza", "Brasileiro")
    cc4 = CartaoCidadao(4, "Ana Pereira", "Angolano")
    cc5 = CartaoCidadao(5, "Pedro Santos", "Moçambicano")

    # Inserção de registros na lista
    list_insert!(list, cc1)
    list_insert!(list, cc2)
    list_insert!(list, cc3)
    list_insert!(list, cc4)
    list_insert!(list, cc5)

    # Exibir o estado atual da lista
    println("Após inserção de 5 registros:")
    print_list(list)

    # Pesquisa de um registro
    println("\nPesquisa de Carlos Souza:")
    x = list_search(list, cc3)
    if x != NIL
        println("Encontrado: ", list.mem.key[x])
    else
        println("Não encontrado")
    end

    # Deleção de um registro
    println("\nDeleção de Maria Oliveira:")
    list_delete!(list, list_search(list, cc2))

    # Exibir o estado atual da lista após deleção
    println("\nEstado da lista após deleção de um registro:")
    print_list(list)
end

main()
