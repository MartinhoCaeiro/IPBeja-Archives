
using Random
using Statistics
struct Pessoa
    idade::Int
    nome::String
    salario::Float64
end

function escolha(numero::Int)
    valor_divido_9 = numero % 9
    valor_divido_2 = numero % 2
    return (valor_divido_9, valor_divido_2)
end

function bubblesort!(pessoas::Vector{Pessoa})
    n = length(pessoas)
    for i in 1:n-1
        for j in 1:(n-i)
            if pessoas[j].idade < pessoas[j+1].idade
                pessoas[j], pessoas[j+1] = pessoas[j+1], pessoas[j]
            end
        end
    end
    return pessoas
end

function ordenar_fotos!(pessoas::Vector{Pessoa})
    return bubblesort!(pessoas)
end

function gerar_pessoas_aleatorias(n::Int)
    pessoas = Vector{Pessoa}(undef, n)
    for i in 1:n
        idade = rand(18:80)
        nome = "Pessoa $i"
        salario = rand(2000.0:5000.0)
        pessoas[i] = Pessoa(idade, nome, salario)
    end
    return pessoas
end

# Função para calcular o tempo médio de execução
function tempo_medio_execucao(n::Int, m::Int)
    tempos = Float64[]
    for _ in 1:m
        pessoas = gerar_pessoas_aleatorias(n)
        tempo = @elapsed bubblesort!(pessoas)
        push!(tempos, tempo)
    end
    return mean(tempos)
end
function main()
    numero = 24473
    println(escolha(numero))

    pessoas = [
        Pessoa(30, "Ana", 3000.0),
        Pessoa(22, "Bruno", 2200.0),
        Pessoa(25, "Carla", 2500.0),
        Pessoa(28, "Diego", 2800.0)
    ]

    pessoas_ordenadas = ordenar_fotos!(pessoas)

    for p in pessoas_ordenadas
        println("Nome: ", p.nome, ", Idade: ", p.idade, ", Salário: ", p.salario)
    end
    n = 5000  # Ajustar este valor conforme necessário para obter pelo menos 10 segundos de execução total
    m = 25
    tempo_medio = tempo_medio_execucao(n, m)
    
    println("Tempo médio de execução para $n elementos (em segundos): $tempo_medio")
end

main()
