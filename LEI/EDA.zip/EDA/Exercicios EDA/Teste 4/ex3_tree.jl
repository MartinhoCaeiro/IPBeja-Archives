# Define a estrutura de um nó na árvore
mutable struct Node
    key::Int
    left::Union{Node, Nothing}
    right::Union{Node, Nothing}
    p::Union{Node, Nothing}
end

# Construtor para criar um novo nó apenas com a chave
function Node(key::Int)
    Node(key, nothing, nothing, nothing)
end

# Define a estrutura da árvore em si
mutable struct Tree
    root::Union{Node, Nothing}
end

# Construtor para criar uma nova árvore vazia
function Tree()
    Tree(nothing)
end

# Função para inserir um novo nó na árvore
function tree_insert!(T, z)
    y = nothing
    x = T.root

    while x !== nothing
        y = x

        if z.key < x.key
            x = x.left
        else
            x = x.right
        end
    end

    z.p = y

    if y === nothing
        T.root = z
    elseif z.key < y.key 
        y.left = z
    else
        y.right = z
    end
end

# Função auxiliar para imprimir a árvore de forma estruturada
function print_tree(node, prefix = "", is_left = true)
    if node !== nothing
        if node.right !== nothing
            print_tree(node.right, "$prefix$(is_left ? "│   " : "    ")", false)
        end
        
        println("$prefix$(is_left ? "└── " : "┌── ")$(node.key)")
        
        if node.left !== nothing
            print_tree(node.left, "$prefix$(is_left ? "    " : "│   ")", true)
        end
    end
end


# Função principal para testar as operações e imprimir a árvore
function insert_elements!(T, elements)
    for element in elements
        tree_insert!(T, Node(element))
    end
end

# Função principal para criar a árvore e inserir os elementos
function main()
    A = [4, 14, 5, 9, 7, 6, 8, 11, 12, 9, 17]
    T = Tree()
    insert_elements!(T, A)

    # Imprimir a árvore de forma estruturada
    println("Estrutura da Árvore:")
    print_tree(T.root)
end

# Chamada da função principal
main()
