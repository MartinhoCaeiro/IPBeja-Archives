# Function mina
function mina(s::String)
    N = 5
    soma = sum([Int(c) for c in s]) % N
    
    if soma == 0
        a = "insertion"
    elseif soma == 1
        a = "merge"
    elseif soma == 2
        a = "bubble"
    elseif soma == 3
        a = "heap"
    else
        a = "quick"
    end
    
    try
        meia = sum([Int(s[k]) + 2 for k in 1:Int(floor(length(s) / 2))]) % N
    catch e
        println("escreva o seu nome completo")
        println("SEM USAR ACENTOS NEM CEDILHAS")
        return
    end
    
    meia = sum([Int(s[k]) + 1 for k in 1:Int(floor(length(s) / 2))]) % N
    meia = (meia != soma) ? meia : ((meia + 1 > N) ? 0 : meia)
    
    if meia == 0
        b = "insertion"
    elseif meia == 1
        b = "bubble"
    elseif meia == 2
        b = "merge"
    elseif meia == 3
        b = "heap"
    else
        b = "quick"
    end
    
    return a, b
end

# Bubble sort implementation
function bubblesort!(A::Array{T}) where T
    for i = 1:length(A) - 1 
        for j = length(A):-1:i + 1
            if A[j] < A[j - 1]
                A[j], A[j - 1] = A[j - 1], A[j]
            end
        end
    end
    return A
end

# Function to generate random numbers
function generate_random_numbers(n::Int)
    return rand(1:100, n)
end

# Function Calculo
function Calculo(x::Float64, y::Float64)
    resultado = abs(x + y) + abs(sqrt(x + y^2))
    return resultado
end

# Measure sorting time
function measure_sorting_time()
    numbers = generate_random_numbers(1000)
    return @elapsed bubblesort!(numbers)
end

# Function to calculate median execution time
function median_execution_time(sort_function, n::Int, m::Int)
    times = [measure_sorting_time() for _ in 1:m]
    return median(times)
end

# Main function to run tests
function main()
    Nome_Completo = "RafaelNarciso"
    a, b = mina(Nome_Completo)
    println("Sorting methods: $a, $b")
    
    x = 8.0
    y = 4.0
    resultado = Calculo(x, y)
    println("Calculo result: $resultado")
    
    println("\nMeasuring execution time for Bubble Sort with 1000 elements:")
    time_bubble = measure_sorting_time()
    println("Execution time for Bubble Sort: $time_bubble seconds")

    println("\nCalculating the median of execution times for Bubble Sort...")
    n = 1000  # Adjust this value to ensure the execution time is significant
    m = 20
    med_time_bubble = median_execution_time(bubblesort!, n, m)
    println("Median execution time for Bubble Sort: $med_time_bubble seconds")
end

main()
