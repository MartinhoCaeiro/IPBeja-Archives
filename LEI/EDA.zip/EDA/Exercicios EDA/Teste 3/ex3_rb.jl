mutable struct Node
    key::String
    color::Bool  # true for red, false for black
    left::Union{Node, Nothing}
    right::Union{Node, Nothing}
    parent::Union{Node, Nothing}
end

mutable struct RedBlackTree
    root::Union{Node, Nothing}
end

const RED = true
const BLACK = false

function left_rotate(tree::RedBlackTree, x::Node)
    y = x.right
    x.right = y.left
    if y.left != nothing
        y.left.parent = x
    end
    y.parent = x.parent
    if x.parent == nothing
        tree.root = y
    elseif x == x.parent.left
        x.parent.left = y
    else
        x.parent.right = y
    end
    y.left = x
    x.parent = y
end

function right_rotate(tree::RedBlackTree, y::Node)
    x = y.left
    y.left = x.right
    if x.right != nothing
        x.right.parent = y
    end
    x.parent = y.parent
    if y.parent == nothing
        tree.root = x
    elseif y == y.parent.right
        y.parent.right = x
    else
        y.parent.left = x
    end
    x.right = y
    y.parent = x
end

function rb_insert(tree::RedBlackTree, key::String)
    new_node = Node(key, RED, nothing, nothing, nothing)
    y = nothing
    x = tree.root

    while x != nothing
        y = x
        if new_node.key < x.key
            x = x.left
        else
            x = x.right
        end
    end

    new_node.parent = y
    if y == nothing
        tree.root = new_node
    elseif new_node.key < y.key
        y.left = new_node
    else
        y.right = new_node
    end

    rb_insert_fixup(tree, new_node)
end

function rb_insert_fixup(tree::RedBlackTree, z::Node)
    while z.parent != nothing && z.parent.color == RED
        if z.parent == z.parent.parent.left
            y = z.parent.parent.right
            if y != nothing && y.color == RED
                z.parent.color = BLACK
                y.color = BLACK
                z.parent.parent.color = RED
                z = z.parent.parent
            else
                if z == z.parent.right
                    z = z.parent
                    left_rotate(tree, z)
                end
                z.parent.color = BLACK
                z.parent.parent.color = RED
                right_rotate(tree, z.parent.parent)
            end
        else
            y = z.parent.parent.left
            if y != nothing && y.color == RED
                z.parent.color = BLACK
                y.color = BLACK
                z.parent.parent.color = RED
                z = z.parent.parent
            else
                if z == z.parent.left
                    z = z.parent
                    right_rotate(tree, z)
                end
                z.parent.color = BLACK
                z.parent.parent.color = RED
                left_rotate(tree, z.parent.parent)
            end
        end
    end
    tree.root.color = BLACK
end

function rb_search(tree::RedBlackTree, key::String)
    node = tree.root
    while node != nothing && key != node.key
        if key < node.key
            node = node.left
        else
            node = node.right
        end
    end
    return node
end

function rb_transplant(tree::RedBlackTree, u::Node, v::Union{Node, Nothing})
    if u.parent == nothing
        tree.root = v
    elseif u == u.parent.left
        u.parent.left = v
    else
        u.parent.right = v
    end
    if v != nothing
        v.parent = u.parent
    end
end

function tree_minimum(node::Node)
    while node.left != nothing
        node = node.left
    end
    return node
end

function rb_delete(tree::RedBlackTree, z::Node)
    y = z
    y_original_color = y.color
    x = nothing
    if z.left == nothing
        x = z.right
        rb_transplant(tree, z, z.right)
    elseif z.right == nothing
        x = z.left
        rb_transplant(tree, z, z.left)
    else
        y = tree_minimum(z.right)
        y_original_color = y.color
        x = y.right
        if y.parent == z
            if x != nothing
                x.parent = y
            end
        else
            rb_transplant(tree, y, y.right)
            y.right = z.right
            y.right.parent = y
        end
        rb_transplant(tree, z, y)
        y.left = z.left
        y.left.parent = y
        y.color = z.color
    end
    if y_original_color == BLACK
        rb_delete_fixup(tree, x)
    end
end

function rb_delete_fixup(tree::RedBlackTree, x::Union{Node, Nothing})
    while x != tree.root && (x == nothing || x.color == BLACK)
        if x == x.parent.left
            w = x.parent.right
            if w.color == RED
                w.color = BLACK
                x.parent.color = RED
                left_rotate(tree, x.parent)
                w = x.parent.right
            end
            if (w.left == nothing || w.left.color == BLACK) && (w.right == nothing || w.right.color == BLACK)
                w.color = RED
                x = x.parent
            else
                if w.right == nothing || w.right.color == BLACK
                    w.left.color = BLACK
                    w.color = RED
                    right_rotate(tree, w)
                    w = x.parent.right
                end
                w.color = x.parent.color
                x.parent.color = BLACK
                if w.right != nothing
                    w.right.color = BLACK
                end
                left_rotate(tree, x.parent)
                x = tree.root
            end
        else
            w = x.parent.left
            if w.color == RED
                w.color = BLACK
                x.parent.color = RED
                right_rotate(tree, x.parent)
                w = x.parent.left
            end
            if (w.right == nothing || w.right.color == BLACK) && (w.left == nothing || w.left.color == BLACK)
                w.color = RED
                x = x.parent
            else
                if w.left == nothing || w.left.color == BLACK
                    w.right.color = BLACK
                    w.color = RED
                    left_rotate(tree, w)
                    w = x.parent.left
                end
                w.color = x.parent.color
                x.parent.color = BLACK
                if w.left != nothing
                    w.left.color = BLACK
                end
                right_rotate(tree, x.parent)
                x = tree.root
            end
        end
    end
    if x != nothing
        x.color = BLACK
    end
end

function print_tree(node::Union{Node, Nothing}, indent::String = "", last::Bool = true)
    if node != nothing
        print(indent)
        if last
            print("R----")
            indent *= "   "
        else
            print("L----")
            indent *= "|  "
        end
        color = node.color == RED ? "RED" : "BLACK"
        println("($(node.key), $color)")
        print_tree(node.left, indent, false)
        print_tree(node.right, indent, true)
    end
end

function test_rb_tree()
    tree = RedBlackTree(nothing)
    
    names = ["Joseph Vissarionovich Stalin", "Adolf Hitler", "Benito Amilcare Andre Mussolini",
             "Francisco Franco Bahamonde", "Pierre Jean Marie Laval", "Engelbert Dolfuss",
             "Mobutu Sese Seko", "Mao Zedong", "Muammar al-Gaddafi", "Nicolae Ceaucescu",
             "Enver Halil Hoxha"]
    
    for name in names
        rb_insert(tree, name)
    end

    println("Árvore após inserções:")
    print_tree(tree.root)

    node_to_remove = rb_search(tree, "Engelbert Dolfuss")
    if node_to_remove != nothing
        rb_delete(tree, node_to_remove)
    end

    println("\nÁrvore após remoção de Engelbert Dolfuss:")
    print_tree(tree.root)
end

test_rb_tree()