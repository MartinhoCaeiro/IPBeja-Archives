using Printf

@enum NodeColor begin
    red
    black
end

mutable struct RBNode
    key::Int
    p::Int
    left::Int
    right::Int
    color::NodeColor
end

function initrbtree(n)
    rbtree = Array{RBNode}(undef, n)
    nil = 1
    for i = 1:n
        node = RBNode(0, nil, nil, nil, black)
        rbtree[i] = node
    end
    rbtree
end

function placenoderb(rbtree, index, key, p, left, right, color)
    rbtree[index] = RBNode(key, p, left, right, color)
end

function printrbtree(rbtree)
    @printf("node, key, parent, left, right, color\n")
    for i = 1:length(rbtree)
        key = rbtree[i].key
        p = rbtree[i].p
        left = rbtree[i].left
        right = rbtree[i].right
        color = rbtree[i].color
        @printf("%4d | %2d | %5d | %4d | %3d | %s\n",
                i, key, p, left, right, color)
    end
end

function left_rotate!(T, x)
    y = T[x].right
    T[x].right = T[y].left
    if T[y].left !== nothing
        T[T[y].left].p = x
    end
    T[y].p = T[x].p
    if T[x].p === nothing
        T.root = y
    else
        if x == T[T[x].p].left
            T[T[x].p].left = y
        else
            T[T[x].p].right = y
        end
    end
    T[y].left = x
    T[x].p = y
end

function main()
    # Step 1: Generate a list of 20 random natural numbers
    A = [26, 23, 20, 44, 77, 55]
    # Step 2: Initialize the red-black tree
    n = 6
    rbtree = initrbtree(n)
    
    # Step 3: Insert the numbers into the tree (simplified, not actual RB tree insertions)
    for i in 1:n
        key = A[i]
        p = i == 1 ? 1 : div(i, 2)
        left = 2*i <= n ? 2*i : 1
        right = 2*i+1 <= n ? 2*i+1 : 1
        color = i % 2 == 0 ? red : black  # Alternate colors for simplicity
        placenoderb(rbtree, i, key, p, left, right, color)
    end
    
    println("Before left rotation:")
    printrbtree(rbtree)
    
    left_rotate!(rbtree, 1)
    
    println("After left rotation:")
    printrbtree(rbtree)
end

main()
