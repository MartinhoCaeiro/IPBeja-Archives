# Função de hash base usando o método da multiplicação
function hash_multiplication(k, m)
    A = (sqrt(5) - 1) / 2
    h = m * (k * A % 1)
    return round(Int, h)  # Arredondando para o inteiro mais próximo
end

# Função de hash do teste quadrático
function hash_quadratic(k, m, i)
    h0 = hash_multiplication(k, m)
    c1 = 0.5
    c2 = 0.5
    h = (h0 + c1*i + c2*i^2) % m
    return h
end

# Função principal para testar a função de hash do teste quadrático
function main()
    # Chaves e tamanho da tabela de hash
    keys = [1234, 5678, 1000, 9000, 5500]
    m = 11  # Tamanho da tabela de hash

    # Teste da função de hash do teste quadrático
    println("Exemplos de hashes usando teste quadrático:")
    for key in keys
        for i in 0:m-1
            hash = hash_quadratic(key, m, i)
            println("Hash de $key com i=$i: $hash")
        end
        println()
    end
end

# Chamada da função principal
main()
