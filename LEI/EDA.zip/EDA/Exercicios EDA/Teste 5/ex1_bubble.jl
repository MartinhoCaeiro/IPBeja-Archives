
using Random
using Statistics



struct Pintura
    idadeemdias::Int
    designacao::String
    autor::String
    preco::Float64
end



function mammamia(nomecompleto::String)
    s = 0
    for char in nomecompleto
        valor = Int(char)
        if valor % 2 == 0
            s += valor * 3
        else
            s += valor * 2
        end
    end
    return s % 5
end
function bubblesort!(Pintura::Vector{Pintura})
    n = length(Pintura)
    for i in 1:n-1
        for j in n:-1:i+1
            if !occursin('a',Pintura[j].autor) && !occursin('a', Pintura[j-1].autor)
                if length(Pintura[j].autor) < length(Pintura[j-1].autor)
                    Pintura[j], Pintura[j-1] = Pintura[j-1], Pintura[j]
                end
            end
        end
    end

    return Pintura
end

function ordenar_Pinturas!(Pintura::Vector{Pintura})
    return bubblesort!(Pintura)
end
function gerar_Pinturas_aleatorias(n::Int)
    pessoas = Vector{Pintura}(undef, n)
    for i in 1:n
        idade = rand(18:80)
        Titulo = "Titulo $i"
        nome = "Nome $i"
        preco = rand(2000.0:5000.0)
        pessoas[i] = Pintura(idade,Titulo, nome, preco)
    end
    return pessoas
end

# Função para calcular o tempo médio de execução
function tempo_medio_execucao(n::Int, m::Int)
    tempos = Float64[]
    for _ in 1:m
        Pinturas = gerar_Pinturas_aleatorias(n)
        tempo = @elapsed bubblesort!(Pinturas)
        push!(tempos, tempo)
    end
    return mean(tempos)
end

function main()
    nomecompleto = "RafaelConceicaoNarciso"
   resultado = mammamia(nomecompleto)
    print(resultado)
    Pinturas = [
        Pintura(24,"Titulo1", "Rafael", 2020),
        Pintura(25,"Titulo2", "Ana", 2021),
        Pintura(26,"Titulo3", "Carlos", 2019),
        Pintura(27,"Titulo4", "Beto", 2018),
        Pintura(28,"Titulo5", "Joana", 2017),
        Pintura(29,"Titulo6", "Joaquin", 2022),
        Pintura(30,"Titulo7", "Jasnau", 2016),
        Pintura(40,"Titulo8", "Iris", 2015),
        Pintura(45,"Titulo9", "Hitler", 2014),
        Pintura(99,"Titulo10", "Salazar", 2013)
    ]
    Pinturas_ordenadas = ordenar_Pinturas!(Pinturas)

    println("Pintura ordenadas:")
    for Pintura in Pinturas_ordenadas
        if !occursin('e', Pintura.autor)
            println("IdadeMedia: ", Pintura.idadeemdias, ", Título: ", Pintura.designacao, ", Autor: ", Pintura.autor,"PRECO: ",Pintura.preco)
        end
    end
    n = 5000  # Ajustar este valor conforme necessário para obter pelo menos 10 segundos de execução total
    m = 30
    tempo_medio = tempo_medio_execucao(n, m)
    
    println("Tempo médio de execução para $n elementos (em segundos): $tempo_medio")
end

main()