using Random
using Statistics

# Definindo a estrutura Mapa3D
mutable struct Mapa3D
    x::Float64
    y::Float64
    z::Float64
end

# Função para gerar uma lista de Mapa3D aleatórios
function generate_random_mapa3D(n::Int)
    return [Mapa3D(rand(), rand(), rand()) for _ in 1:n]
end

# Função para calcular a norma de Mapa3D
function norma_vetor(m::Mapa3D)
    return sqrt(m.x^2 + m.y^2 + m.z^2)
end

# Função de comparação entre dois objetos Mapa3D para Heap Sort
import Base: >
function >(a::Mapa3D, b::Mapa3D)
    return norma_vetor(a) > norma_vetor(b)
end

# Funções auxiliares para Heap Sort
function left(i)
    return 2 * i
end

function right(i)
    return 2 * i + 1
end

function maxheapify!(mapas::Vector{Mapa3D}, i, heapSize)
    l = left(i)
    r = right(i)
    largest = i

    if l <= heapSize && mapas[l] > mapas[i]
        largest = l
    end

    if r <= heapSize && mapas[r] > mapas[largest]
        largest = r
    end

    if largest != i
        mapas[i], mapas[largest] = mapas[largest], mapas[i]
        maxheapify!(mapas, largest, heapSize)
    end
end

function buildmaxheap!(mapas::Vector{Mapa3D})
    heapSize = length(mapas)
    for i in div(length(mapas), 2):-1:1
        maxheapify!(mapas, i, heapSize)
    end
    return heapSize
end

function heapsort!(mapas::Vector{Mapa3D})
    heapSize = buildmaxheap!(mapas)
    for i in length(mapas):-1:2
        mapas[1], mapas[i] = mapas[i], mapas[1]
        heapSize -= 1
        maxheapify!(mapas, 1, heapSize)
    end
    return mapas
end

# Função Bubble Sort para Mapa3D
function bubblesort!(mapas::Vector{Mapa3D})
    n = length(mapas)
    for i in 1:n-1
        for j in 1:n-i
            if norma_vetor(mapas[j]) > norma_vetor(mapas[j+1])
                mapas[j], mapas[j+1] = mapas[j+1], mapas[j]
            end
        end
    end
    return mapas
end

# Função para medir o tempo de execução de cada algoritmo
function measure_sort_time(sort_function, n::Int)
    mapas = generate_random_mapa3D(n)
    start_time = time()
    sort_function(mapas)
    end_time = time()
    return end_time - start_time
end

# Função para calcular a mediana dos tempos de execução
function median_execution_time(sort_function, n::Int, m::Int)
    times = [measure_sort_time(sort_function, n) for _ in 1:m]
    return median(times)
end

# Função principal para demonstrar o funcionamento
function main()
    n = 10000  # Ajuste este valor para que o tempo de execução seja pelo menos 1 segundo
    m = 30

    println("Calculando a mediana dos tempos de execução para $n elementos com $m amostras...")

    println("\nMedindo tempo de execução para Bubble Sort...")
    med_time_bubble = median_execution_time(bubblesort!, n, m)
    println("Mediana dos tempos de execução para Bubble Sort: $med_time_bubble segundos")

    println("\nMedindo tempo de execução para Heap Sort...")
    med_time_heap = median_execution_time(heapsort!, n, m)
    println("Mediana dos tempos de execução para Heap Sort: $med_time_heap segundos")
end

main()
