mutable struct Queue
    Q::Vector{Float64}
    head::Int
    tail::Int
    length::Int
    Queue() = new(Vector{Float64}(undef, 10), 1, 1, 0)
end

function enQueue(Q::Queue, x::Float64)
    Q.Q[Q.tail] = x
    Q.length += 1
    if Q.tail == length(Q.Q)
        Q.tail = 1
    else
        Q.tail += 1
    end
end

function deQueue(Q::Queue)::Float64
    x = Q.Q[Q.head]
    Q.length -= 1
    if Q.head == length(Q.Q)
        Q.head = 1
    else
        Q.head += 1
    end
    return x
end

function isEmpty(Q::Queue)::Bool
    return Q.head == Q.tail
end

# Criando uma fila de números de ponto flutuante
fila_numeros = Queue()

# Adicionando números à fila
enQueue(fila_numeros, 54.4)
enQueue(fila_numeros, 57.9)

enQueue(fila_numeros, 23.5)
enQueue(fila_numeros, deQueue(fila_numeros))
# Removendo o segundo elemento inserido
println("Removendo o segundo elemento inserido...")

# Removendo um elemento da fila (o segundo elemento inserido)  # Removendo o primeiro elemento inserido

numero_removido = deQueue(fila_numeros)  # Removendo o segundo elemento inserido
enQueue(fila_numeros,55.5)
# Imprimindo o número removido
println("Número removido: ", numero_removido)
println()

# Imprimindo o conteúdo da fila após a remoção
println("Conteúdo da fila após a remoção:")
for i in fila_numeros.head:fila_numeros.tail
    println(fila_numeros.Q[i])
end