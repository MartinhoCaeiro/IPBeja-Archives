mutable struct Mapa
    x::Float64
    y::Float64
    
end


function a_sua_sina( s::String )
    N = 5
    soma = sum( [ Int( c ) for c in s ] ) % N
            if soma == 0
            a = "insertion"
            elseif soma == 1
            a = "bubble"
             elseif soma == 2
            a = "merge"
            elseif soma == 3
            a = "heap"
              else
            a = "quick"
     end
    try
    meia = sum( [ Int( s[ k ] ) + 1
    for k = 1:Int(floor(length( s ) / 2)) ] ) % N
    catch e
    println( "escreva o seu nome completo" )
    println( "SEM USAR ACENTOS NEM CEDILHAS" )
    return
    end
    meia = sum( [ Int( s[ k ] ) + 1
    for k = 1:Int(floor(length( s ) / 2)) ] ) % N
    meia = (meia != soma) ? meia : (( meia + 1 > N) ? 0 : meia)
        if meia == 0
        b  = "insertion"
        elseif meia == 1
        b = "bubble"
        elseif meia == 2
        b = "merge"
        elseif meia == 3
        b = "heap"
        else
        b = "quick"
        end
        a, b
end
function modulo_vetor(p::Mapa)
    return sqrt(p.x^2 + p.y^2)
end

# Exemplo de uso


function main()
    nome = "martinhojosenovocaeiro"
   print(a_sua_sina(nome))

    p = Mapa(3.0, 4.0)
println("O módulo do vetor distância do ponto à origem é: ", modulo_vetor(p))
end
main()