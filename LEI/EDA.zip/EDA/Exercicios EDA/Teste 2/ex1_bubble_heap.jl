mutable struct Mapa
    x::Float64
    y::Float64
    z::Float64
end
function bubblesort!(Mapas::Vector{Mapa})
    n = length(Mapas)
    for i in 1:n-1
        for j in n:-1:i+1
            Mapas[j], Mapas[j-1] = Mapas[j-1], Mapas[j]
        end
    end
    return Mapas
end

function ordenar_Mapas!(Mapas::Vector{Mapa})
    return bubblesort!(Mapas)
end

function norma_vetor(p::Mapa)
    return sqrt(p.x^2 + p.y^2 + p.z^2)
end
# Função para calcular a norma do vetor
function norma_vetor(p::Mapa)
    return sqrt(p.x^2 + p.y^2 + p.z^2)
end

import Base: >
# Função de comparação entre dois objetos Mapa
function >(a::Mapa, b::Mapa)
    return norma_vetor(a) > norma_vetor(b)
end

function left(i)
    return 2 * i
end

function right(i)
    return 2 * i + 1
end

function maxheapify!(Mapas::Vector{Mapa}, i, heapSize)
    l = left(i)
    r = right(i)
    largest = i

    if l <= heapSize && Mapas[l] > Mapas[i]
        largest = l
    end

    if r <= heapSize && Mapas[r] > Mapas[largest]
        largest = r
    end

    if largest != i
        temp = Mapas[i]
        Mapas[i] = Mapas[largest]
        Mapas[largest] = temp
        maxheapify!(Mapas, largest, heapSize)
    end
end

function buildmaxheap!(Mapas::Vector{Mapa})
    heapSize = length(Mapas)
    for i in div(length(Mapas), 2):-1:1
        maxheapify!(Mapas, i, heapSize)
    end
    return heapSize
end

function heapsort!(Mapas::Vector{Mapa})
    heapSize = buildmaxheap!(Mapas)
    for i in length(Mapas):-1:2
        temp = Mapas[1]
        Mapas[1] = Mapas[i]
        Mapas[i] = temp
        heapSize -= 1
        maxheapify!(Mapas, 1, heapSize)
    end
    return Mapas
end

function ordenar_Mapas2!(Mapas::Vector{Mapa})
    return heapsort!(Mapas)
end

function main()
    pontos = [
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand()),
        Mapa(rand(), rand(), rand())
    ]

    println("Pontos antes da ordenação Heap:")
    for p in pontos
        println("Ponto (", p.x, ", ", p.y, ", ", p.z, ") com norma ", norma_vetor(p))
    end

    pontos_ordenados_heap = ordenar_Mapas2!(pontos)

    println("\nPontos após a ordenação Heap:")
    for p in pontos_ordenados_heap
        println("Ponto (", p.x, ", ", p.y, ", ", p.z, ") com norma ", norma_vetor(p))
    end


    pontos_ordenados_bubble = ordenar_Mapas!(pontos)

    println("\nPontos após a ordenação Bubble:")
    for p in pontos_ordenados_bubble
        println("Ponto (", p.x, ", ", p.y, ", ", p.z, ") com norma ", norma_vetor(p))
    end
end

main()