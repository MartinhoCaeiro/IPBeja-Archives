using Random

@enum NodeColor begin
    red
    black
end
mutable struct Nomes
    key::Int
    nome::String
    end

mutable struct RBNode
    key::Int64
    p::Int64
    left::Int64
    right::Int64
    color::NodeColor
end

function initrbtree(n)
    rbtree = Array{RBNode}(undef, n)
    nil = 1
    for i = 1:n
        node = RBNode(0, nil, nil, nil, black)
        rbtree[i] = node
    end
    rbtree
end

function placenoderb(rbtree, index, key, p, left, right, color)
    rbtree[index] = RBNode(key, p, left, right, color)
end

function printrbtree(rbtree)
    println("node, key, parent, left, right, color")
    for i in firstindex(rbtree):lastindex(rbtree)
        key = rbtree[i].key
        p = rbtree[i].p
        left = rbtree[i].left
        right = rbtree[i].right
        color = rbtree[i].color
        println("$i | $key | $p | $left | $right | $color")
    end
end



function main()
    # Step 1: Generate a list of 20 random natural numbers
    random_numbers = [45, 32, 29, 28, 47, 56, 4, 5, 8, 9, 11, 12, 55, 56, 48, 33, 77] 
    println("Random numbers: ", random_numbers)
    
    # Step 2: Initialize the red-black tree
    n = 17
    rbtree = initrbtree(n)
    
    # Step 3: Insert the numbers into the tree (simplified, not actual RB tree insertions)
    for i in 1:n
        key = random_numbers[i]
        p = i == 1 ? 1 : div(i, 2)
        left = 2*i <= n ? 2*i : 1
        right = 2*i+1 <= n ? 2*i+1 : 1
        color = i % 2 == 0 ? red : black  # Alternate colors for simplicity
        placenoderb(rbtree, i, key, p, left, right, color)
    end
    
  
    printrbtree(rbtree)
    


end

main()
