using Random

@enum NodeColor begin
    red
    black
end
mutable struct Nomes
    key::Int
    nome::String
    end

mutable struct RBNode
    nome:Nomes
    key::Int64
    p::Int64

    left::Int64
    right::Int64
    color::NodeColor
end

function initrbtree(n)
    rbtree = Array{RBNode}(undef, n)
    nil = 1
    for i = 1:n
        node = RBNode(0, nil, nil, nil, black)
        rbtree[i] = node
    end
    rbtree
end

function placenoderb(rbtree, index, key, p, left, right, color)
    rbtree[index] = RBNode(key, p, left, right, color)
end

function printrbtree(rbtree)
    println("node, key, parent, left, right, color")
    for i in firstindex(rbtree):lastindex(rbtree)
        key = rbtree[i].key
        p = rbtree[i].p
        left = rbtree[i].left
        right = rbtree[i].right
        color = rbtree[i].color
        println("$i | $key | $p | $left | $right | $color")
    end
end
function RB_delete_fixup(T, x)
    while x != T.root && T.mem.color[x] == BLACK
      if x == T.mem.left[T.mem.p[x]]
        w = T.mem.right[T.mem.p[x]]
        if T.mem.color[w] == RED
          T.mem.color[w] = BLACK
          T.mem.color[T.mem.p[w]] = RED
          left_rotate!(T, T.mem.p[x])
          w = T.mem.right[T.mem.p[x]]
        end
        if T.mem.color[T.mem.left[w]] == BLACK && T.mem.color[T.mem.right[w]] == BLACK
          T.mem.color[w] = RED
          x = T.mem.p[x]
        else
          if T.mem.color[T.mem.right[w]] == BLACK
            T.mem.color[T.mem.left[w]] = BLACK
            T.mem.color[w] = RED
            right_rotate!(T, w)
            w = T.mem.right[T.mem.p[x]]
          end
          T.mem.color[w] = T.mem.color[T.mem.p[x]]
          T.mem.color[T.mem.p[x]] = BLACK
          T.mem.color[T.mem.right[w]] = BLACK
          left_rotate!(T, T.mem.p[x])
          x = T.root
        end
      else
        w = T.mem.left[T.mem.p[x]]
        if T.mem.color[w] == RED
          T.mem.color[w] = BLACK
          T.mem.color[T.mem.p[w]] = RED
          right_rotate!(T, T.mem.p[x])
          w = T.mem.left[T.mem.p[x]]
        end
        if T.mem.color[T.mem.right[w]] == BLACK && T.mem.color[T.mem.left[w]] == BLACK
          T.mem.color[w] = RED
          x = T.mem.p[x]
        else
          if T.mem.color[T.mem.left[w]] == BLACK
            T.mem.color[T.mem.right[w]] = BLACK
            T.mem.color[w] = RED
            left_rotate!(T, w)
            w = T.mem.left[T.mem.p[x]]
          end
          T.mem.color[w] = T.mem.color[T.mem.p[x]]
          T.mem.color[T.mem.p[x]] = BLACK
          T.mem.color[T.mem.left[w]] = BLACK
          right_rotate!(T, T.mem.p[x])
          x = T.root
        end
      end
    end
    T.mem.color[x] = BLACK
  end
  
  """
      RB_delete( T, z )
  remoção do nó z
  """
  function RB_delete(T, z::Vector{Nomes})
    y = z
    y_original_color = T.mem.color[y]
    if T.mem.left[z] == NIL
      x = T.mem.right[z]
      RB_transplant!(T, z, T.mem.right[z])
    else
      if T.mem.right[z] == NIL
        x = T.mem.left[z]
        RB_transplant!(T, z, T.mem.left[z])
      else
        y = tree_minimum(T, T.mem.right[z])
        y_original_color = T.mem.color[y]
        x = T.mem.right[y]
        if T.mem.p[y] == z
          T.mem.p[x] = y
        else
          RB_transplant!(T, y, T.mem.right[y])
          T.mem.right[y] = T.mem.right[z]
          T.mem.p[T.mem.right[y]] = y
        end
        RB_transplant!(T, z, y)
        T.mem.left[y] = T.mem.left[z]
        T.mem.p[T.mem.left[y]] = y
        T.mem.color[y] = T.mem.color[z]
      end
    end
    if y_original_color == BLACK
      RB_delete_fixup(T, x)
    end
    free_object!(T.mem, z)
  end

function Nomes( nome::String )
    key = sum( [ Int( c ) for c in nome ] )
    Nomes( key, nome )
    
 end
    

function main()
    # Step 1: Generate a list of 20 random natural numbers
    Nome_Professores = ["Luis Miguel Gomes Tavares",
    "Isabel Sofia Sousa Brito",
    " Elsa Soares Rodrigues",
    " Joao Carlos Martins",
    "Luis Filipe Garcia",
    "Armando Jose Ventura",
    "Jose Jasnau Caeiro",
    "Joao Paulo Barros",
    "MACACO DE MERDA",
    "Rui Miguel Silva",
    "Maria Teresa Godinho"] 

    Nomes(Nome_Professores)


    println("Random numbers: ", random_numbers)
    
    # Step 2: Initialize the red-black tree
    n = 17
    rbtree = initrbtree(n)
    
    # Step 3: Insert the numbers into the tree (simplified, not actual RB tree insertions)
    for i in 1:n
        key = random_numbers[i]
        p = i == 1 ? 1 : div(i, 2)
        left = 2*i <= n ? 2*i : 1
        right = 2*i+1 <= n ? 2*i+1 : 1
        color = i % 2 == 0 ? red : black  # Alternate colors for simplicity
        placenoderb(rbtree, i, key, p, left, right, color)
    end
    
  
    printrbtree(rbtree)
    


end

main()
