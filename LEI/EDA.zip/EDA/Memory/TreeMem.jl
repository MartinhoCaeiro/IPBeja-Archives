"""
EDA 2024
TreeMem.jl
Martinho Caeiro
02/04/2024

Gestão de Memoria para árvores n-árias
"""

# Verifica se o tipo TreeNode já foi definido anteriormente
if !(@isdefined TreeNode)
    # Define o tipo TreeNode como uma estrutura mutável que armazena um valor e um vetor de nós filhos
    mutable struct TreeNode{T}
        value::T   # Valor armazenado no nó
        children::Vector{TreeNode{T}}   # Vetor de nós filhos
    end
end

# Função para criar um novo nó TreeNode com um valor inicial e sem filhos
function TreeNode(value::T) where T
    TreeNode(value, TreeNode{T}[])   # Inicializa um nó com o valor fornecido e um vetor vazio de filhos
end

# Função para adicionar um nó filho a um nó pai
function add_child!(parent::TreeNode, child::TreeNode)
    push!(parent.children, child)   # Adiciona o nó filho ao vetor de filhos do nó pai
end

# Função para imprimir a árvore a partir de um nó raiz, com indentação para representar a estrutura da árvore
function print_tree(node::TreeNode, level::Int = 0)
    println("\t"^level, node.value)   # Imprime o valor do nó com indentação baseada no nível da árvore
    for child in node.children   # Percorre os nós filhos do nó atual
        print_tree(child, level + 1)   # Chama recursivamente a função para imprimir a subárvore enraizada no nó filho
    end
end

# Função principal
function main()
    # Criação da árvore n-ária
    root = TreeNode("A")
    b = TreeNode("B")
    c = TreeNode("C")
    d = TreeNode("D")
    e = TreeNode("E")
    f = TreeNode("F")

    add_child!(root, b)   # Adiciona B como filho de A
    add_child!(root, c)   # Adiciona C como filho de A
    add_child!(b, d)      # Adiciona D como filho de B
    add_child!(b, e)      # Adiciona E como filho de B
    add_child!(c, f)      # Adiciona F como filho de C

    println("Árvore n-ária:")   # Imprime a mensagem indicando a impressão da árvore
    print_tree(root)   # Imprime a árvore a partir do nó raiz
end

main()   # Chama a função principal
