"""
EDA 2024
MemMan.jl
Martinho Caeiro
02/04/2024

Gestão de Memoria para múltiplas listas ligadas
"""

module MemoryManagement
    # Definição de um nó de lista ligada parametrizado por tipo T
    mutable struct ListNode{T}
        value::T                # Valor armazenado no nó
        next::Union{ListNode{T}, Nothing}   # Referência para o próximo nó na lista
    end

    # Definição de uma lista ligada parametrizada por tipo T
    mutable struct LinkedList{T}
        head::Union{ListNode{T}, Nothing}   # Referência para a cabeça da lista
    end

    # Função para alocar um novo objeto na lista
    function allocate_obj(list::LinkedList{T}, value::T) where T
        # Verifica se há espaço disponível na lista
        if list.head === nothing
            println("Sem Espaço")   # Exibe uma mensagem de erro se a lista estiver cheia
            return nothing
        else
            x = list.head   # Obtém a referência para o primeiro nó livre
            list.head = x.next   # Atualiza a cabeça da lista para apontar para o próximo nó livre
            x.value = value   # Define o valor do nó
        end
        return x
    end

    # Função para liberar um objeto da lista
    function free_obj(list::LinkedList{T}, x::Union{ListNode{T}, Nothing}) where T
        # Verifica se o nó a ser liberado não é nulo
        if x !== nothing
            new_node = ListNode{T}(x.value, list.head)   # Cria um novo nó com o valor do nó liberado
            list.head = new_node   # Define o novo nó como a cabeça da lista
        end
    end

    # Função para inserir um novo elemento no início da lista
    function insert_first(list::LinkedList{T}, value::T) where T
        new_node = ListNode{T}(value, list.head)   # Cria um novo nó com o valor fornecido
        list.head = new_node   # Define o novo nó como a cabeça da lista
    end

    # Função para inserir um novo elemento no final da lista
    function insert_last(list::LinkedList{T}, value::T) where T
        # Se a lista estiver vazia, insere o elemento no início
        if list.head === nothing
            insert_first(list, value)
        else
            current = list.head
            # Percorre a lista até encontrar o último nó
            while current.next !== nothing
                current = current.next
            end
            # Cria um novo nó com o valor fornecido e o adiciona após o último nó
            current.next = ListNode{T}(value, nothing)
        end
    end

    # Função para imprimir os elementos da lista
    function print_list(list::LinkedList{T}) where T
        current = list.head
        # Percorre a lista e imprime os valores de cada nó
        while current !== nothing
            println(current.value)
            current = current.next
        end
    end

    # Função para remover o primeiro elemento da lista
    function remove_first(list::LinkedList{T}) where T
        # Verifica se a lista não está vazia
        if list.head !== nothing
            removed_node = list.head   # Armazena o nó a ser removido
            list.head = list.head.next   # Atualiza a cabeça da lista para o próximo nó
            return removed_node   # Retorna o nó removido
        else
            return nothing   # Retorna nulo se a lista estiver vazia
        end
    end

    # Função principal do módulo
    function main()
        list_int = LinkedList{Int}(nothing)   # Cria uma lista ligada para armazenar valores inteiros
        
        # Insere elementos na lista
        insert_first(list_int, 3)
        insert_first(list_int, 2)
        insert_first(list_int, 1)
        insert_last(list_int, 4)
        insert_last(list_int, 5)
        
        println("Elementos da lista:")
        print_list(list_int)   # Imprime os elementos da lista
        
        # Remove o primeiro nó da lista
        removed_node = remove_first(list_int)
        if removed_node !== nothing
            println("Primeiro nó removido: ", removed_node.value)
        else
            println("Lista vazia, nenhum nó removido.")
        end
        
        println("\nElementos da lista após a remoção do primeiro nó:")
        print_list(list_int)   # Imprime os elementos da lista após a remoção
    end

end

MemoryManagement.main()   # Chama a função principal do módulo
