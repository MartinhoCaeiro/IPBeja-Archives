# *********************************************
#  * EDA - Open Adress Table
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: MAy 18, 2024 
#  *********************************************

mutable struct Element
    key::Int
    value::Float64
end

mutable struct OpenAdressTable
    table::Vector{Union{Nothing,Element}}
    table_size::Int
end

function OpenAdressTable(table_size)
    table = Vector{Union{Nothing,Element}}(undef, table_size)
    fill!(table, nothing)
    return OpenAdressTable(table, table_size)
end



# ------------------------------------------------------------------------------------------------------------------------

const NIL = 0

function tableSearch(T, k)
    i = 0
    m = T.table_size
    while i < m
        j = my_hash(k, i, m)
        if T.table[j] === nothing
            return nothing
        elseif T.table[j] !== nothing && T.table[j].key == k
            return j
        else
            i += 1
        end
    end
    return nothing
end


function tableInsert(T, x)
    i = 0
    m = T.table_size
    while i < m
        j = my_hash(x.key, i, m)
        if T.table[j] === nothing
            T.table[j] = x
            return j
        else
            i += 1
        end
    end
    error("Hash table overflow")
end

function tableDelete(T, k)
    j = tableSearch(T, k)
    if j !== nothing
        T.table[j] = nothing
    end
    return j
end


# teste linear
# function h(k, m)
#     return k % m + 1
# end

# function my_hash(key, i, m)
#     return (h(key, m) + i) % m + 1
# end

# teste quadratico
# function h(k, m)
#     return k % m + 1
# end

# function my_hash(key, i, m)
#     return (h(key, m) + c1*i + c2*i^2) % m + 1
# end

# dupla função hash
function h1(k, m)
    return k % 13 + 1
end
function h2(k, m)
    return 1 + (k % 11) + 1
end

function my_hash(key, i, m)
    return (h1(key, m) + i*h2(key, m)) % m + 1
end


# ------------------------------------------------------------------------------------------------------------------------


# Create Table
table_size = 13 #11
T = OpenAdressTable(table_size)

c1 = 1
c2 = 3


# Insert some elements into the table
elements_to_insert = [Element(i, i * 0.2) for i in [10, 22, 31, 4, 15, 28, 59]]
for element in elements_to_insert
    tableInsert(T, element)
end


# Print table contents
function printTable(T::OpenAdressTable)
    println("Table Contents:")
    for (i, elem) in enumerate(T.table)
        if elem === nothing
            println("$i: Empty")
        else
            println("$i: Key = $(elem.key), Value = $(elem.value)")
        end
    end
    println()
end

printTable(T)


# Search for an element
search_key = 22
found_element = tableSearch(T, search_key)
if found_element !== nothing
    println("Found element: position = $(found_element) Key = $(T.table[found_element].key), Value = $(T.table[found_element].value)")
else
    println("Element with key $search_key not found")
end

println()
# Delete an element
delete_key = 22
deleted_index = tableDelete(T, delete_key)
if deleted_index !== nothing
    println("Deleted element at index $deleted_index")
else
    println("Element with key $delete_key not found")
end

# Print table contents after deletion
printTable(T)