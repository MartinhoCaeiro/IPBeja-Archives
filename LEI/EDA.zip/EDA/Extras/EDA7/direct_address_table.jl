# *********************************************
#  * EDA - Tabela de Endereçamento Direto = Direct Address Table
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 28, 2024 
#  *********************************************

function directAddressSearch(T, k)
    return T[k]
end

function directAddressInsert(T, x)
    return T[x.key] = x    
end

function directAddressDelete(T, x)
    return T[x.key] = nothing    
end



# ------------------------------------------------------------------------------------------------------------------------

# Testing Direct Address Table

using CSV
using DataFrames


# Define a structure for the elements to be stored in the table
mutable struct Disciplina
    key::Int
    name::String
    teacher::String
    grade::Int
end

# Define the size of the direct address table
table_size = 15

# Create an array to serve as the direct address table
T = Vector{Union{Nothing, Disciplina}}(undef, table_size)
fill!(T, nothing)  # Fill the array with nothing initially



# Read data from the CSV file
data = CSV.read("EDA7/Disciplinas.csv", DataFrame, header=false)

# Iterate over the rows of the CSV file and insert data into the direct address table
for row in eachrow(data)
    key = row[1]
    name = row[2]
    teacher = row[3]
    grade = row[4]
    disciplina = Disciplina(key, name, teacher, grade)
    directAddressInsert(T, disciplina)
end



# Search for some elements
println("Searching for elements:")
for i in 1:2
    result = directAddressSearch(T, i)
    println("Key: ", result === nothing ? "Not found" : result.key , " Name: ", result === nothing ? "Not found" : result.name)
end



# Delete some elements
delete_key = 3
element_to_delete = directAddressSearch(T, delete_key)
println("\nDeleting the element: ", element_to_delete.key)
directAddressDelete(T, element_to_delete)



# Search for the deleted elements to verify they are not found
println("\nSearching for deleted elements:")
result = directAddressSearch(T, 3)
println("Key: ", result === nothing ? "Not found" : result.key , " Name: ", result === nothing ? "Not found" : result.name)



















# # Define a structure for the elements to be stored in the table
# mutable struct Element
#     key::Int
#     value
# end

# # Define the size of the direct address table
# table_size = 100

# # Create an array to serve as the direct address table
# T = Vector{Union{Nothing, Element}}(undef, table_size)
# fill!(T, nothing)  # Fill the array with nothing initially



# # Test the functions
# # Insert some elements into the table
# elements_to_insert = [Element(i, "Value $i") for i in 1:10]
# for element in elements_to_insert
#     directAddressInsert(T, element)
# end

# # Search for some elements
# println("Searching for elements:")
# for i in 1:10
#     result = directAddressSearch(T, i)
#     println("Key: $i, Value: ", result === nothing ? "Not found" : result.value)
# end

# # Delete some elements
# elements_to_delete = elements_to_insert[3:6]
# println("\nDeleting some elements:")
# for element in elements_to_delete
#     directAddressDelete(T, element)
# end

# # Search for the deleted elements to verify they are not found
# println("\nSearching for deleted elements:")
# for element in elements_to_delete
#     result = directAddressSearch(T, element.key)
#     println("Key: ", element.key, ", Value: ", result === nothing ? "Not found" : result.value)
# end
