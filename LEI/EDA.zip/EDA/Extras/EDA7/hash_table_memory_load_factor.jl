# *********************************************
#  * EDA - Hash Table witjh Load Factor
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: May 14, 2024 
#  *********************************************


mutable struct Disciplina
    key::String
    teacher::String
    grade::Int
end


include("../EDA6/stack.jl")

mutable struct Stack
    S::Array{Int}
    top::Int
    Stack(n) = new(Array{Int}(undef, n), 0)
end


mutable struct MemorySingleLinkedList
    key::Array{Union{Nothing,Disciplina}}
    next::Array{Int64}
    free::Stack
    NIL
end


function MemorySingleLinkedList(n)
    S = Stack(n)
    for x::Int64 = 1:n
        push!(S, x)
    end
    MemorySingleLinkedList(fill(nothing, n),
        zeros(Int64, n),
        S,
        1)

end



function allocate_object!(mem::MemorySingleLinkedList)
    pop!(mem.free)
end


function free_object!(mem::MemorySingleLinkedList, x)
    push!(mem.free, x)
end

const NIL = 0



mutable struct SingleLinkedList
    mem::MemorySingleLinkedList
    head

    SingleLinkedList(mem::MemorySingleLinkedList) = new(mem, NIL)
end




function list_insert!(l::SingleLinkedList, key)
    x = allocate_object!(l.mem)
    l.mem.key[x] = key

    l.mem.next[x] = l.head
    l.head = x
end


function list_delete!(l::SingleLinkedList, x::Int64)
    if l.head == x
        # If the node to delete is the head, update the head
        l.head = l.mem.next[x]
    else
        # Otherwise, find the predecessor of the node to delete
        prev = l.head
        while l.mem.next[prev] != x
            prev = l.mem.next[prev]
        end
        # Update the next pointer of the predecessor to skip over the deleted node
        l.mem.next[prev] = l.mem.next[x]
    end
    # Free the memory associated with the deleted node
    free_object!(l.mem, x)
end


function list_search(l, key)
    x = l.head
    while x != NIL && l.mem.key[x].key != key
        x = l.mem.next[x]
    end
    x
end


# ------------------------------------------------------------------------------------------------------------------------

mutable struct HashTable
    table::Array{SingleLinkedList}
    table_size::Int
    num_elements::Int  # Track the number of elements stored
    load_factor::Float64  # Load factor threshold
end


function HashTable(table_size::Int, load_factor::Float64)
    table = [SingleLinkedList(MemorySingleLinkedList(table_size)) for _ in 1:table_size]
    return HashTable(table, table_size, 0, load_factor)
end


function tableSearch(T, k)
    hash = my_hash(k)
    index = list_search(T.table[hash], k)
    if index > 0 && T.table[hash].mem.key[index].key == k
        return T.table[hash].mem.key[index]
    else
        println("Not found")
        return nothing
    end
end


function tableInsert(T, x)
    hash = my_hash(x.key)
    list_insert!(T.table[hash], x)
    T.num_elements += 1
    current_load_factor = T.num_elements / T.table_size
    if current_load_factor > T.load_factor
        println("Resizing table. Current load factor: ", current_load_factor)
        resize_table!(T)
    end
end

function tableDelete(T, k)
    hash = my_hash(k)
    index = list_search(T.table[hash], k)
    if index != NIL
        list_delete!(T.table[hash], index)
        T.num_elements -= 1
    end
end


function multiply_hash(key::AbstractString, p) # 2^p deve ser menor ou igual ao tamanho da tabela
    k = sum(Int(char) for char in key)
    m = 2^p
    A = (sqrt(5) - 1) / 2
    return trunc(Int, floor(m * (k * A % 1)))
end


function division_hash(key::AbstractString, m) # m é primo não proximo de potencia de 2 
    k = sum(Int(char) for char in key)
    return k % m
end

function jenkings_hash(key::AbstractString)
    hash = 0
    for char in key
        hash += Int(char)
        hash += (hash << 10)
        hash = hash ⊻ (hash >> 6)
    end
    hash += (hash << 3)
    hash = hash ⊻ (hash >> 11)
    hash += (hash << 15)
    return abs(hash % 20 + 1)
end


function my_hash(key::AbstractString)
    # jenkings_hash(key::AbstractString)
    multiply_hash(key::AbstractString, 4)
    # division_hash(key::AbstractString, 19)
end


function resize_table!(T::HashTable)
    # Double the size of the table
    new_table_size = 2 * T.table_size
    println("Resizing hash table from ", T.table_size, " to ", new_table_size)
    new_table = HashTable(new_table_size, T.load_factor)

    # Rehash and insert existing elements into the new table
    for list in T.table
        x = list.head
        while x != NIL
            element = list.mem.key[x]
            new_hash = my_hash(element.key) % new_table_size + 1
            list_insert!(new_table.table[new_hash], element)
            x = list.mem.next[x]
        end
    end

    # Update the hash table with the new table and size
    T.table = new_table.table
    T.table_size = new_table_size

end



# ------------------------------------------------------------------------------------------------------------------------

using CSV
using DataFrames

# Read data from the CSV file
data = CSV.read("EDA7/Disciplinas.csv", DataFrame, header=false)

# Create the Hash Table
table_size = 20
α = 0.7 # Fator de Carga
T = HashTable(table_size, α)


# Iterate over the rows of the CSV file and insert data into the direct address table
for row in eachrow(data)
    key = row[2]
    teacher = row[3]
    grade = row[4]
    disciplina = Disciplina(key, teacher, grade)
    tableInsert(T, disciplina)
end


function printHashTable(T::HashTable)
    println("Hash Table Contents:")
    println()
    for (index, list) in enumerate(T.table)
        println("Hash =  $index")
        if list.head == NIL
            println("  Empty")
        else
            current = list.head
            while current != NIL
                disciplina = list.mem.key[current]
                println("  ", disciplina.key, " - ", disciplina.teacher, ", Nota: ", disciplina.grade)
                current = list.mem.next[current]
            end
            println("  ", "Memory Stack: ", list.mem.free.S[1:list.mem.free.top])
        end
    end
end

println()
printHashTable(T)


delete_item = "Matematica Computacional"
println(tableDelete(T, delete_item))


println("-----------------------")
println("Searching for elements:")
search_name = "Matematica Computacional"
hash = my_hash(search_name)
result = tableSearch(T, search_name)
if result !== nothing
    println("Hash: ", my_hash(result.key), " Name: ", result.key, " Teacher: ", result.teacher, " Grade: ", result.grade)
end
println()



