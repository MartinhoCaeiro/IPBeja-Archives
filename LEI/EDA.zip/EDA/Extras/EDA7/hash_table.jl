# *********************************************
#  * EDA - Hash Table
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 30, 2024 
#  *********************************************


function directAddressSearch(T, k)
    hash = jenkins_hash(k)  
    if T[hash].key == k
        return T[hash]
    else
        println("Not found")
        return nothing
    end
end

function directAddressInsert(T, x)
    hash = jenkins_hash(x.key)  
    T[hash] = x    
end

function directAddressDelete(T, x)
    hash = jenkins_hash(x.key) 
    T[hash] = nothing
end



# function hash(key)
#     return sum( Int(char) for char in key) % 20 + 1
# end

function jenkins_hash(key::AbstractString)
    hash = 0
    for char in key
        hash += Int(char)
        hash += (hash << 10)
        hash = hash ⊻ (hash >> 6)
    end
    hash += (hash << 3)
    hash = hash ⊻ (hash >> 11)
    hash += (hash << 15)
    # println(abs(hash % 20 + 1))
    return abs(hash % 20 + 1)
end



# ------------------------------------------------------------------------------------------------------------------------


using CSV
using DataFrames


mutable struct Disciplina
    key::String
    teacher::String
    grade::Int
end


table_size = 20

T = Vector{Union{Nothing, Disciplina}}(undef, table_size)
fill!(T, nothing)  # Fill the array with nothing initially



# Read data from the CSV file
data = CSV.read("EDA7/Disciplinas.csv", DataFrame, header=false)

# Iterate over the rows of the CSV file and insert data into the direct address table
for row in eachrow(data)
    key = row[2]
    teacher = row[3]
    grade = row[4]
    disciplina = Disciplina(key, teacher, grade)
    directAddressInsert(T, disciplina)
    
    # key = jenkins_hash(teacher)
    # if T[key] === nothing
    #     println( "Not found")
    
    # else
    #     println("Hash: ", key ," Name: ", T[key].name, " Teacher: ", T[key].teacher)
    # end
    
end



println("Print the Hash Table")
for t in T
    if t !== nothing
        println("Hash: ", jenkins_hash(t.key) ," Name: ", t.key, " Teacher: ", t.teacher, " Grade: ", t.grade)
    end
end
println()



println("Searching for elements:")
search_name = "Sistemas Operativos"
result = directAddressSearch(T, search_name)
if result !== nothing
    println("Hash: ", jenkins_hash(result.key) ," Name: ", result.key, " Teacher: ", result.teacher, " Grade: ", result.grade)
end
println()


println(jenkins_hash("Sistemas Digitais"))