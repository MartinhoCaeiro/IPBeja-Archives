# *********************************************
#  * EDA - Hash Table with Memory Menagement
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 30, 2024 
#  *********************************************


mutable struct Disciplina
    key::String
    teacher::String
    grade::Int
end


include("../EDA6/stack.jl")

mutable struct Stack
    S::Array{Int}
    top::Int
    Stack(n) = new(Array{Int}(undef, n), 0)
end


mutable struct MemorySingleLinkedList
    key::Array{Union{Nothing,Disciplina}}
    next::Array{Int64}
    free::Stack
    NIL
end


function MemorySingleLinkedList(n)
    S = Stack(n)
    for x::Int64 = 1:n
        push!(S, x)
    end
    MemorySingleLinkedList(fill(nothing, n),
        zeros(Int64, n),
        S,
        1)

end



function allocate_object!(mem::MemorySingleLinkedList)
    pop!(mem.free)
end


function free_object!(mem::MemorySingleLinkedList, x)
    push!(mem.free, x)
end

const NIL = 0



mutable struct SingleLinkedList
    mem::MemorySingleLinkedList
    head

    SingleLinkedList(mem::MemorySingleLinkedList) = new(mem, NIL)
end




function list_insert!(l::SingleLinkedList, key)
    x = allocate_object!(l.mem)
    l.mem.key[x] = key

    l.mem.next[x] = l.head
    l.head = x
end


function list_delete!(l::SingleLinkedList, x::Int64)
    if l.head == x
        # If the node to delete is the head, update the head
        l.head = l.mem.next[x]
    else
        # Otherwise, find the predecessor of the node to delete
        prev = l.head
        while l.mem.next[prev] != x
            prev = l.mem.next[prev]
        end
        # Update the next pointer of the predecessor to skip over the deleted node
        l.mem.next[prev] = l.mem.next[x]
    end
    # Free the memory associated with the deleted node
    free_object!(l.mem, x)
end


function list_search(l, key)
    x = l.head 
    while x != NIL && l.mem.key[x].key != key
        x = l.mem.next[x]
    end
    x
end


# ------------------------------------------------------------------------------------------------------------------------


mutable struct HashTable
    table::Array{SingleLinkedList}
    table_size::Int
    # num_elements::Int
end

function HashTable(table_size)
    table = [SingleLinkedList(MemorySingleLinkedList(table_size)) for _ in 1:table_size]
    return HashTable(table, table_size) #, 0)
end


function tableSearch(T, k)
    hash = my_hash(k)
    index = list_search(T.table[hash], k)
    if index > 0 && T.table[hash].mem.key[index].key == k
        return T.table[hash].mem.key[index]
    else
        println("Not found")
        return nothing
    end
end

function tableInsert(T, x)
    hash = my_hash(x.key)
    list_insert!(T.table[hash], x)
    # T.num_elements += 1
end

function tableDelete(T, k)
    hash = my_hash(k)
    index = list_search(T.table[hash], k)
    list_delete!(T.table[hash], index)
end



function multiply_hash(key::AbstractString, p) # 2^p deve ser <= ao tamanho da tabela
    k = sum( Int(char) for char in key)
    m = 2^p
    A = (sqrt(5) - 1) / 2
    return trunc(Int, floor(m*(k*A % 1))) 
end


function division_hash(key::AbstractString, m) # m é primo não proximo de potencia de 2 
    k = sum( Int(char) for char in key)
    return k % m
end

function jenkings_hash(key::AbstractString)
    hash = 0
    for char in key
        hash += Int(char)
        hash += (hash << 10)
        hash = hash ⊻ (hash >> 6)
    end
    hash += (hash << 3)
    hash = hash ⊻ (hash >> 11)
    hash += (hash << 15)
    return abs(hash % 20 + 1)
end


function my_hash(key::AbstractString)
    # jenkings_hash(key::AbstractString)
    multiply_hash(key::AbstractString, 4)
    # division_hash(key::AbstractString, 19)
end


# ------------------------------------------------------------------------------------------------------------------------

using CSV
using DataFrames

# Read data from the CSV file
data = CSV.read("EDA7/Disciplinas.csv", DataFrame, header=false)

# Create the Hash Table
table_size = 20
T = HashTable(table_size)


# Iterate over the rows of the CSV file and insert data into the direct address table
for row in eachrow(data)
    key = row[2]
    teacher = row[3]
    grade = row[4]
    disciplina = Disciplina(key, teacher, grade)
    tableInsert(T, disciplina)
end

# function load_factor(T::HashTable)
#     return T.num_elements / T.table_size
# end

function printHashTable(T::HashTable)
    println("Hash Table Contents:")
    println()
    for (index, list) in enumerate(T.table)
        println("Hash =  $index")
        if list.head == NIL
            println("  Empty")
        else
            current = list.head
            while current != NIL
                disciplina = list.mem.key[current]
                println("  ", disciplina.key, " - ", disciplina.teacher, ", Nota: ", disciplina.grade)
                current = list.mem.next[current]
            end
            println("  ", "Memory Stack: ", list.mem.free.S[1:list.mem.free.top])
        end
    end
    # println()
    # println("Load Factor: ", load_factor(T))
end

printHashTable(T)



# println("Print the Hash Table")
# i = 1
# for t in T.table
#     println(i)
#     for x in t.mem.key
#         if x !== nothing
#             println("Hash:", my_hash(x.key), "Lista Ligada: ", x)
#         end
#     end
#     global i+=1
# end
# println()


delete_item = "Matematica Computacional"
println(tableDelete(T, delete_item ))


println("-----------------------")
println("Searching for elements:")
search_name = "Matematica Computacional"
hash = my_hash(search_name)
result = tableSearch(T, search_name)
if result !== nothing
    println("Hash: ", my_hash(result.key)," Name: ", result.key, " Teacher: ", result.teacher, " Grade: ", result.grade)
end
println()



