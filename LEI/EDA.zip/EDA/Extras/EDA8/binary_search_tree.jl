# *********************************************
#  * EDA -  Arvore Binária de Pesquisa = Binary Search Tree
#  * Author: Yara de Sounoa
#  * Number: 23503
#  * Creation Date: May 18, 2024 
#  *********************************************


include("../EDA6/stack.jl")

mutable struct Stack
  S::Array{Int}
  top
  Stack(n) = new(Array{Int}(undef, n), 0)
end


const NIL = nothing

mutable struct MemoryBinarySearchTree
  parent::Array{Union{Nothing,Int64}} # parent
  left::Array{Union{Nothing,Int64}}
  right::Array{Union{Nothing,Int64}}
  key::Array{Int64}
  free::Stack
end


function MemoryBinarySearchTree(n)
  S = Stack(n)
  for x::Int = 1:n
    push!(S, x)
  end

  MemoryBinarySearchTree(fill(NIL, n),
    fill(NIL, n),
    fill(NIL, n),
    zeros(Int, n),
    S)
end

mutable struct BinarySearchTree
  root
  mem::MemoryBinarySearchTree

  BinarySearchTree(mem::MemoryBinarySearchTree) = new(NIL, mem)
end



function allocate_object!(mem::MemoryBinarySearchTree)
  pop!(mem.free)
end

function free_object!(mem::MemoryBinarySearchTree, x)
  push!(mem.free, x)
end




function treeInsert(T::BinarySearchTree, key)
  y = nothing
  x = T.root
  while x !== nothing
    y = x
    if key < T.mem.key[x]
      x = T.mem.left[x]
    else
      x = T.mem.right[x]
    end
  end

  index = allocate_object!(T.mem)
  T.mem.key[index] = key

  T.mem.parent[index] = y

  if y === nothing
    T.root = index
  elseif key < T.mem.key[y]
    T.mem.left[y] = index
  else
    T.mem.right[y] = index
  end
end


function inorderTreeWalk(T::BinarySearchTree, x)
  if x !== nothing
    inorderTreeWalk(T, T.mem.left[x])
    println(T.mem.key[x])
    inorderTreeWalk(T, T.mem.right[x])
  end
end

function inorderTreeWalk(T::BinarySearchTree)
  inorderTreeWalk(T, T.root)
end


function treeSearch(T::BinarySearchTree, x, key)
  if x === nothing || key == T.mem.key[x]
    return x
  end
  if key < T.mem.key[x]
    return treeSearch(T, T.mem.left[x], key)
  else
    return treeSearch(T, T.mem.right[x], key)
  end
end


function iterativeTreeSearch(T::BinarySearchTree, x, k)
  while x !== nothing && k != T.mem.key[x]
    if k < T.mem.key[x]
      x = T.mem.left[x]
    else
      x = T.mem.right[x]
    end
  end
  return x
end


function tree_Minimum(T::BinarySearchTree, x)
  while T.mem.left[x] !== nothing
    x = T.mem.left[x]
  end
  return x
end

function tree_Maximum(T::BinarySearchTree, x)
  while T.mem.right[x] !== nothing
    x = T.mem.right[x]
  end
  return x
end


function treeSuccessor(T::BinarySearchTree, x)
  if T.mem.right[x] !== nothing
    return tree_Minimum(T, T.mem.right[x])
  end
  y = T.mem.parent[x]
  while y !== nothing && x === T.mem.right[y]
    x = y
    y = T.mem.parent[y]
  end
  return y
end


function treePredecessor(T::BinarySearchTree, x)
  if T.mem.left[x] !== nothing
    return tree_Maximum(T, T.mem.left[x])
  end
  y = T.mem.parent[x]
  while y !== nothing && x === T.mem.left[y]
    x = y
    y = T.mem.parent[y]
  end
  return y
end


function treeTransplant(T::BinarySearchTree, u, v)
  if T.mem.parent[u] === nothing
    T.mem.root = v
  elseif u == T.mem.left[T.mem.parent[u]]
    T.mem.left[T.mem.parent[u]] = v
  else
    T.mem.right[T.mem.parent[u]] = v
  end
  if v !== nothing
    T.mem.parent[v] = T.mem.parent[u]
  end
end

function treeDelete(T::BinarySearchTree, z)
  if T.mem.left[z] === nothing
    treeTransplant(T, z, T.mem.right[z])
  elseif T.mem.right[z] === nothing
    treeTransplant(T, z, T.mem.left[z])
  else
    y = tree_Minimum(T, T.mem.right[z])
    if T.mem.parent[y] !== z
      treeTransplant(T, y, T.mem.right[y])
      T.mem.right[y] = T.mem.right[z]
      T.mem.parent[T.mem.right[y]] = y
    end
    treeTransplant(T, z, y)
    T.mem.left[y] = T.mem.left[z]
    T.mem.parent[T.mem.left[y]] = y
  end
  free_object!(T.mem, z)
end


# ------------------------------------------------------------------------------------------------------------------------

# Testing Binary Tree

function printNodeDetails(T::BinarySearchTree, node_index)
  println("Node at index: ", node_index)
  println("Key: ", T.mem.key[node_index])
  println("Parent: ", T.mem.parent[node_index] === nothing ? "nil" : T.mem.key[T.mem.parent[node_index]])
  println("Left Child: ", T.mem.left[node_index] === nothing ? "nil" : T.mem.key[T.mem.left[node_index]])
  println("Right Child: ", T.mem.right[node_index] === nothing ? "nil" : T.mem.key[T.mem.right[node_index]])
  println()
end

function printTreeInfo(T::BinarySearchTree)
  function printNodeInfo(node_index)
    if node_index === nothing
      println("Key: nil, Left: nil, Right: nil, Parent: nil")
    else
      println(
        "Key: ", T.mem.key[node_index],
        ", Left: ", getLeftKey(node_index),
        ", Right: ", getRightKey(node_index),
        ", Parent: ", getParentKey(node_index)
      )
    end
  end

  function getLeftKey(node_index)
    if T.mem.left[node_index] === nothing
      return "nil"
    else
      return T.mem.key[T.mem.left[node_index]]
    end
  end

  function getRightKey(node_index)
    if T.mem.right[node_index] === nothing
      return "nil"
    else
      return T.mem.key[T.mem.right[node_index]]
    end
  end

  function getParentKey(node_index)
    if T.mem.parent[node_index] === nothing
      return "nil"
    else
      return T.mem.key[T.mem.parent[node_index]]
    end
  end

  function printInOrder(node_index)
    if node_index !== nothing
      printInOrder(T.mem.left[node_index])
      printNodeInfo(node_index)
      printInOrder(T.mem.right[node_index])
    end
  end

  printInOrder(T.root)
end

# Insert
new = [30, 47, 88, 97, 27, 13, 63]

mem = MemoryBinarySearchTree(10)
Tree = BinarySearchTree(mem)


println("Stack: ", Tree.mem.free.S)

for item in new
  treeInsert(Tree, item)
  # printNodeDetails(Tree, Tree.root)
end

#PRINT A ARVORE BINARIA
printTreeInfo(Tree)

println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])


# Perform inorder tree walk
println()
println("Inorder Tree Walk:")
inorderTreeWalk(Tree)


# Perform tree search
println()
search_key = 88
result = treeSearch(Tree, Tree.root, search_key)
if result !== nothing
  println("Found key $search_key at index $result")
  printNodeDetails(Tree, result)
else
  println("Key $search_key not found in the tree")
end

# Perform tree search from an arbitrary node
println()
arbitrary_node_index = 9 # para saber o node_index ver a lista de inserção e ir de trás pra frente no stack
search_key = 97
result = treeSearch(Tree, arbitrary_node_index, search_key)
if result !== nothing
  println("Found key $search_key starting from node at index $arbitrary_node_index")
  printNodeDetails(Tree, result)
else
  println("Key $search_key not found starting from node at index $arbitrary_node_index")
end


# Perform iterative tree search from the root
println()
iterative_result = iterativeTreeSearch(Tree, Tree.root, search_key)
if iterative_result !== nothing
  println("Iteratively found key $search_key at index $iterative_result")
  printNodeDetails(Tree, iterative_result)
else
  println("Iteratively did not find key $search_key")
end


# Find Tree Max and minimum
println()
max_index = tree_Maximum(Tree, Tree.root)
min_index = tree_Minimum(Tree, Tree.root)
println("Tree Maximum: ", Tree.mem.key[max_index], " at index: ", max_index)
println("Tree Minimum: ", Tree.mem.key[min_index], " at index: ", min_index)



# Test the treeSuccessor function (Inorder)
println()
successor_key = 47
node_index = treeSearch(Tree, Tree.root, successor_key)
if node_index !== nothing
  successor_index = treeSuccessor(Tree, node_index)
  if successor_index !== nothing
    println("Successor of key $successor_key is: ", Tree.mem.key[successor_index])
    printNodeDetails(Tree, successor_index)
  else
    println("Successor of key $successor_key does not exist")
  end
else
  println("Key $successor_key not found in the tree")
end


# Test the treePredecesspr function (Inorder)
println()
predecessor_key = 47
node_index = treeSearch(Tree, Tree.root, predecessor_key)
if node_index !== nothing
  predecessor_index = treePredecessor(Tree, node_index)
  if successor_index !== nothing
    println("Predecessor of key $predecessor_key is: ", Tree.mem.key[predecessor_index])
    printNodeDetails(Tree, predecessor_index)
  else
    println("Predecessor of key $predecessor_key does not exist")
  end
else
  println("Key $predecessor_key not found in the tree")
end


# Test treeDelete
println()
deleted_key = 63
deleted_index = treeSearch(Tree, Tree.root, deleted_key)
println("Deleting key $(deleted_index)")
treeDelete(Tree, deleted_index)
#PRINT A ARVORE BINARIA
printTreeInfo(Tree)
println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])
