# *********************************************
#  * EDA -  Compare Cases
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************

using Plots

include("heap_sort.jl")
include("measure_time.jl")
include("../EDA2/distributions.jl")

# Best Case
# already sorted
# Θ(nlog(n))

# Worst Case
# sorted in descending order
# Θ(nlog(n))

# Random Case
# Θ(nlog(n))

array_sizes = collect(1:50:5000) 
sample_list =  generate_distrubutions(array_sizes, uniform_rand_list)

best_case_heap_time = measure_time_growth_rate(heapsort!, array_sizes, sample_list)
worst_case_heap_time = measure_time_growth_rate(heapsort!, array_sizes, sample_list)
random_case_heap_time = measure_time_growth_rate(heapsort!, array_sizes, sample_list)


plt = plot(array_sizes, random_case_heap_time , label = "Random Case", xlabel = "n - Array Sizes", ylabel = "Time(s)", title = "Tempos de execução experimental")
plot!(array_sizes, worst_case_heap_time , label = "Worst Case")
plot!(array_sizes, best_case_heap_time, label = "Best case")


