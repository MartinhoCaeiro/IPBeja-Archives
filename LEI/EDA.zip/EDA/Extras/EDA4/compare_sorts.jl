# *********************************************
#  * EDA -  Compare Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************

using Plots
using Statistics

include("heap_sort.jl")
include("../EDA3/merge_sort.jl")
include("measure_time.jl")
include("../EDA2/distributions.jl")


array_sizes = collect(1:50:5000) 
sample_list =  generate_distrubutions(array_sizes, uniform_rand_list)

# heap_times = measure_time_growth_rate(heapsort!, array_sizes, sample_list ) # Θ(n log(n))
# merge_times = measure_time_growth_rate(mergesort!, array_sizes, sample_list) # Θ(n log(n))

# plt = plot(array_sizes, heap_times , label = "Heap Sort", xlabel = "n - Array Sizes", ylabel = "Time(s)", title = "Tempos de execução experimental")
# plot!(array_sizes, merge_times, label = "Merge Sort")




# Statistical analysis of the ratio of the times for the sorting algorithms
function exp_protocol(N, sortingAlgorithm_1, sortingAlgorithm_2, array_sizes, sample_list)
    compared_times = []
    for i in 1 : N 
        sort1_times = measure_time_growth_rate(sortingAlgorithm_1, array_sizes, sample_list ) 
        sort2_times = measure_time_growth_rate(sortingAlgorithm_2, array_sizes, sample_list) 
        compared_times = sort1_times ./ sort2_times
    end

    return compared_times
end

N = 100
compared_times = exp_protocol(N,  mergesort!, heapsort!, array_sizes, sample_list)
compared_mean = mean(compared_times)
compared_std = std(compared_times)
compare_median = median(compared_times)

println("Mean = ", compared_mean," Mediana = ", compare_median , " STD = ", compared_std)
plt = plot(array_sizes, compared_times, legend=false, xlabel = "n - Array Sizes", ylabel = "ratio of times", title = "Ratio of execution Times for Heap and Merge")

