# *********************************************
#  * EDA -  CSV file Reader
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************

function left(i)
    return 2*i
end

function right(i)
    return 2*i + 1
end


function maxheapify!(A::Array{T}, i, heapSize, sortByIndex) where T
    l = left(i)
    r = right(i)

    if l <= heapSize && A[l][sortByIndex] > A[i][sortByIndex]
        largest = l
    else
        largest = i
    end

    if r <= heapSize && A[r][sortByIndex] > A[largest][sortByIndex]
        largest = r
    end

    if largest != i
        temp = A[i]
        A[i] = A[largest]
        A[largest] = temp
        maxheapify!(A, largest, heapSize, sortByIndex)
    end
end

function buildmaxheap!(A::Array{T}, sortByIndex) where T
    heapSize = length(A)
    for i = div(length(A), 2) : -1 : 1
        maxheapify!(A, i, heapSize, sortByIndex)
    end
    length(A)
end

# Heap Sort CSV file
function heapsort_csv!(A::Array{T}, sortByIndex) where T
    heapSize = buildmaxheap!(A, sortByIndex)
    for i = length(A) : -1 : 2
        temp = A[1]
        A[1] = A[i]
        A[i] = temp
        heapSize = heapSize - 1
        maxheapify!(A, 1, heapSize, sortByIndex)
    end
    return A
end




