# *********************************************
#  * EDA -  Bubble Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 28, 2024 
#  *********************************************

"""
--------------------------------------------------------------------------------------
                        Heap Sort Method
"""

function left(i)
    return 2*i
end

function right(i)
    return 2*i + 1
end


function maxheapify!(A::Array{T}, i, heapSize) where T
    l = left(i)
    r = right(i)

    if l <= heapSize && A[l] > A[i]
        largest = l
    else
        largest = i
    end

    if r <= heapSize && A[r] > A[largest]
        largest = r
    end

    if largest != i
        temp = A[i]
        A[i] = A[largest]
        A[largest] = temp
        maxheapify!(A, largest, heapSize)
    end
end

function buildmaxheap!(A::Array{T}) where T
    heapSize = length(A)
    for i = div(length(A), 2) : -1 : 1
        maxheapify!(A, i, heapSize)
    end
    length(A)
end

function heapsort!(A::Array{T}) where T
    heapSize = buildmaxheap!(A)
    for i = length(A) : -1 : 2
        temp = A[1]
        A[1] = A[i]
        A[i] = temp
        heapSize = heapSize - 1
        maxheapify!(A, 1, heapSize)
    end
    return A
end


# heap = [2, 8, 7, 1, 3, 5, 6, 4]
# println("Original: ", heap)
# heapsort!(heap)
# println("Heap: ", heap)
