# *********************************************
#  * EDA -  Taxa de Crescimento Experimental
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************


function generate_distrubutions(array_sizes, distribution)
    return  [distribution(size) for size in array_sizes]
end


function measure_time_growth_rate(sortingAlgorithm, array_sizes, distributions)
    times = []

    for i in eachindex(array_sizes)
        sample = distributions[i]
        time_needed = @elapsed sortingAlgorithm( copy(sample) )
        push!(times, time_needed)
    end

    return times
end
