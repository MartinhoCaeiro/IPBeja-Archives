
using DataFrames
using XLSX
using CSV

include("../EDA2/CSV/csv_reader.jl")
include("heap_csv.jl")


filename = "HDR23-24_Statistical_Annex_HDI_Table.xlsx"
sheetname = "HDI"

function read_excel(filename::String, sheetname::String)
    # df = DataFrame(XLSX.readtable(filename, sheetname))
    # # xf = XLSX.readxlsx(filename)
    # # xf["HDI!B1:O204"]
    xf = XLSX.readxlsx(filename)
    m = xf[1][:]
    df = DataFrame(m[9:12, 2:3], :auto)

end

df = read_excel(filename, sheetname)



function write_DF_to_file(filename, df)
    CSV.write(filename, df, header=false)
end

filename = "EDA4/CSV/IDH.csv"
write_DF_to_file(filename, df)



toSort = read_csv("EDA4/CSV/IDH.csv")
heapSortedByCountry = copy(heapsort_csv!(toSort, 1))
heapSortedByIDH = copy(heapsort_csv!(toSort, 2))

println("Heap Sorted by Country: ", heapSortedByCountry)
println("Heap Sorted by IDH: ", heapSortedByIDH)


function write_file(filename, sorted_array)
    df = DataFrame(sorted_array, :auto)
    CSV.write(filename, df)
end

filename = "/EDA4/CSV/sorted.csv"
write_file(filename,heapSortedByIDH)