# *********************************************
#  * EDA -  Fit Model
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 2, 2024 
#  *********************************************


using Plots

include("bubble_sort.jl")
include("insertion_sort.jl")
include("distributions.jl")


# Θ(n2)
function calc_teorico_quadratico(functionsort, experimental_times, step_size, num_step, percent)

    Order = [] # Order = func(n^2)
    for size in test_sizes
        func = size^2
        push!(Order, func)
    end

    c =  @elapsed functionsort([])
    a = 1
    i = 0
   teorical_times = a.*Order .+ c

    while experimental_times[end] ./  teorical_times[end] < (1 - percent) || experimental_times[end] ./  teorical_times[end] > (1 + percent)
        teorical_times = a .* Order .+ c
        a *= step_size # tamanho do passo 
        i += 1
        if i >= num_step # número de passos permitidos
            println("Limite de passos excedido.") # Diminua o tamanho do passo e aumente o número de passos
            break
        end
    end

    return teorical_times
    
end

function fit_model(functionsort, SortName, test_sizes, step_size, num_step, percent)
    experimental_times = []

    for size in test_sizes
        sample = normal_rand_list(size)
        btime = @elapsed functionsort(copy(sample))
        push!(experimental_times, btime)
    end
  
    
    teorical_times = calc_teorico_quadratico(functionsort, experimental_times, step_size, num_step, percent)
    # println("Erro relativo = ", mean(( experimental_times .-  teorical_times) ./ teorical_times))
    plt = plot(test_sizes, experimental_times, label = SortName, xlabel = "n - Array Size", ylabel = "Time(s)", title = "Protocolo Experimental", linewidth = 2)
    plot!(test_sizes, teorical_times, label = "Tempo Teorico")

end


fit_model(bubblesort!, "Bubble Sort", test_sizes, 10^(-0.01), 5000, 0.1)
# fit_model(insertionsort!, "Insertion Sort", test_sizes, 10^(-0.01), 5000, 0.1)


