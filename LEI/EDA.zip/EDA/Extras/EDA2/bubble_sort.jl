# *********************************************
#  * EDA -  Bubble Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 12, 2024 
#  *********************************************

"""
--------------------------------------------------------------------------------------
                        Bubble Sort Method
"""
function bubblesort!(A::Array{T}) where T
    for i = 1 :  length(A) - 1 
        for j = length(A) : -1 : i + 1  # start:step:stop
            if (A[j] < A[j - 1])
                key = A[j] 
                A[j] = A[j - 1]
                A[j - 1] = key
            end
        end
    end
    return A
end

# bubble = [10, 7, 6, 3, 5, 2, 0, 1]
# println("Original: ", bubble)
# bubblesort!(bubble)
# println("Buble: ", bubble)

#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                 Bubble Sort Method Recursive
"""

function bubblesortrecursive!(A::Array{T}, i::Int = 1, j::Int = length(A)) where T
    if i > length(A) - 1
        return A
    elseif j > i
        if (A[j] < A[j - 1])
            key = A[j] 
            A[j] = A[j - 1]
            A[j - 1] = key
        end
        bubblesortrecursive!(A, i, j - 1)
    else
        bubblesortrecursive!(A, i + 1, length(A))
    end
end


# function bubblesortrecursive!(A::Array{T}, i::Int = 1, j::Int = length(A)) where T
#     if i > length(A) - 1
#         return A
#     elseif j <= i
#         bubblesortrecursive!(A, i + 1, length(A))
#     else
#         if (A[j] < A[j - 1])
#             key = A[j] 
#             A[j] = A[j - 1]
#             A[j - 1] = key
#         end
#         bubblesortrecursive!(A, i, j - 1)
#     end
# end


# function bubblesortrecursive!(A::Array{T}, i = 1, j = length(A)) where T
#     if i < length(A)
#         if j > i
#           if A[j] < A[j - 1]
#             key = A[j]
#             A[j] = A[j - 1]
#             A[j - 1] = key
#           end
    
#           return bubblesortrecursive!(A, i, j - 1)
#         else
#           return bubblesortrecursive!(A, i + 1, length(A))
#         end
#     else
#         return A
#     end
# end

# bubble = [10, 7, 6, 3, 5, 2, 0, 1]
# println("Original: ", bubble)
# bubblesortrecursive!(bubble)
# println("Buble: ", bubble)

#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                    Bubble Sort Method List Comprehension
"""

function bubblesortcomprehension!(A::Array{T}) where T
    [(key = A[j]; A[j] = A[j - 1]; A[j - 1] = key)
        for i in 1 :  length(A) - 1
            for j in length(A) : -1 : i + 1
                if A[j] < A[j - 1]
    ]
end

# bubble = [10, 7, 6, 3, 5, 2, 0, 1]
# println("Original: ", bubble)
# bubblesortcomprehension!(bubble)
# println("Buble: ", bubble)

#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                    Bubble Sort Method Functional Programming
"""
 








