# *********************************************
#  * EDA -  Insertion Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 12, 2024 
#  *********************************************

"""
--------------------------------------------------------------------------------------
                        Insertion Sort Method
"""

function insertionsort!(A::Array{T}) where T
    for j = 2 : length(A)
        key = A[j]
        i = j - 1
        while i > 0 && A[i] > key
            A[i+1] = A[i]
            i = i - 1
        end
        A[i+1] = key
    end
    return A
end

# insertion = [10, 7, 6, 3, 5, 2, 0, 1]
# println("Original: ", insertion)
# insertionsort!(insertion)
# println("Insertion: ", insertion)

#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                        Insertion Sort Method Recursive
"""

function insertionsortrecursive!(A::Array{T}, j::Int = 2, i::Int = j - 1, key = A[j]) where T
    if j > length(A) 
        return A
    else 
        if i > 0 && A[i] > key
            A[i+1] = A[i]
            insertionsortrecursive!(A, j, i - 1, key)
        else
            A[i+1] = key
            j = j + 1
            if j <= length(A)
                key = A[j]
            end
            insertionsortrecursive!(A, j, j - 1, key)
        end
    end
end


# insertion = [10, 7, 6, 3, 5, 2, 0, 1]
# println("Original: ", insertion)
# insertionsortrecursive!(insertion)
# println("Insertion: ", insertion)

#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                        Insertion Sort Method List Comprehension
"""


# function insertionsortFOR!(A::Array{T}) where T
#     for j = 2:length(A)
#         key = A[j]
#         i = j - 1
#         for k = i : -1 : 1
#             if A[k] > key
#                 A[k + 1] = A[k]
#                 i = i -1
#             end
#         end
#         A[i + 1] = key
#     end
# end


function insertionsortcomprehension!(A::Array{T}) where T
    [  (  key = A[j] ; 
          i = j - 1 ; 
         [ (A[k + 1] = A[k]; i = i - 1)  for k = i : -1 : 1 if A[k] > key ] ; 
         A[i + 1] = key
        )
            for j = 2:length(A)  
    ]          
end



# insertion = [10, 7, 6, 3, 5, 2, 0, 1]
# println("Original: ", insertion)
# insertionsortcomprehension!(insertion)
# println("Insertion: ", insertion)

#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                        Insertion Sort Method Functional Programming
"""