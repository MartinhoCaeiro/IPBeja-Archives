# *********************************************
#  * EDA -  CSV file Reader
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 29, 2024 
#  *********************************************

using DataFrames

include("csv_reader.jl")

toSort = read_csv("EDA2/CSV/alunos.csv")


# Bubble Sort CSV file
function bubblesort_csv!(A::Array{T}, sortByIndex) where T
    for i = 1 :  length(A) - 1 
        for j = length(A) : -1 : i + 1 
            if (A[j][sortByIndex] < A[j - 1][sortByIndex])
                key = A[j] 
                A[j] = A[j - 1]
                A[j - 1] = key
            end
        end
    end
    return A
end

# Insertion Sort CSV file
function insertionsort_csv!(A::Array{T}, sortByIndex) where T
    for j = 2 : length(A)
        key = A[j]
        i = j - 1
        while i > 0 && A[i][sortByIndex] > key[sortByIndex]
            A[i+1] = A[i]
            i = i - 1
        end
        A[i+1] = key
    end
    return A
end


bubbleSortedByNumber = copy(bubblesort_csv!(toSort, 1))
bubbleSortedByName = copy(bubblesort_csv!(toSort, 2))

println("Bubble Sorted by Number: ", bubbleSortedByNumber)
println("Bubble Sorted by Name: ", bubbleSortedByName)

println()

insertionSortedByNumber = copy(insertionsort_csv!(toSort, 1))
insertionSortedByName = copy(insertionsort_csv!(toSort, 2))

println("Insertion Sorted by Number: ", insertionSortedByNumber)
println("Insertion Sorted by Name: ", insertionSortedByName)

