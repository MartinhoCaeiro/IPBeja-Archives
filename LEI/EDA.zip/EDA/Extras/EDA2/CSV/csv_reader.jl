# *********************************************
#  * EDA -  CSV file Reader
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 29, 2024 
#  *********************************************

using CSV
using DataFrames

# function read_csv(filename::String)
#     # Read CSV file
#     csv_reader = CSV.File(filename)

#     # Store data in a vector of vectors of strings
#     read = Vector{Vector{String}}()
#     for row in csv_reader
#         # Convert each element to a string before storing
#         push!(read, [string(row[i]) for i in eachindex(row)])
#     end

#     return read
# end


# Using DataFrame always eliminates the first line (title line)
# function read_csv(filename::String)
#     csv_reader = CSV.read(filename, DataFrame)    
#     # println(csv_reader)   
#     array_data = Vector{Vector{String}}()
#     for row in eachrow(csv_reader)
#       push!(array_data, [string(value) for value in row])
#     end
#     return array_data
# end


#  Read CSV file and save into a list
function read_csv(filename::String)
    lines = readlines(filename)
    read = Vector{Vector{String}}()
    for line in lines
      push!(read, split(line, ","))
    end
  
    return read
  end
  
# read_csv("EDA2/CSV/alunos.csv")