# *********************************************
#  * EDA -  Distribuitions
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************


# Normal Distribution
function normal_rand_list(n, μ = 0, σ = 1.0)
    A =  μ .+ σ .* randn(n)
    return A
end

# Sorted Normal Distribution
function sorted_normal_rand_list(n, μ = 0, σ = 1.0)
    A =  μ .+ σ .* randn(n)
    return sort(A)
end

# Reverse Sorted Normal Distribution
function rev_sorted_normal_rand_list(n, μ = 0, σ = 1.0)
    A =  μ .+ σ .* randn(n)
    return sort(A, rev = true)
end


# Uniform Distribution
function uniform_rand_list(N, a = 100, b = -100)
    rand_float_list = [(b - a)*rand() + a for n in 1 : N]
    return rand_float_list
end

