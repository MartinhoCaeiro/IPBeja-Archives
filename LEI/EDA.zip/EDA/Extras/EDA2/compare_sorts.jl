# *********************************************
#  * EDA -  Compare Sorts
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 2, 2024 
#  *********************************************

using Plots

include("bubble_sort.jl")
include("insertion_sort.jl")
include("distributions.jl")


# Compare and plot execution times
function comparetimes(test_sizes)

    bubble_times = []
    insertion_times = []
    
    for size in test_sizes
        sample = normal_rand_list(size)
        btime = @elapsed bubblesort!( copy(sample) )
        itime = @elapsed insertionsort!( copy(sample) )
        push!(bubble_times, btime)
        push!(insertion_times, itime)
    end

    plt_b = plot(test_sizes, bubble_times, label = "Bubble Sort", xlabel = "Array Sizes", ylabel = "Time(s)", title = "Bubble Sort", linewidth = 2)
    plt_i = plot(test_sizes, insertion_times, label = "Insertion Sort", xlabel = "Array Sizes", ylabel = "Time(s)", title = "Insertion Sort", linewidth = 2)

    plot(plt_b, plt_i, layout = (2, 1), legend=false)
    
end

test_sizes = collect(1:50:5000) #[x for x in 0:5000 if x % 50 == 0] # size of the array that will be sorted
# comparetimes(test_sizes)