# *********************************************
#  * EDA -  Measure Times
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 29, 2024 
#  *********************************************

using Plots


# Melhor Cenário
# Θ(n)
function melhor_cenario(Sizes)
    Order_times = []

    for n in Sizes
        func = n
        push!(Order_times, func)
    end
    return Order_times
end

# Pior Cenário
# Θ(n log(n))
function pior_cenario(Sizes)
    Order_times = []

    for n in Sizes
        func = n*log(n)
        push!(Order_times, func)
    end
    return Order_times
end


function taxa_crescimento_prevista(test_sizes)
    melhor_times = melhor_cenario(test_sizes)
    pior_times = pior_cenario(test_sizes)

    plot(test_sizes, melhor_times, xlabel="n", ylabel="time (s)", label="Melhor Cenário", title = "Tempos de execução previstos teoricamente")
    plot!(test_sizes, pior_times, label="Pior Cenário")

end

test_sizes = collect(0:50:5000)
taxa_crescimento_prevista(test_sizes)

