# *********************************************
#  * EDA -  Measure Memory Allocation
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************

using Plots

include("merge_sort.jl")
include("../EDA2/insertion_sort.jl")
include("../EDA2/bubble_sort.jl")
include("../EDA2/distributions.jl")


function measure_memory_growth_rate(sortingAlgorithm, array_sizes, distribution)
    malloc = []

    for size in array_sizes
        sample = distribution(size)
        memory_usage = @allocated sortingAlgorithm( copy(sample) )
        push!(malloc, memory_usage)
    end

    return malloc
end

array_sizes = collect(1:50:5000) 

bubble_memory_alloc = measure_memory_growth_rate(bubblesort!, array_sizes, normal_rand_list)
insertion_memory_alloc = measure_memory_growth_rate(insertionsort!, array_sizes, normal_rand_list)
merge_memory_alloc = measure_memory_growth_rate(mergesort!, array_sizes, normal_rand_list)


plt = plot(array_sizes, bubble_memory_alloc, label = "Bubble Sort", xlabel = "n - Array Sizes", ylabel = "Memory Allocated (bytes)", linewidth = 2)
plot!(array_sizes, insertion_memory_alloc , label = "Insertion Sort")
plot!(array_sizes, merge_memory_alloc , label = "Merge Sort")



