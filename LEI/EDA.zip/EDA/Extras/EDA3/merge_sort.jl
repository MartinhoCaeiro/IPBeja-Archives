# *********************************************
#  * EDA -  Merge Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 28, 2024 
#  *********************************************

"""
--------------------------------------------------------------------------------------
                        Merge Sort Method
"""

function merge!(A::Array{T}, p::Int64, q::Int64, r::Int64) where {T}
    n1 = q - p + 1
    n2 = r - q
    L = Array{T}(undef, n1 + 1)
    R = Array{T}(undef, n2 + 1)

    for i = 1 : n1
        L[i] = A[p + i - 1]
    end
    for j = 1 : n2
        R[j] = A[q + j]
    end

    inf = typemax(T)
    L[n1+1] = inf
    R[n2+1] = inf

    i = 1
    j = 1

    for k = p : r 
        if L[i] <= R[j]
            A[k] = L[i]
            i = i + 1
        else
            A[k] = R[j]
            j = j + 1
        end
    end    
end


function mergesort!(A::Array{T}, p::Int64 = 1, r::Int64 = -1) where {T}
    if r == -1
        r = length(A)
    end

    if p < r
        q = div(p + r, 2) # trunv(Int, (p+r)/2) => math floor
        mergesort!(A, p, q)
        mergesort!(A, q + 1, r)
        merge!(A, p, q, r)
    end
    return A
end


# merge = [2, 8, 7, 1, 3, 5, 6, 4]
# println("Original: ", merge)
# mergesort!(merge, 1, length(merge))
# println("Merge: ", merge)








# # Merge Sort Method
# function mergesort!(A::Vector{T}) where T
#     len = length(A)
#     sortA = Vector{T}()

#     if len == 1
#         return A
#     end

#     mid = div(len,2)

#     L = A[1:mid]
#     R = A[mid+1:end]

#     L = mergesort!(L)
#     R = mergesort!(R)


#     while length(L) > 0 && length(R) > 0
#         if L[1] < R[1]
#             push!(sortA, L[1])
#             popfirst!(L)
#         else
#             push!(sortA, R[1])
#             popfirst!(R)
#         end
#     end

#     append!(sortA, L)
#     append!(sortA, R)

#     return sortA

# end

# merge = randlist(6)
# print(mergesort!(merge))






