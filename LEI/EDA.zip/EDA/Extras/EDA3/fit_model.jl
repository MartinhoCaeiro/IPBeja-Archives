# *********************************************
#  * EDA -  Measure Times
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 30, 2024 
#  *********************************************


using Plots
using BenchmarkTools # to measure time
using Statistics
using StatsBase


include("merge_sort.jl")
include("../EDA2/distributions.jl")

# Pior Cenário
# Θ(n log(n))
function calc_teorico_nlog(functionsort, experimental_times, test_sizes, step_size, num_step, percent)
    error = 1 + percent

    Order = [] # Order = func(n log(n))
    for size in test_sizes
        func = size*log(size)
        push!(Order, func)
    end

    c =  @elapsed functionsort([])
    a = 1
    i = 0
    teorical_times = a.*Order .+ c

    while mean(experimental_times ./  teorical_times) < 1 / error || mean(experimental_times ./  teorical_times) > error
        teorical_times = a.*Order .+ c
        a = a*step_size # tamanho do passo 
    
        i += 1
        if i >= num_step # número de passos permitidos
            println("Limite de passos excedido.") # Diminua o tamanho do passo e aumente o número de passos
            break
        end
    end

    return teorical_times
end


function remove_outliers(data::Vector{T}, threshold::Float64) where T
    mean_value = mean(data)
    std_value = std(data)
    z_scores = abs.((data .- mean_value) ./ std_value)
    filtered_data = data[z_scores .<= threshold]
    outlier_indices = findall(z_scores .> threshold)
    return filtered_data, outlier_indices
end

function exp_protocol(functionsort, SortName, test_sizes, step_size, num_step, percent)
    experimental_times = []

    for size in test_sizes
        sample = normal_rand_list(size)
        btime = @elapsed functionsort(copy(sample))
        push!(experimental_times, btime)
    end

    clean_times,  outlier_indices = remove_outliers(experimental_times, 1.96) # z-score = 1.96 corresponde a 5% (aumente se tirou pontos demais / diminua se aind atem ponto fora da curva)
    clean_sizes = [test_sizes[i] for i in eachindex(test_sizes) if !(i in outlier_indices)]

    teorical_times = calc_teorico_nlog(functionsort, clean_times, clean_sizes, step_size, num_step, percent)

    plt = scatter(test_sizes, experimental_times, label = SortName, xlabel = "n - Array Size", ylabel = "Time(s)", title = "Protocolo Experimental")
    scatter!(clean_sizes, clean_times, label = "Clean Data", markersize = 2)
    plot!(clean_sizes, teorical_times, label = "Tempo Teorico", linewidth = 4)
end

test_sizes = collect(1:50:5000)
exp_protocol(mergesort!, "Merge Sort", test_sizes, 10^(-0.01), 5000, 0.1)





