# *********************************************
#  * EDA -  Compare Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 29, 2024 
#  *********************************************


include("merge_sort.jl")
include("../EDA2/bubble_sort.jl")

# Uniform Distribution
function uniform_rand_list(a, b, N)
    rand_float_list = [(b - a)*rand() + a for n in 1 : N]
    return rand_float_list
end


# Mede tempo de execução
function measure_time(sortingAlgorithm, sample)
    return @elapsed sortingAlgorithm( copy(sample) )
end


function comapare_sorts(sortingAlgorithm_1, sortingAlgorithm_2, num_step)
    N = 1
    sample = uniform_rand_list(-100, 100, N)

    while  1000*measure_time(sortingAlgorithm_1, sample) > measure_time(sortingAlgorithm_2, sample)
        println(N)
        N += 50
        sample = uniform_rand_list(-100, 100, N)

        if N >= num_step # número de passos permitidos
            println("Limite de passos excedido.")
            println("Break => N: ", N, "    T_dif: ", measure_time(sortingAlgorithm_2, sample)/measure_time(sortingAlgorithm_1, sample))
            break
        end
    end
    return (N, measure_time(sortingAlgorithm_2, sample)/measure_time(sortingAlgorithm_1, sample) )
end


println(comapare_sorts(mergesort!, bubblesort!, 10^5))