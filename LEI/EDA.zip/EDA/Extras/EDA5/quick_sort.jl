# *********************************************
#  * EDA -  Bubble Sort
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: Mar 19, 2024 
#  *********************************************

# best case - nlogn
# worst case - n^2

"""
--------------------------------------------------------------------------------------
                        Quick Sort Method
"""

function quicksort!(A::Array{T}, p, r) where T
    if p < r
        q = partition!(A, p, r)
        quicksort!(A, p, q-1) # sort the left side
        quicksort!(A, q+1, r) # sort the right side
    end
end

function partition!(A::Array{T}, p, r) where T
    x = A[r] # pivot
    i = p - 1
    for j = p : r - 1 # run trough the array
        if A[j] <= x
            i = i + 1 # marks the first big element
            temp = A[i]
            A[i] = A[j]
            A[j] = temp
        end
    end
    temp = A[i + 1]
    A[i + 1] = A[r]
    A[r] = temp
    return i + 1    
end


quick = [2, 8, 7, 1, 3, 5, 6, 4]
println("Original: ", quick)
quicksort!(quick, 1, length(quick))
println("Quick: ", quick)


#--------------------------------------------------------------------------------------

"""
--------------------------------------------------------------------------------------
                        Random Quick Sort Method
"""

function randomquicksort!(A::Array{T}, p, r) where T
    if p < r
        q = randompartition!(A, p, r)
        randomquicksort!(A, p, q-1) # sort the left side
        randomquicksort!(A, q+1, r) # sort the right side
    end
end

function randompartition!(A::Array{T}, p, r) where T
    i = rand(p:r) # randomize the pivot by permutating wich element is in the last position
    temp = A[i]
    A[i] = A[r]
    A[r] = temp
    return partition!(A, p, r)
end


randomquick = [2, 8, 7, 1, 3, 5, 6, 4]
println("Original: ", randomquick)
randomquicksort!(randomquick, 1, length(randomquick))
println("RandomQuick: ", randomquick)

