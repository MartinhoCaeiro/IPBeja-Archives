# *********************************************
#  * EDA -  Arvore Binária de Pesquisa = Binary Search Tree
#  * Author: Yara de Sounoa
#  * Number: 23503
#  * Creation Date: May 19, 2024 
#  *********************************************

include("./RB_binary_search_tree.jl")



# ------------------------------------------------------------------------------------------------------------------------
# Testing Binary Tree


function test_insertion()
    mem = MemoryBinaryTreeRB(10)
    Tree = BinaryTreeRB(mem)

    # Define the keys to insert
    keys = [30, 47, 88, 97, 27, 13, 63]
    println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])
    # Insert each key into the tree
    for key in keys
        RB_insert!(Tree, key)
    end

    # Perform inorder tree walk and print the tree structure
    inorder_tree_walk(Tree, Tree.root)

    println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])
end


function test_left_rotation()
    mem = MemoryBinaryTreeRB(10)
    tree = BinaryTreeRB(mem)

    keys = [30, 47, 88, 97, 27, 13, 63]
    for key in keys
        RB_insert!(tree, key)
    end

    println("Before left rotation:")
    inorder_tree_walk(tree, tree.root)

    x = recursive_tree_search(tree, tree.root, 47)
    left_rotate!(tree, x)

    println("After left rotation:")
    inorder_tree_walk(tree, tree.root)
end


function test_right_rotation()
    mem = MemoryBinaryTreeRB(10)
    tree = BinaryTreeRB(mem)

    keys = [30, 47, 88, 97, 27, 13, 63]
    for key in keys
        RB_insert!(tree, key)
    end

    println("Before right rotation:")
    inorder_tree_walk(tree, tree.root)

    x = recursive_tree_search(tree, tree.root, 47)
    right_rotate!(tree, x)

    println("After right rotation:")
    inorder_tree_walk(tree, tree.root)
end


function test_deletion()
    mem = MemoryBinaryTreeRB(10)
    tree = BinaryTreeRB(mem)

    keys = [30, 47, 88, 97, 27, 13, 63]
    for key in keys
        RB_insert!(tree, key)
    end

    println("Before deletion:")
    inorder_tree_walk(tree, tree.root)

    deleted_key = 47
    z = recursive_tree_search(tree, tree.root, deleted_key)
    RB_delete(tree, z)

    println("After deletion of $(deleted_key):")
    inorder_tree_walk(tree, tree.root)
end


function test_tree_minimum()
    mem = MemoryBinaryTreeRB(10)
    tree = BinaryTreeRB(mem)

    keys = [30, 47, 88, 97, 27, 13, 63]
    for key in keys
        RB_insert!(tree, key)
    end

    min_node = tree_minimum(tree, tree.root)
    println("Minimum key in the tree: $(tree.mem.key[min_node])")
end

function test_tree_maximum()
    mem = MemoryBinaryTreeRB(10)
    tree = BinaryTreeRB(mem)

    keys = [30, 47, 88, 97, 27, 13, 63]
    for key in keys
        RB_insert!(tree, key)
    end

    min_node = tree_maximum(tree, tree.root)
    println("Maximum key in the tree: $(tree.mem.key[min_node])")
end

function run_all_tests()

    println("\nTesting insertion:")
    test_insertion()

    println("\nTesting left rotation:")
    test_left_rotation()

    println("\nTesting right rotation:")
    test_right_rotation()

    println("\nTesting deletion:")
    test_deletion()

    println("\nTesting tree minimum:")
    test_tree_minimum()

    println("\nTesting tree maximum:")
    test_tree_maximum()
end

run_all_tests()