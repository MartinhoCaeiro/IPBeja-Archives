# *********************************************
#  * EDA -  Arvore Binária de Pesquisa = Binary Search Tree
#  * Author: Yara de Sounoa
#  * Number: 23503
#  * Creation Date: May 19, 2024 
#  *********************************************

include("String_RB_binary_search_tree.jl")


# ------------------------------------------------------------------------------------------------------------------------
# Testing Binary Tree



function test_insertion(names)
    mem = MemoryBinaryTreeRB(15)
    Tree = BinaryTreeRB(mem)

    # Define the keys to insert

    println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])
    # Insert each key into the tree
    for name in names
        RB_insert!(Tree, name)
    end

    # Perform inorder tree walk and print the tree structure
    inorder_tree_walk(Tree, Tree.root)

    println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])

end


println("\nTesting insertion:")
test_insertion(names)



# for name in names
#     println(name.nome)
# end