using Printf
include("../EDA6/stack.jl")

mutable struct Stack
    S::Array{Int}
    top::Int
    Stack(n) = new(Array{Int}(undef, n), 0)
end

mutable struct Nomes
    key::Int
    nome::String
end

function Nomes(nome::String)
    key = sum([Int(c) for c in nome])
Nomes(key, nome)
end

mutable struct MemoryBinaryTreeRB
    key::Array{Union{Nothing,Nomes}}
    p::Array{Int64}
    left::Array{Int64}
    right::Array{Int64}
    color::Array{Int}
    free::Stack
end

function MemoryBinaryTreeRB(n::Int)
    S = Stack(n)
    for x::Int = 2:n
        push!(S, x)
    end
    MemoryBinaryTreeRB(fill(nothing, n),
        ones(Int64, n),
        ones(Int64, n),
        ones(Int64, n),
        ones(Int, n),
        S)
end

mutable struct BinaryTreeRB
    mem::MemoryBinaryTreeRB
    root::Int
    BinaryTreeRB(mem::MemoryBinaryTreeRB) = new(mem, NIL)
end

const RED = 0
const BLACK = 1
const NIL = 1

function allocate_object!(mem::MemoryBinaryTreeRB)
    return pop!(mem.free)
end

function free_object!(mem::MemoryBinaryTreeRB, x)
    push!(mem.free, x)
end

function imprimirRB(T::BinaryTreeRB, x::Int)
    key = T.mem.key[x] !== nothing ? T.mem.key[x].key : 0

    if T.mem.p[x] != NIL
        p = T.mem.key[T.mem.p[x]] !== nothing ? T.mem.key[T.mem.p[x]].key : 0
    else
        p = 0
    end

    if T.mem.left[x] != NIL
        left = T.mem.key[T.mem.left[x]] !== nothing ? T.mem.key[T.mem.left[x]].key : 0
    else
        left = 0
    end

    if T.mem.right[x] != NIL
        right = T.mem.key[T.mem.right[x]] !== nothing ? T.mem.key[T.mem.right[x]].key : 0
    else
        right = 0
    end

    color = T.mem.color[x] == RED ? "RED" : "BLACK"

    @printf("pos => %3d | key = %3d | p => %3d | left => %3d | right => %3d | color = %s\n",
        x, key, p, left, right, color)
end

function inorder_tree_walk(T::BinaryTreeRB, x::Int)
    if x != NIL
        inorder_tree_walk(T, T.mem.left[x])
        imprimirRB(T, x)
        inorder_tree_walk(T, T.mem.right[x])
    end
end

function inorder_tree_walk_arr(T::BinaryTreeRB, x::Int, arr=Any[])
    if x != NIL
        inorder_tree_walk_arr(T, T.mem.left[x], arr)
        push!(arr, x)
        inorder_tree_walk_arr(T, T.mem.right[x], arr)
    end
    return arr
end

function left_rotate!(T::BinaryTreeRB, x::Int)
    y = T.mem.right[x]
    T.mem.right[x] = T.mem.left[y]
    if T.mem.left[y] != NIL
        T.mem.p[T.mem.left[y]] = x
    end
    T.mem.p[y] = T.mem.p[x]
    if T.mem.p[x] == NIL
        T.root = y
    else
        if x == T.mem.left[T.mem.p[x]]
            T.mem.left[T.mem.p[x]] = y
        else
            T.mem.right[T.mem.p[x]] = y
        end
    end
    T.mem.left[y] = x
    T.mem.p[x] = y
end

function right_rotate!(T::BinaryTreeRB, x::Int)
    y = T.mem.left[x]
    T.mem.left[x] = T.mem.right[y]
    if T.mem.right[y] != NIL
        T.mem.p[T.mem.right[y]] = x
    end
    T.mem.p[y] = T.mem.p[x]
    if T.mem.p[x] == NIL
        T.root = y
    else
        if x == T.mem.right[T.mem.p[x]]
            T.mem.right[T.mem.p[x]] = y
        else
            T.mem.left[T.mem.p[x]] = y
        end
    end
    T.mem.right[y] = x
    T.mem.p[x] = y
end

function RB_insert_fixup!(T::BinaryTreeRB, z::Int)
    while T.mem.color[T.mem.p[z]] == RED
        if T.mem.p[z] == T.mem.left[T.mem.p[T.mem.p[z]]]
            y = T.mem.right[T.mem.p[T.mem.p[z]]]
            if T.mem.color[y] == RED
                T.mem.color[T.mem.p[z]] = BLACK
                T.mem.color[y] = BLACK
                T.mem.color[T.mem.p[T.mem.p[z]]] = RED
                z = T.mem.p[T.mem.p[z]]
            else
                if z == T.mem.right[T.mem.p[z]]
                    z = T.mem.p[z]
                    left_rotate!(T, z)
                end
                T.mem.color[T.mem.p[z]] = BLACK
                T.mem.color[T.mem.p[T.mem.p[z]]] = RED
                right_rotate!(T, T.mem.p[T.mem.p[z]])
            end
        else
            y = T.mem.left[T.mem.p[T.mem.p[z]]]
            if T.mem.color[y] == RED
                T.mem.color[T.mem.p[z]] = BLACK
                T.mem.color[y] = BLACK
                T.mem.color[T.mem.p[T.mem.p[z]]] = RED
                z = T.mem.p[T.mem.p[z]]
            else
                if z == T.mem.left[T.mem.p[z]]
                    z = T.mem.p[z]
                    right_rotate!(T, z)
                end
                T.mem.color[T.mem.p[z]] = BLACK
                T.mem.color[T.mem.p[T.mem.p[z]]] = RED
                left_rotate!(T, T.mem.p[T.mem.p[z]])
            end
        end
    end
    T.mem.color[T.root] = BLACK
end

function RB_insert!(T::BinaryTreeRB, key::Nomes)
    z = allocate_object!(T.mem)
    T.mem.key[z] = key

    y = NIL
    x = T.root
    while x != NIL
        y = x
        if T.mem.key[z].key < T.mem.key[x].key
            x = T.mem.left[x]
        else
            x = T.mem.right[x]
        end
    end

    T.mem.p[z] = y
    if y == NIL
        T.root = z
    else
        if T.mem.key[z].key < T.mem.key[y].key
            T.mem.left[y] = z
        else
            T.mem.right[y] = z
        end
    end
    T.mem.left[z] = NIL
    T.mem.right[z] = NIL
    T.mem.color[z] = RED
    RB_insert_fixup!(T, z)
end

function tree_minimum(T::BinaryTreeRB, x::Int)
    while T.mem.left[x] != NIL
        x = T.mem.left[x]
    end
    imprimirRB(T, x)
    x
end

function tree_maximum(T::BinaryTreeRB, x::Int)
    while T.mem.right[x] != NIL
        x = T.mem.right[x]
    end
    imprimirRB(T, x)
    x
end

function RB_transplant!(T::BinaryTreeRB, u::Int, v::Int)
    if T.mem.p[u] == NIL
        T.root = v
    else
        if u == T.mem.left[T.mem.p[u]]
            T.mem.left[T.mem.p[u]] = v
        else
            T.mem.right[T.mem.p[u]] = v
        end
    end
    T.mem.p[v] = T.mem.p[u]
end

function RB_delete_fixup!(T::BinaryTreeRB, x::Int)
    while x != T.root && T.mem.color[x] == BLACK
        if x == T.mem.left[T.mem.p[x]]
            w = T.mem.right[T.mem.p[x]]
            if T.mem.color[w] == RED
                T.mem.color[w] = BLACK
                T.mem.color[T.mem.p[w]] = RED
                left_rotate!(T, T.mem.p[x])
                w = T.mem.right[T.mem.p[x]]
            end
            if T.mem.color[T.mem.left[w]] == BLACK && T.mem.color[T.mem.right[w]] == BLACK
                T.mem.color[w] = RED
                x = T.mem.p[x]
            else
                if T.mem.color[T.mem.right[w]] == BLACK
                    T.mem.color[T.mem.left[w]] = BLACK
                    T.mem.color[w] = RED
                    right_rotate!(T, w)
                    w = T.mem.right[T.mem.p[x]]
                end
                T.mem.color[w] = T.mem.color[T.mem.p[x]]
                T.mem.color[T.mem.p[x]] = BLACK
                T.mem.color[T.mem.right[w]] = BLACK
                left_rotate!(T, T.mem.p[x])
                x = T.root
            end
        else
            w = T.mem.left[T.mem.p[x]]
            if T.mem.color[w] == RED
                T.mem.color[w] = BLACK
                T.mem.color[T.mem.p[w]] = RED
                right_rotate!(T, T.mem.p[x])
                w = T.mem.left[T.mem.p[x]]
            end
            if T.mem.color[T.mem.right[w]] == BLACK && T.mem.color[T.mem.left[w]] == BLACK
                T.mem.color[w] = RED
                x = T.mem.p[x]
            else
                if T.mem.color[T.mem.left[w]] == BLACK
                    T.mem.color[T.mem.right[w]] = BLACK
                    T.mem.color[w] = RED
                    left_rotate!(T, w)
                    w = T.mem.left[T.mem.p[x]]
                end
                T.mem.color[w] = T.mem.color[T.mem.p[x]]
                T.mem.color[T.mem.p[x]] = BLACK
                T.mem.color[T.mem.left[w]] = BLACK
                right_rotate!(T, T.mem.p[x])
                x = T.root
            end
        end
    end
    T.mem.color[x] = BLACK
end

function RB_delete!(T::BinaryTreeRB, z::Int)
    y = z
    y_original_color = T.mem.color[y]
    if T.mem.left[z] == NIL
        x = T.mem.right[z]
        RB_transplant!(T, z, T.mem.right[z])
    else
        if T.mem.right[z] == NIL
            x = T.mem.left[z]
            RB_transplant!(T, z, T.mem.left[z])
        else
            y = tree_minimum(T, T.mem.right[z])
            y_original_color = T.mem.color[y]
            x = T.mem.right[y]
            if T.mem.p[y] == z
                T.mem.p[x] = y
            else
                RB_transplant!(T, y, T.mem.right[y])
                T.mem.right[y] = T.mem.right[z]
                T.mem.p[T.mem.right[y]] = y
            end
            RB_transplant!(T, z, y)
            T.mem.left[y] = T.mem.left[z]
            T.mem.p[T.mem.left[y]] = y
            T.mem.color[y] = T.mem.color[z]
        end
    end
    if y_original_color == BLACK
        RB_delete_fixup!(T, x)
    end
    free_object!(T.mem, z)
end

function recursive_tree_search(T::BinaryTreeRB, x::Int, k::Int)
    if x == NIL || (T.mem.key[x] !== nothing && k == T.mem.key[x].key)
        return x
    end
    if k < T.mem.key[x].key
        return recursive_tree_search(T, T.mem.left[x], k)
    else
        return recursive_tree_search(T, T.mem.right[x], k)
    end
end

function test_insertion()
    mem = MemoryBinaryTreeRB(15)
    Tree = BinaryTreeRB(mem)

    # Define the keys to insert
    names = [
        Nomes("Luis Miguel Gomes Tavares"),
        Nomes("Isabel Sofia Sousa Brito"),
        Nomes("Elsa Soares Rodrigues"),
        Nomes("Joao Carlos Martins"),
        Nomes("Luis Filipe Garcia"),
        Nomes("Armando Jose Ventura"),
        Nomes("Jose Jasnau Caeiro"),
        Nomes("Joao Paulo Barros"),
        Nomes("Luis Carlos Bruno"),
        Nomes("Rui Miguel Silva"),
        Nomes("Maria Teresa Godinho"),
    ]

    println("Stack: ", isempty(Tree.mem.free.S[1:Tree.mem.free.top]) ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])

    for name in names
        RB_insert!(Tree, name)
    end

    # inorder_tree_walk(Tree, Tree.root)

    # for i in inorder_tree_walk_arr(Tree, Tree.root, names)
    #     println(filter(name -> name.key == Tree.mem.key[i], names))
    # end

    println("Stack: ", isempty(Tree.mem.free.S[1:Tree.mem.free.top]) ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])
end

println("\nTesting insertion:")
test_insertion()
