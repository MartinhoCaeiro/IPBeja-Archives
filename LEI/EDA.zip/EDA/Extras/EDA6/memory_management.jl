# *********************************************
#  * EDA -  gestão de memoria = memory management
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 14, 2024 
#  *********************************************

function listInsert!(L, x)
    x.next = L.head
    if L.head !== nothing
        L.head.prev = x
    end
    L.head = x
    x.prev = nothing
end

# Function to print only the linked lists keys
function printKeys(L)
    # print("Linked List Keys: ")
    x = L.head
    while x !== nothing
        print(x.key, " ")
        x = x.next
    end
    # println()
end

# Define a Node structure for the linked list
mutable struct Node
    key::Int
    prev::Union{Node, Nothing}
    next::Union{Node, Nothing}
end

# Define a LinkedList structure
mutable struct LinkedList
    head::Union{Node, Nothing}
    # tail::Union{Node, Nothing}
end



# Variável global para a lista livre
global free::Union{Node, Nothing} = nothing

function allocateObject()
    global free  # Declarar a variável global dentro da função
    if free === nothing
        error("Out of memory!")
    else 
        x = free
    end
    free = x.next
    return x
end

function freeObject(x)
    global free  # Declarar a variável global dentro da função
    x.next = free
    free = x
end



# Testar o sistema de gestão de memória
# Criar uma lista ligada
function initLinkedList()
    return LinkedList(nothing)
end

L = initLinkedList()

# Inserir alguns nós na lista ligada
node1 = Node(1, nothing, nothing)
node2 = Node(4, nothing, nothing)
node3 = Node(16, nothing, nothing)
node4 = Node(9, nothing, nothing)
node5 = Node(-1, nothing, nothing)
node6 = Node(-1, nothing, nothing)
node7 = Node(-1, nothing, nothing)
listInsert!(L, node1)
listInsert!(L, node2)
listInsert!(L, node3)
listInsert!(L, node4)
listInsert!(L, node5)
listInsert!(L, node6)
listInsert!(L, node7)



print("Original: ")
printKeys(L)
println()


# Liberar um objeto de memória
freeObject(L.head)

print("After free: ")
printKeys(L)
println()
println("Free node: ", free)


# Alocar um novo objeto de memória
# new_node = allocateObject()
# new_node.key = 4


# print("After allocate: ")
# printKeys(L)
# println()


