
# *********************************************
#  * EDA -  Arvore N-aria = N-ary Tree
#  * Author: Yara de Sounoa
#  * Number: 23503
#  * Creation Date: May 21, 2024 
#  *********************************************

include("../EDA6/stack.jl")

mutable struct Stack
    S::Array{Int}
    top::Int
    Stack(n) = new(Array{Int}(undef, n), 0)
end

const NIL = nothing


mutable struct MemoryNaryTree
    p::Vector{Union{Nothing, Int64}} # parent
    children::Vector{Vector{Union{Nothing, Int64}}} # children
    key::Vector{Int64}
    free::Stack
end

function MemoryNaryTree(n)
    S = Stack(n)
    for x in 1:n
        push!(S, x)
    end

    MemoryNaryTree(
        fill(NIL, n),
        [Vector{Union{Nothing, Int64}}() for _ in 1:n],
        zeros(Int64, n),
        S
    )
end



mutable struct NaryTree
    root::Union{Nothing, Int64}
    mem::MemoryNaryTree

    NaryTree(mem::MemoryNaryTree) = new(NIL, mem)
end


function allocate_object!(mem::MemoryNaryTree)
    return pop!(mem.free)
end

function free_object!(mem::MemoryNaryTree, x)
    push!(mem.free, x)
end



function add_node!(T::NaryTree, key::Int64, parent::Union{Nothing, Int64} = nothing)
    x = allocate_object!(T.mem)
    T.mem.key[x] = key
    T.mem.p[x] = parent
    if parent === nothing
        T.root = x
    else
        append!(T.mem.children[parent], x)
    end
    return x
end


function remove_node!(T::NaryTree, x::Int64)
    parent = T.mem.p[x]
    if parent !== nothing
        T.mem.children[parent] = filter(x -> x != x, T.mem.children[parent])
    end
    for child in T.mem.children[x]
        if child !== nothing
            remove_node!(T, child)
        end
    end
    T.mem.children[x] = Vector{Union{Nothing, Int64}}()  # Reset children vector
    free_object!(T.mem, x)
end


function search!(T::NaryTree, node_index::Union{Nothing, Int64}, key::Int64)
    if node_index === nothing
        return nothing
    elseif T.mem.key[node_index] == key
        return node_index
    else
        for child in T.mem.children[node_index]
            if child !== nothing
                result = search!(T, child, key)
                if result !== nothing
                    return result
                end
            end
        end
        return nothing
    end
end


function print_tree!(T::NaryTree, node_index::Union{Nothing, Int64}, depth::Int = 0)
    if node_index === nothing
        return
    end
    println("  "^depth * "Node $(T.mem.key[node_index]): Children => ", [T.mem.key[child] for child in T.mem.children[node_index] if child !== nothing])
    for child in T.mem.children[node_index]
        if child !== nothing
            print_tree!(T, child, depth + 1)
        end
    end
end



# -----------------------------------------------------------------------------------------------------------------------------------------
# Testing the N-ary Tree

function test_nary_tree()
    mem = MemoryNaryTree(20) # n=10 nodes
    T = NaryTree(mem)

    println("Stack: ", stackEmpty(T.mem.free) == true ? "Empty" : T.mem.free.S[1:T.mem.free.top])

    # Add nodes
    root = add_node!(T, 1)
    child2 = add_node!(T, 2, root)
    child3 = add_node!(T, 3, root)
    child4 = add_node!(T, 4, root)
    child5 = add_node!(T, 11, root)

    add_node!(T, 5, child2)
    add_node!(T, 6, child2)
    add_node!(T, 7, child2)
    add_node!(T, 8, child3)
    add_node!(T, 9, child4)
    add_node!(T, 10, child4)

    # Print tree
    println("Initial N-ary Tree:")
    print_tree!(T, T.root)

    println("Stack: ", stackEmpty(T.mem.free) == true ? "Empty" : T.mem.free.S[1:T.mem.free.top])

    # Search for a node
    key_to_search = 7
    search_result = search!(T, T.root, key_to_search)
    println("\nSearch for key $key_to_search: ", search_result !== nothing ? "Found" : "Not found")

    # Remove a node
    key_to_remove = 4
    node_to_remove = search!(T, T.root, key_to_remove)
    if node_to_remove !== nothing
        remove_node!(T, node_to_remove)
    end

    # Print tree after removal
    println("\nN-ary Tree after removing key $key_to_remove:")
    print_tree!(T, T.root)
end

test_nary_tree()
