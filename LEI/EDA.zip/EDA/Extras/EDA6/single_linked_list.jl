# *********************************************
#  * EDA - Single Linked List
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: May 01, 2024 
#  *********************************************


include("stack.jl")

mutable struct Stack
    S::Array{Int}
    top
    Stack(n) = new(Array{Int}(undef, n), 0)
  end
  


mutable struct MemorySingleLinkedList
    key::Array{Int}
    next::Array{Int64}
    free::Stack
    NIL
end


function MemorySingleLinkedList( n )
    S = Stack( n )
    for x::Int64 = 1:n
        push!(S, x)
    end
    MemorySingleLinkedList( zeros(Int64,  n ),
                            zeros(Int64,  n ),
                            S,
                            1 )

end



function allocate_object!( mem::MemorySingleLinkedList )
    pop!( mem.free )
end


function free_object!( mem::MemorySingleLinkedList, x )
    push!( mem.free, x )
end

const NIL = 0



mutable struct SingleLinkedList
    mem::MemorySingleLinkedList
    head

    SingleLinkedList( mem::MemorySingleLinkedList ) = new( mem, NIL )
end




function list_insert!( l::SingleLinkedList, key )
    x = allocate_object!( l.mem )
    l.mem.key[ x ] = key
    
    l.mem.next[ x ] = l.head
    l.head = x
end


function list_delete!(l::SingleLinkedList, x::Int64)
    if x < 1
        return 
    end
    if l.head == x
        # If the node to delete is the head, update the head
        l.head = l.mem.next[x]
    else
        # Otherwise, find the predecessor of the node to delete
        prev = l.head
        while l.mem.next[prev] != x
            prev = l.mem.next[prev]
        end
        # Update the next pointer of the predecessor to skip over the deleted node
        l.mem.next[prev] = l.mem.next[x]
    end
    # Free the memory associated with the deleted node
    free_object!(l.mem, x)
end


function list_search( l, key )
    x = l.head
    while x != NIL && l.mem.key[ x ] != key 
        x = l.mem.next[ x ]
    end
    x
end



# ------------------------------------------------------------------------------------------------------------------------



function printListKeys(l::SingleLinkedList)
    print("Linked List Keys: ")
    current = l.head
    while current != NIL
        print(l.mem.key[current], " ")
        current = l.mem.next[current]
    end
    println()
    println("Head:", l.head == NIL ? "NIL" : l.head)
    println("Memory Stack: ", l.mem.free.S[1:l.mem.free.top])
    println("------")
end


# Criando uma memória para as listas simplesmente ligadas
list_size = 6
mem = MemorySingleLinkedList(list_size)

# Criando uma lista simplesmente ligada
l = SingleLinkedList(mem)
println("Memory Stack: ", l.mem.free.S[1:l.mem.free.top])

# Inserindo elementos na lista
list_insert!(l, 33)
list_insert!(l, 40)
list_insert!(l, 57)
list_insert!(l, 76)
list_insert!(l, 98)

# Printing the state of the list
printListKeys(l)
println()


# Procurando um elemento na lista
# println("Posição do elemento 40 na lista:", list_search(l, 40))

# Removendo um elemento da lista
# list_delete!(l, list_search(l, 400))

# Procurando novamente o elemento removido
search = list_search(l, 33)
println("Posição do elemento 40 após remoção:",  search== 0 ? " Not Found" :  search)
println()

# Printing the state of the list
# printListKeys(l)
