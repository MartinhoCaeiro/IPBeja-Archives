# *********************************************
#  * EDA -  Arvore Binária = Binary Tree
#  * Author: Yara de Sounoa
#  * Number: 23503
#  * Creation Date: April 23, 2024 
#  *********************************************


include("stack.jl")

mutable struct Stack
  S::Array{Int}
  top
  Stack(n) = new(Array{Int}(undef, n), 0)
end


const NIL = nothing

mutable struct MemoryBinaryTree
  p::Array{Union{Nothing,Int64}} # parent
  left::Array{Union{Nothing,Int64}}
  right::Array{Union{Nothing,Int64}}
  key::Array{Int64}
  free::Stack
  NIL
end


function MemoryBinaryTree(n)
  S = Stack(n)
  for x::Int = 1:n
    push!(S, x)
  end

  MemoryBinaryTree(fill(NIL, n),
    fill(NIL, n),
    fill(NIL, n),
    zeros(Int, n),
    S,
    1)
end

mutable struct BinaryTree
  root
  mem::MemoryBinaryTree

  BinaryTree(mem::MemoryBinaryTree) = new(NIL, mem)
end



function allocate_object!(mem::MemoryBinaryTree)
  pop!(mem.free)
end

function free_object!(mem::MemoryBinaryTree, x)
  push!(mem.free, x)
end




function treeInsert(T::BinaryTree, key)
  y = nothing
  x = T.root
  while x !== nothing
    y = x
    rng = rand(0:1)
    if rng == 0
      x = T.mem.left[x]
    else
      x = T.mem.right[x]
    end
  end

  index = allocate_object!(T.mem)
  T.mem.key[index] = key

  T.mem.p[index] = y

  if y === nothing
    T.root = index
  elseif T.mem.left[y] === nothing && T.mem.right[y] === nothing
    rng = rand(0:1)
    if rng == 0
      T.mem.left[y] = index
    else
      T.mem.right[y] = index
    end
  elseif T.mem.left[y] === nothing
    T.mem.left[y] = index
  else
    T.mem.right[y] = index
  end
end


function Search(T::BinaryTree, node_index, key)
  if node_index === nothing || T.mem.key[node_index] == key
      return node_index
  else
      left_result = Search(T::BinaryTree,T.mem.left[node_index], key)
      right_result = Search(T::BinaryTree,T.mem.right[node_index], key)
      return left_result !== nothing ? left_result : right_result
  end
end

function treeDelete(T::BinaryTree, key)
  function removeNode(node_index)
      if T.mem.p[node_index] === nothing
          T.root = nothing
      elseif node_index == T.mem.left[T.mem.p[node_index]]
          T.mem.left[T.mem.p[node_index]] = nothing
      else
          T.mem.right[T.mem.p[node_index]] = nothing
      end
      free_object!(T.mem, node_index)
  end
  
  

  node_index = Search(T::BinaryTree,T.root, key)
  if node_index !== nothing
      removeNode(node_index)
  end
end


function treeDeletePromote(T::BinaryTree, key)
  function promote(u, v)
      if T.mem.p[u] === nothing
          T.root = v
      elseif u == T.mem.left[T.mem.p[u]]
          T.mem.left[T.mem.p[u]] = v
      else
          T.mem.right[T.mem.p[u]] = v
      end
      if v !== nothing
          T.mem.p[v] = T.mem.p[u]
      end
  end
  
  function successor(node_index)
      if T.mem.right[node_index] === nothing
          return T.mem.left[node_index]
      else
          y = minimum(T.mem.right[node_index])
          if T.mem.p[y] !== node_index
              promote(y, T.mem.right[y])
              T.mem.right[y] = T.mem.right[node_index]
              T.mem.p[T.mem.right[y]] = y
          end
          return y
      end
  end
  
  function minimum(node_index)
      while T.mem.left[node_index] !== nothing
          node_index = T.mem.left[node_index]
      end
      return node_index
  end
  
  z = Search(T::BinaryTree,T.root, key)  
  if z === nothing
      return  # Node not found, do nothing
  end
  
  if T.mem.left[z] === nothing
      promote(z, T.mem.right[z])
  elseif T.mem.right[z] === nothing
      promote(z, T.mem.left[z])
  else
      y = successor(z)
      if T.mem.p[y] !== z
          promote(y, T.mem.right[y])
          T.mem.right[y] = T.mem.right[z]
          T.mem.p[T.mem.right[y]] = y
      end
      promote(z, y)
      T.mem.left[y] = T.mem.left[z]
      T.mem.p[T.mem.left[y]] = y
  end
  
  free_object!(T.mem, z)  # Assuming you have a function to free the memory of the deleted node
end


# ------------------------------------------------------------------------------------------------------------------------

# Testing Binarry Tree

function printNodeDetails(T::BinaryTree, node_index)
  println("Node at index: ", node_index)
  println("Key: ", T.mem.key[node_index])
  println("Parent: ", T.mem.p[node_index] === nothing ? "nil" : T.mem.key[T.mem.p[node_index]])
  println("Left Child: ", T.mem.left[node_index] === nothing ? "nil" : T.mem.key[T.mem.left[node_index]])
  println("Right Child: ", T.mem.right[node_index] === nothing ? "nil" : T.mem.key[T.mem.right[node_index]])
  println()
end

function printTreeInfo(T::BinaryTree)
  function printNodeInfo(node_index)
    if node_index === nothing
      println("Key: nil, Left: nil, Right: nil, Parent: nil")
    else
      println(
        "Key: ", T.mem.key[node_index],
        ", Left: ", getLeftKey(node_index),
        ", Right: ", getRightKey(node_index),
        ", Parent: ", getParentKey(node_index)
      )
    end
  end

  function getLeftKey(node_index)
    if T.mem.left[node_index] === nothing
      return "nil"
    else
      return T.mem.key[T.mem.left[node_index]]
    end
  end

  function getRightKey(node_index)
    if T.mem.right[node_index] === nothing
      return "nil"
    else
      return T.mem.key[T.mem.right[node_index]]
    end
  end

  function getParentKey(node_index)
    if T.mem.p[node_index] === nothing
      return "nil"
    else
      return T.mem.key[T.mem.p[node_index]]
    end
  end

  function printInOrder(node_index)
    if node_index !== nothing
      printInOrder(T.mem.left[node_index])
      printNodeInfo(node_index)
      printInOrder(T.mem.right[node_index])
    end
  end

  printInOrder(T.root)
end

# Insert
new = [30, 47, 88, 97, 27, 13, 63]

mem = MemoryBinaryTree(10)
Tree = BinaryTree(mem)


println("Stack: ", Tree.mem.free.S)

for item in new
  treeInsert(Tree, item)
  # printNodeDetails(Tree, Tree.root)
end

#PRINT A ARVORE BINARIA
printTreeInfo(Tree)

println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])


treeDeletePromote(Tree, 88)

#PRINT A ARVORE BINARIA
printTreeInfo(Tree)

println("Stack: ", stackEmpty(Tree.mem.free) == true ? "Empty" : Tree.mem.free.S[1:Tree.mem.free.top])
