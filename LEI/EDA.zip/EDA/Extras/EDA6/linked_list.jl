# *********************************************
#  * EDA -  Lista Ligada = Liked List
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 14, 2024 
#  *********************************************


function listSearch!(L, k)
    x = L.head
    while x !== nothing && x.key != k
        x = x.next
    end
    return x
end

function listDelete!(L, x)
    if x.prev !== nothing
        x.prev.next = x.next
    else
        L.head = x.next
    end
        
    if x.next !== nothing
        x.next.prev = x.prev
    end
end

function listInsert!(L, x)
    x.next = L.head
    if L.head !== nothing
        L.head.prev = x
    end
    L.head = x
    x.prev = nothing
end


# ------------------------------------------------------------------------------------------------------------------------

# Testing Liked List Properties

# Define a Node structure for the linked list
mutable struct Node
    key::Int
    prev::Union{Node, Nothing}
    next::Union{Node, Nothing}
end

# Define a LinkedList structure
mutable struct LinkedList
    head::Union{Node, Nothing}
    # tail::Union{Node, Nothing}
end


# Function to initialize an empty linked list
function initLinkedList()
    return LinkedList(nothing)
end

# Function to print only the linked lists keys
function printKeys(L)
    print("Linked List Keys: ")
    x = L.head
    while x !== nothing
        print(x.key, " ")
        x = x.next
    end
    println()
end

# Function to print the state of the linked list
function printLinkedList(L::LinkedList)
    # println("Linked List:")
    printKeys(L)
    if L.head === nothing
        println("Head: nothing")
    else
        println("Head: ", L.head.key)
    end
    # if L.tail === nothing
    #     println("Tail: nothing")
    # else
    #     println("Tail: ", L.tail.key)
    # end
    println("------")
end

# Create a linked list and perform operations
L = initLinkedList()

# Insert n nodes into the linked list
n = 5
for i = 1 : n
    listInsert!(L, Node(i, nothing, nothing))
end
# node1 = Node(1, nothing, nothing)
# node2 = Node(2, nothing, nothing)
# node3 = Node(3, nothing, nothing)
# listInsert!(L, node1)
# listInsert!(L, node2)
# listInsert!(L, node3)

# Print the state of the linked list
printLinkedList(L)

# Search for a node in the linked list
result = listSearch!(L, 2)
println("Search result: ", result.key)
println("------")


# Delete the chosen node
# listDelete!(L, node2)
node_to_delete = listSearch!(L, 3)
listDelete!(L, node_to_delete)

# Print the state of the linked list after deletion
printLinkedList(L)





