# *********************************************
#  * EDA -  Lista de Espera = Queue
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 2, 2024 
#  *********************************************

# lista de espera => FIFO ( first-in, first-out)

function enQueue(Q, x) # Insert
    Q.Q[Q.tail] = x
    if Q.tail == Q.length
        Q.tail = 1
    else
        Q.tail = Q.tail + 1
    end
end


function deQueue(Q) # Delete
    x =  Q.Q[Q.head]
    if Q.head == Q.length
        Q.head = 1
    else
        Q.head = Q.head + 1
    end
    return x
end


# Function to check if the queue is empty
function isEmpty(Q)
    # Check if the queue is filled with nothing and the head and tail are at the starting positions
    return all(x -> x === nothing, Q.Q) && Q.head == 1 && Q.tail == 1
end

# ------------------------------------------------------------------------------------------------------------------------

# Testing Queue properties

# Define Struct
mutable struct Queue
    Q:: Array{Union{Int, Nothing}} #Array{Int} # 
    head::Int
    tail::Int
    length::Int
    Queue(n) =  new(fill(nothing, n), 1, 1, n) #new(fill(-1, n), 1, 1, n) #
end


# Function to print the state of the queue
function printQueue(Q::Queue)
    println("Queue: ", Q.Q)
    println("Head: ", Q.head)
    println("Tail: ", Q.tail)
    println("Length: ", Q.length)
    println("------")
end


n = 5
# Create a queue with a length of n
Q = Queue(n)

# Check if the queue is initially empty
println("Is the queue empty? ", isEmpty(Q))

# Enqueue elements into the queue
println("Enqueuing elements:")
for i = 1:n
    x = rand(1:10)
    println("Enqueueing $x")
    enQueue(Q, x)
    printQueue(Q)
end

# Dequeue elements from the queue
println("Dequeuing elements:")
for i = 1:n
    println("Dequeuing ", deQueue(Q))
    printQueue(Q)
end







