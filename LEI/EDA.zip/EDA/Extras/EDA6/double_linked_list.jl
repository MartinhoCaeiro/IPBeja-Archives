# *********************************************
#  * EDA - Double Linked List
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: May 01, 2024 
#  *********************************************


mutable struct Stack
    S::Array{Int}
    top::Int
    Stack(n) = new(Array{Int}(undef, n), 0)
end

function stackempty(S)
    if S.top == 0
        return true
    else
        return false
    end
end

function push!(S, x)
    S.top = S.top + 1
    S.S[S.top] = x #S é o atrinuto da struct então quero aceder ao atributo (S) da struct (S)
end

function pop!(S)
    if stackempty(S)
        throw(DomainError("A lista está vazia.", "underflow"))
    else
        S.top = S.top - 1
        return S.S[S.top + 1]
    end
end

"""
    MemoryDoubleLinkedList
a estrutura de dados permite a representação
de listas duplamente ligadas com até n entradas
"""
mutable struct MemoryDoubleLinkedList
    key::Array{Int}
    prev::Array{Int64}
    next::Array{Int64}
    free::Stack
    NIL
end

"""
    MemoryDoubleLinkedList( n )
construtor de memória para n posições
"""
function MemoryDoubleLinkedList( n )
    S = Stack( n )
    for x::Int64 = 1:n
        push!(S, x)
    end
    MemoryDoubleLinkedList( zeros(Int64,  n ),
                            zeros(Int64,  n ),
                            zeros(Int64,  n ),
                            S,
                            1 )

end

"""
    allocate_object!( mem )

reserva memória para um objeto da lista duplamente ligada
"""
function allocate_object!( mem::MemoryDoubleLinkedList )
    pop!( mem.free )
end

"""
    free_object!( mem )

liberta memória para um objeto da lista duplamente ligada
"""
function free_object!( mem::MemoryDoubleLinkedList, x )
    push!( mem.free, x )
end

const NIL = 0

"""
    DoubleLinkedList

representação de lista duplamente ligada
"""
mutable struct DoubleLinkedList
    mem::MemoryDoubleLinkedList
    head

    DoubleLinkedList( mem::MemoryDoubleLinkedList ) = new( mem, NIL )
end

"""
    list_insert!( l::DoubleLinkedList, key )
inserção dum elemento da lista com o valor key
"""
function list_insert!( l::DoubleLinkedList, key )
    x = allocate_object!( l.mem )
    l.mem.key[ x ] = key
    
    l.mem.next[ x ] = l.head
    if l.head != NIL
        l.mem.prev[ l.head ] = x
    end
    l.head = x
    l.mem.prev[ x ] = NIL
end

"""
    list_delete!( l, x )
remove um elemento da lista na posição x da memória
"""
function list_delete!( l, x::Int64 )
    if l.mem.prev[ x ] != NIL
       l.mem.next[ l.mem.prev[ x ]] = l.mem.next[ x ] 
    else
        l.head = l.mem.next[ x ]
    end
    if l.mem.next[ x ] != NIL
        l.mem.prev[ l.mem.next[ x ]] = l.mem.prev[ x ]
    end
    free_object!( l.mem, x )
end

"""
    list_search( l, key )
pesquisa do elemento da lista l com a chave key
"""
function list_search( l, key )
    x = l.head
    while x != NIL && l.mem.key[ x ] != key
        x = l.mem.next[ x ]
    end
    x
end

"""
    allocate_list!( mem::MemoryDoubleLinkedList )

Reserva memória para uma nova lista ligada.
"""
function allocate_list!(mem::MemoryDoubleLinkedList)
    allocate_object!(mem)
end

"""
    free_list!( mem::MemoryDoubleLinkedList, x )

Liberta a memória alocada para uma lista ligada.
"""
function free_list!(mem::MemoryDoubleLinkedList, x::Int64)
    free_object!(mem, x)
end



# ------------------------------------------------------------------------------------------------------------------------


function printListState(l::DoubleLinkedList)
    println("State of the list:")
    println("Head:", l.head == NIL ? "NIL" : l.head)
    current = l.head
    while current != NIL
        prev_key = l.mem.prev[current] == NIL ? "NIL" : l.mem.key[l.mem.prev[current]]
        next_key = l.mem.next[current] == NIL ? "NIL" : l.mem.key[l.mem.next[current]]
        println("Key:", l.mem.key[current], " Prev:", prev_key, " Next:", next_key)
        current = l.mem.next[current]
    end
    println("Memory Stack: ", l.mem.free.S[1:l.mem.free.top])
end


function printListKeys(l::DoubleLinkedList)
    print("Linked List Keys: ")
    current = l.head
    while current != NIL
        print(l.mem.key[current], " ")
        current = l.mem.next[current]
    end
    println()
    println("Head:", l.head == NIL ? "NIL" : l.head)
    println("Memory Stack: ", l.mem.free.S[1:l.mem.free.top])
    println("------")
end


# Criando uma memória para as listas duplamente ligadas
mem = MemoryDoubleLinkedList(10)

# Criando uma lista duplamente ligada
l = DoubleLinkedList(mem)
println("Memory Stack: ", l.mem.free.S[1:l.mem.free.top])

# Inserindo elementos na lista
list_insert!(l, 5)
list_insert!(l, 10)
list_insert!(l, 15)

# Printing the state of the list
printListState(l)
printListKeys(l)
println()



# Procurando um elemento na lista
println("Posição do elemento 10 na lista:", list_search(l, 10))

# Removendo um elemento da lista
list_delete!(l, list_search(l, 10))

# Procurando novamente o elemento removido
println("Posição do elemento 10 após remoção:", list_search(l, 10))
println()

# Printing the state of the list
printListKeys(l)



list_insert!(l, 90)
# # Printing the state of the list
println()
# printListState(l)
printListKeys(l)
println()



# Criando uma nova lista e liberando a memória
mem2 = MemoryDoubleLinkedList(5)
list1 = DoubleLinkedList(mem2)
println("Memory Stack: ", list1.mem.free.S[1:list1.mem.free.top])
list_insert!(list1, 1)
list_insert!(list1, 2)
list_insert!(list1, 3)
free_list!(mem2, allocate_list!(mem2))
println()
printListKeys(list1)
println()

