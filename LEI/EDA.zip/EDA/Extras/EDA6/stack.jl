# *********************************************
#  * EDA -  Pihla = Stack
#  * Author: Yara de Souza
#  * Number: 23503
#  * Creation Date: April 2, 2024 
#  *********************************************

# pilha => LIFO ( last-in, first-out)

function stackEmpty(S)
    if S.top == 0
        return true
    else
        return false
    end
end

function pop!(S)
    if stackEmpty(S)
        println("Error: Overflow")
    else
        S.top = S.top - 1
        return S.S[S.top + 1]
    end
end

function push!(S, x)
    S.top = S.top + 1
    S.S[S.top] = x 
end


# ------------------------------------------------------------------------------------------------------------------------

# Testing Stack properties


# mutable struct StackNum
#     S::Array{Int}
#     top::Int
#     StackNum(n) = new(Array{Int}(undef, n), 0)
# end

# S = StackNum(10)

# println("Is the Stack empty: ", stackEmpty(S))

# # Populating my stack
# for i = 1 : 10
#     push!(S, rand(1:10))
# end

# println("My Stack: ", S.S[1:S.top])
# pop!(S)
# println("My Stack after pop: ", S.S[1:S.top])
# println("Is the Stack empty: ", stackEmpty(S))




# mutable struct StackChar
#     S::Array{Char}
#     top::Int
#     StackChar(n) = new(Array{Char}(undef, n), 0)
# end

# S = StackChar(10)

# println("Is the Stack empty: ", stackEmpty(S))

# # Populating my stack
# for i = 1 : 10
#     push!(S, Char(rand('a':'z')))
# end

# println("My Stack: ", S.S[1:S.top])
# pop!(S)
# println("My Stack after pop: ", S.S[1:S.top])
# println("Is the Stack empty: ", stackEmpty(S))


