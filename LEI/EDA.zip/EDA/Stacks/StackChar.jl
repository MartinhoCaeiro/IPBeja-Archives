"""
EDA 2024
StackChar.jl
Martinho Caeiro
02/04/2024

Implementação de uma Pilha com caracteres
"""

# Definição de uma estrutura mutável (mutable struct) Stack para representar uma pilha
mutable struct Stack
    top::Int  # Índice do topo da pilha
    data::Vector{Any}  # Vetor para armazenar os elementos da pilha
end

# Função para verificar se a pilha está vazia
function stack_empty!(S)
    return S.top == 0
end

# Função para empilhar um elemento na pilha
function push!(S, x)
    S.top += 1
    S.data[S.top] = x
end

# Função para desempilhar um elemento da pilha
function pop!(S)
    if stack_empty!(S)
        println("Underflow!")  # Mensagem de erro se a pilha estiver vazia
    else
        S.top -= 1
        return S.data[S.top + 1]  # Retorna o elemento desempilhado
    end
end

# Função para inverter uma string usando uma pilha
function reverse_string(input_string)
    S = Stack(0, Vector{Char}(undef, length(input_string)))  # Cria uma pilha vazia
    
    for char in input_string
        push!(S, char)  # Empilha cada caractere da string
    end
    
    reversed_string = ""
    while !stack_empty!(S)
        reversed_string *= string(pop!(S))  # Desempilha cada caractere e constrói a string invertida
    end
    
    return reversed_string
end

# Função principal
function main()
    input_string = "Portugal"
    reversed_string = reverse_string(input_string)
    println("String original: $input_string")
    println("String invertida: $reversed_string")
end

# Chama a função principal para executar o código
main()
