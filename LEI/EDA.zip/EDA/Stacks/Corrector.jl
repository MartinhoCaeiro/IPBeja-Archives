"""
EDA 2024
Corrector.jl
Martinho Caeiro
02/04/2024

Corretor de parêntesis de uma expressão matemática
"""

# Definição de uma estrutura mutável (mutable struct) Stack para representar uma pilha
mutable struct Stack
    top::Int  # Índice do topo da pilha
    data::Vector{Char}  # Vetor para armazenar os elementos da pilha
end

# Função para verificar se a pilha está vazia
function stack_empty!(S)
    return S.top == 0
end

# Função para empilhar um elemento na pilha
function push!(S, x)
    S.top += 1
    S.data[S.top] = x
end

# Função para desempilhar um elemento da pilha
function pop!(S)
    if stack_empty!(S)
        println("Underflow!")  # Mensagem de erro se a pilha estiver vazia
    else
        S.top -= 1
        return S.data[S.top + 1]  # Retorna o elemento desempilhado
    end
end

# Função para verificar se os parênteses em uma expressão estão balanceados
function check_parentheses(expression)
    S = Stack(0, Vector{Char}(undef, length(expression)))  # Cria uma pilha vazia
    
    for char in expression
        if char == '('
            push!(S, char)  # Empilha '('
        elseif char == ')'
            if stack_empty!(S) || pop!(S) != '('  # Se a pilha estiver vazia ou o topo não for '('
                return false  # Os parênteses estão desbalanceados
            end
        end
    end
    
    return stack_empty!(S)  # Se a pilha estiver vazia, os parênteses estão balanceados
end

# Função principal
function main()
    expression1 = "((2+3)*5)"
    expression2 = "((2+3)*5"
    expression3 = ")(2+3)*5)"

    # Verifica se os parênteses estão balanceados e imprime o resultado
    println("Expressão 1: ", check_parentheses(expression1))  
    println("Expressão 2: ", check_parentheses(expression2))  
    println("Expressão 3: ", check_parentheses(expression3))  
end

# Chama a função principal para executar o código
main()
