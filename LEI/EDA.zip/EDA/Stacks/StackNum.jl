"""
EDA 2024
StackNum.jl
Martinho Caeiro
02/04/2024

Implementação de uma Pilha com 100 números aleatórios
"""

# Definição da estrutura mutável (mutable struct) Stack para representar uma pilha
mutable struct Stack
    top::Int            # Índice do topo da pilha
    data::Vector{Any}   # Vetor para armazenar os elementos da pilha
end

# Função para verificar se a pilha está vazia
function stack_empty!(S)
    return S.top == 0
end

# Função para empilhar um elemento na pilha
function push!(S, x)
    S.top += 1
    S.data[S.top] = x
end

# Função para desempilhar um elemento da pilha
function pop!(S)
    if stack_empty!(S)
        println("Underflow!")  # Mensagem de erro se a pilha estiver vazia
    else
        S.top -= 1
        return S.data[S.top + 1]  # Retorna o elemento desempilhado
    end
end

# Função principal
function main()
    S = Stack(0, Vector{Any}(undef, 100))  # Cria uma pilha com capacidade para 100 elementos
    
    # Preenche a pilha com 100 números aleatórios entre 1 e 100
    for _ in 1:100
        push!(S, rand(1:100))
    end
    
    println("Desempilhando a pilha...")
    # Desempilha e imprime cada elemento da pilha
    while !stack_empty!(S)
        println(pop!(S))
    end
end

# Chama a função principal para executar o código
main()
