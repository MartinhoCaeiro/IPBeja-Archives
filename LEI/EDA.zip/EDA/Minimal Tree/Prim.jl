"""
EDA 2024
Prim.jl
Martinho Caeiro
07/05/2024

Algoritmo de Prim
"""

mutable struct Graph
    V::Vector{Char}  # Armazena os vértices do grafo como um vetor de caracteres
    E::Vector{Tuple{Char,Char}}  # Armazena as arestas do grafo como um vetor de tuplas de caracteres
end

function mst_prim(G, w, r)
    key = Dict(v => Inf for v in G.V)  # Inicializa um dicionário para armazenar as chaves de cada vértice
    pi = Dict{Char,Union{Char,Nothing}}(v => nothing for v in G.V)  # Inicializa um dicionário para armazenar os pais de cada vértice

    key[r] = 0  # Define a chave do vértice raiz como 0
    Q = Set(G.V)  # Inicializa um conjunto contendo todos os vértices do grafo

    while !isempty(Q)  # Enquanto o conjunto Q não estiver vazio
        u = extract_min(Q, key)  # Extrai o vértice com a menor chave do conjunto Q

        for v in neighbors(G, u)  # Para cada vizinho v de u
            if v in Q && w(u, v) < key[v]  # Se v está no conjunto Q e o peso da aresta (u, v) é menor que a chave de v
                pi[v] = u  # Atualiza o pai de v como u
                key[v] = w(u, v)  # Atualiza a chave de v com o peso da aresta (u, v)
            end
        end
    end

    return pi  # Retorna o dicionário de pais
end

function extract_min(Q, key)
    min_key = Inf
    min_vertex = nothing

    for v in Q  # Para cada vértice v no conjunto Q
        if key[v] < min_key  # Se a chave de v for menor que a menor chave encontrada até agora
            min_key = key[v]  # Atualiza a menor chave encontrada
            min_vertex = v  # Atualiza o vértice com a menor chave
        end
    end

    delete!(Q, min_vertex)  # Remove o vértice com a menor chave do conjunto Q
    return min_vertex  # Retorna o vértice com a menor chave
end

function neighbors(G, u)
    neighbors = []
    for (v1, v2) in G.E  # Para cada aresta (v1, v2) no conjunto de arestas do grafo
        if v1 == u  # Se v1 for igual a u
            push!(neighbors, v2)  # Adiciona v2 à lista de vizinhos
        elseif v2 == u  # Se v2 for igual a u
            push!(neighbors, v1)  # Adiciona v1 à lista de vizinhos
        end
    end
    return neighbors  # Retorna a lista de vizinhos
end

function send_file(pi, filepath)
    file = open(filepath, "w")

    if file isa IOStream  # Verifica se o arquivo foi aberto com sucesso
        write(file, "Árvore geradora mínima para o algoritmo Prim:\n")
        for (v, parent) in pi  # Para cada vértice e seu pai na árvore geradora mínima
            if parent !== nothing  # Se o vértice tiver um pai
                write(file, "('$parent', '$v')\n")  # Escreve a aresta pai-vértice no arquivo
            end
        end
        close(file)  # Fecha o arquivo
        println("Árvore de envergadura mínima exportada para um arquivo")
    else
        println("Erro ao abrir o arquivo para escrita.")  # Imprime uma mensagem de erro se o arquivo não puder ser aberto
    end
end

function total_weight(pi, w)
    total = 0
    for (v, parent) in pi  # Para cada vértice e seu pai na árvore geradora mínima
        if parent !== nothing  # Se o vértice tiver um pai
            total += w[(parent, v)]  # Adiciona o peso da aresta pai-vértice ao total
        end
    end
    return total  # Retorna o peso total da árvore de envergadura mínima
end

function main()
    V = ['A', 'B', 'C', 'D', 'E']  # Lista de vértices do grafo
    E = [('A', 'B'), ('A', 'C'), ('B', 'C'), ('B', 'D'), ('C', 'D'), ('C', 'E'), ('D', 'E')]  # Lista de arestas do grafo
    w = Dict(('A', 'B') => 4, ('B', 'A') => 4,
        ('A', 'C') => 2, ('C', 'A') => 2,
        ('B', 'C') => 1, ('C', 'B') => 1,
        ('B', 'D') => 3, ('D', 'B') => 3,
        ('C', 'D') => 5, ('D', 'C') => 5,
        ('C', 'E') => 6, ('E', 'C') => 6,
        ('D', 'E') => 7, ('E', 'D') => 7)  # Dicionário que mapeia cada aresta para seu peso

    G = Graph(V, E)  # Cria o grafo

    A = mst_prim(G, (u, v) -> w[(u, v)], 'A')  # Executa o al

    println("Árvore geradora mínima encontrada pelo algoritmo de Prim:")

    for (v, parent) in A  # Para cada vértice e seu pai na árvore geradora mínima
        if parent !== nothing
            println("('$parent', '$v')")
        end
    end

    weight = total_weight(A, w)
    println("A soma das ponderações da árvore de envergadura mínima é $weight.")
    send_file(A, "./EDA/Minimal Tree/arvore_minima_prim.txt")  # Envia a árvore de envergadura mínima para um arquivo
end

main()  # Chama a função principal para executar o algoritmo
