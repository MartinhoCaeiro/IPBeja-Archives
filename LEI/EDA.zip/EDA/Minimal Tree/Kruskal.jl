"""
EDA 2024
Kruskal.jl
Martinho Caeiro
07/05/2024

Algoritmo de Kruskal
"""

# Definição de um grafo representado por um conjunto de vértices (V) e um conjunto de arestas (E)
mutable struct Graph
    V::Vector{Char}  # Conjunto de vértices, representado por um vetor de caracteres
    E::Vector{Tuple{Char,Char}}  # Conjunto de arestas, representado por um vetor de tuplas de caracteres
end

# Função para encontrar a árvore geradora mínima usando o algoritmo de Kruskal
function mst_kruskal!(G, w)
    parent = Dict()  # Dicionário para armazenar os pais dos vértices na árvore
    rank = Dict()    # Dicionário para armazenar a altura das árvores

    # Inicializa os conjuntos disjuntos para cada vértice
    for v in G.V
        make_set(parent, rank, v)
    end

    # Ordena as arestas do grafo por peso
    edges = sort(G.E, by=x -> w[x])

    A = []  # Lista para armazenar as arestas da árvore geradora mínima

    # Percorre as arestas do grafo em ordem crescente de peso
    for (u, v) in edges
        # Se a inclusão da aresta (u, v) não forma um ciclo na árvore
        if find_set(parent, u) != find_set(parent, v)
            push!(A, (u, v))  # Adiciona a aresta à árvore
            union!(parent, rank, u, v)  # Une as árvores que contêm os vértices u e v
        end
    end

    return A  # Retorna a lista de arestas da árvore geradora mínima
end

# Função auxiliar para inicializar um conjunto disjunto para um vértice v
function make_set(parent, rank, v)
    parent[v] = v  # O pai inicial de v é ele mesmo
    rank[v] = 0    # A altura inicial da árvore é 0
end

# Função auxiliar para encontrar o representante (raiz) do conjunto que contém v
function find_set(parent, v)
    # Se o pai de v não é v, recalcula o pai de v recursivamente
    if parent[v] != v
        parent[v] = find_set(parent, parent[v])
    end
    return parent[v]  # Retorna o pai de v, que é a raiz do conjunto
end

# Função auxiliar para unir dois conjuntos disjuntos que contêm u e v
function union!(parent, rank, u, v)
    pu = find_set(parent, u)  # Encontra o representante do conjunto que contém u
    pv = find_set(parent, v)  # Encontra o representante do conjunto que contém v

    # Se as alturas das árvores de u e v são diferentes, anexa a árvore de menor altura à árvore de maior altura
    if rank[pu] > rank[pv]
        parent[pv] = pu
    elseif rank[pu] < rank[pv]
        parent[pu] = pv
    else
        parent[pu] = pv
        rank[pv] += 1  # Se as alturas são iguais, incrementa a altura da árvore resultante
    end
end

# Função para exportar a árvore geradora mínima para um arquivo
function send_file(A, filepath)
    file = open(filepath, "w")

    if file isa IOStream
        # Escreve a árvore geradora mínima no arquivo
        write(file, "Árvore geradora mínima para o algoritmo Kruskal:\n")
        for (v1, v2) in A
            write(file, "('$v1', '$v2')\n")
        end

        close(file)  # Fecha o arquivo após a escrita
        println("Árvore de envergadura mínima exportada para um arquivo")
    else
        println("Erro ao abrir o arquivo para escrita.")
    end
end

# Função para calcular o peso total de uma árvore geradora mínima
function total_weight(A, w)
    total = 0

    # Soma os pesos das arestas da árvore
    for edge in A
        total += w[edge]
    end

    return total
end

# Função principal
function main()
    # Define os vértices, as arestas e os pesos das arestas do grafo
    V = ['A', 'B', 'C', 'D', 'E']
    E = [('A', 'B'), ('A', 'C'), ('B', 'C'), ('B', 'D'), ('C', 'D'), ('C', 'E'), ('D', 'E')]
    w = Dict(('A', 'B') => 4, ('A', 'C') => 2, ('B', 'C') => 1, ('B', 'D') => 3, ('C', 'D') => 5, ('C', 'E') => 6, ('D', 'E') => 7)

    G = Graph(V, E)  # Cria um grafo com os vértices e as arestas definidas

    A = mst_kruskal!(G, w)  # Encontra a árvore geradora mínima usando o algoritmo de Kruskal

    # Imprime as arestas da árvore geradora mínima
    println("Árvore geradora mínima encontrada pelo algoritmo de Kruskal:")
    
    for edge in A
        println(edge)
    end

    weight = total_weight(A, w)  # Calcula o peso total da árvore geradora mínima
    println("A soma das ponderações da árvore de envergadura mínima é $weight.")

    send_file(A, "./EDA/Minimal Tree/arvore_minima_kruskal.txt")  # Exporta a árvore geradora mínima para um arquivo
end

main()  # Chama a função principal para executar o algoritmo de Kruskal e exportar a árvore geradora mínima
