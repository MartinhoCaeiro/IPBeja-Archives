"""
EDA 2024
Lines.jl
Martinho Caeiro
02/04/2024

Filas de Espera com Teste
"""

module MyQueue
    using Test  # Importa o módulo Test para realizar os testes
    export Queue, enqueue!, dequeue!, main  # Exporta os tipos e funções principais

    # Definição da estrutura da fila
    mutable struct Queue
        data::Vector{Any}  # Vetor que armazena os elementos da fila
        head::Int  # Índice da cabeça da fila
        tail::Int  # Índice da cauda da fila
    end

    # Função para enfileirar um elemento na fila
    function enqueue!(Q::Queue, x)
        Q.data[Q.tail] = x  # Adiciona o elemento na posição da cauda da fila

        if Q.tail == length(Q.data)  # Se a cauda atingir o final do vetor,
            Q.tail = 1  # volta para o início
        else
            Q.tail += 1  # Senão, avança para a próxima posição
        end
    end

    # Função para desenfileirar um elemento da fila
    function dequeue!(Q::Queue)
        x = Q.data[Q.head]  # Remove o elemento na posição da cabeça da fila

        if Q.head == length(Q.data)  # Se a cabeça atingir o final do vetor,
            Q.head = 1  # volta para o início
        else 
            Q.head += 1  # Senão, avança para a próxima posição
        end
        return x  # Retorna o elemento removido
    end

    # Função para testar a implementação da fila
    function test_queue()
        Q = Queue(Vector{Any}(undef, 3), 1, 1)  # Cria uma fila com capacidade para 3 elementos
    
        enqueue!(Q, "Cliente 1")  # Enfileira alguns elementos
        enqueue!(Q, "Cliente 2")
        enqueue!(Q, "Cliente 3")
        @test dequeue!(Q) == "Cliente 1"  # Testa se os elementos são desenfileirados na ordem correta
        @test dequeue!(Q) == "Cliente 2"
        @test dequeue!(Q) == "Cliente 3"
    
        enqueue!(Q, "Cliente 4")  # Enfileira mais elementos
        enqueue!(Q, "Cliente 5")
        enqueue!(Q, "Cliente 6")
        @test dequeue!(Q) == "Cliente 4"  # Testa novamente
        @test dequeue!(Q) == "Cliente 5"
        @test dequeue!(Q) == "Cliente 6"
    end

    # Função principal que chama os testes da fila
    function main()
        test_queue()
    end
end

MyQueue.main()  # Chama a função principal para executar os testes
