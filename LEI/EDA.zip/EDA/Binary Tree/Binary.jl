"""
EDA 2024
Binary.jl
Martinho Caeiro
16/04/2024

Árvores de pesquisa binária
"""

# Define a estrutura de um nó na árvore
mutable struct Node
    key::Int
    left::Union{Node, Nothing}
    right::Union{Node, Nothing}
    p::Union{Node, Nothing}
end

# Construtor para criar um novo nó apenas com a chave
function Node(key::Int)
    Node(key, nothing, nothing, nothing)
end

# Define a estrutura da árvore em si
mutable struct Tree
    root::Union{Node, Nothing}
end

# Construtor para criar uma nova árvore vazia
function Tree()
    Tree(nothing)
end

# Função de travessia in-order (em ordem)
function in_order!(x)
    if x !== nothing
        in_order!(x.left)  # Traverse the left subtree
        println(x.key)     # Print the node's key
        in_order!(x.right) # Traverse the right subtree
    end
end

# Função para busca recursiva na árvore
function tree_search!(x, k)
    if x === nothing || k == x.key
        return x
    end

    if k < x.key
        return tree_search!(x.left, k)
    else
        return tree_search!(x.right, k)
    end
end

# Função para busca iterativa na árvore
function iterative_search!(x, k)
    while x !== nothing && k != x.key
        if k < x.key
            x = x.left
        else
            x = x.right
        end
    end
    return x
end

# Função para encontrar o mínimo na árvore
function tree_min!(x)
    while x.left !== nothing
        x = x.left
    end
    return x
end

# Função para encontrar o máximo na árvore
function tree_max!(x)
    while x.right !== nothing
        x = x.right
    end
    return x
end

# Função para encontrar o sucessor de um nó
function tree_sucessor!(x)
    if x.right !== nothing
        return tree_min!(x.right)
    end

    y = x.p

    while y !== nothing && x == y.right
        x = y
        y = y.p
    end
    return y
end

# Função para encontrar o predecessor de um nó
function tree_predecessor!(x)
    if x.left !== nothing
        return tree_min!(x.left)
    end

    y = x.p

    while y !== nothing && x == y.left
        x = y
        y = y.p
    end
    return y
end

# Função para inserir um novo nó na árvore
function tree_insert!(T, z)
    y = nothing
    x = T.root

    while x !== nothing
        y = x

        if z.key < x.key
            x = x.left
        else
            x = x.right
        end
    end

    z.p = y

    if y === nothing
        T.root = z
    elseif z.key < y.key 
        y.left = z
    else
        y.right = z
    end
end

# Função para transplantar uma subárvore em outra posição
function tree_transplant!(T, u, v)
    if u.p === nothing
        T.root = v
    elseif u == u.p.left
        u.p.left = v
    else
        u.p.right = v
    end

    if v !== nothing
        v.p = u.p
    end
end

# Função para deletar um nó da árvore
function tree_delete!(T, z)
    if z.left === nothing
        tree_transplant!(T, z, z.right)
    elseif z.right === nothing
        tree_transplant!(T, z, z.left)
    else
        y = tree_min!(z.right)
        
        if y.p != z
            tree_transplant!(T, y, y.right)
            y.right = z.right
            y.right.p = y
        end

        tree_transplant!(T, z, y)
        y.left = z.left
        y.left.p = y
    end
end

# Função principal para testar as operações
function main()
    T = Tree()

    # Inserção de vários nós na árvore
    tree_insert!(T, Node(50))
    tree_insert!(T, Node(30))
    tree_insert!(T, Node(20))
    tree_insert!(T, Node(40))
    tree_insert!(T, Node(60))
    tree_insert!(T, Node(55))
    tree_insert!(T, Node(65))
    
    # Teste da função de travessia in-order
    println("Função In Order:")
    in_order!(T.root)
    
    # Teste da função de busca recursiva
    search = tree_search!(T.root, 50)
    println("Função Search ao valor 50:")
    println(search.key)

    # Teste da função de busca iterativa
    iterative_search = iterative_search!(T.root, 50)
    println("Função Iterative Search ao valor 50:")
    println(iterative_search.key)

    # Teste da função para encontrar o mínimo
    min = tree_min!(T.root)
    println("Função Minimum:")
    println(min.key)

    # Teste da função para encontrar o máximo
    max = tree_max!(T.root)
    println("Função Maximum:")
    println(max.key)

    # Teste da função para encontrar o sucessor
    successor = tree_sucessor!(search)
    println("Função Sucessor:")
    println(successor.key)

    # Teste da função para encontrar o predecessor
    predecessor = tree_predecessor!(iterative_search)
    println("Função Predecessor:")
    println(predecessor.key)

    # Teste da função de transplante
    u = tree_search!(T.root, 40)
    v = tree_search!(T.root, 50)
    tree_transplant!(T, u, v)
    println("Função Transplant:")

    # Teste da função de deleção
    delete = tree_search!(T.root, 65)
    tree_delete!(T, delete)
    println("Função Delete:")
    println(T.root)
end

# Chamada da função principal
main()
