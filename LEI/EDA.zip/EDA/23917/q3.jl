"""
Exame EDA Epoca Normal

Ficheiro: q3.jl
Nome: Martinho Caeiro
Data: 12/06/2024

Questão: 3
Status: Está a funcionar.
"""


# Função para criar o grafo
function fgXXXXX(tuples::Vector{Tuple{Int, Int, Float64}})
    grafo = Dict{Int, Vector{Tuple{Int, Float64}}}()
    for (s, t, w) in tuples
        if !haskey(grafo, s)
            grafo[s] = Vector{Tuple{Int, Float64}}()
        end
        push!(grafo[s], (t, w))
        if !haskey(grafo, t)
            grafo[t] = Vector{Tuple{Int, Float64}}()
        end
    end
    return grafo
end

# Função auxiliar para encontrar e remover o nó com a menor distância na fila de prioridade
function extract_min!(pq::Vector{Tuple{Int, Float64}})
    min_index = 1
    for i in 2:length(pq)
        if pq[i][2] < pq[min_index][2]
            min_index = i
        end
    end
    min_node = pq[min_index]
    deleteat!(pq, min_index)
    return min_node
end

# Função do algoritmo de Dijkstra
function dijkstra(grafo::Dict{Int, Vector{Tuple{Int, Float64}}}, start::Char)
    dist = Dict{Int, Float64}()
    for node in keys(grafo)
        dist[node] = Inf
    end
    dist[start] = 0.0

    pq = [(start, 0.0)]

    while !isempty(pq)
        current, current_dist = extract_min!(pq)

        for (neighbor, weight) in grafo[current]
            new_dist = current_dist + weight
            if new_dist < dist[neighbor]
                dist[neighbor] = new_dist
                push!(pq, (neighbor, new_dist))
            end
        end
    end

    return dist
end

# Função para imprimir as distâncias mínimas
function imprimir_distancias(dist::Dict{Int, Float64})
    for (node, distance) in dist
        println("Distância de origem até $node: $distance")
    end
end

function main()
    # Criação do grafo
    tuples = [
        (1, 2, 6.5), 
        (1, 3, 2.8),
        (3, 4, 1.9),
        (4, 5, 3.4),
        (4, 6, 3.3),
        (5, 3, 5.5),
        (5, 8, 4.0),
        (6, 7, 2.5)
    ]
    grafo = fgXXXXX(tuples)

    println("Grafo:")
    for (k, v) in grafo
        println("$k -> $v")
    end

    # Aplicação do algoritmo de Dijkstra
    start_node = 1
    distancias = dijkstra(grafo, start_node)
    
    println("\nDistâncias mínimas usando Dijkstra:")
    imprimir_distancias(distancias)
end

main()


