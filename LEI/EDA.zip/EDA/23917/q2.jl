"""
Exame EDA Epoca Normal

Ficheiro: q2.jl
Nome: Marinho Caeiro
Data: 12/06/2024

Questão: 2
Status: Está a funcionar com a alinea 1 e 2 da questão juntas, ou seja, foi logo implementada a fila de espera à estrutura.
"""

struct Espaco3D
    x::Float64
    y::Float64
    z::Float64
end

mutable struct Queue
    Q::Vector{Espaco3D}
    head::Int
    tail::Int
    length::Int
    Queue() = new(Vector{Espaco3D}(undef, 10), 1, 1, 10)
end

function enQueue(Q::Queue, x::Espaco3D)
    Q.Q[Q.tail] = x
    if Q.tail == Q.length
        Q.tail = 1
    else
        Q.tail += 1
    end
end

function deQueue(Q::Queue)::Espaco3D
    x = Q.Q[Q.head]
    if Q.head == Q.length
        Q.head = 1
    else
        Q.head += 1
    end
    return x
end

function isEmpty(Q::Queue)::Bool
    return Q.head == Q.tail
end

function main()
    # Criando uma fila de espera de Espaco3D
    fila_Espaco3D = Queue()

    # Adicionando Espaco3D à fila
    println("Fila de Espera do Espaco3D:")
    for _ in 1:10
        enQueue(fila_Espaco3D, Espaco3D(rand(), rand(), rand()))
    end

    println(fila_Espaco3D)

    # Removendo espaços da fila
    println("\nRemovendo espaços da fila:")
    for _ in 1:10
        local Espaco3D_removido = deQueue(fila_Espaco3D)
    end
    println(Espaco3D_removido)

    # Verificando se a fila está vazia
    println("\nA fila está vazia? ", isEmpty(fila_Espaco3D))

end

main()