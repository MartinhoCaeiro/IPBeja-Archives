"""
Exame EDA Epoca Normal

Ficheiro: q1.jl
Nome: Marinho Caeiro
Data: 12/06/2024

Questão: 1
Status: Está a funcionar.
"""

function bubblesort!(A)
    for i = 1:length(A) - 1 
        for j = length(A):-1:i + 1
            if A[j] < A[j - 1]
                A[j], A[j - 1] = A[j - 1], A[j]
            end
        end
    end
    return A
end


function sizeofN(A, n::Int)
    tempo = @elapsed bubblesort!(A)

    if tempo < m
        println("Demorou menos de 60 segundos!")
    else
        return length(A)
    end
end

function main()
    A = []
    A = rand(-100:100, 20)
    
    A = bubblesort!(A)

    println(A)
    m = 5000
    A = rand(0:1000, 20) 
    tamanho = sizeofN(A, n)
    
    println("O tamanho de N para tempo de execução maior a 60 segundos: $tamanho")
end

main()