"""
EDA 2024
List.jl
Martinho Caeiro
02/04/2024

Listas Ligadas
"""

# Definição de um nó de lista ligada
mutable struct ListNode
    data::Any            # Dado armazenado no nó
    prev::Union{ListNode, Nothing}   # Referência para o nó anterior
    next::Union{ListNode, Nothing}   # Referência para o próximo nó
end

# Definição da lista ligada
mutable struct List
    head::Union{ListNode, Nothing}   # Referência para o primeiro nó da lista
    tail::Union{ListNode, Nothing}   # Referência para o último nó da lista
end

# Função para busca de um elemento na lista
function list_search(L::List, k)
    x = L.head

    # Percorre a lista até encontrar o elemento ou chegar ao final
    while x !== nothing && x.data != k
        x = x.next
    end
    return x
end

# Função para inserção de um nó na lista
function list_insert(L::List, x::ListNode)
    x.next = L.head
    if L.head !== nothing
        L.head.prev = x
    end
    L.head = x
    x.prev = nothing

    if L.tail === nothing
        L.tail = x
    end
end

# Função para remoção de um nó da lista
function list_delete(L::List, x::ListNode)
    if x.prev !== nothing
        x.prev.next = x.next
    else
        L.head = x.next
    end

    if x.next !== nothing
        x.next.prev = x.prev
    else
        L.tail = x.prev
    end
end

# Função principal
function main()
    L = List(nothing, nothing)
    
    # Inserção de elementos na lista
    for i in 1:5
        node = ListNode(i, nothing, nothing)
        list_insert(L, node)
    end
    
    println("Searching for value 3:")
    node = list_search(L, 3)
    println(node)
    
    println("Deleting value 3:")
    list_delete(L, node)
    node = list_search(L, 3)
    println(node)
end

main()
