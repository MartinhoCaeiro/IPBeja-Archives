"""
EDA 2024
HeapComp.jl
Martinho Caeiro
12/03/2024

Comparação Heap Sort com Merge Sort
"""

using Plots

function merge_sort!(A)
    # Implementação do algoritmo Merge Sort recursivo
    if length(A) <= 1
        return A
    end
    middle = div(length(A), 2)
    left = merge_sort!(A[1:middle])
    right = merge_sort!(A[middle+1:end])
    return merge(left, right)
end

function merge(left, right)
    # Função auxiliar para mesclar duas listas ordenadas
    result = similar(left, length(left) + length(right))
    i, j, k = 1, 1, 1
    while i <= length(left) && j <= length(right)
        if left[i] <= right[j]
            result[k] = left[i]
            i += 1
        else
            result[k] = right[j]
            j += 1
        end
        k += 1
    end
    while i <= length(left)
        result[k] = left[i]
        i += 1
        k += 1
    end
    while j <= length(right)
        result[k] = right[j]
        j += 1
        k += 1
    end
    return result
end

function heapify!(A, i, n)
    # Função para ajustar um nó no heap
    l = 2 * i
    r = 2 * i + 1

    # Encontra o maior entre o nó e seus filhos
    if l <= n && A[l] > A[i]
        largest = l
    else
        largest = i
    end

    if r <= n && A[r] > A[largest]
        largest = r
    end

    # Se o maior não for o nó atual, troca com o maior filho e continua ajustando
    if largest != i
        A[i], A[largest] = A[largest], A[i]
        heapify!(A, largest, n)
    end
end

function max_heap!(A)
    # Transforma um array em um heap máximo
    n = length(A)
    for i = n ÷ 2:-1:1
        heapify!(A, i, n)
    end
    return A
end

function heap_sort!(A)
    # Ordena um array usando heap sort
    max_heap!(A)

    n = length(A)
    for i = n:-1:2
        A[1], A[i] = A[i], A[1]
        n -= 1
        heapify!(A, 1, n)
    end
    return A
end

function generate_input(n, scenario)
    # Gera uma amostra de entrada baseada no cenário
    if scenario == "melhor"
        return collect(1:n)
    elseif scenario == "pior"
        return collect(n:-1:1)
    else
        return rand(1:n, n)
    end
end

function measure_time(sort_function, scenario, sizes)
    # Mede o tempo de execução de uma função de ordenação para diferentes tamanhos de entrada
    times = []
    for size in sizes
        input = generate_input(size, scenario)
        time_elapsed = @elapsed sort_function(copy(input))
        push!(times, time_elapsed)
    end
    return times
end

function plot_growth(sort_functions, scenarios, sizes)
    # Plota o crescimento do tempo de execução em relação ao tamanho da entrada para diferentes cenários e funções de ordenação
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Tempo (s)", title="Aumento do Tempo com a Complexidade")

    for sort_function in sort_functions
        for scenario in scenarios
            times = measure_time(sort_function, scenario, sizes)
            plot!(sizes, times, label="$sort_function - $scenario")
        end
    end
    display(plot!())
end

function main()
    # Função principal que executa o teste de desempenho comparativo entre Heap Sort e Merge Sort
   sort_functions = [heap_sort!, merge_sort!]
   scenarios = ["melhor", "pior", "aleatório"]
   sizes = 100:100:1000
   plot_growth(sort_functions, scenarios, sizes)

   A = [16, 4, 10, 14, 7, 9, 3, 2, 8, 1]
   x = heap_sort!(A)
   print("Resultado do Heap Sort: $x\n")
end

main()
