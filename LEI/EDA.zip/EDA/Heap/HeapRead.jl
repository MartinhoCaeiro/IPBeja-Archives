"""
EDA 2024
HeapRead.jl
Martinho Caeiro
12/03/2024

Heap Sort com Leitura de Excel
"""

using Plots, DataFrames, CSV

# Função para comparação de elementos
function isgreater(x, y)
    return x > y
end

# Função para ajustar um nó em um heap
function heapify!(A, i, n, compare)
    l = 2 * i
    r = 2 * i + 1

    if l <= n && compare(A[l], A[i])
        largest = l
    else
        largest = i
    end

    if r <= n && compare(A[r], A[largest])
        largest = r
    end

    if largest != i
        A[i], A[largest] = A[largest], A[i]
        heapify!(A, largest, n, compare)
    end
end

# Função para transformar um array em um heap máximo
function max_heap!(A, compare)
    n = length(A)
    for i = n ÷ 2:-1:1
        heapify!(A, i, n, compare)
    end
    return A
end

# Função para ordenar um array usando Heap Sort
function heap_sort!(A, compare)
    max_heap!(A, compare)

    n = length(A)
    for i = n:-1:2
        A[1], A[i] = A[i], A[1]
        n -= 1
        heapify!(A, 1, n, compare)
    end
    return A
end

# Função para gerar uma amostra de entrada com diferentes cenários
function generate_input(n, scenario)
    if scenario == "melhor"
        return collect(1:n)
    elseif scenario == "pior"
        return collect(n:-1:1)
    else
        return rand(1:n, n)
    end
end

# Função para medir o tempo de execução do Heap Sort para diferentes tamanhos de entrada e cenários
function measure_time(scenario, sizes, compare)
    times = []
    for size in sizes
        input = generate_input(size, scenario)
        time_elapsed = @elapsed heap_sort!(copy(input), compare)
        push!(times, time_elapsed)
    end
    return times
end

# Função para plotar o crescimento do tempo de execução em relação ao tamanho da entrada para diferentes cenários
function plot_growth(scenarios, sizes, compare)
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Tempo (s)", title="Aumento do Tempo com a Complexidade")

    for scenario in scenarios
        times = measure_time(scenario, sizes, compare)
        plot!(sizes, times, label=scenario)
    end
    display(plot!())
end

function main()
    scenarios = ["melhor", "pior", "aleatório"]
    sizes = 100:100:1000

    # Plota o crescimento do tempo de execução em relação ao tamanho da entrada para diferentes cenários
    plot_growth(scenarios, sizes, isgreater)

    # Lê os dados do arquivo CSV
    df = CSV.read("EDA\\data.csv", DataFrame)
    A = df[:, 1]

    # Ordena o array lido do CSV usando Heap Sort
    x = heap_sort!(A, isgreater)
    println("Resultado do Heap Sort: $x")
end

main()
