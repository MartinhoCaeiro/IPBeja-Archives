"""
EDA 2024
Heap2.jl
Martinho Caeiro
12/03/2024

Heap Sort com Métrica de Comparação
"""

using Plots

function less_than(a, b)
    return a < b
end

function heapify!(A, i, n, compare=less_than)
    # Função para ajustar um nó no heap
    l = 2 * i
    r = 2 * i + 1

    # Encontra o maior (ou menor, dependendo da função de comparação) entre o nó e seus filhos
    if l <= n && compare(A[l], A[i])
        largest = l
    else
        largest = i
    end

    if r <= n && compare(A[r], A[largest])
        largest = r
    end

    # Se o maior (ou menor) não for o nó atual, troca com o maior filho (ou menor) e continua ajustando
    if largest != i
        A[i], A[largest] = A[largest], A[i]
        heapify!(A, largest, n, compare)
    end
end

function max_heap!(A, compare=less_than)
    # Transforma um array em um heap máximo (ou mínimo, dependendo da função de comparação)
    n = length(A)
    for i = n ÷ 2:-1:1
        heapify!(A, i, n, compare)
    end
    return A
end

function heap_sort!(A, compare=less_than)
    # Ordena um array usando heap sort com uma função de comparação personalizada
    max_heap!(A, compare)

    n = length(A)
    for i = n:-1:2
        # Troca o maior (ou menor) elemento (na raiz) com o último elemento não ordenado
        A[1], A[i] = A[i], A[1]
        n -= 1
        # Reconstroi o heap para o array restante
        heapify!(A, 1, n, compare)
    end
    return A
end

function generate_input(n, scenario)
    # Gera uma amostra de entrada baseada no cenário
    if scenario == "melhor"
        return collect(1:n)
    elseif scenario == "pior"
        return collect(n:-1:1)
    else
        return rand(1:n, n)
    end
end

function measure_time(scenario, sizes, compare=less_than)
    # Mede o tempo de execução do heap sort para diferentes tamanhos de entrada
    times = []
    for size in sizes
        input = generate_input(size, scenario)
        time_elapsed = @elapsed heap_sort!(copy(input), compare)
        push!(times, time_elapsed)
    end
    return times
end

function plot_growth(scenarios, sizes, compare=less_than)
    # Plota o crescimento do tempo de execução em relação ao tamanho da entrada para diferentes cenários
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Tempo (s)", title="Aumento do Tempo com a Complexidade")

    for scenario in scenarios
        times = measure_time(scenario, sizes, compare)
        plot!(sizes, times, label="$scenario ($compare)")
    end
    display(plot!())
end

function main()
    # Função principal que executa o teste com diferentes cenários e funções de comparação
    scenarios = ["melhor", "pior", "aleatório"]
    sizes = 100:100:50000

    # Definição de uma função de comparação personalizada (maior que)
    compare_func(x, y) = x > y
    plot_growth(scenarios, sizes, compare_func)
end

main()
