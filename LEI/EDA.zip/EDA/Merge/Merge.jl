"""
EDA 2024
Merge.jl
Martinho Caeiro
05/03/2024

Merge Sort
"""

# Importa as bibliotecas necessárias
using Plots, BenchmarkTools

# Função para ordenar a sublista A[p:r] usando o algoritmo Merge Sort
function merge_sort!(A, p, q, r)
    # Calcula os tamanhos das sublistas
    n1 = q - p + 1
    n2 = r - q
    
    # Inicializa vetores para armazenar as sublistas L e R, acrescidos de um elemento sentinel
    L = zeros(1, n1+1) 
    R = zeros(1, n2+1)
    
    # Copia os elementos das sublistas de A para os vetores L e R
    for i = 1:n1   
        L[i] = A[p + i - 1]
    end
    
    for j = 1:n2 
        R[j] = A[q + j]
    end
    
    # Adiciona o elemento sentinel ao final de L e R
    L[n1+1] = Inf
    R[n2+1] = Inf
   
    # Inicializa os índices para percorrer os vetores L e R
    i = 1
    j = 1
    
    # Percorre os vetores L e R para ordenar a sublista A[p:r]
    for k = p:r
        if L[i] <= R[j]
            A[k] = L[i] 
            i += 1
        else
            A[k] = R[j] 
            j += 1
        end
    end

    return A[p:r]  # Retorna a sublista ordenada
end

# Função para estimar a complexidade do Merge Sort
function merge_graph_est()
    # Define funções para o melhor e pior caso de complexidade
    f_melhor(n) = n
    f_pior(n) = n * log2(n)
    
    # Valores de entrada
    n_values = 1:1000

    # Calcula os tempos estimados para o melhor e pior caso
    melhor_caso = f_melhor.(n_values)
    pior_caso = f_pior.(n_values)

    # Plota os gráficos de melhor e pior caso
    plot(n_values, melhor_caso, label="Melhor Caso", xlabel="Tamanho da Entrada (n)", ylabel="Tempo de Execução", linewidth=2)
    plot!(n_values, pior_caso, label="Pior Caso", linestyle=:dash, linewidth=2)
    title!("Estimativa do Merge Sort")
end

# Função para medir o tempo de execução do Merge Sort com diferentes tamanhos de entrada
function merge_sort_time(n)
    A = rand(1:100, n)  # Gera uma lista aleatória de tamanho n
    p = 1
    q = div(n, 2)
    r = n
    return @belapsed merge_sort!($A, $p, $q, $r)  # Mede o tempo de execução do Merge Sort
end

# Função para plotar o crescimento do tempo de execução do Merge Sort com diferentes tamanhos de entrada
function merge_graph()
    sizes = 10:24  # Tamanhos de entrada
    times = [merge_sort_time(size) for size in sizes]  # Mede o tempo de execução para cada tamanho de entrada
    ratios = [times[i+1] / times[i] for i in 1:length(times)-1]  # Calcula as razões de crescimento entre tamanhos consecutivos
    growth_rate = sum(ratios) / length(ratios)  # Calcula a taxa de crescimento média

    println("Taxa de crescimento média: $growth_rate")

    # Plota o tempo de execução em escala log-log e adiciona uma linha indicando a taxa de crescimento média
    scatter(sizes, times, label="Tempos de Execução", xlabel="Tamanho da Entrada", ylabel="Tempo (s)", xscale=:log2, yscale=:log2)
    plot!([sizes[1], sizes[end]], [times[1], times[1]*growth_rate^(length(sizes)-1)], label="Taxa de Crescimento Média", linestyle=:dash)
end

# Função principal
function main()
    # Lista de entrada
    A = [2,3,4,1,6,7,8,1,2,4,5,7,1,2,3,6,7,8]
    p = 9
    q = 12
    r = 16

    # Aplica o Merge Sort na sublista A[p:r] e imprime o resultado
    x = merge_sort!(A, p, q, r)
    println("Resultado do Merge Sort: $x\n")

    # Plota os gráficos de estimativa e crescimento do tempo de execução do Merge Sort
    merge_graph_est()
    merge_graph()
end

main()  # Chama a função principal
