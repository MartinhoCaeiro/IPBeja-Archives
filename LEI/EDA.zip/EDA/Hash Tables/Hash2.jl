"""
EDA 2024
Hash2.jl
Martinho Caeiro
09/04/2024

Hash Tables com Resolução de Colisões
"""

# Função para calcular o hash de uma chave
function h(key)
    return string(key)  # Retorna uma representação em string da chave (poderia ser uma função de hash mais sofisticada)
end

# Função para criar uma tabela de dispersão vazia
function hash_create()
    return Dict()  # Retorna um dicionário vazio, que será usado como a tabela de dispersão
end

# Função para inserir um elemento na tabela de dispersão com resolução de colisões
function hash_insert(T, x)
    hash_key = h(x.key)  # Calcula o hash da chave
    if !haskey(T, hash_key)  # Verifica se a chave já existe na tabela
        T[hash_key] = []  # Se não existir, cria uma lista vazia para armazenar os elementos com a mesma chave
    end
    push!(T[hash_key], x)  # Adiciona o elemento à lista correspondente à chave na tabela
end

# Função para buscar um elemento na tabela de dispersão com resolução de colisões
function hash_search(T, k)
    hash_key = h(k)  # Calcula o hash da chave
    if haskey(T, hash_key)  # Verifica se a chave existe na tabela
        for item in T[hash_key]  # Percorre os elementos da lista correspondente à chave
            if item.key == k  # Se encontrar a chave desejada, retorna o elemento correspondente
                return item
            end
        end
    end
    return nothing  # Se a chave não for encontrada, retorna nothing
end

# Função para excluir um elemento da tabela de dispersão com resolução de colisões
function hash_delete(T, x)
    hash_key = h(x.key)  # Calcula o hash da chave do elemento a ser excluído
    if haskey(T, hash_key)  # Verifica se a chave existe na tabela
        filter!(y -> y != x, T[hash_key])  # Remove o elemento da lista correspondente à chave
    end
end

# Função principal
function main()
    T = hash_create()  # Cria uma tabela de dispersão vazia

    # Insere alguns elementos na tabela
    hash_insert(T, (key = "BD2", value = 16))
    hash_insert(T, (key = "SO", value = 17))
    hash_insert(T, (key = "SO", value = 15))  # Note que a chave "SO" já existe na tabela
    hash_insert(T, (key = "LP", value = 10))

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 'SO' na tabela e imprime
    println("Valor associado à chave 'SO': ", hash_search(T, "SO"))

    # Exclui o elemento associado à chave 'SO' da tabela
    hash_delete(T, hash_search(T, "SO"))
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
