"""
EDA 2024
Open.jl
Martinho Caeiro
09/04/2024

Endereçamento Aberto com Struct
"""

# Definição da struct KeyValue para representar os pares chave-valor
struct KeyValue
    key::Int
    value::Float64
end

# Função para criar uma tabela de dispersão vazia
function open_create()
    return Dict{Int, KeyValue}()  # Cria um dicionário vazio para representar a tabela de dispersão
end

# Função para inserir um par chave-valor na tabela de dispersão utilizando endereçamento aberto
function open_insert(T, kv::KeyValue, h, m)
    i = 0
    while i != m
        j = h(kv.key, i, m)  # Calcula o índice utilizando a função de hash
        if !haskey(T, j)  # Verifica se a posição está vazia
            T[j] = kv  # Insere o par chave-valor na posição
            return j  # Retorna o índice onde o par foi inserido
        else
            i += 1  # Incrementa o contador de tentativas
        end
    end
    println("Hash Table Overflow")  # Imprime uma mensagem de erro se ocorrer overflow
end

# Função para buscar um valor na tabela de dispersão utilizando endereçamento aberto
function open_search(T, k, h, m)
    i = 0
    while i != m
        j = h(k, i, m)  # Calcula o índice utilizando a função de hash
        if haskey(T, j) && T[j].key == k  # Verifica se o elemento está na posição calculada
            return T[j]  # Retorna o par chave-valor encontrado
        end
        i += 1  # Incrementa o contador de tentativas
    end
    return nothing  # Retorna nothing se o elemento não for encontrado
end

# Função para excluir um par chave-valor da tabela de dispersão utilizando endereçamento aberto
function open_delete(T, k, h, m)
    index = open_search(T, k, h, m)  # Busca o índice do par na tabela
    if index !== nothing  # Se o par for encontrado
        delete!(T, index)  # Exclui o par da tabela
    end
end

# Função de hash utilizada para calcular os índices na tabela de dispersão
function h(k, i, m)
    return (k + i) % m  # Calcula o índice utilizando a fórmula (k + i) % m
end

# Função principal
function main()
    T = open_create()  # Cria uma tabela de dispersão vazia
    m = 3  # Tamanho da tabela

    # Insere alguns pares chave-valor na tabela utilizando endereçamento aberto
    open_insert(T, KeyValue(42, 3.14), h, m)
    open_insert(T, KeyValue(23, 2.71), h, m)
    open_insert(T, KeyValue(17, 1.618), h, m)

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 23 na tabela e imprime
    println("Valor associado à chave 23: ", open_search(T, 23, h, m))

    # Exclui o par associado à chave 23 da tabela
    open_delete(T, 23, h, m)
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
