"""
EDA 2024
Direct.jl
Martinho Caeiro
09/04/2024

Endereçamento Direto com Disciplinas
"""

# Função para criar uma tabela de endereçamento direto
function direct_create()
    return Dict()  # Retorna um dicionário vazio
end

# Função para inserir um elemento na tabela de endereçamento direto
function direct_insert(T, x)
    T[x.key] = x  # Associa a chave x.key ao valor x no dicionário T
end

# Função para buscar um elemento na tabela de endereçamento direto
function direct_search(T, k)
    return T[k]  # Retorna o valor associado à chave k no dicionário T
end

# Função para excluir um elemento da tabela de endereçamento direto
function direct_delete(T, x)
    T[x.key] = nothing  # Define como nothing o valor associado à chave x.key no dicionário T
end

# Função principal
function main()
    T = direct_create()  # Cria uma tabela de endereçamento direto vazia

    # Insere alguns elementos na tabela
    direct_insert(T, (key = "BD2", value = 16))
    direct_insert(T, (key = "SO", value = 15))
    direct_insert(T, (key = "LP", value = 10))

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 'SO' na tabela e imprime
    println("Valor associado à chave 'SO': ", direct_search(T, "SO"))

    # Exclui o elemento associado à chave 'SO' da tabela
    direct_delete(T, T["SO"])
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
