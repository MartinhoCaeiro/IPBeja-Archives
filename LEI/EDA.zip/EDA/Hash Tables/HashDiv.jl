"""
EDA 2024
HashDiv.jl
Martinho Caeiro
09/04/2024

Hash Tables pelo Método da Divisão
"""

# Função para calcular o hash de uma chave utilizando o método da divisão
function h(key, m)
    return key % m  # Calcula o resto da divisão da chave pelo tamanho da tabela (m)
end

# Função para criar uma tabela de dispersão vazia
function hash_create()
    return Dict()  # Retorna um dicionário vazio, que será usado como a tabela de dispersão
end

# Função para inserir um elemento na tabela de dispersão utilizando o método da divisão
function hash_insert(T, key, value, m)
    idx = h(key, m)  # Calcula o índice do elemento na tabela
    if !haskey(T, idx)  # Verifica se o índice já existe na tabela
        T[idx] = []  # Se não existir, cria uma lista vazia para armazenar os elementos com o mesmo índice
    end
    push!(T[idx], (key = key, value = value))  # Adiciona o elemento à lista correspondente ao índice na tabela
end

# Função para buscar um elemento na tabela de dispersão utilizando o método da divisão
function hash_search(T, k, m)
    idx = h(k, m)  # Calcula o índice da chave na tabela
    if haskey(T, idx)  # Verifica se o índice existe na tabela
        for item in T[idx]  # Percorre os elementos da lista correspondente ao índice
            if item.key == k  # Se encontrar a chave desejada, retorna o elemento correspondente
                return item
            end
        end
    end
    return nothing  # Se a chave não for encontrada, retorna nothing
end

# Função para excluir um elemento da tabela de dispersão utilizando o método da divisão
function hash_delete(T, k, m)
    idx = h(k, m)  # Calcula o índice da chave na tabela
    if haskey(T, idx)  # Verifica se o índice existe na tabela
        for (i, item) in enumerate(T[idx])  # Percorre os elementos da lista correspondente ao índice
            if item.key == k  # Se encontrar a chave desejada, exclui o elemento da lista
                deleteat!(T[idx], i)
                break
            end
        end
    end
end

# Função principal
function main()
    T = hash_create()  # Cria uma tabela de dispersão vazia
    m = 10  # Define o tamanho da tabela

    # Insere alguns elementos na tabela
    hash_insert(T, 42, 16, m)
    hash_insert(T, 23, 15, m)
    hash_insert(T, 17, 10, m)

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 23 na tabela e imprime
    println("Valor associado à chave 23: ", hash_search(T, 23, m))

    # Exclui o elemento associado à chave 23 da tabela
    hash_delete(T, 23, m)
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
