"""
EDA 2024
Open.jl
Martinho Caeiro
09/04/2024

Endereçamento Aberto
"""

# Função para criar uma tabela de dispersão vazia
function open_create()
    return Dict()
end

# Função para inserir um elemento na tabela de dispersão utilizando endereçamento aberto
function open_insert(T, k, h, m)
    i = 0
    while i != m
        j = h(k, i, m)  # Calcula o índice utilizando a função de hash
        if !haskey(T, j)  # Verifica se a posição está vazia
            T[j] = k  # Insere o elemento na posição
            return j  # Retorna o índice onde o elemento foi inserido
        else
            i += 1  # Incrementa o contador de tentativas
        end
    end
    println("Hash Table Overflow")  # Imprime uma mensagem de erro se ocorrer overflow
end

# Função para buscar um elemento na tabela de dispersão utilizando endereçamento aberto
function open_search(T, k, h, m)
    i = 0
    while i != m
        j = h(k, i, m)  # Calcula o índice utilizando a função de hash
        if haskey(T, j) && T[j] == k  # Verifica se o elemento está na posição calculada
            return j  # Retorna o índice onde o elemento foi encontrado
        end
        i += 1  # Incrementa o contador de tentativas
    end
    return nothing  # Retorna nothing se o elemento não for encontrado
end

# Função para excluir um elemento da tabela de dispersão utilizando endereçamento aberto
function open_delete(T, k, h, m)
    index = open_search(T, k, h, m)  # Busca o índice do elemento na tabela
    if index !== nothing  # Se o elemento for encontrado
        delete!(T, index)  # Exclui o elemento da tabela
    end
end

# Função de hash utilizada para calcular os índices na tabela de dispersão
function h(k, i, m)
    return (k + i) % m  # Calcula o índice utilizando a fórmula (k + i) % m
end

# Função principal
function main()
    T = open_create()  # Cria uma tabela de dispersão vazia
    m = 10  # Tamanho da tabela

    # Insere alguns elementos na tabela utilizando endereçamento aberto
    open_insert(T, 42, h, m)
    open_insert(T, 23, h, m)
    open_insert(T, 17, h, m)

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 23 na tabela e imprime
    println("Valor associado à chave 23: ", open_search(T, 23, h, m))

    # Exclui o elemento associado à chave 23 da tabela
    open_delete(T, 23, h, m)
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
