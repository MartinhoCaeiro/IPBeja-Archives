"""
EDA 2024
HashMult.jl
Martinho Caeiro
09/04/2024

Hash Tables pelo Método da Multiplicação
"""

# Função de hash utilizando o método da multiplicação
function h(key, A, m, _, c)
    return floor(m * ((key * A) % 1))
end

# Função para criar uma tabela de dispersão
function hash_create()
    return Dict()
end

# Função para inserir um elemento na tabela de dispersão
function hash_insert(T, key, value, A, m, b, c)
    T[h(key, A, m, b, c)] = (key = key, value = value)
end

# Função para buscar um elemento na tabela de dispersão
function hash_search(T, k, A, m, b, c)
    return T[h(k, A, m, b, c)]
end

# Função para excluir um elemento da tabela de dispersão
function hash_delete(T, key, A, m, b, c)
    T[h(key, A, m, b, c)] = nothing
end

# Função principal
function main()
    T = hash_create()  # Cria uma tabela de dispersão vazia
    A = 0.61803398875  # Fator de escala
    m = 10             # Tamanho da tabela
    b = 1              # Número a ser adicionado após o cálculo do hash
    c = 0              # Constante

    # Insere alguns elementos na tabela
    hash_insert(T, 42, 16, A, m, b, c)
    hash_insert(T, 23, 15, A, m, b, c)
    hash_insert(T, 17, 10, A, m, b, c)

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 23 na tabela e imprime
    println("Valor associado à chave 23: ", hash_search(T, 23, A, m, b, c))

    # Exclui o elemento associado à chave 23 da tabela
    hash_delete(T, 23, A, m, b, c)
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
