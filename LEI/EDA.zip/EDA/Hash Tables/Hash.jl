"""
EDA 2024
Hash.jl
Martinho Caeiro
09/04/2024

Hash Tables
"""

# Função para calcular o hash de uma chave
function h(key)
    return string(key)  # Retorna uma representação em string da chave (poderia ser uma função de hash mais sofisticada)
end

# Função para criar uma tabela de dispersão vazia
function hash_create()
    return Dict()  # Retorna um dicionário vazio, que será usado como a tabela de dispersão
end

# Função para inserir um elemento na tabela de dispersão
function hash_insert(T, x)
    T[h(x.key)] = x  # Associa a chave h(x.key) ao valor x no dicionário T
end

# Função para buscar um elemento na tabela de dispersão
function hash_search(T, k)
    return T[h(k)]  # Retorna o valor associado à chave h(k) no dicionário T
end

# Função para excluir um elemento da tabela de dispersão
function hash_delete(T, x)
    T[h(x.key)] = nothing  # Define como nothing o valor associado à chave h(x.key) no dicionário T
end

# Função principal
function main()
    T = direct_create()  # Cria uma tabela de dispersão vazia

    # Insere alguns elementos na tabela
    direct_insert(T, (key = "BD2", value = 16))
    direct_insert(T, (key = "SO", value = 15))
    direct_insert(T, (key = "LP", value = 10))

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave 'SO' na tabela e imprime
    println("Valor associado à chave 'SO': ", direct_search(T, "SO"))

    # Exclui o elemento associado à chave 'SO' da tabela
    direct_delete(T, T["SO"])
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
