"""
EDA 2024
HashLoad.jl
Martinho Caeiro
09/04/2024

Hash Tables com Fator de Carga
"""

# Função para calcular o hash de uma chave
function h(key)
    return string(key)
end

# Função para criar uma tabela de dispersão com fator de carga e tamanho inicial especificados
function hash_create(load_factor::Float64=0.7, initial_size::Int=16)
    return Dict{String, Any}(), load_factor, initial_size
end

# Função para inserir um elemento na tabela de dispersão
function hash_insert(T, x, load_factor, initial_size)
    T[h(x.key)] = x  # Insere o elemento na tabela utilizando a função de hash

    # Verifica se o fator de carga excede o limite
    if length(T) / initial_size > load_factor
        resize_hash!(T, 2 * length(T))  # Se sim, redimensiona a tabela
    end
end

# Função para redimensionar a tabela de dispersão
function resize_hash!(T, new_size)
    new_T = Dict{String, Any}(undef, new_size)  # Cria uma nova tabela com o novo tamanho
    for (key, value) in T  # Transfere os elementos da tabela antiga para a nova
        new_T[key] = value
    end
    T = new_T  # Atualiza a referência da tabela original para a nova tabela
end

# Função para buscar um elemento na tabela de dispersão
function hash_search(T, k)
    return T[h(k)]
end

# Função para excluir um elemento da tabela de dispersão
function hash_delete(T, x)
    delete!(T, h(x.key))
end

# Função principal
function main()
    T, load_factor, initial_size = hash_create(0.7)  # Cria uma tabela de dispersão com fator de carga 0.7 e tamanho inicial 16

    # Insere alguns elementos na tabela
    hash_insert(T, (key = "BD2", value = 16), load_factor, initial_size)
    hash_insert(T, (key = "SO", value = 15), load_factor, initial_size)
    hash_insert(T, (key = "LP", value = 10), load_factor, initial_size)

    println("Tabela após inserção:")
    println(T)

    # Busca o valor associado à chave "SO" na tabela e imprime
    println("Valor associado à chave 'SO': ", hash_search(T, "SO"))

    # Exclui o elemento associado à chave "SO" da tabela
    hash_delete(T, T["SO"])
    
    println("Tabela após exclusão:")
    println(T)
end

main()  # Chama a função principal para executar o código
