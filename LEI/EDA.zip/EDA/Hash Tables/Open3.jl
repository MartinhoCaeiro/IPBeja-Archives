"""
EDA 2024
Open.jl
Martinho Caeiro
09/04/2024

Endereçamento Aberto para Teste Linear, Quadrático e Dupla Hash
"""

# Função de sonda linear
function linear_probe(k, i, m)
    return (k + i) % m
end

# Função de sonda quadrática
function quadratic_probe(k, i, m)
    return (k + i^2) % m
end

# Função de sonda dupla hash
function double_hash(k, i, m)
    h1 = k % m
    h2 = 1 + (k % (m - 1)) 
    return (h1 + i * h2) % m
end

# Função para criar uma tabela de dispersão vazia
function open_create()
    return Dict()
end

# Função para inserir um elemento na tabela utilizando endereçamento aberto
function open_insert(T, k, h, m)
    i = 0
    while i != m
        j = h(k, i, m)  # Calcula o índice utilizando a função de sonda
        if !haskey(T, j)  # Verifica se a posição está vazia
            T[j] = k  # Insere o elemento na posição
            return j  # Retorna o índice onde o elemento foi inserido
        else
            i += 1  # Incrementa o contador de tentativas
        end
    end
    println("Hash Table Overflow")  # Imprime uma mensagem de erro se ocorrer overflow
end

# Função para buscar um elemento na tabela utilizando endereçamento aberto
function open_search(T, k, h, m)
    i = 0
    while i != m
        j = h(k, i, m)  # Calcula o índice utilizando a função de sonda
        if haskey(T, j) && T[j] == k  # Verifica se o elemento está na posição calculada
            return j  # Retorna o índice onde o elemento foi encontrado
        end
        i += 1  # Incrementa o contador de tentativas
    end
    return nothing  # Retorna nothing se o elemento não for encontrado
end

# Função para excluir um elemento da tabela utilizando endereçamento aberto
function open_delete(T, k, h, m)
    index = open_search(T, k, h, m)  # Busca o índice do elemento na tabela
    if index !== nothing  # Se o elemento for encontrado
        delete!(T, index)  # Exclui o elemento da tabela
    end
end

# Função principal
function main()
    T_linear = open_create()  # Cria uma tabela de dispersão vazia para o teste linear
    T_quadratic = open_create()  # Cria uma tabela de dispersão vazia para o teste quadrático
    T_double_hash = open_create()  # Cria uma tabela de dispersão vazia para o teste com dupla função de hash
    m = 3  # Tamanho da tabela

    # Teste com sonda linear
    println("Teste Linear:")
    open_insert(T_linear, 42, linear_probe, m)
    open_insert(T_linear, 23, linear_probe, m)
    open_insert(T_linear, 17, linear_probe, m)

    println("Tabela após inserção:")
    println(T_linear)

    println("Valor associado à chave 23: ", open_search(T_linear, 23, linear_probe, m))

    open_delete(T_linear, 23, linear_probe, m)
    
    println("Tabela após exclusão:")
    println(T_linear)
    println()

    # Teste com sonda quadrática
    println("Teste Quadrático:")
    open_insert(T_quadratic, 42, quadratic_probe, m)
    open_insert(T_quadratic, 23, quadratic_probe, m)
    open_insert(T_quadratic, 17, quadratic_probe, m)

    println("Tabela após inserção:")
    println(T_quadratic)

    println("Valor associado à chave 23: ", open_search(T_quadratic, 23, quadratic_probe, m))

    open_delete(T_quadratic, 23, quadratic_probe, m)
    
    println("Tabela após exclusão:")
    println(T_quadratic)
    println()

    # Teste com dupla função de hash
    println("Teste com Dupla Função de Hash:")
    open_insert(T_double_hash, 42, double_hash, m)
    open_insert(T_double_hash, 23, double_hash, m)
    open_insert(T_double_hash, 17, double_hash, m)

    println("Tabela após inserção:")
    println(T_double_hash)

    println("Valor associado à chave 23: ", open_search(T_double_hash, 23, double_hash, m))

    open_delete(T_double_hash, 23, double_hash, m)
    
    println("Tabela após exclusão:")
    println(T_double_hash)
end

main()