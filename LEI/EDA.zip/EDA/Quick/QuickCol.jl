"""
EDA 2024
QuickCol.jl
Martinho Caeiro
19/03/2024

Quick Sort que pode ordenar tabelas de várias entradas
"""

using CSV, DataFrames  # Importa os pacotes CSV e DataFrames para manipulação de arquivos CSV e tabelas de dados

# Função quick_sort! para ordenar uma tabela de várias entradas
function quick_sort!(A, p=1, r=nrow(A); col=1)
    if p < r
        q = quick_part!(A, p, r, col)  # Particiona a tabela
        quick_sort!(A, p, q - 1, col=col)  # Ordena a parte esquerda da tabela
        quick_sort!(A, q + 1, r, col=col)  # Ordena a parte direita da tabela
    end
end

# Função quick_part! para particionar a tabela A
function quick_part!(A, p, r, col)
    x = A[r, col]  # Escolhe o último elemento como pivô
    i = p - 1  # Inicializa o índice do menor elemento

    for j = p:r-1
        if A[j, col] <= x
            i += 1
            A[i, :], A[j, :] = A[j, :], A[i, :]  # Troca as linhas com elementos menores que o pivô
        end
    end
    A[i+1, col], A[r, col] = A[r, col], A[i+1, col]  # Coloca o pivô na posição correta
    return i + 1  # Retorna a posição do pivô
end

# Função read_csv para ler um arquivo CSV e retornar um DataFrame
function read_csv(filename)
    return CSV.read(filename, DataFrame; header=false)
end

# Função principal main para executar o código
function main()
    filename = "EDA\\Quick\\data.csv"  # Caminho do arquivo CSV
    A = read_csv(filename)  # Lê o arquivo CSV e armazena os dados em um DataFrame

    println("Dados originais:")
    println(A)

    # Ordenar pelo primeiro elemento de cada linha
    quick_sort!(A, col=1)
    println("Ordenado pelo primeiro elemento de cada linha:")
    println(A)

    # Ordenar pelo segundo elemento de cada linha
    quick_sort!(A, col=2)
    println("\nOrdenado pelo segundo elemento de cada linha:")
    println(A)

    # Ordenar pelo terceiro elemento de cada linha
    quick_sort!(A, col=3)
    println("\nOrdenado pelo terceiro elemento de cada linha:")
    println(A)
end

main()  # Chama a função principal para executar o código
