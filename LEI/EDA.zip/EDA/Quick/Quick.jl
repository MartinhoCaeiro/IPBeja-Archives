"""
EDA 2024
Quick.jl
Martinho Caeiro
19/03/2024

Quick Sort com Grafico
"""

using Plots  # Importa o pacote Plots para visualização dos gráficos

# Função quick_sort! para ordenar um array A de forma rápida
function quick_sort!(A, p=1, r=length(A))
    if p < r
        q = quick_part!(A, p, r)  # Particiona o array
        quick_sort!(A, p, q - 1)  # Ordena a parte esquerda do array
        quick_sort!(A, q + 1, r)  # Ordena a parte direita do array
    end
end

# Função quick_part! para particionar o array A
function quick_part!(A, p, r)
    x = A[r]  # Escolhe o último elemento como pivô
    i = p - 1  # Inicializa o índice do menor elemento

    for j = p:r - 1
        if A[j] <= x
            i += 1
            A[i], A[j] = A[j], A[i]  # Troca os elementos menores que o pivô para a esquerda
        end 
    end
    A[i + 1], A[r] = A[r], A[i + 1]  # Coloca o pivô na posição correta
    return i + 1  # Retorna a posição do pivô
end

# Função permute! para trocar os elementos de posição em um array
function permute!(A, i, j)
    temp = A[i]
    A[i] = A[j]
    A[j] = temp
end

# Função generate_input para gerar uma entrada de dados com base no cenário (melhor, pior, aleatório)
function generate_input(n, scenario)
    if scenario == "melhor"
        return collect(1:n)  # Melhor caso: array ordenado
    elseif scenario == "pior"
        return collect(n:-1:1)  # Pior caso: array inversamente ordenado
    else
        return rand(1:n, n)  # Caso aleatório: array com números aleatórios
    end
end

# Função measure_time para medir o tempo de execução do algoritmo para diferentes tamanhos de entrada
function measure_time(scenario, sizes)
    times = []
    for size in sizes
        input = generate_input(size, scenario)
        time_elapsed = @elapsed quick_sort!(copy(input))  # Mede o tempo de execução
        push!(times, time_elapsed)  # Armazena o tempo na lista de tempos
    end
    return times  # Retorna a lista de tempos
end

# Função plot_growth para plotar o crescimento do tempo de execução com a complexidade
function plot_growth(scenarios, sizes)
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Tempo (s)", title="Aumento do Tempo com a Complexidade")

    for scenario in scenarios
        times = measure_time(scenario, sizes)  # Mede o tempo para o cenário atual
        plot!(sizes, times, label=scenario)  # Plota o tempo em função do tamanho da amostra
    end
    display(plot!())  # Exibe o gráfico
end

# Função main para executar o algoritmo e plotar o gráfico
function main()
    scenarios = ["melhor", "pior", "aleatório"]  # Define os cenários a serem testados
    sizes = 100:100:1000  # Define os tamanhos das amostras a serem testados
    plot_growth(scenarios, sizes)  # Plota o crescimento do tempo de execução

    A = [16, 4, 10, 14, 7, 9, 3, 2, 8, 1]  # Array de exemplo
    quick_sort!(A)  # Ordena o array
    println("Resultado do Quick Sort: ", A)  # Imprime o resultado
end

main()  # Chama a função principal para executar o código
