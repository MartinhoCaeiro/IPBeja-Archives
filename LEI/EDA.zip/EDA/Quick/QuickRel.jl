"""
EDA 2024
QuickRel.jl
Martinho Caeiro
19/03/2024

Quick Sort com Erro Relativo
"""

using Plots  # Importa o pacote Plots para criar gráficos

# Função principal do Quick Sort
function quick_sort!(A, p=1, r=length(A))
    if p < r
        q = quick_part!(A, p, r)  # Particiona o array
        quick_sort!(A, p, q - 1)  # Ordena a parte esquerda
        quick_sort!(A, q + 1, r)  # Ordena a parte direita
    end
end

# Função de particionamento do Quick Sort
function quick_part!(A, p, r)
    x = A[r]  # Escolhe o pivô como o último elemento
    i = p - 1  # Inicializa o índice do menor elemento

    for j = p:r - 1
        if A[j] <= x
            i += 1
            A[i], A[j] = A[j], A[i]  # Troca os elementos
        end 
    end
    A[i + 1], A[r] = A[r], A[i + 1]  # Coloca o pivô na posição correta
    return i + 1  # Retorna a posição do pivô
end

# Função para permutar (trocar) dois elementos em um array
function permute!(A, i, j)
    temp = A[i]
    A[i] = A[j]
    A[j] = temp
end

# Função para gerar diferentes cenários de entrada para os testes
function generate_input(n, scenario)
    if scenario == "melhor"
        return collect(1:n)  # Caso melhor: array ordenado
    elseif scenario == "pior"
        return collect(n:-1:1)  # Caso pior: array ordenado de forma decrescente
    else
        return rand(1:n, n)  # Caso aleatório: array com valores randômicos
    end
end

# Função para medir o tempo de execução do Quick Sort e calcular o erro relativo
function measure_time(scenario, sizes)
    times = []
    errors = []
    for size in sizes
        input = generate_input(size, scenario)
        local_times = []
        for _ in 1:5  # Executa 5 vezes para calcular a média e o desvio padrão
            time_elapsed = @elapsed quick_sort!(copy(input))
            push!(local_times, time_elapsed)
        end
        average_time = mean(local_times)  # Calcula o tempo médio
        push!(times, average_time)
        push!(errors, std(local_times) / average_time)  # Calcula o erro relativo
    end
    return times, errors
end

# Função para plotar o crescimento do erro relativo do tempo de execução
function plot_growth(scenarios, sizes)
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Erro Relativo", title="Erro Relativo do Tempo de Execução")

    for scenario in scenarios
        times, errors = measure_time(scenario, sizes)
        plot!(sizes, errors, label=scenario)  # Adiciona os dados ao gráfico
    end
    display(plot!())  # Exibe o gráfico
end

# Função principal
function main()
    scenarios = ["melhor", "pior", "aleatório"]  # Lista de cenários
    sizes = 100:100:1000  # Tamanhos dos arrays para teste
    plot_growth(scenarios, sizes)  # Plota o crescimento do erro relativo

    A = [16, 4, 10, 14, 7, 9, 3, 2, 8, 1]
    quick_sort!(A)  # Ordena o array usando Quick Sort
    println("Resultado do Quick Sort: ", A)  # Imprime o resultado
end

main()  # Chama a função principal para executar o código
