/*
EDA 2024
QuickC.c
Martinho Caeiro
19/03/2024

Quick Sort em C
*/

#include <stdio.h>
#include <stdlib.h>

// Função de comparação para o qsort
int comparar(const void *a, const void *b) {
    // Converte os ponteiros genéricos para inteiros e compara os valores apontados
    return (*(int*)a - *(int*)b);
}

int main() {
    // Array de números a serem ordenados
    int numeros[] = {5, 2, 9, 1, 6, 4, 3, 7, 8};
    // Determina o tamanho do array
    int tamanho = sizeof(numeros) / sizeof(numeros[0]);

    // Imprime o array original
    printf("Array original:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    // Ordena o array usando a função qsort da biblioteca padrão C
    qsort(numeros, tamanho, sizeof(int), comparar);

    // Imprime o array ordenado
    printf("Array ordenado:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    return 0;
}
