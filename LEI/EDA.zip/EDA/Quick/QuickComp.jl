"""
EDA 2024
QuickComp.jl
Martinho Caeiro
19/03/2024

Comparação Quick Sort com Merge Sort
"""

using Plots  # Importa o pacote Plots para criar gráficos

# Função para ordenar um array usando Merge Sort
function merge_sort!(A)
    if length(A) <= 1
        return A  # Retorna se o array tem 1 ou menos elementos
    end
    middle = div(length(A), 2)  # Encontra o ponto médio
    left = merge_sort!(A[1:middle])  # Ordena a metade esquerda
    right = merge_sort!(A[middle+1:end])  # Ordena a metade direita
    return merge(left, right)  # Mescla as duas metades ordenadas
end

# Função para mesclar dois arrays ordenados
function merge(left, right)
    result = similar(left, length(left) + length(right))  # Cria um array do mesmo tipo e tamanho da soma dos dois arrays
    i, j, k = 1, 1, 1  # Inicializa índices
    while i <= length(left) && j <= length(right)
        if left[i] <= right[j]
            result[k] = left[i]
            i += 1
        else
            result[k] = right[j]
            j += 1
        end
        k += 1
    end
    while i <= length(left)
        result[k] = left[i]
        i += 1
        k += 1
    end
    while j <= length(right)
        result[k] = right[j]
        j += 1
        k += 1
    end
    return result  # Retorna o array mesclado
end

# Função para reorganizar a estrutura de heap
function heapify!(A, i, n)
    l = 2 * i
    r = 2 * i + 1

    if l <= n && A[l] > A[i]
        largest = l
    else
        largest = i
    end

    if r <= n && A[r] > A[largest]
        largest = r
    end

    if largest != i
        A[i], A[largest] = A[largest], A[i]
        heapify!(A, largest, n)
    end
end

# Função para ordenar um array usando Quick Sort
function quick_sort!(A, p=1, r=length(A))
    if p < r
        q = quick_part!(A, p, r)  # Particiona o array e obtém o índice do pivô
        quick_sort!(A, p, q - 1)  # Ordena a parte esquerda
        quick_sort!(A, q + 1, r)  # Ordena a parte direita
    end
end

# Função para particionar o array para Quick Sort
function quick_part!(A, p, r)
    x = A[r]  # Escolhe o último elemento como pivô
    i = p - 1  # Inicializa o índice do menor elemento

    for j = p:r - 1
        if A[j] <= x
            i += 1
            A[i], A[j] = A[j], A[i]  # Troca os elementos
        end 
    end
    A[i + 1], A[r] = A[r], A[i + 1]  # Coloca o pivô na posição correta
    return i + 1  # Retorna a posição do pivô
end

# Função para gerar diferentes cenários de entrada para os testes
function generate_input(n, scenario)
    if scenario == "melhor"
        return collect(1:n)  # Caso melhor: array ordenado
    elseif scenario == "pior"
        return collect(n:-1:1)  # Caso pior: array ordenado de forma decrescente
    else
        return rand(1:n, n)  # Caso aleatório: array com valores randômicos
    end
end

# Função para medir o tempo de execução dos algoritmos de ordenação
function measure_time(sort_function, scenario, sizes)
    times = []
    for size in sizes
        input = generate_input(size, scenario)
        time_elapsed = @elapsed sort_function(copy(input))  # Mede o tempo de execução
        push!(times, time_elapsed)
    end
    return times
end

# Função para plotar o crescimento do tempo de execução com o aumento do tamanho do array
function plot_growth(sort_functions, scenarios, sizes)
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Tempo (s)", title="Aumento do Tempo com a Complexidade")

    for sort_function in sort_functions
        for scenario in scenarios
            times = measure_time(sort_function, scenario, sizes)
            plot!(sizes, times, label="$sort_function - $scenario")  # Adiciona os dados ao gráfico
        end
    end
    display(plot!())  # Exibe o gráfico
end

# Função principal
function main()
   sort_functions = [quick_sort!, merge_sort!]  # Lista de funções de ordenação
   scenarios = ["melhor", "pior", "aleatório"]  # Lista de cenários
   sizes = 100:100:1000  # Tamanhos dos arrays para teste
   plot_growth(sort_functions, scenarios, sizes)  # Plota o crescimento do tempo de execução

   A = [16, 4, 10, 14, 7, 9, 3, 2, 8, 1]
   quick_sort!(A)  # Ordena o array usando Quick Sort
   print("Resultado do Quick Sort: ", A)  # Imprime o resultado
end

main()  # Chama a função principal para executar o código
