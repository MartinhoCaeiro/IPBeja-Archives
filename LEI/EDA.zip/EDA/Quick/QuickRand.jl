"""
EDA 2024
QuickRand.jl
Martinho Caeiro
19/03/2024

Quick Sort Versão Aleatorizada
"""

using Plots  # Importa o pacote Plots para criar gráficos

# Função principal do Quick Sort aleatorizado
function rand_quick_sort!(A, p=1, r=length(A))
    if p < r
        q = rand_quick_part!(A, p, r)  # Particiona o array de forma aleatória
        rand_quick_sort!(A, p, q - 1)  # Ordena a parte esquerda
        rand_quick_sort!(A, q + 1, r)  # Ordena a parte direita
    end
end

# Função para particionar o array de forma aleatória
function rand_quick_part!(A, p, r)
    i = rand(p:r)  # Seleciona um índice aleatório entre p e r
    A[r], A[i] = A[i], A[r]  # Troca o elemento aleatório com o último elemento
    return quick_part!(A, p, r)  # Chama a função de particionamento padrão
end

# Função de particionamento padrão do Quick Sort
function quick_part!(A, p, r)
    x = A[r]  # Escolhe o pivô como o último elemento
    i = p - 1  # Inicializa o índice do menor elemento

    for j = p:r - 1
        if A[j] <= x
            i += 1
            A[i], A[j] = A[j], A[i]  # Troca os elementos
        end 
    end
    A[i + 1], A[r] = A[r], A[i + 1]  # Coloca o pivô na posição correta
    return i + 1  # Retorna a posição do pivô
end

# Função para gerar diferentes cenários de entrada para os testes
function generate_input(n, scenario)
    if scenario == "melhor"
        return collect(1:n)  # Caso melhor: array ordenado
    elseif scenario == "pior"
        return collect(n:-1:1)  # Caso pior: array ordenado de forma decrescente
    else
        return rand(1:n, n)  # Caso aleatório: array com valores randômicos
    end
end

# Função para medir o tempo de execução do Quick Sort aleatorizado
function measure_time(scenario, sizes)
    times = []
    for size in sizes
        input = generate_input(size, scenario)
        time_elapsed = @elapsed begin
            rand_quick_sort!(input)  # Mede o tempo de execução
        end
        push!(times, time_elapsed)
    end
    return times
end

# Função para plotar o crescimento do tempo de execução com o aumento do tamanho do array
function plot_growth(scenarios, sizes)
    plot(legend=:bottomright, xlabel="Tamanho da Amostra (n)", ylabel="Tempo (s)", title="Aumento do Tempo com a Complexidade")

    for scenario in scenarios
        times = measure_time(scenario, sizes)
        plot!(sizes, times, label=scenario)  # Adiciona os dados ao gráfico
    end
    display(plot!())  # Exibe o gráfico
end

# Função principal
function main()
    scenarios = ["melhor", "pior", "aleatório"]  # Lista de cenários
    sizes = 100:100:1000  # Tamanhos dos arrays para teste
    plot_growth(scenarios, sizes)  # Plota o crescimento do tempo de execução

    A = [16, 4, 10, 14, 7, 9, 3, 2, 8, 1]
    rand_quick_sort!(A)  # Ordena o array usando Quick Sort aleatorizado
    println("Resultado do Quick Sort Versão Aleatorizada: ", A)  # Imprime o resultado
end

main()  # Chama a função principal para executar o código
