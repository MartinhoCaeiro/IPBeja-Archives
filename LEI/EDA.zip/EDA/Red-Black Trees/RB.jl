"""
EDA 2024
RB.jl
Martinho Caeiro
23/04/2024

Árvores Red-Black
"""

# Definição da estrutura de um nó da árvore Red-Black
mutable struct Node
    key::Int  # Chave do nó
    color::Symbol  # Cor do nó (:RED ou :BLACK)
    left::Union{Node, Nothing}  # Ponteiro para o filho esquerdo
    right::Union{Node, Nothing}  # Ponteiro para o filho direito
    p::Union{Node, Nothing}  # Ponteiro para o pai
end

# Definição da estrutura da árvore Red-Black
mutable struct Tree
    root::Union{Node, Nothing}  # Raiz da árvore
    nothing::Node  # Nó sentinela que representa "nada"
end

# Inicializa uma árvore Red-Black com um nó sentinela
function initialize_tree()
    nothing_node = Node(0, :BLACK, nothing, nothing, nothing)  # Nó sentinela
    return Tree(nothing, nothing_node)  # Cria a árvore com a raiz e o nó sentinela
end

# Rotação à esquerda
function left_rotate!(T, x)
    y = x.right  # Define y
    x.right = y.left  # Transforma a subárvore esquerda de y na subárvore direita de x

    if y.left != T.nothing
        y.left.p = x  # Atualiza o pai de y.left
    end

    y.p = x.p  # Liga o pai de x a y

    if x.p == T.nothing
        T.root = y  # Atualiza a raiz da árvore
    elseif x == x.p.left
        x.p.left = y  # Atualiza o filho esquerdo do pai de x
    else
        x.p.right = y  # Atualiza o filho direito do pai de x
    end

    y.left = x  # Coloca x à esquerda de y
    x.p = y  # Define o pai de x como y
end

# Rotação à direita
function right_rotate!(T, x)
    y = x.left  # Define y
    x.left = y.right  # Transforma a subárvore direita de y na subárvore esquerda de x

    if y.right != T.nothing
        y.right.p = x  # Atualiza o pai de y.right
    end

    y.p = x.p  # Liga o pai de x a y

    if x.p == T.nothing
        T.root = y  # Atualiza a raiz da árvore
    elseif x == x.p.right
        x.p.right = y  # Atualiza o filho direito do pai de x
    else
        x.p.left = y  # Atualiza o filho esquerdo do pai de x
    end

    y.right = x  # Coloca x à direita de y
    x.p = y  # Define o pai de x como y
end

# Inserção de um nó na árvore Red-Black
function insert!(T, z)
    y = T.nothing  # Inicializa y como nó sentinela
    x = T.root  # Começa pela raiz da árvore

    while x != T.nothing
        y = x  # Move y para baixo
        if z.key < x.key
            x = x.left  # Move x para a esquerda
        else
            x = x.right  # Move x para a direita
        end
    end

    z.p = y  # Define o pai de z como y

    if y == T.nothing
        T.root = z  # Define z como a raiz da árvore
    elseif z.key < y.key
        y.left = z  # Define z como filho esquerdo de y
    else
        y.right = z  # Define z como filho direito de y
    end

    z.left = T.nothing  # Define o filho esquerdo de z como nó sentinela
    z.right = T.nothing  # Define o filho direito de z como nó sentinela
    z.color = :RED  # Define a cor de z como vermelho
    insert_fixup!(T, z)  # Corrige a árvore para manter as propriedades Red-Black
end

# Corrige a árvore após a inserção para manter as propriedades Red-Black
function insert_fixup!(T, z)
    while z.p.color == :RED
        if z.p == z.p.p.left
            y = z.p.p.right  # Tio de z
            if y.color == :RED
                z.p.color = :BLACK
                y.color = :BLACK
                z.p.p.color = :RED
                z = z.p.p
            else
                if z == z.p.right
                    z = z.p
                    left_rotate!(T, z)
                end
                z.p.color = :BLACK
                z.p.p.color = :RED
                right_rotate!(T, z.p.p)
            end
        else
            y = z.p.p.left  # Tio de z
            if y.color == :RED
                z.p.color = :BLACK
                y.color = :BLACK
                z.p.p.color = :RED
                z = z.p.p
            else
                if z == z.p.left
                    z = z.p
                    right_rotate!(T, z)
                end
                z.p.color = :BLACK
                z.p.p.color = :RED
                left_rotate!(T, z.p.p)
            end
        end
    end
    T.root.color = :BLACK
end

# Transplanta um nó na árvore
function transplant!(T, u, v)
    if u.p == T.nothing
        T.root = v  # Atualiza a raiz da árvore
    elseif u == u.p.left
        u.p.left = v  # Atualiza o filho esquerdo do pai de u
    else
        u.p.right = v  # Atualiza o filho direito do pai de u
    end
    v.p = u.p  # Atualiza o pai de v
end

# Deleta um nó da árvore Red-Black
function delete!(T, z)
    y = z
    y_original_color = y.color

    if z.left == T.nothing
        x = z.right
        transplant!(T, z, z.right)
    elseif z.right == T.nothing
        x = z.left
        transplant!(T, z, z.left)
    else
        y = minimum(z.right)
        y_original_color = y.color
        x = y.right
        if y.p == z
            x.p = y
        else
            transplant!(T, y, y.right)
            y.right = z.right
            y.right.p = y
        end
        transplant!(T, z, y)
        y.left = z.left
        y.left.p = y
        y.color = z.color
    end

    if y_original_color == :BLACK
        delete_fixup!(T, x)
    end
end

# Encontra o nó com o valor mínimo
function minimum!(x)
    while x.left !== nothing
        x = x.left
    end
    return x
end

# Corrige a árvore após a deleção para manter as propriedades Red-Black
function delete_fixup!(T, x)
    while x != T.root && x.color == :BLACK
        if x == x.p.left
            w = x.p.right
            if w.color == :RED
                w.color = :BLACK
                x.p.color = :RED
                left_rotate!(T, x.p)
                w = x.p.right
            end
            if w.left.color == :BLACK && w.right.color == :BLACK
                w.color = :RED
                x = x.p
            else
                if w.right.color == :BLACK
                    w.left.color = :BLACK
                    w.color = :RED
                    right_rotate!(T, w)
                    w = x.p.right
                end
                w.color = x.p.color
                x.p.color = :BLACK
                w.right.color = :BLACK
                left_rotate!(T, x.p)
                x = T.root
            end
        else
            w = x.p.left
            if w.color == :RED
                w.color = :BLACK
                x.p.color = :RED
                right_rotate!(T, x.p)
                w = x.p.left
            end
            if w.right.color == :BLACK && w.left.color == :BLACK
                w.color = :RED
                x = x.p
            else
                if w.left.color == :BLACK
                    w.right.color = :BLACK
                    w.color = :RED
                    left_rotate!(T, w)
                    w = x.p.left
                end
                w.color = x.p.color
                x.p.color = :BLACK
                w.left.color = :BLACK
                right_rotate!(T, x.p)
                x = T.root
            end
        end
    end
    x.color = :BLACK
end

# Função principal para testar a implementação
function main()
    T = initialize_tree()

    insert!(T, Node(10, :RED, T.nothing, T.nothing, T.nothing))
    insert!(T, Node(20, :RED, T.nothing, T.nothing, T.nothing))
    insert!(T, Node(30, :RED, T.nothing, T.nothing, T.nothing))
    insert!(T, Node(40, :RED, T.nothing, T.nothing, T.nothing))
    insert!(T, Node(50, :RED, T.nothing, T.nothing, T.nothing))

    delete!(T, T.root)  # Deleta a raiz da árvore
end

main()  # Chama a função principal para executar o código
