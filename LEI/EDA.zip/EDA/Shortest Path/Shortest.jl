"""
EDA 2024
Shortest.jl
Martinho Caeiro
14/05/2024

Algoritmo de Bellman-Ford e Dijsktra (Custos: Distância entre capitais de distritos de Portugal)
"""

module ShortestPaths

using DataStructures

# Definições das estruturas e funções

# Define uma estrutura para representar cada vértice no grafo.
# Cada vértice tem um identificador único (id), uma distância (d) e um predecessor (pi).
mutable struct Vertex
    id::Int
    d::Float64
    pi::Union{Nothing,Vertex}  # Pode ser um Vertex ou Nothing
end

# Define a estrutura de grafo, que contém um vetor de vértices,
# um vetor de tuplas representando as arestas e um dicionário de adjacências.
struct Graph
    V::Vector{Vertex}
    E::Vector{Tuple{Vertex,Vertex,Float64}}
    Adj::Dict{Vertex,Vector{Vertex}}  # Dicionário de adjacências: vértice -> lista de vértices adjacentes
end

# Função que inicializa as distâncias dos vértices em G a partir de uma fonte s
function single_source!(G::Graph, s::Vertex)
    for v in G.V
        v.d = Inf  # Define a distância de todos os vértices como infinito
        v.pi = nothing  # Define o predecessor de todos os vértices como nothing
    end
    s.d = 0  # Define a distância do vértice de origem como 0
end

# Função que relaxa uma aresta (u, v) se encontrar um caminho mais curto para v através de u
function relax!(u::Vertex, v::Vertex, w::Function)
    if v.d > u.d + w(u, v)  # Se encontrar um caminho mais curto para v através de u
        v.d = u.d + w(u, v)  # Atualiza a distância de v
        v.pi = u  # Define o predecessor de v como u
    end
end

# Algoritmo de Bellman-Ford para encontrar o caminho mais curto a partir de uma fonte s em G
function bellman_ford!(G::Graph, w::Function, s::Vertex)
    single_source!(G, s)  # Inicializa as distâncias a partir de s

    # Relaxa todas as arestas repetidamente
    for i in 1:(length(G.V)-1)  # Relaxa as arestas |V| - 1 vezes
        for (u, v, weight) in G.E
            relax!(u, v, (x, y) -> weight)  # Relaxa a aresta (u, v)
        end
    end

    # Verifica se há ciclos de peso negativo
    for (u, v, weight) in G.E
        if v.d > u.d + weight
            return false  # Retorna falso se encontrar um ciclo de peso negativo
        end
    end

    return true  # Retorna verdadeiro se não houver ciclos de peso negativo
end

# Algoritmo de Dijkstra para encontrar o caminho mais curto a partir de uma fonte s em G
function dijkstra!(G::Graph, w::Function, s::Vertex)
    single_source!(G, s)  # Inicializa as distâncias a partir de s
    S = Set{Vertex}()  # Conjunto de vértices processados
    Q = PriorityQueue{Tuple{Float64,Int},Float64}()  # Fila de prioridade para selecionar o próximo vértice

    # Inicializa a fila de prioridade com todas as distâncias
    for v in G.V
        enqueue!(Q, (v.d, v.id), v.d)  # Adiciona a distância de v à fila de prioridade
    end

    # Enquanto houver vértices não processados na fila de prioridade
    while !isempty(Q)
        (_, u_id) = dequeue!(Q)  # Remove o vértice com a menor distância da fila
        u = G.V[u_id]  # Obtém o vértice correspondente

        push!(S, u)  # Adiciona u ao conjunto de vértices processados

        # Relaxa todas as arestas saindo de u
        for v in G.Adj[u]
            if v ∉ S && v.d > u.d + w(u, v)  # Se encontrar um caminho mais curto para v através de u
                relax!(u, v, w)  # Relaxa a aresta (u, v)
                enqueue!(Q, (v.d, v.id), v.d)  # Atualiza a fila de prioridade com a nova distância de v
            end
        end
    end
end

# Algoritmo de ordenação topológica
function topological_sort!(G::Graph)
    visited = Dict{Vertex,Bool}()  # Dicionário para rastrear se um vértice foi visitado
    for v in G.V
        visited[v] = false  # Define todos os vértices como não visitados
    end

    stack = []  # Pilha para armazenar a ordenação topológica

    # Função auxiliar para fazer a busca em profundidade (DFS)
    function dfs!(v)
        visited[v] = true  # Marca o vértice como visitado
        for u in G.Adj[v]  # Para cada vértice adjacente a v
            if !visited[u]  # Se o vértice ainda não foi visitado
                dfs!(u)  # Chama recursivamente a DFS a partir de u
            end
        end
        push!(stack, v)  # Adiciona v à pilha após visitar todos os seus vizinhos
    end

    # Percorre todos os vértices do grafo
    for v in G.V
        if !visited[v]  # Se o vértice ainda não foi visitado
            dfs!(v)  # Chama a DFS a partir de v
        end
    end

    return reverse(stack)  # Retorna a ordenação topológica reversa da pilha
end

# Algoritmo para encontrar os caminhos mais curtos usando ordenação topológica
function shortest_paths!(G::Graph, w::Function, s::Vertex)
    order = topological_sort!(G)  # Obtém a ordenação topológica dos vértices
    single_source!(G, s)  # Inicializa as distâncias a partir de s

    # Relaxa todas as arestas de acordo com a ordenação topológica
    for u in order
        for v in G.Adj[u]
            relax!(u, v, w)  # Relaxa a aresta (u, v)
        end
    end
end

# Função main
function main()
    # Criação de vértices
    lisboa = Vertex(1, Inf, nothing)
    porto = Vertex(2, Inf, nothing)
    faro = Vertex(3, Inf, nothing)
    braga = Vertex(4, Inf, nothing)
    vila_real = Vertex(5, Inf, nothing)
    coimbra = Vertex(6, Inf, nothing)

    vertices = [lisboa, porto, faro, braga, vila_real, coimbra]

    # Criação de arestas (com pesos)
    edges = [(lisboa, porto, 313.0),
        (lisboa, faro, 278.0),
        (porto, braga, 55.0),
        (porto, vila_real, 120.0),
        (braga, vila_real, 108.0),
        (lisboa, coimbra, 203.0)]

    # Lista de adjacências
    adj = Dict(lisboa => [porto, faro, coimbra],
        porto => [braga, vila_real],
        faro => [],
        braga => [vila_real],
        vila_real => [],
        coimbra => [])

    # Criação do grafo
    G = Graph(vertices, edges, adj)

    # Função de peso
    w(u, v) = first(filter(e -> e[1] == u && e[2] == v, edges))[3]

    # Chamando Bellman-Ford
    println("Executando Bellman-Ford:")
    if bellman_ford!(G, w, lisboa)
        println("Distâncias mínimas a partir de Lisboa:")
        for v in G.V
            println("Vértice $(v.id): Distância = $(v.d), Predecessor = $(v.pi === nothing ? "None" : v.pi.id)")
        end
    else
        println("O grafo contém um ciclo de peso negativo.")
    end

    # Resetando as distâncias e predecessores
    single_source!(G, lisboa)

    # Chamando Dijkstra
    println("\nExecutando Dijkstra:")
    dijkstra!(G, w, lisboa)
    println("Distâncias mínimas a partir de Lisboa:")
    for v in G.V
        println("Vértice $(v.id): Distância = $(v.d), Predecessor = $(v.pi === nothing ? "None" : v.pi.id)")
    end

    # Resetando as distâncias e predecessores
    single_source!(G, lisboa)

    # Chamando shortest_paths
    println("\nExecutando Shortest Paths (Topological Sort):")
    shortest_paths!(G, w, lisboa)
    println("Distâncias mínimas a partir de Lisboa:")
    for v in G.V
        println("Vértice $(v.id): Distância = $(v.d), Predecessor = $(v.pi === nothing ? "None" : v.pi.id)")
    end
end

end # módulo ShortestPaths

# Chama a função main
ShortestPaths.main()

