"""
EDA 2024
Bubble.jl
Martinho Caeiro
27/02/2024

Bubble Sort e Insertion Sort
"""

using Plots, Statistics

# Define o tamanho do array de teste
N = 20

# Função de ordenação Bubble Sort
function bubble_sort!(A)
    len = length(A)
    for i = 1:len-1
        for j = 2:len
            if A[j] < A[j-1]
                tmp = A[j-1]
                A[j-1] = A[j]
                A[j] = tmp
            end
        end
    end
    return A
end

# Função de ordenação Insertion Sort
function insertion_sort!(A)
    len = length(A)
    for i in 2:len
        tmp = A[i]
        j = i - 1
        while j >= 1 && A[j] > tmp
            A[j+1] = A[j]
            j -= 1
        end
        A[j+1] = tmp
    end
    return A
end

# Função para medir o tempo de execução de um algoritmo de ordenação
function measure_time(sorting_algorithm, x)
    t1 = time_ns()  # Marca o tempo inicial
    sorting_algorithm(x)
    t2 = time_ns()  # Marca o tempo final
    return (t2 - t1) / 1e9  # Retorna o tempo em segundos
end

# Função para gerar uma sequência de tamanhos de array
function generate_sizes(start, stop, step)
    return start:step:stop
end

# Função para executar testes de desempenho em um algoritmo de ordenação
function run_tests(sorting_algorithm)
    sizes = generate_sizes(100, 1000, 100)  # Gera tamanhos de array de 100 a 1000, com passo de 100
    times = Float64[]
    
    for size in sizes
        x = randn(size)  # Gera um array de números aleatórios de tamanho 'size'
        time_taken = measure_time(sorting_algorithm, x)  # Mede o tempo de execução do algoritmo
        push!(times, time_taken)  # Adiciona o tempo à lista
    end
    return sizes, times
end

# Função para criar um gráfico normal de desempenho dos algoritmos
function normal_graph()
    bubble_sizes, bubble_times = run_tests(bubble_sort!)  # Executa testes com Bubble Sort
    insertion_sizes, insertion_times = run_tests(insertion_sort!)  # Executa testes com Insertion Sort

    plot(bubble_sizes, bubble_times, label="Bubble Sort", xlabel="Tamanho do Array", ylabel="Tempo (s)", linewidth=2)
    plot!(insertion_sizes, insertion_times, label="Insertion Sort", linewidth=2)
    title!("Comparação de Desempenho: Bubble Sort vs Insertion Sort")
end

# Função para criar um gráfico de desempenho relativo dos algoritmos
function relative_graph()
    bubble_sizes, bubble_times = run_tests(bubble_sort!)  # Executa testes com Bubble Sort
    insertion_sizes, insertion_times = run_tests(insertion_sort!)  # Executa testes com Insertion Sort

    bubble_errors = abs.((bubble_times .- mean(bubble_times)) ./ mean(bubble_times))
    insertion_errors = abs.((insertion_times .- mean(insertion_times)) ./ mean(insertion_times))

    filtered_bubble_sizes = bubble_sizes[bubble_errors .< 0.1]
    filtered_bubble_times = bubble_times[bubble_errors .< 0.1]
    filtered_insertion_sizes = insertion_sizes[insertion_errors .< 0.1]
    filtered_insertion_times = insertion_times[insertion_errors .< 0.1]

    plot(filtered_bubble_sizes, filtered_bubble_times, yerr=filtered_bubble_times.*0.1, label="Bubble Sort", xlabel="Tamanho do Array", ylabel="Tempo (s)", linewidth=2)
    plot!(filtered_insertion_sizes, filtered_insertion_times, yerr=filtered_insertion_times.*0.1, label="Insertion Sort", linewidth=2)
    title!("Comparação de Desempenho: Bubble Sort vs Insertion Sort (Erro Relativo < 10%)")
end

# Função principal para executar o código
function main()
    numeros = randn(N)  # Gera um array de N números aleatórios
    r = bubble_sort!(numeros)  # Ordena o array usando Bubble Sort
    m = insertion_sort!(numeros)  # Ordena o array usando Insertion Sort
    
    println("Resultado do Bubble Sort: $r\n")
    println("Resultado do Insertion Sort: $m\n")

    normal_graph()  # Cria o gráfico de desempenho normal
    relative_graph()  # Cria o gráfico de desempenho relativo
end

# Chamada da função principal
main()
