"""
EDA 2024
Recursive.jl
Martinho Caeiro
27/02/2024

Recursiva do Bubble Sort e Insertion Sort
"""

N = 20  # Define o tamanho do array para os testes

# Função recursiva para Bubble Sort
function recursive_bubble_sort!(A, len=length(A))
    if len <= 1
        return A
    end
    
    for i in 1:len-1
        if A[i] > A[i+1]
            A[i], A[i+1] = A[i+1], A[i]  # Troca os elementos adjacentes se estiverem na ordem errada
        end
    end
    
    recursive_bubble_sort!(A, len-1)  # Chama a função recursivamente para o subarray
end

# Função recursiva para Insertion Sort
function recursive_insertion_sort!(A, len=length(A))
    if len <= 1
        return A
    end
    
    recursive_insertion_sort!(A, len-1)  # Ordena o subarray recursivamente
    
    last = A[len]
    j = len - 1
    while j >= 1 && A[j] > last
        A[j+1] = A[j]  # Move os elementos maiores que 'last' uma posição para a direita
        j -= 1
    end
    A[j+1] = last  # Insere 'last' na posição correta
    
    return A
end

# Bubble Sort usando comprehensions (compreensões de lista)
function comprehensions_bubble_sort!(A)
    len = length(A)
    len <= 1 && return A
    
    sorted = [A[i] > A[i+1] ? (A[i+1], A[i]) : (A[i], A[i+1]) for i in 1:len-1]
    A = [sorted[1:end-1] ; A[end]]  # Concatena o array ordenado com o último elemento
    
    recursive_bubble_sort!(A[1:end-1])  # Chama a função recursiva para o subarray
end

# Insertion Sort usando comprehensions (compreensões de lista)
function comprehensions_insertion_sort!(A)
    len = length(A)
    len <= 1 && return A
    
    A[1:end-1] = recursive_insertion_sort!(A[1:end-1])  # Ordena o subarray recursivamente
    
    last = A[end]
    j = len - 1
    while j >= 1 && A[j] > last
        A[j+1] = A[j]  # Move os elementos maiores que 'last' uma posição para a direita
        j -= 1
    end
    A[j+1] = last  # Insere 'last' na posição correta
    
    return A
end

# Função para calcular o desvio padrão de um array
function calculate_std_deviation(data)
    n = length(data)
    mean_val = sum(data) / n
    squared_diff = map(x -> (x - mean_val)^2, data)  # Calcula a diferença quadrada de cada elemento em relação à média
    variance = sum(squared_diff) / n
    std_deviation = sqrt(variance)  # Calcula a raiz quadrada da variância
    return std_deviation
end

# Função para remover números negativos de um array
function remove_negative_numbers(data)
    return filter(x -> x >= 0, data)  # Filtra os elementos que são maiores ou iguais a 0
end

# Função principal para executar o código
function main()
    numeros = randn(N)  # Gera um array de N números aleatórios
    r1 = recursive_bubble_sort!(numeros)  # Ordena o array usando Bubble Sort recursivo
    m1 = recursive_insertion_sort!(numeros)  # Ordena o array usando Insertion Sort recursivo
    r2 = comprehensions_bubble_sort!(numeros)  # Ordena o array usando comprehensions no Bubble Sort
    m2 = comprehensions_insertion_sort!(numeros)  # Ordena o array usando comprehensions no Insertion Sort
    r3 = calculate_std_deviation(numeros)  # Calcula o desvio padrão do array
    m3 = remove_negative_numbers(numeros)  # Remove números negativos do array
    
    println("Resultado do Bubble Sort Recursiva: $r1\n")
    println("Resultado do Insertion Sort Recursiva: $m1\n")
    println("Resultado do Bubble Sort Comprehensions: $r2\n")
    println("Resultado do Insertion Sort Comprehensions: $m2\n")
    println("Resultado do Desvio Padrão: $r3\n")
    println("Resultado da Remoção de Números Negativos: $m3\n")
end

# Chama a função principal
main()
