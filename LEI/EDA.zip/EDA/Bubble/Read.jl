"""
EDA 2024
Read.jl
Martinho Caeiro
27/02/2024

Leitura de CSV
"""

using CSV, DataFrames

# Função de ordenação Bubble Sort
function bubble_sort!(A)
    len = length(A)
    for i = 1:len-1
        for j = 2:len
            if A[j] < A[j-1]
                tmp = A[j-1]
                A[j-1] = A[j]
                A[j] = tmp
            end
        end
    end
    return A
end

# Função de ordenação Insertion Sort
function insertion_sort!(A)
    len = length(A)
    for i in 2:len
        tmp = A[i]
        j = i - 1
        while j >= 1 && A[j] > tmp
            A[j+1] = A[j]
            j -= 1
        end
        A[j+1] = tmp
    end
    return A
end

# Função principal para executar o código
function main()
    # Lê o arquivo CSV 'alunos.csv' localizado no diretório 'EDA' e armazena em um DataFrame
    dados_alunos = CSV.read("EDA\\alunos.csv", header=false, DataFrame)
    
    # Extrai a primeira coluna do DataFrame (assumindo que é a coluna dos números mecanográficos dos alunos)
    dados_alunos_coluna = dados_alunos[:, 1]
    
    # Ordena a coluna extraída usando Bubble Sort
    b = bubble_sort!(dados_alunos_coluna)
    
    # Ordena a coluna extraída usando Insertion Sort
    i = insertion_sort!(dados_alunos_coluna)

    # Imprime os resultados da ordenação
    println("Dados dos alunos ordenados por número mecanográfico usando Bubble Sort: $b\n")
    println("Dados dos alunos ordenados por número mecanográfico usando Insertion Sort: $i\n")
end

# Chama a função principal
main()
