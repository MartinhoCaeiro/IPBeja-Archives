// Chamada de pacotes
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <pthread.h>
#include <unistd.h>

#define MAX_NAME 15  // Número máximo de caracteres no nome
#define MAX_ENERGY 100 // Energia máxima
#define N_ROOMS 15 // Número de salas
#define MAX_ROOM_DESCRIPTION 200 // Número máximo de caracteres na descrição da sala
#define START_ROOM 0 // Sala inicial
#define ANS_MOVE 10 // Número máximo de caracteres na resposta de movimento

pthread_cond_t combatCondition = PTHREAD_COND_INITIALIZER;
pthread_mutex_t combatMutex = PTHREAD_MUTEX_INITIALIZER;
int inCombat = 0;

// Personagem com os seus atributos
struct Player {
    char name[MAX_NAME];
    int energy;
    int position;
    int key;
    int treasure;
};

// Sala com os seus atributos
struct Room {
    int north;
    int south;
    int west;
    int east;
    int up;
    int down;
    char description[MAX_ROOM_DESCRIPTION];
    int treasure;
};

// Monstro com os seus atributos
struct Monster {
    int mEnergy;
    int mPosition;
};

// Chamada de funções
void PVP(int *pEnergy, int *mEnergy);
void startPlayer(struct Player *pPlayer);
void showPlayerInfo(struct Player player);
void createMap(struct Room *pRooms);
void game(struct Player *pPlayer, struct Room *pRooms);
void moveMonster(struct Monster *pM1);
void describePos(struct Room *pRoom);
void movePlayer(struct Player *pPlayer, struct Room *pRooms, char *moveInput);
pthread_t monsterThread;
void* moveMonsterThread(void* arg);


// Função principal
int main() {
    struct Player player;
    struct Room rooms[N_ROOMS];

    srand(time(NULL));

    startPlayer(&player);
    showPlayerInfo(player);
    createMap(rooms);
    game(&player, rooms);


    return 0;
}

// Função que inicia o personagem
void startPlayer(struct Player *pPlayer) {
    printf("Olá Samurai, sou o Johnny Silverhand, bem vindo a Night City em 2077! Diz o teu nome, para colocarmos na tua lápide!\n");
    scanf("%s", pPlayer->name);
    pPlayer->energy = MAX_ENERGY;
    pPlayer->position = START_ROOM;
    pPlayer->treasure = 0;
    pPlayer->key = 0;

}

// Função que mostra as informações do personagem
void showPlayerInfo(struct Player player) {
    printf("CARREGANDO INFORMAÇÕES DO USUÁRIO %s\n", player.name);
    printf("O TEU CYBERWARE TEM %d PONTOS DE VIDA!\n", player.energy);
    printf("A SUA LOCALIZAÇÃO ATUAL É A SALA %d\n", player.position);
}

// Função que cria o mapa
void createMap(struct Room *pRooms) {

    //Sala 0
    pRooms[0].north  = -1;
    pRooms[0].south = -1;
    pRooms[0].east = 1;
    pRooms[0].west = -1;
    pRooms[0].up = -1;
    pRooms[0].down = -1;
    strcpy(pRooms[0].description, "A torre Arasaka, da ultima vez que cá estive a situação tornou-se...explosiva.\n");
    pRooms[0].treasure = -1;

    //Sala 1
    pRooms[1].north  = 3;
    pRooms[1].south = -1;
    pRooms[1].east = 2;
    pRooms[1].west = 0;
    pRooms[1].up = -1;
    pRooms[1].down = -1;
    strcpy(pRooms[1].description, "A recepção da torre Arasaka, possivelmente a pior maneira de invadir um local altamente seguro, mas tú é que sabes...\n");
    pRooms[1].treasure = -1;

    //Sala 2
    pRooms[2].north  = -1;
    pRooms[2].south = -1;
    pRooms[2].east = -1;
    pRooms[2].west = 1;
    pRooms[2].up = -1;
    pRooms[2].down = -1;
    strcpy(pRooms[2].description, "A sala dos funcionários da recepção...estranhamente vazia...\n");
    pRooms[2].treasure = -1;

    //Sala 3
    pRooms[3].north  = 4;
    pRooms[3].south = 1;
    pRooms[3].east = 5;
    pRooms[3].west = -1;
    pRooms[3].up = -1;
    pRooms[3].down = -1;
    strcpy(pRooms[3].description, "O corredor principal...Estás a ouvir o mesmo que eu?\n");
    pRooms[3].treasure = -1;

    //Sala 4
    pRooms[4].north  = -1;
    pRooms[4].south = 3;
    pRooms[4].east = -1;
    pRooms[4].west = -1;
    pRooms[4].up = -1;
    pRooms[4].down = -1;
    strcpy(pRooms[4].description, "A cozinha principal...Não me parece que tenhas cara de cozinheiro, por isso não brinques muito.\n");
    pRooms[4].treasure = -1;

    //Sala 5
    pRooms[5].north  = 6;
    pRooms[5].south = -1;
    pRooms[5].east = 7;
    pRooms[5].west = 3;
    pRooms[5].up = -1;
    pRooms[5].down = -1;
    strcpy(pRooms[5].description, "Este poderá ser o corredor mais longo de sempre... Já estou cansado de tanto andar. \n");
    pRooms[5].treasure = -1;

    //Sala 6
    pRooms[6].north  = -1;
    pRooms[6].south = 5;
    pRooms[6].east = -1;
    pRooms[6].west = -1;
    pRooms[6].up = -1;
    pRooms[6].down = -1;
    strcpy(pRooms[6].description, "A sala dos seguranças Arasaka...Acho que estou a ver um upgrade Cyberware de defesa no cacifo.\n");
    pRooms[6].treasure = -1;

    //Sala 7
    pRooms[7].north  = -1;
    pRooms[7].south = -1;
    pRooms[7].east = 9;
    pRooms[7].west = 5;
    pRooms[7].up = -1;
    pRooms[7].down = -1;
    strcpy(pRooms[7].description, "OUTRO CORREDOR?! Isto está a tornar-se ridiculo, devem pensar que estamos no Walking Simulator.\n");
    pRooms[7].treasure = -1;

    //Sala 8
    pRooms[8].north  = -1;
    pRooms[8].south = -1;
    pRooms[8].east = -1;
    pRooms[8].west = -1;
    pRooms[8].up = 7;
    pRooms[8].down = -1;
    strcpy(pRooms[8].description, "Uma cave... Parece que era utilizada como laboratório.\n");
    pRooms[8].treasure = -1;

    //Sala 9
    pRooms[9].north  = 10;
    pRooms[9].south = -1;
    pRooms[9].east = -1;
    pRooms[9].west = 7;
    pRooms[9].up = -1;
    pRooms[9].down = -1;
    strcpy(pRooms[9].description, "A recepção para o escritório de Saburo Arasaka... Espera! Aquele é o Sandayu Oda?!\n");
    pRooms[9].treasure = -1;

    //Sala 10
    pRooms[10].north  = 11;
    pRooms[10].south = 9;
    pRooms[10].east = -1;
    pRooms[10].west = -1;
    pRooms[10].up = -1;
    pRooms[10].down = -1;
    strcpy(pRooms[10].description, "Ok...se este não for o ultimo corredor eu vou detonar outra Nuke tal como em 2023.\n");
    pRooms[10].treasure = -1;

    //Sala 11
    pRooms[11].north  = 12;
    pRooms[11].south = 10;
    pRooms[11].east = -1;
    pRooms[11].west = 13;
    pRooms[11].up = -1;
    pRooms[11].down = -1;
    strcpy(pRooms[11].description, "Que barulho foi este? Estão a organizar uma festa ou quê?\n");
    pRooms[11].treasure = -1;

    //Sala 12
    pRooms[12].north  = -1;
    pRooms[12].south = 11;
    pRooms[12].east = -1;
    pRooms[12].west = -1;
    pRooms[12].up = -1;
    pRooms[12].down = -1;
    strcpy(pRooms[12].description, "A Sala do Adam Smacher! Ele não se deve importar que levemos algumas coisas 'emprestadas'.\n");
    pRooms[12].treasure = -1;

    //Sala 13
    pRooms[13].north  = -1;
    pRooms[13].south = -1;
    pRooms[13].east = 11;
    pRooms[13].west = 14;
    pRooms[13].up = -1;
    pRooms[13].down = -1;
    strcpy(pRooms[13].description, "A porta para o Escritório de Saburo Arasaka... Pelo barulho não deve ser só oxigénio que está ai dentro.\n");
    pRooms[13].treasure = -1;

    //Sala 14
    pRooms[14].north  = -1;
    pRooms[14].south = -1;
    pRooms[14].east = 13;
    pRooms[14].west = -1;
    pRooms[14].up = -1;
    pRooms[14].down = -1;
    strcpy(pRooms[14].description, "O Escritório de Saburo Arasaka... M***A! É O ADAM SMASHER! CUIDADO!!\n");
    pRooms[14].treasure = -1;

}


// Função com a lógica do jogo
void game(struct Player *pPlayer, struct Room *pRooms) {
    struct Monster m1;
    struct Monster boss;
    m1.mEnergy = 50;
    m1.mPosition = 3;
    boss.mEnergy = 300;
    boss.mPosition = 14;
    char moveInput[ANS_MOVE];
    int healthCount1 = 0;
    int healthCount2 = 0;
    int healthCount3 = 0;
    pthread_cond_init(&combatCondition, NULL);
    pthread_mutex_init(&combatMutex, NULL);

    // Inicializa a thread do monstro
    pthread_t monsterThread;
    if (pthread_create(&monsterThread, NULL, moveMonsterThread, (void*)&m1) != 0) {
        fprintf(stderr, "Erro ao criar a thread do monstro\n");
        exit(EXIT_FAILURE);
    }

    while (pPlayer->treasure != 1 || pPlayer->energy < 0) {
        pthread_mutex_lock(&combatMutex);
        
        //Combate com o segurança
        if ((pPlayer->position == m1.mPosition && m1.mEnergy > 0) || (pPlayer->position == m1.mPosition + 1 && m1.mEnergy > 0)){
            inCombat = 1;
            printf("%s", pRooms[pPlayer->position].description);
            do{
                
                showPlayerInfo(*pPlayer);
                printf("O inimigo está com %d Pontos de Vida!\n", m1.mEnergy);
                
                // Se o personagem for derrotado o jogo termina
                if (pPlayer->energy <= 0) {
                    printf("Foste morto pelo Inimigo. Não me admirava tendo em conta a tua falta de habilidade. Sayonara %s!\n", pPlayer -> name);
                    break;
                } 
                else {
                    printf("Modo Combate ativo, o que irás fazer?\n");
                    printf("Lutar até à morte - A\n");
                    printf("Fugir desesperadamente - B\n");
                    char ans[MAX_NAME];
                    scanf("%s", ans);
                    switch (toupper(ans[0]))
                    {
                    case 'A': // Lutar contra o segurança
                        PVP(&pPlayer->energy, &m1.mEnergy);
                        if(m1.mEnergy < 0) {
                            m1.mEnergy = 0;
                        }
                        printf("Pontos de Vida do inimigo após Combate = %d\n", m1.mEnergy);
                        break;
                    case 'B': // Fugir para a sala anterior
                        pPlayer -> position = pPlayer -> position - 1;
                        printf("Essas perninhas ainda dão para alguma coisa, parece que o despistámos.\n");
                        break;
                    default:
                        break;
                    }
                }
            }
            while(pPlayer->position == m1.mPosition && m1.mEnergy > 0);
        }
        inCombat = 0;
        pthread_mutex_unlock(&combatMutex);
        
        if(m1.mEnergy == 0) {
            if (pthread_join(monsterThread, NULL) != 0) {
                fprintf(stderr, "Erro ao aguardar a conclusão da thread do monstro.\n");
                exit(EXIT_FAILURE);
            }

            pthread_cond_destroy(&combatCondition);
            pthread_mutex_destroy(&combatMutex);
        }

        // Combate com o boss final
        if (pPlayer->position == boss.mPosition && boss.mEnergy > 0) {
            printf("%s",pRooms[pPlayer->position].description);
            do{
                showPlayerInfo(*pPlayer);
                printf("O inimigo está com %d Pontos de Vida!\n", boss.mEnergy);
                
                // Se o personagem for derrotado o jogo termina
                if (pPlayer->energy <= 0) {
                    printf("Foste morto pelo Inimigo. Não me admirava tendo em conta a tua falta de habilidade. Sayonara %s!\n", pPlayer -> name);
                    break;
                } 
                else {
                    printf("Modo Combate ativo, o que irás fazer?\n");
                    printf("Lutar até à morte - A\n");
                    printf("Escolher a saída mais fácil - B\n");
                    char ans[MAX_NAME];
                    scanf("%s", ans);
                    switch (toupper(ans[0]))
                    {
                    case 'A': // Lutar contra o boss final
                        PVP(&pPlayer->energy, &boss.mEnergy);
                        if(boss.mEnergy < 0) {
                            boss.mEnergy = 0;
                        }
                        printf("Pontos de Vida do inimigo após Combate = %d\n", boss.mEnergy);
                        break;
                    case 'B': // Não há opção de fuga com o boss, apenas homicidio na própria pessoa.
                        pPlayer -> energy = 0;
                        pPlayer -> position = -1;
                        printf("Quando eu te disse para apontares para a cabeça, eu não me referia à tua...\n");
                        break;
                    default:
                        break;
                    }
                }
            }
            while(pPlayer->position == boss.mPosition && boss.mEnergy > 0);
        }

        // Abertura da sala do tesouro
        if (pPlayer->position == 4 && pRooms[7].down == -1) {
            printf("Uma alavanca numa cozinha, nada suspeito, huh.\n");
            printf("Ativar a Alavanca - A\n");
            printf("Não fazer nada - B\n");
            char ans[MAX_NAME];
            scanf("%s", ans);
            switch (toupper(ans[0])){
                case 'A':
                    printf("Quem não arrisca, não come bacalhau - Fer0m0nas, 2012\n");
                    pRooms[7].down = 8;
                    break;
                case 'B':
                    printf("É melhor não fazer nada... vai que ainda corre mal...\n");
                    break;
                default:
                    break;
            }
        }
        
        // Adquirir chave do tesouro após derrotar o boss final
        if (pPlayer->position == 14 && pPlayer ->energy > 0) {
            pPlayer->key = 1;
            strcpy(pRooms[8].description, "Uma cave... Parece que era utilizada como laboratório. Espera.. Aquilo é..?\n");
        }

        // Abertura do tesouro
        if (pPlayer->position == 8 && pPlayer -> key == 1) {
            pPlayer->treasure = 1;
        }
        
        describePos(&pRooms[pPlayer->position]);
        
        // Fim do jogo
        if (pPlayer->treasure == 1 && pPlayer->position == 8) {
            printf("Encontraste o Mikoshi! Finalmente posso sair da tua cabeça!\n");
            break;
        }

        // Pede ao jogador a direção
        printf("Para onde vamos, Samurai?\n");
        scanf("%s", moveInput);
        movePlayer(pPlayer, pRooms, moveInput);

        
        // Sala com aumento de energia
        if (pPlayer->position == 2) {
            if (healthCount1 == 0) {
                healthCount1 += 1;
                pPlayer->energy += 25;
                printf("Encontraste um upgrade de Cyberware de defesa! Agora tens %d PONTOS DE VIDA!\n", pPlayer->energy);
            }
            else {
                printf("Já apanhaste tudo o que estava dentro desta sala! Agora para de empatar que temos um objetivo a concluir!\n");
            }
        }
        
        // Sala com aumento de energia
        if (pPlayer->position == 6) {
            if (healthCount2 == 0) {
                healthCount2 += 1;
                pPlayer->energy += 25;
                printf("Encontraste um upgrade de Cyberware de defesa! Agora tens %d PONTOS DE VIDA!\n", pPlayer->energy);
            }
            else {
                printf("Já apanhaste tudo o que estava dentro desta sala! Agora para de empatar que temos um objetivo a concluir!\n");
            }
        }

        // Sala com aumento de energia
        if (pPlayer->position == 12) {
            if (healthCount3 == 0) {
                healthCount3 += 1;
                pPlayer->energy += 25;
                printf("Encontraste um upgrade de Cyberware de defesa! Agora tens %d PONTOS DE VIDA!\n", pPlayer->energy);
            }
            else {
                printf("Já apanhaste tudo o que estava dentro desta sala! Agora para de empatar que temos um objetivo a concluir!\n");
            }
        }

    }
    
}


// Função com a lógica do combate
void PVP(int *pEnergy, int *mEnergy) {
    printf("Como vais atacar o inimigo?\n");
    printf("Arasaka Shingen Mk.V - A\n");
    printf("Arasaka Weeping Reaver Katana - B\n");
    printf("Arasaka Mantis Blades - C\n");
    printf("Demon Slayer - D\n");

    char resposta[MAX_NAME];
    scanf("%s", resposta);

    if (resposta[0] != '\0') {
        char opcao = toupper(resposta[0]);

        int acerto = 0;
        int dano = 0;

        switch (opcao) {
            case 'A':
                if (rand() % 2 == 1) {
                    dano = (rand() % 10) + 1;
                    *mEnergy -= dano;
                }
                break;
            case 'B':
                acerto = rand() % 2;
                if (acerto == 1) {
                    dano = (rand() % 20) + 1;
                    *mEnergy -= dano;
                }
                break;
            case 'C':
                acerto = rand() % 2;
                if (acerto == 1) {
                    dano = (rand() % 2) + 1;
                    *mEnergy -= dano;
                    printf("Calma Samurai, apenas os elites Arasaka têm isso. Mas os teus punhos fizeram algo de jeito!\n");
                }
                break;
            case 'D':
                *mEnergy -= 50;
                printf("De onde é que veio essa arma? Estiveste noutro universo ou algo assim?\n");
                break;

            default:
                printf("Deves pensar que estamos onde, num conto de fadas? Tás a ver outra opção, por acaso?.\n");
        }

        //Contra-ataque do boss final e do segurança
        acerto = rand() % 2;
        if (acerto == 1) {
            dano = (rand() % 5) + 1;
            *pEnergy -= dano;
            
        }
    } 
    else {
        printf("Essa arma não a tens colega.\n");
    }
}


// Função que move o segurança
void moveMonster(struct Monster *pM1) {
    pM1->mPosition = rand() % 2 + 3;
    pthread_cond_signal(&combatCondition);
}


// Thread que move o segurança independentemente
void* moveMonsterThread(void* arg) {
    struct Monster* pM1 = (struct Monster*)arg;

    while (1) {
        pthread_mutex_lock(&combatMutex);
        moveMonster(pM1);
        pthread_mutex_unlock(&combatMutex);

        usleep(5000000); // Aguarda 5 segundos antes de mover novamente
    }

    return NULL;
}


// Função que indica as direções possiveis
void describePos(struct Room *pRoom) {
    if (pRoom->north != -1) {
        printf("Existe uma porta a Norte.\n");
    }
    if (pRoom->south != -1) {
        printf("Existe uma porta a Sul.\n");
    }
    if (pRoom->east != -1) {
        printf("Existe uma porta a Este.\n");
    }
    if (pRoom->west != -1) {
        printf("Existe uma porta a Oeste.\n");
    }
    if (pRoom->up != -1) {
        printf("Existe um alçapão acima de ti.\n");
    }
    if (pRoom->down != -1) {
        printf("Existe um alçapão abaixo de ti\n");
    }
    
    printf("%s", pRoom -> description);
}


// Função que move o personagem
void movePlayer(struct Player *pPlayer, struct Room *pRooms, char *moveInput) {
    int newRoomIndex = -1;
     for (int i = 0; moveInput[i]; i++) {
        moveInput[i] = toupper(moveInput[i]);
    }

    if (strcmp(moveInput, "NORTE") == 0) {
        newRoomIndex = pRooms[pPlayer->position].north;
    } else if (strcmp(moveInput, "SUL") == 0) {
        newRoomIndex = pRooms[pPlayer->position].south;
    } else if (strcmp(moveInput, "ESTE") == 0) {
        newRoomIndex = pRooms[pPlayer->position].east;
    } else if (strcmp(moveInput, "OESTE") == 0) {
        newRoomIndex = pRooms[pPlayer->position].west;
    } else if (strcmp(moveInput, "ABAIXO") == 0) {
        newRoomIndex = pRooms[pPlayer->position].down;
    } else if (strcmp(moveInput, "ACIMA") == 0) {
        newRoomIndex = pRooms[pPlayer->position].up;
    } else {
        printf("Quê palavra é essa? Tenta novamente.\n");
        return;
    }

    // Garante que o personagem só se pode deslocar para salas adjacentes
    if (newRoomIndex != -1) {
        pPlayer->position = newRoomIndex;
    } else {
        printf("Só se souberes atravessar paredes é que passas por ai!\n");
    }
}