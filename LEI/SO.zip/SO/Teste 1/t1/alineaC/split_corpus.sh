#!/bin/bash

# A divisão é feita através do número total de linhas a multiplicar pela percentagem que queremos dividir.
# Neste caso são 10000 linhas, 80% para o inicio, 20% para o fim.
#O inicio é guardado no treino.txt, o fim é guardado no teste.txt

cat frasesPublico10000.txt | head -8000 > treino.txt

cat frasesPublico10000.txt | tail -2000 > teste.txt
