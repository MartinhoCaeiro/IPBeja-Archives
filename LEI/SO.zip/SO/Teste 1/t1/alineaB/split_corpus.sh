#!/bin/bash

# A divisão é feita através do número total de linhas a multiplicar pela percentagem que queremos dividir.
# Neste caso são 10000 linhas, 80% para o inicio, 20% para o fim.
#O inicio é guardado no treino.txt, o fim é guardado no teste.txt

splitStart=0.8
splitEnd=0.2

lineCount= gawk -f frasesPublico10000.txt


	gawk -v total_lines="$lineCount" -v percentage="$splitStart" -f get_last_lines.awk frasesPublico10000.txt > treino.txt
	
	gawk -v total_lines="$lineCount" -v percentage="$splitEnd" -f get_last_lines.awk $file frasesPublico10000.txt > teste.txt


