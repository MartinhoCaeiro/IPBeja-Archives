#!/bin/bash

cat frasesPublico10000.txt |tr -s '[:space:]' | tr ' ' '\n' | sort | uniq -c | sort -n -r | head -100 | tr -s  ' ' |cut  -d ' ' -f 3 > top100.txt
