#!/bin/bash

cd ~/tg1/words_dict
echo "" > info.txt
while IFS= read -r line; do

    lastWordOne=$(echo "$line" | awk '{print $(NF-1)}')
    lastWordTwo=$(echo "$line" | awk '{print $NF}')


    if grep -Fq -- "$lastWordOne" "words.txt" && grep -Fq -- "$lastWordTwo" "words.txt"; then
        echo "$lastWordOne $lastWordTwo" >> info.txt
    else
        echo "Erro - caracter não encontrado"
    fi


done < "words_pairs.txt"
