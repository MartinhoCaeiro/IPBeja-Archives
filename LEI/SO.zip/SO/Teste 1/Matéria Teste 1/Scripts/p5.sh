#!/bin/bash
cd ~/tg1/corpus_txt

cat frasePorLinha.txt | tr '[:upper:]' '[:lower:]' | tr -d -c "[:alpha:][:space:]ãœîïüéèêëàâçôûùæ\'-"| tr -s " " |tr -d "»«" | tr -s "[\']\" "| sed 's/\b\([[:punct:]]*\)\(.*\)\([[:punct:]]*\)\b/\2/g' |awk '{for (i = 1; i < NF; i++) print $i, $(i+1)}' | sort | uniq -c > words_pairs.txt
mv words_pairs.txt ~/tg1/words_dict
