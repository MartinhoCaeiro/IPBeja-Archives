#!/bin/bash
# Criação das diretorias necessárias
mkdir tg1
cd tg1
mkdir scripts corpus corpus_txt corpus_info words_dict sentences_dict
cd ..
mv p1.sh p2.sh p3.sh p4.sh p5.sh p6.sh ~/tg1/scripts

