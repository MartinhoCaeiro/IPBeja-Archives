#!/bin/bash
cd ~/tg1/corpus_txt/
cat frasePorLinha.txt | tr '[:upper:]' '[:lower:]' | tr -d -c "[:alpha:][:space:]ãœîïüéèêëàâçôûùæ\'-"| tr -s " " |tr -d "»«" | tr -s "[\']\" "| sed 's/\b\([[:punct:]]*\)\(.*\)\([[:punct:]]*\)\b/\2/g' | tr ' ' '\n' | sort | uniq -c > words.txt

mv words.txt ~/tg1/words_dict
