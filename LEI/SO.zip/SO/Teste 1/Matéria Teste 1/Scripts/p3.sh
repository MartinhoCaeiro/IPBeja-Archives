cd ~/tg1/corpus_txt/
nCaracteres=`cat frasePorLinha.txt | wc -c`
echo "Número de Caracteres: " $nCaracteres > info.txt
nLinhas=`cat frasePorLinha.txt | wc -l`
echo "Número de linhas: " $nLinhas >> info.txt
nPalavras=`cat frasePorLinha.txt | wc -w`
echo "Número de palavras: " $nPalavras >> info.txt

nPalavrasDiferentes=$(cat frasePorLinha.txt | tr '[:upper:]' '[:lower:]' |  tr -d -c "[:alpha:][:space:]ãœîïüéèêëàâçôûùæ\'-"| tr -s " " |tr -d "»«" | tr -s "[\']\" "| sed 's/\b\([[:punct:]]*\)\(.*\)\([[:punct:]]*\)\b/\2/g' | tr ' ' '\n' | sort | uniq | wc -l)
calcQuo=$(echo "scale=3; $nPalavrasDiferentes / $nPalavras" | bc -l)
echo "Razão entre palavras diferentes/total: " $calcQuo >> info.txt
echo "Número total de frases: " $nLinhas >> info.txt
nFrasesDiferentes=$(cat frasePorLinha.txt | sort | uniq | wc -l)
echo "Número de Frases Diferentes: " $nFrasesDiferentes >> info.txt
calQuoFrase=$(echo "scale=2; $nFrasesDiferentes / $nLinhas" | bc -l)
echo "Razão entre frases diferentes/Total: " $calQuoFrase >> info.txt
mv info.txt ~/tg1/corpus_info
