#!/bin/bash
cd ~/Downloads/fra_mixed_2009_300K
mv fra_mixed_2009_300K-sentences.txt ~/tg1/corpus
cd ~/tg1/corpus/
cat fra_mixed_2009_300K-sentences.txt | cut -f 2- > frasePorLinha.txt
mv frasePorLinha.txt ~/tg1/corpus_txt
