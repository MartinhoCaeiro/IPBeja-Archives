#!/bin/bash

file=$1

if [ ! -f "$file" ]; then
	echo "Usage: ./moreSimplified <Sourcefile.txt>"
	exit 1
fi

start=1
linesToRead=20

#Methods
showNext(){
	clear #clears previous content and updates to current
	
	((start+=20))
	((linesToRead+=20))
	
	awk -v start="$start" -v nLines="$linesToRead" -f showLines.awk $file
}


showPrevious(){

	clear #clears previous content and updates to current
	
		((linesToRead-=20))
		((start-=20))	
	
	awk -v start="$start" -v nLines="$linesToRead" -f showLines.awk $file
}



#EXEC


#Shows the first 20 lines in the begining
awk -v start="$start" -v nLines="$linesToRead" -f showLines.awk $file

#More command simplified
while :
do
	#Asks User
	answer=""
	
	while [ "$answer" != "n" ] && [ "$answer" != "p" ] && [ "$answer" != "q" ]; do
		echo "n (next) | p (previous) | q (quit)"
		read answer
	done
	
	
	#Checks
	case "$answer" in
	
		"n")
	 	showNext
	 	;;
	 	
	 	"p")
	 	showPrevious
	 	;;
	 	
	 	"q")
	 	exit 0
	 	;;
	 
	 esac
	 
done


