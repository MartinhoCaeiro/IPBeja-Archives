#!/bin/bash

file=$1
if [ ! -f "$file" ]; then
	echo "Usage: ./moreSimplified <Sourcefile.txt>"
	exit 1
fi

start=1
linesToRead=20

#Methods

addNewLine(){
	clear
	((linesToRead++))
	awk -v start="$start" -v nLines="$linesToRead" -f showLines.awk $file
}


#RUN

#Shows the first 20 lines in the begining
awk -v start="$start" -v nLines="$linesToRead" -f showLines.awk $file

#More command simplified
while :
do
	#Asks User
	answer=""
	
	while [ "$answer" != "y" ] && [ "$answer" != "n" ]; do
		echo "More (y/n)"
		read answer
	done
	
	
	#Checks
	if [ "$answer" == "y" ]; then 
		addNewLine
	else
		break
	fi
done


