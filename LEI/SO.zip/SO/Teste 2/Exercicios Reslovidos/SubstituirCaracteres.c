//Um ficheiro
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    int c;

    // Conjuntos originais e de substituição
    char *conjuntoOriginal = argv[1];
    char *conjuntoSubstituto = argv[2];
    
    // Abre o arquivo para exibir o conteúdo original
    while ((c = getchar()) != EOF) {
        // Substitui caracteres de acordo com os conjuntos fornecidos
        int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
        if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
            putchar(conjuntoSubstituto[indice]);
        } else {
            putchar(c);
        }
    }

    return 0;
}

//-----------------------------------------------------------------------------

//De um arquivo para outro
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    int c;
    FILE *f;
    FILE *outputF;
    // Conjuntos originais e de substituição
    char *conjuntoOriginal = argv[1];
    char *conjuntoSubstituto = argv[2];

    if (argc == 5) {
        // Se houver 5 argumentos, assume que o terceiro é o nome do arquivo
        f = fopen(argv[3], "r");
        outputF = fopen(argv[4], "w");
        if (f == NULL) {
            perror("Erro ao abrir o arquivo");
            return 1;
        }

        while ((c = fgetc(f)) != EOF) {
            // Substitui caracteres de acordo com os conjuntos fornecidos
            int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
            if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                fputc(conjuntoSubstituto[indice], outputF);
            } else {
                fputc(c, outputF);
            }
        }

        fclose(f);
    } else if (argc == 3) {
        // Se houver 3 argumentos, assume que a entrada é do pipeline
        while ((c = getchar()) != EOF) {
            // Substitui caracteres de acordo com os conjuntos fornecidos
            int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
            if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                putchar(conjuntoSubstituto[indice]);
            } else {
                putchar(c);
            }
        }
    } else {
        fprintf(stderr, "Uso: %s <conjunto_original> <conjunto_substituto> [arquivoEntrada] [arquivoSaida]\n", argv[0]);
        return 1;
    }

    return 0;
}

//--------------------------------------------------------------------------------

//Com fork
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {

    int c;
    FILE *f;
    FILE *outputF;
    // Conjuntos originais e de substituição
    char *conjuntoOriginal = argv[1];
    char *conjuntoSubstituto = argv[2];

    if (argc == 5) {
        // Se houver 5 argumentos, assume que o terceiro é o nome do arquivo
        f = fopen(argv[3], "r");
        outputF = fopen(argv[4], "w");
        pid_t pid1, pid2;
        int status1, status2;
        pid1 = fork();
        if (pid1 == 0)
        {
            while ((c = fgetc(f)) != EOF) {
            // Substitui caracteres de acordo com os conjuntos fornecidos
            int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
            if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                fputc(conjuntoSubstituto[indice], outputF);
            } else {
                fputc(c, outputF);
            }
        }
        }else{
            pid2 = fork();
            int contador = 0;
            if (pid2==0){
                while ((c = fgetc(f)) != EOF) {
                int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
                if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                    contador++;
                    }
                }
            }else{
                waitpid(pid1, &status1, 0);
                waitpid(pid2, &status2, 0);
            }
        }

        fclose(f);
    } else if (argc == 3) {
        // Se houver 3 argumentos, assume que a entrada é do pipeline
        while ((c = getchar()) != EOF) {
            // Substitui caracteres de acordo com os conjuntos fornecidos
            int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
            if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                putchar(conjuntoSubstituto[indice]);
            } else {
                putchar(c);
            }
        }
    } else {
        fprintf(stderr, "Uso: %s <conjunto_original> <conjunto_substituto> [arquivoEntrada] [arquivoSaida]\n", argv[0]);
        return 1;
    }

    return 0;
}

//--------------------------------------------------------------------------------

//Simplificado
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {

    int c;
    FILE *f;
    FILE *outputF;
    int contador = 0;

    // Conjuntos originais e de substituição
    char *conjuntoOriginal = argv[1];
    char *conjuntoSubstituto = argv[2];

    if (argc == 5) {
        // Se houver 5 argumentos, assume que o terceiro é o nome do arquivo
        f = fopen(argv[3], "r");
        outputF = fopen(argv[4], "w");
        pid_t pid1, pid2;
        int status1, status2;
        pid1 = fork();
        if (pid1 == 0)
        {
            while ((c = fgetc(f)) != EOF) {
            // Substitui caracteres de acordo com os conjuntos fornecidos
            int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
            if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                fputc(conjuntoSubstituto[indice], outputF);
                contador++;
            } else {
                fputc(c, outputF);
            }
        }
        }else{
            pid2 = fork();
            if (pid2==0){
                waitpid(pid1, &status1, 0);
                printf("Foram alteradas %d letras\n", contador);
            }else{
                waitpid(pid2, &status2, 0);
            }
        }

        fclose(f);
    } else if (argc == 3) {
        // Se houver 3 argumentos, assume que a entrada é do pipeline
        while ((c = getchar()) != EOF) {
            // Substitui caracteres de acordo com os conjuntos fornecidos
            int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
            if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
                putchar(conjuntoSubstituto[indice]);
            } else {
                putchar(c);
            }
        }
    } else {
        fprintf(stderr, "Uso: %s <conjunto_original> <conjunto_substituto> [arquivoEntrada] [arquivoSaida]\n", argv[0]);
        return 1;
    }

    return 0;
}