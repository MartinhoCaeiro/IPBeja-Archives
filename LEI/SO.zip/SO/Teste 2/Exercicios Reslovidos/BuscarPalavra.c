// Um arquivo
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *f;
    char *palavraBuscada = argv[1];
    char *nomeArquivo = argv[2];
    char linha[100];
    int numeroLinha = 0;


    f = fopen(nomeArquivo, "r");

    
    while (fgets(linha, sizeof(linha), f) != NULL) {
        numeroLinha++;

        // Procurar a palavra na linha
        if (strstr(linha, palavraBuscada) != NULL) {
            printf("Palavra encontrada na linha %d: %s", numeroLinha, linha);
        }
    }

    fclose(f);

    return 0;  // SaÃ­da do programa com sucesso
}

//---------------------------------------------------------------------

//Metodo diferente
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *f;
    char *palavraBuscada = argv[1];
    
    char linha[100];
    
    for (int i = 2; i < argc; i++)
    {
        int numeroLinha = 0;
        char *nomeArquivo = argv[i];
    f = fopen(nomeArquivo, "r");

    printf("Ficheiro %s\n", nomeArquivo);
    while (fgets(linha, sizeof(linha), f) != NULL) {
        numeroLinha++;

        // Procurar a palavra na linha
        if (strstr(linha, palavraBuscada) != NULL) {
            printf("Palavra encontrada na linha %d: %s", numeroLinha, linha);
        }
    }

    fclose(f);
    }
    
    

    return 0;  // SaÃ­da do programa com sucesso
}

//---------------------------------------------------------------------

//Vários ficheiros
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

FILE *f;
char linha[100];

void acharPalavra(char *nomeArquivo, char *palavraBuscada);

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Uso: %s <palavra_buscada> <arquivo1> <arquivo2> ... <arquivoN>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *palavraBuscada = argv[1];

    for (int i = 2; i < argc; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            char *nomeArquivo = argv[i];
            acharPalavra(nomeArquivo, palavraBuscada);
            exit(EXIT_SUCCESS);
        }
    }

    // Aguardar todos os processos filhos terminarem
    for (int i = 2; i < argc; i++) {
        wait(NULL);
    }

    return 0;
}

void acharPalavra(char *nomeArquivo, char *palavraBuscada) {
    int numeroLinha = 0;
    f = fopen(nomeArquivo, "r");


    printf("Ficheiro %s\n", nomeArquivo);
    while (fgets(linha, sizeof(linha), f) != NULL) {
        numeroLinha++;

        // Procurar a palavra na linha
        if (strstr(linha, palavraBuscada) != NULL) {
            printf("Palavra encontrada na linha %d: %s", numeroLinha, linha);
        }
    }

    fclose(f);
    exit(EXIT_SUCCESS); // Importante incluir a saída no final da função
}

//-------------------------------------------------------------------------

//Uso de estrutura
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <semaphore.h>

FILE *f;
char linha[100];

// Estrutura para armazenar dados compartilhados entre os processos
typedef struct {
    int nVezes;
    sem_t sem;
} SharedData;

void acharPalavra(char *nomeArquivo, char *palavraBuscada, SharedData *sharedData);

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Uso: %s <palavra_buscada> <arquivo1> <arquivo2> ... <arquivoN>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *palavraBuscada = argv[1];

    // Inicializar dados compartilhados
    SharedData *sharedData = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sharedData->nVezes = 0;
    sem_init(&sharedData->sem, 1, 1);

    for (int i = 2; i < argc; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            char *nomeArquivo = argv[i];
            acharPalavra(nomeArquivo, palavraBuscada, sharedData);
            exit(EXIT_SUCCESS);
        }
    }

    // Aguardar todos os processos filhos terminarem
    for (int i = 2; i < argc; i++) {
        wait(NULL);
    }

    printf("Foram contadas %d vezes a palavra '%s'\n", sharedData->nVezes, palavraBuscada);

    // Desvincular e destruir os recursos compartilhados
    sem_destroy(&sharedData->sem);
    munmap(sharedData, sizeof(SharedData));

    return 0;
}

void acharPalavra(char *nomeArquivo, char *palavraBuscada, SharedData *sharedData) {
    int numeroLinha = 0;
    f = fopen(nomeArquivo, "r");

    printf("Ficheiro %s\n", nomeArquivo);
    while (fgets(linha, sizeof(linha), f) != NULL) {
        numeroLinha++;

        // Procurar a palavra na linha
        if (strstr(linha, palavraBuscada) != NULL) {
            // Esperar pelo semáforo para garantir a exclusão mútua
            sem_wait(&sharedData->sem);

            // Modificar a variável compartilhada
            sharedData->nVezes++;

            // Liberar o semáforo
            sem_post(&sharedData->sem);

            printf("Palavra encontrada na linha %d: %s", numeroLinha, linha);
        }
    }

    fclose(f);
    exit(EXIT_SUCCESS);
}