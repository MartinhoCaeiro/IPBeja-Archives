//Um ficheiro
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *f;
    char *nomeArquivo = argv[1];
    char linha[100];
    int numeroLinha = 0;


    f = fopen(nomeArquivo, "r");

    
    while (fgets(linha, sizeof(linha), f) != NULL) {
        numeroLinha++;
            printf("%d: %s", numeroLinha, linha);
        
    }

    fclose(f);

    return 0;  // SaÃ­da do programa com sucesso
}

//---------------------------------------------------------------------------

//Repetir intervalo
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *f;
    char *nomeArquivo = argv[1];
    char linha[100];
    int numeroLinha = 0;

    

    int espacoDesejado = argc - 2;
    int repeticoes = espacoDesejado / 2;

    for (int i = 0; i < repeticoes; i++) {
        int n1 = atoi(argv[2 + 2 * i]);
        int n2 = atoi(argv[3 + 2 * i]);
        f = fopen(nomeArquivo, "r");

        // Reinicializar a variável numeroLinha para cada conjunto de linhas
        numeroLinha = 0;

        while (fgets(linha, sizeof(linha), f) != NULL) {
            numeroLinha++;
            if (numeroLinha >= n1 && numeroLinha <= n2) {
                printf("%d: %s", numeroLinha, linha);
            }
        }
        fclose(f);

    }

    

    return 0; // Saída do programa com sucesso
}

//---------------------------------------------------------------------

//Com fork
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc, char *argv[]) {
    FILE *f;
    char *nomeArquivo = argv[1];
    char linha[100];
    int numeroLinha = 0;

    

    int espacoDesejado = argc - 2;
    int repeticoes = espacoDesejado / 2;

    for (int i = 0; i < repeticoes; i++) {
        pid_t pid = fork();
        if (pid == 0)
        {
            int n1 = atoi(argv[2 + 2 * i]);
        int n2 = atoi(argv[3 + 2 * i]);
        f = fopen(nomeArquivo, "r");

        // Reinicializar a variável numeroLinha para cada conjunto de linhas
        numeroLinha = 0;

        while (fgets(linha, sizeof(linha), f) != NULL) {
            numeroLinha++;
            if (numeroLinha >= n1 && numeroLinha <= n2) {
                printf("%d: %s", numeroLinha, linha);
            }
        }
        fclose(f);
        exit(EXIT_SUCCESS);
        }
        
        
    }
    
    

    return 0; // Saída do programa com sucesso
}

//---------------------------------------------------------

//Com contagem de linhas
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <semaphore.h>

#include <string.h>
typedef struct {
    int nVezes;
    sem_t sem;
} SharedData;

int main(int argc, char *argv[]) {
    FILE *f;
    char *nomeArquivo = argv[1];
    char linha[100];
    int numeroLinha = 0;

    

    int espacoDesejado = argc - 2;
    int repeticoes = espacoDesejado / 2;
    SharedData *sharedData = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sharedData->nVezes = 0;
    sem_init(&sharedData->sem, 1, 1);
    for (int i = 0; i < repeticoes; i++) {
        pid_t pid = fork();
        if (pid == 0)
        {
        int n1 = atoi(argv[2 + 2 * i]);
        int n2 = atoi(argv[3 + 2 * i]);
        f = fopen(nomeArquivo, "r");

        // Reinicializar a variável numeroLinha para cada conjunto de linhas
        numeroLinha = 0;

        while (fgets(linha, sizeof(linha), f) != NULL) {
            numeroLinha++;
            if (numeroLinha >= n1 && numeroLinha <= n2) {
                sem_wait(&sharedData->sem);
                sharedData->nVezes++;
                sem_post(&sharedData->sem);
                printf("%d: %s", numeroLinha, linha);
            }
        }
        fclose(f);
        exit(EXIT_SUCCESS);
        }
        
        
    }
    for (int i = 0; i < repeticoes; i++)
    {
        wait(NULL);
    }
    
    printf("Foram contadas no total %d linhas!", sharedData->nVezes);
    sem_destroy(&sharedData->sem);
    munmap(sharedData, sizeof(SharedData));
    return 0; // Saída do programa com sucesso
}