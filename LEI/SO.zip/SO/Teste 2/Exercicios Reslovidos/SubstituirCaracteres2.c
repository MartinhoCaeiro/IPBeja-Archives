//Um ficheiro
#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Uso: %s arquivo_original caracter_remover caracter_substituir\n", argv[0]);
        return 1;
    }

    FILE *f;
    int c;
    char remover = argv[2];  // Pega o primeiro caractere da string
    char substituir = argv[3];  // Pega o primeiro caractere da string

    // Abre o arquivo para exibir o conteúdo original
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    printf("Conteúdo original:\n");
    while ((c = fgetc(f)) != EOF) {
        putchar(c);
    }
    printf("\n");
    fclose(f);

    // Abre novamente o arquivo para exibir o conteúdo com alterações
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    printf("\nConteúdo com alterações:\n");
    while ((c = fgetc(f)) != EOF) {
        if (c == remover) {
            putchar(substituir);
        } else {
            putchar(c);
        }
    }

    fclose(f);
    printf("\n");

    return 0;
}

//-----------------------------------------------------------------------

//Metodo alternativo
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 4 || strlen(argv[2]) != strlen(argv[3])) {
        printf("Uso: %s arquivo_original conjunto_original conjunto_substituto\n", argv[0]);
        return 1;
    }

    FILE *f;
    int c;

    // Conjuntos originais e de substituição
    char *conjuntoOriginal = argv[2];
    char *conjuntoSubstituto = argv[3];

    // Abre o arquivo para exibir o conteúdo original
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    printf("Conteúdo original:\n");
    while ((c = fgetc(f)) != EOF) {
        putchar(c);
    }

    fclose(f);

    // Abre novamente o arquivo para exibir o conteúdo com alterações
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    printf("\nConteúdo com alterações:\n");
    while ((c = fgetc(f)) != EOF) {
        // Substitui caracteres de acordo com os conjuntos fornecidos
        int indice = strchr(conjuntoOriginal, c) - conjuntoOriginal;
        if (indice >= 0 && indice < strlen(conjuntoOriginal)) {
            putchar(conjuntoSubstituto[indice]);
        } else {
            putchar(c);
        }
    }

    fclose(f);

    return 0;
}

//-------------------------------------------------------------------

//Com threads
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

typedef struct {
    char *inputFile;
    char *outputFile;
    char *conjuntoOriginal;
    char *conjuntoSubstituto;
} ThreadArgs;

void *processFile(void *arg) {
    ThreadArgs *args = (ThreadArgs *)arg;
    FILE *inputFile = fopen(args->inputFile, "r");
    FILE *outputFile = fopen(args->outputFile, "w");

    if (inputFile == NULL || outputFile == NULL) {
        perror("Erro ao abrir arquivo");
        return NULL;
    }

    int c;

    while ((c = fgetc(inputFile)) != EOF) {
        int indice = strchr(args->conjuntoOriginal, c) - args->conjuntoOriginal;
        if (indice >= 0 && indice < strlen(args->conjuntoOriginal)) {
            fputc(args->conjuntoSubstituto[indice], outputFile);
        } else {
            fputc(c, outputFile);
        }
    }

    fclose(inputFile);
    fclose(outputFile);

    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 5 || (argc - 1) % 2 != 0) {
        printf("Uso: %s conjunto_original conjunto_substituto inputFile1 outputFile1 [inputFile2 outputFile2 ...]\n", argv[0]);
        return 1;
    }

    int numFiles = (argc - 1) / 2;

    pthread_t threads[numFiles];
    ThreadArgs threadArgs[numFiles];

    for (int i = 0; i < numFiles; i++) {
        threadArgs[i].inputFile = argv[i * 2 + 3];
        threadArgs[i].outputFile = argv[i * 2 + 4];
        threadArgs[i].conjuntoOriginal = argv[1];
        threadArgs[i].conjuntoSubstituto = argv[2];

        if (pthread_create(&threads[i], NULL, processFile, (void *)&threadArgs[i]) != 0) {
            perror("Erro ao criar thread");
            return 1;
        }
    }

    for (int i = 0; i < numFiles; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("Erro ao aguardar a conclusão da thread");
            return 1;
        }
    }

    printf("Processamento concluído para %d arquivo(s).\n", numFiles);

    return 0;
}