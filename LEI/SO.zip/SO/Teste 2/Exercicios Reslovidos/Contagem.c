//Um ficheiro
#include <stdio.h>

int main(int argc, char *argv[]) {
    
    int nWords = 0;
    int nChar = 0;
    int nLines = 1;
    int dentroDaPalavra = 0;
    FILE *f;
    int c;

    // Abre o arquivo para exibir o conteúdo original
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    while ((c = fgetc(f)) != EOF) {
        nChar++;
        if (c == '\n')
        {
            nLines++;
        }
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
            dentroDaPalavra = 0;
        } else {
            // Se não estiver dentro de uma palavra e encontrar um caractere válido, incrementa o contador de palavras
            if (!dentroDaPalavra) {
                dentroDaPalavra = 1;
                nWords++;
            }
        
        }
    }
    printf("Número de Palavras = %d\n", nWords);
    printf("Número de Linhas = %d\n", nLines);
    printf("Número de Caracteres = %d\n", nChar);


    printf("\n");
    fclose(f);

    return 0;
}

//-------------------------------------------------------------------------

//Mais que um ficheiro
#include <stdio.h>

int main(int argc, char *argv[]) {
    
    
    FILE *f;
    int c;
    for(int i = 1; i<argc; i++ ) {
        int nWords = 0;
        int nChar = 0;
        int nLines = 0;
        int dentroDaPalavra = 0;
        // Abre o arquivo para exibir o conteúdo original
        f = fopen(argv[i], "r");
        if (f == NULL) {
            perror("Erro ao abrir o arquivo");
            return 1;
        }

        while ((c = fgetc(f)) != EOF) {
            nChar++;
            if (c == '\n')
            {
                nLines++;
            }
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                dentroDaPalavra = 0;
            } else {
                // Se não estiver dentro de uma palavra e encontrar um caractere válido, incrementa o contador de palavras
                if (!dentroDaPalavra) {
                    dentroDaPalavra = 1;
                    nWords++;
                }
            
            }
        }
        printf("Ficheiro nº %d\n", i);
        printf("Número de Palavras = %d\n", nWords);
        printf("Número de Linhas = %d\n", nLines);
        printf("Número de Caracteres = %d\n", nChar);
    }

    printf("\n");
    fclose(f);

    return 0;
}

//-------------------------------------------------------------------------------

//Com fork
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    FILE *f;
    pid_t pid1, pid2, pid3;
    int status;

    // Abre o arquivo para exibir o conteúdo original
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    // Cria o primeiro processo filho
    if ((pid1 = fork()) == 0) {
        // Código do primeiro filho (contagem de caracteres)
        contarCaracteres(f);
        fclose(f);
        exit(0);
    }

    // Cria o segundo processo filho
    if ((pid2 = fork()) == 0) {
        // Código do segundo filho (contagem de palavras)
        fclose(f); // Fecha o arquivo no segundo filho, pois não precisa mais do ponteiro do arquivo do pai
        f = fopen(argv[1], "r"); // Reabre o arquivo para o segundo filho
        contarPalavras(f);
        fclose(f);
        exit(0);
    }

    if ((pid3 == fork()) == 0)
    {
        fclose(f); // Fecha o arquivo no pai, pois não precisa mais do ponteiro do arquivo do pai
        f = fopen(argv[1], "r"); // Reabre o arquivo para o pai
        contarLinhas(f);
        fclose(f);
        exit(0);
    }
    
    

    // Espera pelos filhos terminarem
    waitpid(pid1, &status, 0);
    waitpid(pid2, &status, 0);
    waitpid(pid3, &status, 0);

    return 0;
}

void contarCaracteres(FILE *file) {
    int nChar = 0;
    int c;
    
    while ((c = fgetc(file)) != EOF) {
        nChar++;
    }

    printf("Número de Caracteres: %d\n", nChar);
}

void contarPalavras(FILE *file) {
    int nWords = 0;
    int dentroDaPalavra = 0;
    int c;

    while ((c = fgetc(file)) != EOF) {
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
            dentroDaPalavra = 0;
        } else {
            if (!dentroDaPalavra) {
                dentroDaPalavra = 1;
                nWords++;
            }
        }
    }

    printf("Número de Palavras: %d\n", nWords);
}

void contarLinhas(FILE *file) {
    int nLines = 1; // Começa com 1, pois há pelo menos uma linha no arquivo
    int c;

    while ((c = fgetc(file)) != EOF) {
        if (c == '\n') {
            nLines++;
        }
    }

    printf("Número de Linhas: %d\n", nLines);
}

//--------------------------------------------------------------------------------------

//Mais avançado
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/shm.h>

// Estrutura para armazenar os resultados
struct Resultados {
    int nCaracteres;
    int nPalavras;
    int nLinhas;
};

// Funções para contar caracteres, palavras e linhas
void contarCaracteres(FILE *file, struct Resultados *resultados) {
    int c;

    while ((c = fgetc(file)) != EOF) {
        resultados->nCaracteres++;
    }
}

void contarPalavras(FILE *file, struct Resultados *resultados) {
    int dentroDaPalavra = 0;
    int c;

    while ((c = fgetc(file)) != EOF) {
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
            dentroDaPalavra = 0;
        } else {
            if (!dentroDaPalavra) {
                dentroDaPalavra = 1;
                resultados->nPalavras++;
            }
        }
    }
}

void contarLinhas(FILE *file, struct Resultados *resultados) {
    int c;

    while ((c = fgetc(file)) != EOF) {
        if (c == '\n') {
            resultados->nLinhas++;
        }
    }
}

int main(int argc, char *argv[]) {
    FILE *f;
    pid_t pid1, pid2, pid3, pid4;
    int status;

    // Criação de memória compartilhada para armazenar os resultados
    key_t key = ftok("/tmp", 'A');
    int shmid = shmget(key, sizeof(struct Resultados), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("Erro ao criar memória compartilhada");
        return 1;
    }

    struct Resultados *resultados = shmat(shmid, NULL, 0);

    // Abre o arquivo para exibir o conteúdo original
    f = fopen(argv[1], "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    // Cria o primeiro processo filho
    if ((pid1 = fork()) == 0) {
        contarCaracteres(f, resultados);
        fclose(f);
        exit(0);
    }

    // Reposiciona o ponteiro de arquivo para o início
    rewind(f);

    // Cria o segundo processo filho
    if ((pid2 = fork()) == 0) {
        contarPalavras(f, resultados);
        fclose(f);
        exit(0);
    }

    // Reposiciona o ponteiro de arquivo para o início
    rewind(f);

    // Cria o terceiro processo filho
    if ((pid3 = fork()) == 0) {
        contarLinhas(f, resultados);
        fclose(f);
        exit(0);
    }

    // Espera pelos filhos terminarem
    waitpid(pid1, &status, 0);
    waitpid(pid2, &status, 0);
    waitpid(pid3, &status, 0);

    // Cria o quarto processo filho
    if ((pid4 = fork()) == 0) {
        // Código do quarto filho (apresentar no ecrã os valores armazenados na memória compartilhada)
        printf("Número de Caracteres: %d\n", resultados->nCaracteres);
        printf("Número de Palavras: %d\n", resultados->nPalavras);
        printf("Número de Linhas: %d\n", resultados->nLinhas);
        exit(0);
    }

    // Espera pelo quarto filho terminar
    waitpid(pid4, &status, 0);

    // Libera recursos de memória compartilhada
    shmdt(resultados);
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}