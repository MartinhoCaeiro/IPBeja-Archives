#include <stdio.h>

int main(int argc, char *argv[]) {
    FILE *f1;
    FILE *f2;
    int c;
    int d;

    // Abre o arquivo 1 para exibir o conteúdo
    f1 = fopen(argv[1], "r");
    if (f1 == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }
    
    // Abre o arquivo 2 para exibir o conteúdo
    f2 = fopen(argv[2], "r");
    if (f2 == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    while ((c = fgetc(f1)) != EOF) {
        putchar(c);
       
    }

    printf("\t");
    
    while ((d = fgetc(f2)) != EOF) {
        putchar(d); 
    }
    
    fclose(f1);
    fclose(f2);

    return 0;  // Sai­da do programa com sucesso
}