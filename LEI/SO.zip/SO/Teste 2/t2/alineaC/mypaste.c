#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <sys/mman.h>

int main(int argc, char *argv[]){
  FILE *f1;
  FILE *f2;
  int c;
  int d;
  int pid, childPid;

  sem_t *sem = mmap(NULL, sizeof (sem_t*), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
  sem_init(sem, 1, 1);
  
  pid=fork();
  if( pid == 0 ){
    sem_wait( sem );

    // Abre o arquivo 1 para exibir o conteúdo
    f1 = fopen(argv[1], "r");
    if (f1 == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }
    
    while ((c = fgetc(f1)) != EOF) {
        putchar(c); 
    }
    fclose(f1);

    fflush(stdout);
    sem_post( sem );
    printf("\n");
  }
  else{
    pid=fork();
    if( pid == 0 ){
      sem_wait( sem );

      // Abre o arquivo 2 para exibir o conteúdo
    f2 = fopen(argv[2], "r");
    if (f2 == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    while ((d = fgetc(f2)) != EOF) {
        putchar(d);
    }

    fclose(f2);

    fflush(stdout);
    sem_post( sem );
    }
    else{
      
      wait(&childPid);
      wait(&childPid);
      
      sem_destroy(sem);
      munmap(sem, sizeof(sem_t*));
     
    }
    
  }
  
  return 0;
}