#include <stdio.h>

int main(){
 printf( "Olá Mundo!\n");
	
 return 0;
	
}
