#include <stdio.h>

#define MAX_PLAYER_NAME 50
#define MAX_PLAYER_ENERGY 100
#define INIT_PLAYER_CELL 0

struct Player{
 char name[MAX_PLAYER_NAME];
 int energy;
 int cell;
};

void InitPlayer(struct Player *pPlayer){
 printf("Olá! Como te chamas?\n");
 scanf("%s", pPlayer->name);
 pPlayer->energy = MAX_PLAYER_ENERGY;
 pPlayer->cell = INIT_PLAYER_CELL;
}

void ShowPlayer(struct Player player){
 printf("Boa sorte %s!\n", player.name);
 printf("A sua energia é %d.\n", player.energy);
 printf("A sua sala inicial é %d.\n", player.cell);
}

int main(){
 struct Player player;
    
 InitPlayer(&player);
 ShowPlayer(player);
	
 return 0;
}