create database Produtos

create table produtos (
 nr_produto smallint primary key,
 nome_produto varchar(60)not null,
 preco_produto decimal(10,2) not null,
 quantidade int not null)

create table fornecedores (
 nr_fornecedor smallint primary key,
 nome_fornecedor varchar(80),
 morada_fornecedor varchar(50),
 localidade varchar(30),
 fax_fornecedor varchar(20))

create table encomendas (
 nr_encomenda smallint primary key,
 data_encomenda date not null,
 nr_fornecedor smallint,
 foreign key (nr_fornecedor)
 references fornecedores(nr_fornecedor)
 on update cascade
 on delete cascade)

create table item (
 nr_produto smallint not null,
 nr_encomenda smallint not null,
 unidades_item int not null,
 foreign key(nr_produto)
 references produtos(nr_produto)
 on update cascade
 on delete cascade,
 foreign key(nr_encomenda)
 references encomendas(nr_encomenda)
 on update cascade
 on delete cascade,
 primary key(nr_produto,nr_encomenda))

create table tipos (
 nr_tipo smallint primary key,
 nome_tipo varchar(30))

create table tipos_fornecedores (
 nr_fornecedor smallint not null,
 nr_tipo smallint not null,
 foreign key(nr_fornecedor)
 references fornecedores(nr_fornecedor)
 on update cascade
 on delete cascade,
 foreign key(nr_tipo)
 references tipos(nr_tipo)
 on update cascade
 on delete cascade,
 primary key(nr_fornecedor, nr_tipo))

insert into produtos
 values(1, 'batatas',2.4, 1),
 (2, 'morangos',2.5, 2),
 (3, 'leite', 0.85,3),
 (4, 'queijo flamengo', 3.45,4),
 (5, 'p�o', 1.80, 2)

insert into item
values  (1,2,10),
		(2,1,20),
		(2,4,15),
		(3,2,20),
		(3,3,10),
		(3,4,10),
		(4,2,10),
		(4,3,15),
		(4,4,10),
		(4,5,4),
		(5,4,40)

insert into encomendas
	values  (1, '2014-12-08', 1),
			(2, '2014-12-08', 2),
			(3, '2014-09-06', 1),
			(4, '2014-12-12', 2),
			(5, '2014-12-12', 4)

insert into fornecedores
	values  (1,'Auchan','rue de la vie','Fran�a','12345gh'),
			(2, 'Marco', 'rua maria pia','Lisboa - Portugal','675tgfsse'),
			(3,'Jumbo', 'ruth adfres','Alemanha','iut65fds'),
			(4,'Continente', 'rua aaa Portugal','Portugal','mnbg453')

insert into tipos
	values(1,'Retalho'),(2,'Venda Direta')

insert into tipos_fornecedores
	values  (1,1),
			(1,2),
			(2,2),
			(3,1),
			(4,1),
			(4,2)

select nome_fornecedor
from fornecedores

select nome_fornecedor, nome_tipo
from fornecedores, tipos, tipos_fornecedores
where tipos.nr_tipo = tipos_fornecedores.nr_tipo and
	  fornecedores.nr_fornecedor = tipos_fornecedores.nr_fornecedor and
	  nome_tipo like 'Retalho'

select nome_fornecedor, nome_tipo
from fornecedores, tipos, tipos_fornecedores
where tipos.nr_tipo = tipos_fornecedores.nr_tipo and
	  fornecedores.nr_fornecedor = tipos_fornecedores.nr_fornecedor and
	  nome_tipo like 'Venda Direta'

select nome_fornecedor, prazo_pagamento
from fornecedores, encomendas
where fornecedores.nr_fornecedor = encomendas.nr_fornecedor

select nome_fornecedor, prazo_pagamento
from fornecedores, encomendas
where fornecedores.nr_fornecedor = encomendas.nr_fornecedor and
	  nome_fornecedor like 'Marco'

select nome_fornecedor
from fornecedores, encomendas
where fornecedores.nr_fornecedor = encomendas.nr_fornecedor
group by nome_fornecedor

select nr_encomenda
from  encomendas

select nome_produto
from produtos

select nr_encomenda, nome_produto
from  produtos, item
where item.nr_produto = produtos.nr_produto
order by nr_encomenda asc

select nr_encomenda, nome_produto
from  produtos, item
where item.nr_produto = produtos.nr_produto and 
	  nr_encomenda = 2

select nr_encomenda, nome_produto, unidades_item
from  produtos, item
where item.nr_produto = produtos.nr_produto and
	  unidades_item > 5
order by nr_encomenda asc

select nome_produto, quantidade
from produtos

select nome_produto, preco_produto
from produtos
where preco_produto = (select preco_produto
					   from produtos
					   where nome_produto like 'batatas')