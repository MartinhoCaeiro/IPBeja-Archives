USE AdventureWorks2022
GO

	IF EXISTS (SELECT * FROM sys.tables WHERE OBJECT_ID = OBJECT_ID('Person.Person_Teste'))
		DROP TABLE Person.Person_Teste;

GO

	SELECT * INTO Person.Person_Teste FROM Person.Person;

GO

SELECT *
	 FROM Person.Person_Teste WHERE LastName = 'Brown';

GO


CREATE NONCLUSTERED INDEX Name_Index
	ON Person.Person_Teste (LastName);

GO


IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('Person.Person_Teste')
AND name = 'Name_Index')
	DROP INDEX Person.Person_Teste.Name_Index;

CREATE CLUSTERED INDEX Name_Index ON Person.Person_Teste (LastName);

GO

SELECT *
	 FROM Person.Person_Teste WHERE LastName = 'Brown';

GO



IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('Person.Person_Teste')
AND name = 'Name_Index')
	DROP INDEX Person.Person_Teste.Name_Index;
 
 CREATE NONCLUSTERED INDEX Name_Index ON Person.Person_Teste (FirstName, LastName);
 
 GO

SELECT FirstName, LastName
	FROM Person.Person_Teste
	WHERE FirstName like '%Jo%' and LastName = 'Brown';

GO


IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('Person.Person_Teste')
AND name = 'Name_Index')
	DROP INDEX Person.Person_Teste.Name_Index;
 
 CREATE CLUSTERED INDEX Name_Index ON Person.Person_Teste (FirstName, LastName);
 
 GO

SELECT FirstName, LastName
	FROM Person.Person_Teste
	WHERE FirstName like '%Jo%' and LastName = 'Brown';

GO