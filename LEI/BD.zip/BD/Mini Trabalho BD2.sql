--2.� Mini trabalho de Base de Dados 2
--Grupo 4

USE AdventureWorks2022


--a)
CREATE PROCEDURE MostrarProdutos
AS (SELECT * FROM Production.Product)

EXECUTE MostrarProdutos

--b)
CREATE PROCEDURE MostrarSubcategoria
AS (SELECT Production.Product.Name AS Product, Production.ProductSubcategory.Name AS Subcategory 
FROM Production.Product, Production.ProductSubcategory
WHERE Product.ProductSubcategoryID = ProductSubcategory.ProductSubcategoryID)

EXECUTE MostrarSubcategoria

--c)
CREATE PROCEDURE BuscarProduto
 @ReorderPoint int
AS
 SET NOCOUNT ON;

 SELECT Production.Product.ProductID, Production.Product.Name, Production.Product.ReorderPoint
 FROM Production.Product
 WHERE
 ReorderPoint = @ReorderPoint
 IF (@@ROWCOUNT = 0)
 RAISERROR('No product was found!',16,1);

 EXECUTE BuscarProduto @ReorderPoint = 3;

 --d)
 CREATE PROCEDURE InserirProduto
AS
BEGIN
    SET IDENTITY_INSERT Production.Product ON;

    INSERT INTO Production.Product (
        ProductID, Name, ProductNumber, MakeFlag, FinishedGoodsFlag,
        Color, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice,
        Size, SizeUnitMeasureCode, WeightUnitMeasureCode, Weight,
        DaysToManufacture, ProductLine, Class, Style, ProductSubcategoryID,
        ProductModelID, SellStartDate, rowguid, ModifiedDate)
    
	VALUES (
        1000, 'Road-750 Black, 56', 'BK-R19B-56', 1, 1, 'Black', 100, 75,
        343.6496, 539.99, 56, 'CM', 'LB', 21, 4, 'R', 'L', 'U', 2, 31,
        '2013-05-30', NEWID(), '2014-02-08 10:01:36.827');

    SET IDENTITY_INSERT Production.Product OFF;
END;

 EXECUTE InserirProduto

 --e)
 SELECT * From Production.Product
 WHERE Product.ProductID = 1000
 IF (@@ROWCOUNT = 0)
 RAISERROR('No product was found!',16,1);

 --f)
 CREATE PROCEDURE EliminarProduto
  @ProductID int
 AS
 SET NOCOUNT ON;

 DELETE FROM Production.Product
 WHERE ProductID = @ProductID
 IF (@@ROWCOUNT = 0)
 RAISERROR('No product was found!',16,1);

 EXECUTE EliminarProduto @ProductID = 1000;
