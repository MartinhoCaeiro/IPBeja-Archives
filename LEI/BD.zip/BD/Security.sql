USE AdventureWorks2022;

SELECT * FROM Person.PhoneNumberType;

INSERT INTO Person.PhoneNumberType
Values('YourMomma','2023-10-31')

UPDATE Person.PhoneNumberType
SET Name = 'YourDaddy'
WHERE PhoneNumberTypeID = 4;

DELETE FROM Person.PhoneNumberType
WHERE Name = 'YourDaddy';


GRANT ALTER ANY SCHEMA to User1
GRANT EXECUTE to User1
GRANT CONTROL to User1
EXEC sp_addrolemember N'db_datareader', N'User1'
EXEC sp_addrolemember N'db_datawriter', N'User1'

GRANT SELECT ON Person.PhoneNumberType TO User1 WITH GRANT OPTION;
ALTER ROLE db_datareader ADD MEMBER User1;
ALTER ROLE db_datawriter ADD MEMBER User1;

USE AdventureWorks2022; -- Selecione o banco de dados apropriado
CREATE USER User2 FOR LOGIN testeBD;


GRANT SELECT ON Person.PhoneNumberType TO User2;

SELECT * FROM sys.fn_builtin_permissions(DEFAULT)
WHERE permission_name = 'CREATE LOGIN'

DENY SELECT ON Person.PhoneNumberType TO User2;

SELECT * FROM sys.fn_builtin_permissions(DEFAULT)
WHERE permission_name = 'SELECT'


CREATE PROCEDURE SelectEx
AS
BEGIN
    SELECT * FROM Person.PhoneNumberType;
END;

GRANT EXECUTE ON SelectEx TO User2;