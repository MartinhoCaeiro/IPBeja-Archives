create database Encomendas

create table cliente(
nr_cl smallint primary key,
nomeCliente varchar(100),
morada varchar(120),
localidade varchar(60),
contacto varchar(15))

create table encomenda(
nrencomenda smallint primary key,
nr_cl smallint,
foreign key(nr_cl) 
references cliente(nr_cl),
data_enc date)

create table produtos(
nrprod smallint primary key,
nome_prod varchar(60),
preco_prod decimal(10, 2))

create table linhaenc(
nrlinhaenc smallint primary key,
nrencomenda smallint,
nrprod smallint,
foreign key(nrencomenda)
references encomenda(nrencomenda),
foreign key(nrprod)
references produtos(nrprod),
quant integer)

insert into cliente
values	(01, 'elsa rodrigues', 'rua de beja', 'beja', '7800-501'),
		(02, 'diogo patusca', 'rua das flores', 'beja', '7800-502'),
		(03, 'rodrigo in�cio', 'rua das flores', 'beja', '1200-546')

insert into encomenda
values	(11, 02, '20230212'),
		(12, 03, '20230213'),
		(13, 01, '20230312'),
		(14, 03, '20230314'),
		(15, 01, '20230316')

insert into produtos
values	(02, 'espinafres', 2.30),
		(03, 'batatas', 3.20),
		(04, 'cebola', 2.40),
		(05, 'costeletas', 12.00),
		(06, 'salm�o', 30.00)

insert into linhaenc
values	(01, 11, 03, 3),
		(02, 11, 02, 1),
		(03, 11, 05, 3),
		(04, 12, 06, 2),
		(05, 13, 03, 1),
		(06, 13, 06, 3),
		(07, 14, 04, 2),
		(08, 14, 05, 2),
		(09, 14, 02, 1),
		(10, 15, 06, 3),
		(11, 15, 04, 2)

select * from cliente
select * from cliente where nomeCliente like  'e%'

select nomeCliente, cliente.nr_cl, nrencomenda
from cliente, encomenda
where cliente.nr_cl = encomenda.nr_cl

select nomeCliente, cliente.nr_cl, encomenda.nrencomenda, nome_prod, quant, preco_prod
from cliente, encomenda, linhaenc, produtos 
where	cliente.nr_cl = encomenda.nr_cl and
		encomenda.nrencomenda = linhaenc.nrencomenda and
		produtos.nrprod = linhaenc.nrprod and
		encomenda.nrencomenda = 11