create database Voos

create table marcas(
nr_marca smallint primary key,
nome_marca varchar(60),
autonomia_marca decimal(10,2),
lugares_marca integer)

create table avioes(
matricula_aviao varchar(40) primary key,
nome_aviao varchar(60),
nr_marca smallint not null,
foreign key(nr_marca)
references marcas(nr_marca))

create table voo(
nr_voo smallint primary key,
data_voo date,
hora_voo time,
partida_voo varchar(100),
destino_voo varchar(100),
matricula_aviao varchar(40) not null,
foreign key(matricula_aviao)
references avioes(matricula_aviao))

create table pilotos(
nr_piloto smallint primary key,
nome_piloto varchar(60))

create table comandante(
nr_voo smallint,
foreign key (nr_voo)
references voo(nr_voo),
nr_piloto smallint,
foreign key (nr_piloto)
references pilotos(nr_piloto),
primary key(nr_voo, nr_piloto))

insert into pilotos
values	(1, 'Paul Bonhomme'),
		(2, 'Hannes Arch'),
		(3, 'Mike Mangold'),
		(4, 'Peter Besenyei'),
		(5, 'Ant�nio Alonso')

insert into marcas
values	(1, 'Boeing', 1400, 100),
		(2, 'Airbus', 980, 9000)

insert into avioes
values	('TP-1435', '777', 1),
		('TP-2541', '767', 1),
		('TP-1097', 'A-320', 2),
		('TP-3412', 'A-380', 2)

insert into voo
values	(1, '20141224', '12:00', 'Paris', 'Lisboa', 'TP-2541'),
		(2, '20141002', '15:00', 'Londres', 'Porto', 'TP-3412'),
		(3, '20141111', '20:00', 'Lisboa', 'Faro', 'TP-1097'),
		(4, '20140924', '09:00', 'Lisboa', 'Madrid', 'TP-1097')

insert into comandante
values	(1, 1),
		(2, 1),
		(3, 2),
		(4, 4)

select nome_marca, autonomia_marca
from marcas

select nome_marca, nome_aviao, partida_voo, destino_voo, nome_piloto
from avioes, voo, marcas, pilotos, comandante
where avioes.matricula_aviao = voo.matricula_aviao and
	  marcas.nr_marca = avioes.nr_marca and
	  voo.nr_voo = comandante.nr_voo and
	  pilotos.nr_piloto = comandante.nr_piloto and
	  partida_voo like 'Londres' and
	  destino_voo like 'Porto'

select nome_marca, nome_piloto
from avioes, voo, marcas, pilotos, comandante
where pilotos.nr_piloto = comandante.nr_piloto and
	  voo.nr_voo = comandante.nr_voo and
	  avioes.matricula_aviao = voo.matricula_aviao and
	  marcas.nr_marca = avioes.nr_marca and
	  nome_marca like 'Boeing'

select nome_marca, nome_piloto
from avioes, voo, marcas, pilotos, comandante
where pilotos.nr_piloto = comandante.nr_piloto and
	  voo.nr_voo = comandante.nr_voo and
	  avioes.matricula_aviao = voo.matricula_aviao and
	  marcas.nr_marca = avioes.nr_marca and
	  nome_piloto like 'Paul Bonhomme'

select TOP 1 pilotos.nome_piloto, count(comandante.nr_voo) as numero_voos
from pilotos, comandante
where pilotos.nr_piloto = comandante.nr_piloto
group by pilotos.nome_piloto
order by numero_voos DESC

select nome_marca, nome_aviao, lugares_marca
from marcas, avioes
where marcas.nr_marca = avioes.nr_marca
order by lugares_marca DESC

select max(nr_flights) as max_nr_flights
from( select count(pilotos.nr_piloto) as nr_flights
	  from pilotos, voo, comandante
	  where pilotos.nr_piloto = comandante.nr_piloto and
	  comandante.nr_voo = voo.nr_voo
	  group by pilotos.nr_piloto) as max_flights

select marcas.nome_marca
from marcas
where marcas.lugares_marca in ( select max(marcas.lugares_marca)
							    from marcas)