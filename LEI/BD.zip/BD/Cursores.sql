USE AdventureWorks2022

DECLARE vend_cursor CURSOR
 FOR SELECT * FROM Purchasing.Vendor
OPEN vend_cursor
FETCH NEXT FROM vend_cursor;
WHILE @@FETCH_STATUS = 0
 FETCH NEXT FROM vend_cursor;
PRINT 'fecha cursor'
CLOSE vend_cursor
PRINT 'liberta recursos'
DEALLOCATE vend_cursor 


CREATE PROCEDURE mostraCustomerNull
 AS
DECLARE mCustomerCursor
CURSOR FOR SELECT * FROM Sales.Customer WHERE PersonID IS NULL
OPEN mCustomerCursor
FETCH NEXT FROM mCustomerCursor
WHILE (@@fetch_status = 0)
 BEGIN
 FETCH NEXT FROM mCustomerCursor
END
CLOSE mCustomerCursor
DEALLOCATE mCustomerCursor

EXECUTE mostraCustomerNull


IF OBJECT_ID('Sales.ProcessCustomer') IS NOT NULL
DROP PROC Sales.ProcessCustomer;

CREATE PROC Sales.ProcessCustomer (@custid AS INT)
AS
 PRINT 'Processing customer ' + CAST(@custid AS VARCHAR(10));

EXECUTE Sales.ProcessCustomer @custid = 3;

 
 SET NOCOUNT ON;
DECLARE @curcustid AS INT;
DECLARE cust_cursor CURSOR FAST_FORWARD
FOR
 SELECT CustomerID
 FROM Sales.Customer;
OPEN cust_cursor;
FETCH NEXT FROM cust_cursor INTO @curcustid;
WHILE @@FETCH_STATUS = 0
BEGIN
 EXEC Sales.ProcessCustomer @custid = @curcustid;
 FETCH NEXT FROM cust_cursor INTO @curcustid;
END;
CLOSE cust_cursor;
DEALLOCATE cust_cursor;