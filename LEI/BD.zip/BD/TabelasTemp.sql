USE AdventureWorks2022

IF OBJECT_ID ('Tab_temporarias','TR') IS NOT NULL
 DROP TRIGGER Tab_temporarias; 

CREATE TRIGGER Tab_temporarias
ON Person.ContactType
AFTER UPDATE, DELETE, INSERT
AS
print 'inserted'
SELECT * FROM inserted
print 'deleted'
select * from deleted 

SET IDENTITY_INSERT Person.ContactType ON;
INSERT INTO Person.ContactType(ContactTypeID, Name)
VALUES (21, 'Sales Maker');
SET IDENTITY_INSERT Person.ContactType OFF;

DELETE FROM Person.ContactType
 WHERE ContactTypeID = 21;

select * from Person.ContactType


IF OBJECT_ID ('Purchasing.LowCredit','TR') IS NOT NULL
 DROP TRIGGER Purchasing.LowCredit;  CREATE TRIGGER Purchasing.LowCredit 
 ON Purchasing.PurchaseOrderHeader
AFTER INSERT
AS
IF EXISTS (SELECT * FROM Purchasing.PurchaseOrderHeader AS p
 JOIN inserted AS i
 ON p.PurchaseOrderID = i.PurchaseOrderID
 JOIN Purchasing.Vendor AS v
 ON v.BusinessEntityID = p.VendorID
 WHERE v.CreditRating = 5)
BEGIN
RAISERROR ('A vendor`s credit rating is too low to accept new purchase orders.', 16, 1);
ROLLBACK TRANSACTION;
RETURN
END;

SET IDENTITY_INSERT Purchasing.PurchaseOrderHeader ON;
INSERT INTO Purchasing.PurchaseOrderHeader(PurchaseOrderID, RevisionNumber, Status, EmployeeID, VendorID, ShipMethodID, OrderDate, SubTotal, TaxAmt, Freight, ModifiedDate)
VALUES (4013, 5, 3, 255, 1550, 3, '2011-04-16', 355.67, 23.0734, 7.3782, '2011-04-25');
SET IDENTITY_INSERT Purchasing.PurchaseOrderHeader OFF;