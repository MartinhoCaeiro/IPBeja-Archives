USE [AdventureWorks2022]

DECLARE @Test money
SELECT @Test = MAX(UnitPrice) FROM Sales.SalesOrderDetail
PRINT @Test 

DECLARE @custo money
PRINT 'este � o velho custo'
PRINT @custo
SET @custo =3000
PRINT 'este � o novo custo'
PRINT @custo 
 
Declare @maximo money, @minimo money
SELECT @maximo = MAX(UnitPrice), @minimo=MIN(UnitPrice) FROM
Sales.SalesOrderDetail
Print 'este � o m�ximo custo'
Print @maximo
Print 'este � o m�nimo custo'
Print @minimo 

set @maximo= (select max(UnitPrice) FROM Sales.SalesOrderDetail )
set @minimo= (select min(UnitPrice) FROM Sales.SalesOrderDetail )
Print 'este � o m�ximo custo - 2'
Print @maximo
Print 'este � o m�nimo custo - 2'
Print @minimo
Select @maximo as Maximo, @minimo as Minimo 


SELECT ProductNumber, ProductLine, Name,
CASE
WHEN ProductLine = 'R' THEN 'Road'
 WHEN ProductLine = 'M' THEN 'Mountain'
 WHEN ProductLine = 'T' THEN 'Touring'
 WHEN ProductLine = 'S' THEN 'Other sale items'
 ELSE 'Not for sale'
 END AS ProductType
FROM Production.Product
ORDER BY ProductNumber;

IF EXISTS (SELECT * FROM Sales.Store)
BEGIN
 DECLARE @number_rows INT
 SELECT @number_rows = count(*) FROM Sales.Store
 PRINT 'Existem '+ CAST(@number_rows AS VARCHAR(10))
 + ' lojas de bicicletas '
END
ELSE
 PRINT 'Esta tabela n�o contem linhas'


IF (SELECT COUNT(*) FROM Production.Product WHERE Name LIKE 'Touring-3000%') > 5
    PRINT 'Existem mais do que 5 produtos cujo nome come�a por ''Touring-3000...''';
ELSE IF (SELECT COUNT(*) FROM Production.Product WHERE Name LIKE 'Touring-3000%') = 5
    PRINT 'Existem 5 produtos cujo nome come�a por ''Touring-3000...''';
ELSE
    PRINT 'N�o existem mais do que 5 produtos cujo nome come�a por ''Touring-3000...''';


IF (SELECT COUNT(*) FROM Production.Product WHERE Name LIKE 'Touring-3000%') > 5
    SELECT AVG(Production.Product.Weight) AS AvgWeight FROM Production.Product WHERE Name LIKE 'Touring-3000%';
ELSE IF (SELECT COUNT(*) FROM Production.Product WHERE Name LIKE 'Touring-3000%') = 5
    PRINT 'Existem 5 produtos cujo nome come�a por ''Touring-3000...''';
ELSE
    PRINT 'N�o existem mais do que 5 produtos cujo nome come�a por ''Touring-3000...''';

DECLARE @MediaAtual FLOAT, @PMaximo FLOAT;

SELECT @MediaAtual = AVG(Production.Product.ListPrice), @PMaximo = MAX(Production.Product.ListPrice)
FROM Production.Product

WHILE @MediaAtual < 300 AND @PMaximo <= 500
BEGIN
UPDATE Production.Product
SET Production.Product.ListPrice = Production.Product.ListPrice * 2;

SELECT @MediaAtual = AVG(Production.Product.ListPrice), @PMaximo = MAX(Production.Product.ListPrice)
FROM Production.Product;
END;
PRINT 'A m�dia atual � ' + CAST(@MediaAtual AS VARCHAR(10)) + ' e o pre�o m�ximo � ' + CAST(@PMaximo AS VARCHAR(10))