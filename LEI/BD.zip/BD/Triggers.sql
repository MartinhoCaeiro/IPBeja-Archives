USE AdventureWorks2022;

IF OBJECT_ID ('Sales.mensagemP', 'TR') IS NOT NULL
 DROP TRIGGER Sales.mensagemP;

CREATE TRIGGER mensagemP
ON Sales.Customer
AFTER INSERT, UPDATE 
AS PRINT 'Altera��o feita!'; 

SET IDENTITY_INSERT Sales.Customer ON;
INSERT INTO Sales.Customer(CustomerID)
VALUES (30120);
SET IDENTITY_INSERT Sales.Customer OFF;


IF OBJECT_ID ('Sales.apagar_customers', 'TR') IS NOT NULL
 DROP TRIGGER Sales.apagar_customers;

create trigger apagar_customers
on Sales.Customer
for delete
as
print 'Apaguei um registo?'
rollback transaction 

DELETE FROM Sales.Customer
 WHERE CustomerID = 30120;


IF EXISTS (SELECT * FROM sys.triggers
 WHERE parent_class = 0 AND name = 'safety')
DROP TRIGGER safety ON DATABASE;

CREATE TRIGGER safety
ON DATABASE
FOR DROP_TABLE, ALTER_TABLE
AS RAISERROR('Seguran�a ativada!',16,1);


CREATE TRIGGER verifica_departamento
 ON HumanResources.Employee
 FOR insert AS
 if not exists (select * from HumanResources.Employee, HumanResources.Department, HumanResources.EmployeeDepartmentHistory
 where Employee.BusinessEntityID = EmployeeDepartmentHistory.BusinessEntityID and 
 EmployeeDepartmentHistory.DepartmentID = Department.DepartmentID)
 begin
 print 'O departamento onde pretende inserir o empregado n�o existe!'
 rollback transaction
 end;