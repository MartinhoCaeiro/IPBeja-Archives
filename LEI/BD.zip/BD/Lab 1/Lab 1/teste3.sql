CREATE DATABASE teste3
ON PRIMARY
(
NAME = teste3_dados_1,
FILENAME = 'c:\databases\teste3_dados_1.mdf',
SIZE = 3MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
),
(
NAME = teste3_dados_2,
FILENAME = 'c:\databases\teste3_dados_2.ndf',
SIZE = 1MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
),
FILEGROUP teste3_filegroup_1
(
NAME = db_nome_dados_3,
FILENAME = 'c:\databases\teste3_dados_3.ndf',
SIZE = 1MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
),
(
NAME = teste3_dados_4,
FILENAME = 'c:\databases\teste3_dados_4.ndf',
SIZE = 1MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
),
FILEGROUP teste3_filegroup_indices
(
NAME = db_nome_dados_5,
FILENAME = 'c:\databases\teste3_dados_5.ndf',
SIZE = 1MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
)
LOG ON
(
NAME = teste3_log_1,
FILENAME = 'c:\databases\teste3_log_1.ldf',
SIZE = 1MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
),
( NAME = teste3_log_2,
FILENAME = 'c:\databases\teste3_log_2.ldf',
SIZE = 1MB,
MAXSIZE = 200MB,
FILEGROWTH = 10%
); 

SELECT * FROM sys.filegroups;
SELECT * FROM sys.database_files; USE teste3CREATE TABLE tabelaA
( cod INT CONSTRAINT pk_tA PRIMARY KEY, nome VARCHAR(20),BI INT
);

sp_help tabelaA;CREATE TABLE tabelaB
( cod INT CONSTRAINT pk_tB PRIMARY KEY, nome VARCHAR(20)
) ON teste3_filegroup_1; 

sp_help tabelaB;

CREATE TABLE tabelaC
( cod INT CONSTRAINT pk_tC PRIMARY KEY ON teste3_filegroup_indices, nome
VARCHAR(20)
)ON teste3_filegroup_1;

sp_help tabelaC;