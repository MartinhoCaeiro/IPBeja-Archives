CREATE DATABASE teste2;

SELECT * FROM sys.databases;

SELECT * FROM sys.database_files;

SELECT * FROM sys.tables;

SELECT sum(size)
FROM sys.database_files;

SELECT physical_name, growth, is_percent_growth
FROM sys.database_files;

IF (EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'teste2'))
BEGIN
	DROP DATABASE teste2
END