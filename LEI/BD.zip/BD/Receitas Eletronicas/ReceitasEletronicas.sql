--Cria��o da Base de Dados
CREATE DATABASE Receitas;

--Usar a Base de Dados
USE Receitas;

--Cria��o das Tabelas
EXECUTE master.dbo.xp_create_subdir 'C:\BDReceitas\'

ALTER DATABASE Receitas
ADD FILEGROUP Disco1;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco1',
    FILENAME = 'C:\BDReceitas\Disco1.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco1;

CREATE TABLE instituicoes(
nr_instituicao SMALLINT PRIMARY KEY,
nome_instituicao VARCHAR(60),
tipo_instituicao VARCHAR(60))
ON Disco1;


ALTER DATABASE Receitas
ADD FILEGROUP Disco2;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco2',
    FILENAME = 'C:\BDReceitas\Disco2.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco2;

CREATE TABLE medico(
nr_medico SMALLINT PRIMARY KEY,
senha VARCHAR(60),
nome_medico VARCHAR(60),
telefone INT NOT NULL,
especialidade VARCHAR(60))
ON Disco2;


ALTER DATABASE Receitas
ADD FILEGROUP Disco3;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco3',
    FILENAME = 'C:\BDReceitas\Disco3.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco3;

CREATE TABLE historico(
nr_medico SMALLINT NOT NULL,
FOREIGN KEY(nr_medico)
REFERENCES medico(nr_medico),
nr_instituicao SMALLINT NOT NULL,
FOREIGN KEY(nr_instituicao)
REFERENCES instituicoes(nr_instituicao),
PRIMARY KEY(nr_medico, nr_instituicao),
dt_inicio VARCHAR(60),
dt_fim VARCHAR(60))
ON Disco3;


ALTER DATABASE Receitas
ADD FILEGROUP Disco4;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco4',
    FILENAME = 'C:\BDReceitas\Disco4.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco4;

CREATE TABLE paciente(
nr_bi INT NOT NULL PRIMARY KEY,
nome_paciente VARCHAR(60),
morada VARCHAR(60),
localidade VARCHAR(60),
dt_nascimento VARCHAR(60),
nr_utente INT NOT NULL,
nr_segsocial INT NOT NULL,
nr_contribuinte INT NOT NULL,
telefone INT NOT NULL,
email VARCHAR(60))
ON Disco4;


ALTER DATABASE Receitas
ADD FILEGROUP Disco5;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco5',
    FILENAME = 'C:\BDReceitas\Disco5.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco5;

CREATE TABLE receitas(
nr_receita SMALLINT PRIMARY KEY,
nr_medico SMALLINT NOT NULL,
FOREIGN KEY(nr_medico)
REFERENCES medico(nr_medico),
nr_bi INT NOT NULL,
FOREIGN KEY(nr_bi)
REFERENCES paciente(nr_bi),
validade VARCHAR(60))
ON Disco5;


ALTER DATABASE Receitas
ADD FILEGROUP Disco6;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco6',
    FILENAME = 'C:\BDReceitas\Disco6.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco6;

CREATE TABLE farmacias(
nr_farmacia SMALLINT PRIMARY KEY,
nome_farmacia VARCHAR(60),
localidade VARCHAR(60),
telefone VARCHAR(60),
vendas INT NOT NULL)
ON Disco6;


ALTER DATABASE Receitas
ADD FILEGROUP Disco7;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco7',
    FILENAME = 'C:\BDReceitas\Disco7.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco7;

CREATE TABLE registo(
nr_farmacia SMALLINT NOT NULL,
FOREIGN KEY(nr_farmacia)
REFERENCES farmacias(nr_farmacia),
nr_receita SMALLINT NOT NULL,
FOREIGN KEY(nr_receita)
REFERENCES receitas(nr_receita),
PRIMARY KEY (nr_farmacia, nr_receita))
ON Disco7;


ALTER DATABASE Receitas
ADD FILEGROUP Disco8;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco8',
    FILENAME = 'C:\BDReceitas\Disco8.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco8;

CREATE TABLE farmaceuticos(
nr_farmaceutico SMALLINT PRIMARY KEY,
nome_farmaceutico VARCHAR(60),
nr_farmacia SMALLINT NOT NULL,
FOREIGN KEY(nr_farmacia)
REFERENCES farmacias(nr_farmacia))
ON Disco8;


ALTER DATABASE Receitas
ADD FILEGROUP Disco9;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco9',
    FILENAME = 'C:\BDReceitas\Disco9.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco9;

CREATE TABLE medicamentos(
nr_medicamento SMALLINT PRIMARY KEY,
nome_medicamento VARCHAR(60),
tipo_medicamento VARCHAR(60),
lab_fabrico VARCHAR(60),
apresentacao VARCHAR(60),
quantidade INT NOT NULL,
nr_farmacia SMALLINT NOT NULL,
FOREIGN KEY(nr_farmacia)
REFERENCES farmacias(nr_farmacia),
stock INT NOT NULL)
ON Disco9;


ALTER DATABASE Receitas
ADD FILEGROUP Disco10;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco10',
    FILENAME = 'C:\BDReceitas\Disco10.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco10;

CREATE TABLE lista_medicamentos(
nr_medicamento SMALLINT NOT NULL,
FOREIGN KEY(nr_medicamento)
REFERENCES medicamentos(nr_medicamento),
nr_receita SMALLINT NOT NULL,
FOREIGN KEY(nr_receita)
REFERENCES receitas(nr_receita),
PRIMARY KEY(nr_receita, nr_medicamento),
quant_pedida INT NOT NULL,
posologia VARCHAR(60))
ON Disco10;


ALTER DATABASE Receitas
ADD FILEGROUP Disco11;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'Disco11',
    FILENAME = 'C:\BDReceitas\Disco11.mdf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP Disco11;

CREATE TABLE vendas(
id_venda SMALLINT PRIMARY KEY NOT NULL,
nr_medicamento SMALLINT NOT NULL,
nr_farmacia SMALLINT NOT NULL,
FOREIGN KEY(nr_medicamento)
REFERENCES medicamentos(nr_medicamento),
FOREIGN KEY(nr_farmacia)
REFERENCES farmacias(nr_farmacia),
qnt_vendida INT)
ON Disco11;


ALTER DATABASE Receitas
ADD FILEGROUP DiscoLog;

ALTER DATABASE Receitas
ADD FILE
    (NAME = 'DiscoLog',
    FILENAME = 'C:\BDReceitas\DiscoLog.ldf',
    SIZE = 100MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10MB)
TO FILEGROUP DiscoLog;


--Cria��o de Triggers
CREATE TRIGGER Insercao1
ON instituicoes
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Institui��es!'; 

CREATE TRIGGER Insercao2
ON medico
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Medico!'; 

CREATE TRIGGER Insercao3
ON historico
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Hist�rico!'; 

CREATE TRIGGER Insercao4
ON paciente
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Paciente!'; 

CREATE TRIGGER Insercao5
ON receitas
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Receitas!'; 

CREATE TRIGGER Insercao6
ON farmacias
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Farmacias!'; 

CREATE TRIGGER Insercao7
ON registo
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Registo!'; 

CREATE TRIGGER Insercao8
ON farmaceuticos
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Farmaceuticos!'; 

CREATE TRIGGER Insercao9
ON medicamentos
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Medicamentos!'; 

CREATE TRIGGER Insercao10
ON lista_medicamentos
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Lista-Medicamentos!'; 

CREATE TRIGGER Insercao11
ON vendas
AFTER INSERT, UPDATE 
AS PRINT 'Valores Inseridos na tabela Vendas!'; 


--Inserir Valores
INSERT INTO instituicoes
VALUES(1, 'PGT', 'Privado'),
(2, 'ASD', 'Publico'),
(3, 'AGB', 'Privado'),
(4, 'RTS', 'Privado'),
(5, 'CKG', 'Publico')

INSERT INTO medico
VALUES(1, 478, 'Paula', 963445647, 'Cardiologia'),
(2, 467, 'Miguel', 947477480, 'Terapia'),
(3, 974, 'Jos�', 964540540, 'Urulogia'),
(4, 022, 'Marco', 927784900, 'Ortodontia'),
(5, 748, 'Laura', 946595738, 'Cardiologia')

INSERT INTO historico
VALUES(1, 3, '10/10/2020', '10/10/2022'),
(2, 5, '10/11/2019', '05/11/2022'),
(3, 2, '01/01/2020', '10/05/2021'),
(4, 1, '07/04/2019', '07/07/2021'),
(5, 4, '09/10/2018', '05/12/2020')

INSERT INTO paciente
VALUES(1, 'Berto', 'Rua Lisboa', 'Porto', '10/10/1959', 4423, 2384234, 23472, 962384623, 'Berto@gmail.com'),
(2, 'Raul', 'Rua Porto', 'Lisboa', '05/11/2000', 3546, 3894573, 34653, 964653477, 'Berto@hotmail.com'),
(3, 'Joaquina', 'Rua Faro', 'Beja', '07/04/1999', 8346, 7878656, 78356, 987362837, 'Joaquina@gmail.com'),
(4, 'In�s', 'Rua Lisboa', 'Beja', '07/04/1970', 7846, 4853657, 28463, 936725382, 'In�s@hotmail.com'),
(5, 'Guilherme', 'Rua Beja', 'Faro','09/10/2004', 9853, 3265274, 82462, 966753784, 'Guilherme@hotmail.com')

INSERT INTO receitas
VALUES(1, 3, 2, '05/11/2022'),
(2, 2, 3, '09/10/2018'),
(3, 5, 4, '10/11/2019'),
(4, 1, 5, '10/10/2020'),
(5, 4, 1, '07/07/2021')

INSERT INTO farmacias
VALUES(1, 'AKDS', 'Lisboa', 946182731, 255),
(2, 'RGJR', 'Porto', 946583553, 567),
(3, 'NHLD', 'Beja', 946954375, 640),
(4, 'NNES', 'Lisboa', 937424289, 300),
(5, 'OREH', 'Faro', 908437483, 1000)

INSERT INTO registo
VALUES(1, 3),
(2, 2),
(3, 5),
(4, 1),
(5, 4)

INSERT INTO farmaceuticos
VALUES(1, 'Joana', 3),
(2, 'Maria', 1),
(3, 'Rui', 5),
(4, 'Rafael', 4),
(5, 'Bruno', 2)

INSERT INTO medicamentos
VALUES(1, 'Bilamina', 'Comparticipado','ASGDSJ', 'Xarope', 10, 1, 43),
(2, 'Tamina', 'N�o Comparticipado','DFNDJD', 'Comprimido', 25, 3, 65),
(3, 'Espirina', 'Comparticipado','ORUEFHD', 'Comprimido', 5, 5, 54),
(4, 'Parlamina', 'Comparticipado','MVBDSD', 'Xarope', 33, 4, 76),
(5, 'Fislamina', 'N�o Comparticipado','EYRUWE', 'Xarope', 50, 2, 32)

INSERT INTO lista_medicamentos
VALUES(1, 4, 20, '2 vezes ao dia'),
(2, 1, 100, '1 vezes ao dia'),
(3, 2, 15, '3 vezes ao dia'),
(4, 3, 50, '3 vezes ao dia'),
(5, 5, 35, '1 vezes ao dia') 

INSERT INTO vendas
VALUES(1,1,2,50),
(2,2,1,55),
(3,2,2,60),
(4,1,3,60),
(5,3,3,50),
(6,4,3,20),
(7,5,1,30),
(8,5,2,40)


--Procuras com Stored Procedures
CREATE PROCEDURE Respostas1 
AS SELECT TOP 1 nome_farmacia, sum(vendas.qnt_vendida) as total_vendas
FROM farmacias, vendas
WHERE farmacias.nr_farmacia = vendas.nr_farmacia
GROUP BY farmacias.nr_farmacia, farmacias.vendas, nome_farmacia
ORDER BY total_vendas DESC
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontradas farm�cias!',16,1);

EXECUTE Respostas1


CREATE PROCEDURE Respostas2
AS SELECT TOP 10 medicamentos.nome_medicamento, SUM(vendas.qnt_vendida) AS qnt_total_vendida
FROM medicamentos, vendas
WHERE medicamentos.nr_medicamento = vendas.nr_medicamento
GROUP BY medicamentos.nome_medicamento
ORDER BY qnt_total_vendida DESC;
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados medicamentos!',16,1);

EXECUTE Respostas2


CREATE PROCEDURE Respostas3
AS SELECT TOP 10 farmacias.nome_farmacia, medicamentos.nome_medicamento, SUM(vendas.qnt_vendida) AS total_vendidos
FROM medicamentos, vendas, farmacias
WHERE medicamentos.nr_medicamento = vendas.nr_medicamento AND vendas.nr_farmacia = farmacias.nr_farmacia
GROUP BY farmacias.nome_farmacia, medicamentos.nome_medicamento
ORDER BY farmacias.nome_farmacia, total_vendidos DESC;
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados medicamentos!',16,1);

EXECUTE Respostas3


CREATE PROCEDURE Respostas4
AS SELECT nome_paciente, count(nr_receita) as total_receitas
FROM paciente, receitas
WHERE paciente.nr_bi = receitas.nr_bi
GROUP BY nome_paciente
ORDER BY total_receitas DESC
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados pacientes/receitas!',16,1);

EXECUTE Respostas4


CREATE PROCEDURE Respostas5
AS SELECT nome_medico, especialidade
FROM medico
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados m�dicos/especialidades!',16,1);

EXECUTE Respostas5


CREATE PROCEDURE Respostas6
AS SELECT nome_medico, nome_instituicao
FROM medico, instituicoes, historico
WHERE medico.nr_medico = historico.nr_medico AND
instituicoes.nr_instituicao = historico.nr_instituicao
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados m�dicos/institui��es!',16,1);

EXECUTE Respostas6


CREATE PROCEDURE Respostas7
AS SELECT nome_medico, count(nr_receita) AS total_receitas
FROM medico, receitas
WHERE medico.nr_medico = receitas.nr_medico
GROUP BY nome_medico
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados m�dicos/receitas!',16,1);

EXECUTE Respostas7


CREATE PROCEDURE Respostas8
AS SELECT nome_medico, nome_paciente, count(nr_receita) AS total_receitas
FROM medico, paciente, receitas
WHERE medico.nr_medico = receitas.nr_medico AND
paciente.nr_bi = receitas.nr_bi
GROUP BY nome_medico, nome_paciente
IF (@@ROWCOUNT = 0)
RAISERROR('N�o foram encontrados m�dicos/pacientes/receitas!',16,1);

EXECUTE Respostas8


--Seguran�a
ALTER AUTHORIZATION ON SCHEMA::[db_datareader] TO [guest]
ALTER AUTHORIZATION ON SCHEMA::[db_denydatawriter] TO [guest]
ALTER AUTHORIZATION ON SCHEMA::[db_owner] TO [dbo]

--Exemplo Seguran�a User
ALTER AUTHORIZATION ON SCHEMA::[db_datareader] TO [user]
ALTER AUTHORIZATION ON SCHEMA::[db_denydatawriter] TO [user]

--Backups da Base de Dados
EXECUTE master.dbo.xp_create_subdir 'C:\BDReceitas\Backups\'

--Todos os meses
BACKUP DATABASE Receitas TO DISK = N'C:\BDReceitas\Backups\ReceitasEletronicas' WITH NOFORMAT, NOINIT, 
NAME = N'ReceitasEletronicas-Full Database Backup', SKIP, NOREWIND, NOUNLOAD, STATS = 10

--Todas as semanas
BACKUP DATABASE Receitas TO DISK = N'C:\BDReceitas\Backups\ReceitasEletronicas' WITH DIFFERENTIAL , NOFORMAT, NOINIT,
NAME = N'ReceitasEletronicas-Differential Database Backup', SKIP, NOREWIND, NOUNLOAD, STATS = 10

--Todos os dias
BACKUP LOG Receitas TO DISK = N'C:\BDReceitas\Backups\ReceitasEletronicas' WITH NOFORMAT, NOINIT,
NAME = N'ReceitasEletronicas-Transaction Log Backup', SKIP, NOREWIND, NOUNLOAD, STATS = 10


--Restauro da BD
DECLARE @backupSetId AS INT

SELECT @backupSetId = position 
FROM msdb.backupset WHERE database_name=N'Receitas' AND 
backup_set_id=(SELECT max(backup_set_id) FROM msdb..backupset WHERE database_name=N'Receitas' )

IF @backupSetId IS NULL BEGIN 
RAISERROR(N'N�o foi possivel encontrar o Backup da BD ''Receitas''.', 16, 1) END

RESTORE VERIFYONLY FROM DISK = N'C:\Backups\Teste' WITH FILE = @backupSetId, NOUNLOAD, NOREWIND


--Criar Email da Base de Dados
EXECUTE msdb.dbo.sysmail_add_profile_sp  
    @profile_name = 'Notifica��es',  
    @description = 'Perfil utilizado para enviar notifica��es atrav�s do Gmail.' ;

EXECUTE msdb.dbo.sysmail_add_principalprofile_sp  
    @profile_name = 'Notifica��es',  
    @principal_name = 'public',  
    @is_default = 1 ;

EXECUTE msdb.dbo.sysmail_add_account_sp  
    @account_name = 'Gmail',  
    @description = 'Conta email para enviar notifica��es.',  
    @email_address = 'teste@gmail.com',  
    @display_name = 'Envio Automatico',  
    @mailserver_name = 'smtp.gmail.com',
    @port = 465,
    @enable_ssl = 1,
    @username = 'teste@gmail.com',
    @password = '1234' ;

EXECUTE msdb.dbo.sysmail_add_profileaccount_sp  
    @profile_name = 'Notifica��es',  
    @account_name = 'Gmail',  
    @sequence_number =1 ; 