USE AdventureWorks2022

create procedure MostraPessoas
as (select * from Person.Person)

execute MostraPessoas


create procedure MostrarEmpregados
as (select FirstName, LastName, Name as Department 
from Person.Person, HumanResources.Employee,HumanResources.EmployeeDepartmentHistory, HumanResources.Department
where Department.DepartmentID = EmployeeDepartmentHistory.DepartmentID and
Employee.BusinessEntityID = EmployeeDepartmentHistory.BusinessEntityID and
Employee.BusinessEntityID = Person.BusinessEntityID)

execute MostrarEmpregados


IF OBJECT_ID ( 'HumanResources.uspGetEmployees', 'P' ) IS NOT NULL
 DROP PROCEDURE HumanResources.uspGetEmployees; 

 CREATE PROCEDURE HumanResources.uspGetEmployees
 @LastName nvarchar(50),
 @FirstName nvarchar(50)
AS
 SET NOCOUNT ON;

 SELECT Person.Person.FirstName, Person.Person.LastName, JobTitle
 FROM Person.Person, HumanResources.Employee
 where
Person.Person.BusinessEntityID=HumanResources.Employee.BusinessEntityID
and FirstName = @FirstName AND LastName = @LastName
 IF (@@ROWCOUNT = 0)
 RAISERROR('No name was found!',16,1);

EXECUTE HumanResources.uspGetEmployees @FirstName = N'Pilar', @LastName = N'Ackerman'; 


IF OBJECT_ID ( 'Production.uspGetWhereUsedProductID', 'P' ) IS NOT NULL
 DROP PROCEDURE Production.uspGetWhereUsedProductID; 

 CREATE PROCEDURE Production.uspGetWhereUsedProductID
 @ProductID int
AS
 SET NOCOUNT ON;

 SELECT Production.Product.ProductID, Production.Product.Name, Production.Product.ListPrice
 FROM Production.Product
 where
 ProductID = @ProductID
 IF (@@ROWCOUNT = 0)
 RAISERROR('No part was found!',16,1);

 EXECUTE Production.uspGetWhereUsedProductID @ProductID = 819;


 IF OBJECT_ID ( 'Production.uspGetWhereUsedDepartmentID', 'P' ) IS NOT NULL
 DROP PROCEDURE Production.uspGetWhereUsedDepartmentID; 

 CREATE PROCEDURE Production.uspGetWhereUsedDepartmentID
 @DepartmentID smallint
AS
 SET NOCOUNT ON;

 SELECT Department.DepartmentID, FirstName, LastName, JobTitle, Name as Department
 FROM Person.Person, HumanResources.Employee,HumanResources.EmployeeDepartmentHistory, HumanResources.Department
 where
 Department.DepartmentID = EmployeeDepartmentHistory.DepartmentID and
Employee.BusinessEntityID = EmployeeDepartmentHistory.BusinessEntityID and
Employee.BusinessEntityID = Person.BusinessEntityID and Department.DepartmentID = @DepartmentID
 IF (@@ROWCOUNT = 0)
 RAISERROR('No department was found!',16,1);

 EXECUTE Production.uspGetWhereUsedDepartmentID @DepartmentID = 5;


 IF OBJECT_ID('Sales.uspGetEmployeeSalesYTD', 'P') IS NOT NULL
 DROP PROCEDURE Sales.uspGetEmployeeSalesYTD;

 CREATE PROCEDURE Sales.uspGetEmployeeSalesYTD
@SalesPerson nvarchar(50),
@SalesYTD money OUTPUT
AS
 SET NOCOUNT ON;
 SELECT @SalesYTD = SalesYTD
 FROM Sales.SalesPerson AS sp
 JOIN HumanResources.vEmployee AS e ON e.BusinessEntityID =
sp.BusinessEntityID
 WHERE LastName = @SalesPerson;
RETURN

DECLARE @SalesYTDBySalesPerson money;

EXECUTE Sales.uspGetEmployeeSalesYTD
 N'Blythe', @SalesYTD = @SalesYTDBySalesPerson OUTPUT;

PRINT 'Year-to-date sales for this employee is ' +
 convert(varchar(10),@SalesYTDBySalesPerson); 


 IF OBJECT_ID ( 'Production.uspGetList', 'P' ) IS NOT NULL
 DROP PROCEDURE Production.uspGetList; 

 CREATE PROCEDURE Production.uspGetList 
 @Product varchar(40)
 , @MaxPrice money
 , @ComparePrice money OUTPUT
 , @ListPrice money OUT
AS
 SET NOCOUNT ON;
 SELECT p.[Name] AS Product, p.ListPrice AS 'List Price'
 FROM Production.Product AS p
 JOIN Production.ProductSubcategory AS s
 ON p.ProductSubcategoryID = s.ProductSubcategoryID
 WHERE s.[Name] LIKE @Product AND p.ListPrice < @MaxPrice;

SET @ListPrice = (SELECT MAX(p.ListPrice)
 FROM Production.Product AS p
 JOIN Production.ProductSubcategory AS s
 ON p.ProductSubcategoryID = s.ProductSubcategoryID
 WHERE s.[Name] LIKE @Product AND p.ListPrice < @MaxPrice);

SET @ComparePrice = @MaxPrice; 

DECLARE @ComparePrice money, @Cost money
EXECUTE Production.uspGetList '%Bikes%', 700,
 @ComparePrice OUT,
 @Cost OUTPUT
IF @Cost <= @ComparePrice
BEGIN
 PRINT 'These products can be purchased for less than
 $'+RTRIM(CAST(@ComparePrice AS varchar(20)))+'.'
END
ELSE
 PRINT 'The prices for all products in this category exceed
 $'+ RTRIM(CAST(@ComparePrice AS varchar(20)))+'.' 