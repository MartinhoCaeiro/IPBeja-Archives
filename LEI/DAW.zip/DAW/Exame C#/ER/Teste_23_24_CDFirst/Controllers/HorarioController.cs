using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Models;

namespace Teste_23_24_CDFirst.Controllers
{
    public class HorarioController : Controller
    {
        private readonly AppDbContext _context;

        public HorarioController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Horario
        public async Task<IActionResult> Index()
        {
            var appDbContext = _context.Horarios.Include(h => h.AnoLetivo).Include(h => h.UC);
            return View(await appDbContext.ToListAsync());
        }


        [HttpGet]
        public async Task<IActionResult> FilterSchedule(int number)
        {
            var aluno = await _context.Alunos.FirstOrDefaultAsync(a => a.Numero == number);
            if (aluno == null)
            {
                return NotFound();
            }

            var horarios = await _context.Horarios
                .Include(h => h.UC)
                .Include(h => h.AnoLetivo)
                .Where(h => h.UC.AlunoUCs.Any(au => au.AlunoId == aluno.AlunoId))
                .ToListAsync();

            return View("Index", horarios);
        }

        // GET: Horario/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var horarioModel = await _context.Horarios
                .Include(h => h.AnoLetivo)
                .Include(h => h.UC)
                .FirstOrDefaultAsync(m => m.HorarioId == id);
            if (horarioModel == null)
            {
                return NotFound();
            }

            return View(horarioModel);
        }

        // GET: Horario/Create
        public IActionResult Create()
        {
            ViewData["AnoLetivoId"] = new SelectList(_context.AnoLetivos, "AnoId", "Denominacao");
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome");
            return View();
        }

        // POST: Horario/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("HorarioId,UcId,AnoLetivoId,SemestreLetivo,DiaSemana,HoraInicial,HoraFinal")] HorarioModel horarioModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(horarioModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AnoLetivoId"] = new SelectList(_context.AnoLetivos, "AnoId", "Denominacao", horarioModel.AnoLetivoId);
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome", horarioModel.UcId);
            return View(horarioModel);
        }

        // GET: Horario/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var horarioModel = await _context.Horarios.FindAsync(id);
            if (horarioModel == null)
            {
                return NotFound();
            }
            ViewData["AnoLetivoId"] = new SelectList(_context.AnoLetivos, "AnoId", "Denominacao", horarioModel.AnoLetivoId);
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome", horarioModel.UcId);
            return View(horarioModel);
        }

        // POST: Horario/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("HorarioId,UcId,AnoLetivoId,SemestreLetivo,DiaSemana,HoraInicial,HoraFinal")] HorarioModel horarioModel)
        {
            if (id != horarioModel.HorarioId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(horarioModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HorarioModelExists(horarioModel.HorarioId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AnoLetivoId"] = new SelectList(_context.AnoLetivos, "AnoId", "Denominacao", horarioModel.AnoLetivoId);
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome", horarioModel.UcId);
            return View(horarioModel);
        }

        // GET: Horario/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var horarioModel = await _context.Horarios
                .Include(h => h.AnoLetivo)
                .Include(h => h.UC)
                .FirstOrDefaultAsync(m => m.HorarioId == id);
            if (horarioModel == null)
            {
                return NotFound();
            }

            return View(horarioModel);
        }

        // POST: Horario/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var horarioModel = await _context.Horarios.FindAsync(id);
            if (horarioModel != null)
            {
                _context.Horarios.Remove(horarioModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HorarioModelExists(int id)
        {
            return _context.Horarios.Any(e => e.HorarioId == id);
        }
    }
}
