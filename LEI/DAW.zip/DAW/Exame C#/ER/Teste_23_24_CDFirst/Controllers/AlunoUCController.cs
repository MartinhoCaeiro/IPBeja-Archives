using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Models;

namespace Teste_23_24_CDFirst.Controllers
{
    public class AlunoUCController : Controller
    {
        private readonly AppDbContext _context;

        public AlunoUCController(AppDbContext context)
        {
            _context = context;
        }

        // GET: AlunoUC
        public async Task<IActionResult> Index()
        {
            var appDbContext = _context.AlunoUCs.Include(a => a.Aluno).Include(a => a.UC);
            return View(await appDbContext.ToListAsync());
        }

        // GET: AlunoUC/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alunoUCModel = await _context.AlunoUCs
                .Include(a => a.Aluno)
                .Include(a => a.UC)
                .FirstOrDefaultAsync(m => m.AlunoUcId == id);
            if (alunoUCModel == null)
            {
                return NotFound();
            }

            return View(alunoUCModel);
        }

        // GET: AlunoUC/Create
        public IActionResult Create()
        {
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "Nome");
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome");
            return View();
        }

        // POST: AlunoUC/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AlunoUcId,AlunoId,UcId")] AlunoUCModel alunoUCModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(alunoUCModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "Nome", alunoUCModel.AlunoId);
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome", alunoUCModel.UcId);
            return View(alunoUCModel);
        }

        // GET: AlunoUC/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alunoUCModel = await _context.AlunoUCs.FindAsync(id);
            if (alunoUCModel == null)
            {
                return NotFound();
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "Nome", alunoUCModel.AlunoId);
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome", alunoUCModel.UcId);
            return View(alunoUCModel);
        }

        // POST: AlunoUC/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AlunoUcId,AlunoId,UcId")] AlunoUCModel alunoUCModel)
        {
            if (id != alunoUCModel.AlunoUcId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(alunoUCModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AlunoUCModelExists(alunoUCModel.AlunoUcId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "Nome", alunoUCModel.AlunoId);
            ViewData["UcId"] = new SelectList(_context.UCs, "UcId", "Nome", alunoUCModel.UcId);
            return View(alunoUCModel);
        }

        // GET: AlunoUC/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alunoUCModel = await _context.AlunoUCs
                .Include(a => a.Aluno)
                .Include(a => a.UC)
                .FirstOrDefaultAsync(m => m.AlunoUcId == id);
            if (alunoUCModel == null)
            {
                return NotFound();
            }

            return View(alunoUCModel);
        }

        // POST: AlunoUC/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var alunoUCModel = await _context.AlunoUCs.FindAsync(id);
            if (alunoUCModel != null)
            {
                _context.AlunoUCs.Remove(alunoUCModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AlunoUCModelExists(int id)
        {
            return _context.AlunoUCs.Any(e => e.AlunoUcId == id);
        }
    }
}
