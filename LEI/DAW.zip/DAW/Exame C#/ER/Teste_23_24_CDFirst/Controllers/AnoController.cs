using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Models;

namespace Teste_23_24_CDFirst.Controllers
{
    public class AnoController : Controller
    {
        private readonly AppDbContext _context;

        public AnoController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Ano
        public async Task<IActionResult> Index()
        {
            return View(await _context.AnoLetivos.ToListAsync());
        }

        // GET: Ano/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anoModel = await _context.AnoLetivos
                .FirstOrDefaultAsync(m => m.AnoId == id);
            if (anoModel == null)
            {
                return NotFound();
            }

            return View(anoModel);
        }

        // GET: Ano/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Ano/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AnoId,Denominacao")] AnoModel anoModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(anoModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(anoModel);
        }

        // GET: Ano/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anoModel = await _context.AnoLetivos.FindAsync(id);
            if (anoModel == null)
            {
                return NotFound();
            }
            return View(anoModel);
        }

        // POST: Ano/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AnoId,Denominacao")] AnoModel anoModel)
        {
            if (id != anoModel.AnoId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(anoModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AnoModelExists(anoModel.AnoId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(anoModel);
        }

        // GET: Ano/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anoModel = await _context.AnoLetivos
                .FirstOrDefaultAsync(m => m.AnoId == id);
            if (anoModel == null)
            {
                return NotFound();
            }

            return View(anoModel);
        }

        // POST: Ano/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var anoModel = await _context.AnoLetivos.FindAsync(id);
            if (anoModel != null)
            {
                _context.AnoLetivos.Remove(anoModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AnoModelExists(int id)
        {
            return _context.AnoLetivos.Any(e => e.AnoId == id);
        }
    }
}
