using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class AlunoUCModel
    {
        [Key]
        public int AlunoUcId { get; set; }
        [ForeignKey("AlunoId")]
        [Display(Name = "Aluno")]
        public int AlunoId { get; set; }
        [ForeignKey("UcId")]
        [Display(Name = "UC")]
        public int UcId { get; set; }

        // Relação com Aluno
        public AlunoModel? Aluno { get; set; }

        // Relação com UC
        public UCModel? UC { get; set; }
    }
}