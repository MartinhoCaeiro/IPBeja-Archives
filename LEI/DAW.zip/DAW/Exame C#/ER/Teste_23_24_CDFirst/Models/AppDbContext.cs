using Microsoft.EntityFrameworkCore;

namespace Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<CursoModel>? Cursos { get; set; }
        public DbSet<UCModel>? UCs { get; set; }
        public DbSet<AlunoModel>? Alunos { get; set; }
        public DbSet<AlunoUCModel>? AlunoUCs { get; set; }
        public DbSet<AnoModel>? AnoLetivos { get; set; }
        public DbSet<HorarioModel>? Horarios { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AlunoUCModel>()
                .HasOne(a => a.Aluno)
                .WithMany(a => a.AlunoUCs)
                .HasForeignKey(a => a.AlunoId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<AlunoUCModel>()
                .HasOne(a => a.UC)
                .WithMany(u => u.AlunoUCs)
                .HasForeignKey(a => a.UcId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
