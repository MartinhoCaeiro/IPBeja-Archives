using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class HorarioModel
    {
        [Key]
        public int HorarioId { get; set; }
        [ForeignKey("UcId")]
        [Display(Name = "UC")]
        public int UcId { get; set; }
        [ForeignKey("AnoLetivoId")]
        [Display(Name = "Ano Letivo")]
        public int AnoLetivoId { get; set; }
        [Required]
        public int SemestreLetivo { get; set; }
        [Required]
        public string DiaSemana { get; set; }
        [Required]
        [Range(typeof(TimeSpan), "09:00:00", "19:00:00", ErrorMessage = "Hora Inicial deve estar entre 09:00:00 e 19:00:00.")]
        public TimeSpan HoraInicial { get; set; }
        [Required]
        [Range(typeof(TimeSpan), "09:00:00", "19:00:00", ErrorMessage = "Hora Final deve estar entre 09:00:00 e 19:00:00.")]
        public TimeSpan HoraFinal { get; set; }

        // Relação com UC
        public UCModel? UC { get; set; }

        // Relação com AnoLetivo
        public AnoModel? AnoLetivo { get; set; }
    }
}
