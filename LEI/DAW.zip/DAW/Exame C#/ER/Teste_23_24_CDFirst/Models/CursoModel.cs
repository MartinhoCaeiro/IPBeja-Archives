using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class CursoModel
{
    [Key]
    public int CursoId { get; set; }
    [Required]
    public string Nome { get; set; }

    // Relação com UC
    public ICollection<UCModel>? UCs { get; set; }
    public ICollection<AlunoModel>? Alunos { get; set; }
}

}