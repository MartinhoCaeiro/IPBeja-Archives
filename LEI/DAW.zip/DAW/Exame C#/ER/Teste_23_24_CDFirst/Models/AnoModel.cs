using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class AnoModel
    {
        [Key]
        public int AnoId { get; set; }
        [Required]
        public string Denominacao { get; set; }

        // Relação com Horário
        public ICollection<HorarioModel>? Horarios { get; set; }
    }
}

