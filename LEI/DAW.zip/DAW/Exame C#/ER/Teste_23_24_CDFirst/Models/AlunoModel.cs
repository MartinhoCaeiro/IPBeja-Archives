using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class AlunoModel
{
    [Key]
    public int AlunoId { get; set; }
    [Required]
    public int Numero { get; set; }
    [Required]
    public string Nome { get; set; }
    [ForeignKey("CursoId")]
    [Display(Name = "Curso")]
    public int CursoId { get; set; }

    // Relação com Curso
    public CursoModel? Curso { get; set; }

    // Relação com AlunoUC
    public ICollection<AlunoUCModel>? AlunoUCs { get; set; }
}

}