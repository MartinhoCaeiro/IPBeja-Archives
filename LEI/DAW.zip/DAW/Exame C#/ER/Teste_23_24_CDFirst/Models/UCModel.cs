using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class UCModel
{
    [Key]
    public int UcId { get; set; }
    [Required]
    public string Nome { get; set; }
    [ForeignKey("CursoId")]
    [Display(Name = "Curso")]
    public int CursoId { get; set; }
    [Required]
    public int SemestreCurricular { get; set; }

    // Relação com Curso
    public CursoModel? Curso { get; set; }

    // Relação com AlunoUC
    public ICollection<AlunoUCModel>? AlunoUCs { get; set; }

    // Relação com Horário
    public ICollection<HorarioModel>? Horarios { get; set; }
}

}