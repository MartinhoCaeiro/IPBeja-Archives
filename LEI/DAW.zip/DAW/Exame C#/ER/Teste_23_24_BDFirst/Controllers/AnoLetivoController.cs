using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Teste_23_24_BDFirst.Models;

namespace Teste_23_24_BDFirst.Controllers
{
    public class AnoLetivoController : Controller
    {
        private readonly ErbdfContext _context;

        public AnoLetivoController(ErbdfContext context)
        {
            _context = context;
        }

        // GET: AnoLetivo
        public async Task<IActionResult> Index()
        {
            return View(await _context.AnoLetivos.ToListAsync());
        }

        // GET: AnoLetivo/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anoLetivo = await _context.AnoLetivos
                .FirstOrDefaultAsync(m => m.AnoLetivoId == id);
            if (anoLetivo == null)
            {
                return NotFound();
            }

            return View(anoLetivo);
        }

        // GET: AnoLetivo/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AnoLetivo/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AnoLetivoId,Denominacao")] AnoLetivo anoLetivo)
        {
            if (ModelState.IsValid)
            {
                _context.Add(anoLetivo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(anoLetivo);
        }

        // GET: AnoLetivo/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anoLetivo = await _context.AnoLetivos.FindAsync(id);
            if (anoLetivo == null)
            {
                return NotFound();
            }
            return View(anoLetivo);
        }

        // POST: AnoLetivo/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AnoLetivoId,Denominacao")] AnoLetivo anoLetivo)
        {
            if (id != anoLetivo.AnoLetivoId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(anoLetivo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AnoLetivoExists(anoLetivo.AnoLetivoId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(anoLetivo);
        }

        // GET: AnoLetivo/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anoLetivo = await _context.AnoLetivos
                .FirstOrDefaultAsync(m => m.AnoLetivoId == id);
            if (anoLetivo == null)
            {
                return NotFound();
            }

            return View(anoLetivo);
        }

        // POST: AnoLetivo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var anoLetivo = await _context.AnoLetivos.FindAsync(id);
            if (anoLetivo != null)
            {
                _context.AnoLetivos.Remove(anoLetivo);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AnoLetivoExists(int id)
        {
            return _context.AnoLetivos.Any(e => e.AnoLetivoId == id);
        }
    }
}
