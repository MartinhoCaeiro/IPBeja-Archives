using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Teste_23_24_BDFirst.Models;

namespace Teste_23_24_BDFirst.Controllers
{
    public class AlunoUcController : Controller
    {
        private readonly ErbdfContext _context;

        public AlunoUcController(ErbdfContext context)
        {
            _context = context;
        }

        // GET: AlunoUc
        public async Task<IActionResult> Index()
        {
            var erbdfContext = _context.AlunoUcs.Include(a => a.Aluno).Include(a => a.Uc);
            return View(await erbdfContext.ToListAsync());
        }

        // GET: AlunoUc/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alunoUc = await _context.AlunoUcs
                .Include(a => a.Aluno)
                .Include(a => a.Uc)
                .FirstOrDefaultAsync(m => m.AlunoUcId == id);
            if (alunoUc == null)
            {
                return NotFound();
            }

            return View(alunoUc);
        }

        // GET: AlunoUc/Create
        public IActionResult Create()
        {
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "AlunoId");
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "UcId");
            return View();
        }

        // POST: AlunoUc/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AlunoUcId,AlunoId,UcId")] AlunoUc alunoUc)
        {
            if (ModelState.IsValid)
            {
                _context.Add(alunoUc);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "AlunoId", alunoUc.AlunoId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "UcId", alunoUc.UcId);
            return View(alunoUc);
        }

        // GET: AlunoUc/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alunoUc = await _context.AlunoUcs.FindAsync(id);
            if (alunoUc == null)
            {
                return NotFound();
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "AlunoId", alunoUc.AlunoId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "UcId", alunoUc.UcId);
            return View(alunoUc);
        }

        // POST: AlunoUc/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AlunoUcId,AlunoId,UcId")] AlunoUc alunoUc)
        {
            if (id != alunoUc.AlunoUcId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(alunoUc);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AlunoUcExists(alunoUc.AlunoUcId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AlunoId"] = new SelectList(_context.Alunos, "AlunoId", "AlunoId", alunoUc.AlunoId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "UcId", alunoUc.UcId);
            return View(alunoUc);
        }

        // GET: AlunoUc/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alunoUc = await _context.AlunoUcs
                .Include(a => a.Aluno)
                .Include(a => a.Uc)
                .FirstOrDefaultAsync(m => m.AlunoUcId == id);
            if (alunoUc == null)
            {
                return NotFound();
            }

            return View(alunoUc);
        }

        // POST: AlunoUc/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var alunoUc = await _context.AlunoUcs.FindAsync(id);
            if (alunoUc != null)
            {
                _context.AlunoUcs.Remove(alunoUc);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AlunoUcExists(int id)
        {
            return _context.AlunoUcs.Any(e => e.AlunoUcId == id);
        }
    }
}
