﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Teste_23_24_BDFirst.Models;

public partial class ErbdfContext : DbContext
{
    public ErbdfContext()
    {
    }

    public ErbdfContext(DbContextOptions<ErbdfContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Aluno> Alunos { get; set; }

    public virtual DbSet<AlunoUc> AlunoUcs { get; set; }

    public virtual DbSet<AnoLetivo> AnoLetivos { get; set; }

    public virtual DbSet<Curso> Cursos { get; set; }

    public virtual DbSet<Horario> Horarios { get; set; }

    public virtual DbSet<Uc> Ucs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=ERBDF;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Aluno>(entity =>
        {
            entity.HasKey(e => e.AlunoId).HasName("PK__aluno__1ADCAB698F68EB78");

            entity.ToTable("aluno");

            entity.HasIndex(e => e.Numero, "UQ__aluno__FC77F211994D13D3").IsUnique();

            entity.Property(e => e.AlunoId).HasColumnName("aluno_id");
            entity.Property(e => e.CursoId).HasColumnName("curso_id");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .HasColumnName("nome");
            entity.Property(e => e.Numero).HasColumnName("numero");

            entity.HasOne(d => d.Curso).WithMany(p => p.Alunos)
                .HasForeignKey(d => d.CursoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__aluno__curso_id__4F7CD00D");
        });

        modelBuilder.Entity<AlunoUc>(entity =>
        {
            entity.HasKey(e => e.AlunoUcId).HasName("PK__aluno_uc__02B8255BE537F7CE");

            entity.ToTable("aluno_uc");

            entity.Property(e => e.AlunoUcId).HasColumnName("aluno_uc_id");
            entity.Property(e => e.AlunoId).HasColumnName("aluno_id");
            entity.Property(e => e.UcId).HasColumnName("uc_id");

            entity.HasOne(d => d.Aluno).WithMany(p => p.AlunoUcs)
                .HasForeignKey(d => d.AlunoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__aluno_uc__aluno___52593CB8");

            entity.HasOne(d => d.Uc).WithMany(p => p.AlunoUcs)
                .HasForeignKey(d => d.UcId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__aluno_uc__uc_id__534D60F1");
        });

        modelBuilder.Entity<AnoLetivo>(entity =>
        {
            entity.HasKey(e => e.AnoLetivoId).HasName("PK__ano_leti__6A5F645A81F6F5CD");

            entity.ToTable("ano_letivo");

            entity.Property(e => e.AnoLetivoId).HasColumnName("ano_letivo_id");
            entity.Property(e => e.Denominacao)
                .HasMaxLength(50)
                .HasColumnName("denominacao");
        });

        modelBuilder.Entity<Curso>(entity =>
        {
            entity.HasKey(e => e.CursoId).HasName("PK__curso__5D7B3D20135BC333");

            entity.ToTable("curso");

            entity.Property(e => e.CursoId).HasColumnName("curso_id");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .HasColumnName("nome");
        });

        modelBuilder.Entity<Horario>(entity =>
        {
            entity.HasKey(e => e.HorarioId).HasName("PK__horario__5A3872284E5EE5B7");

            entity.ToTable("horario");

            entity.Property(e => e.HorarioId).HasColumnName("horario_id");
            entity.Property(e => e.AnoLetivoId).HasColumnName("ano_letivo_id");
            entity.Property(e => e.DiaSemana).HasColumnName("dia_semana");
            entity.Property(e => e.HoraFinal).HasColumnName("hora_final");
            entity.Property(e => e.HoraInicial).HasColumnName("hora_inicial");
            entity.Property(e => e.SemestreLetivo).HasColumnName("semestre_letivo");
            entity.Property(e => e.UcId).HasColumnName("uc_id");

            entity.HasOne(d => d.AnoLetivo).WithMany(p => p.Horarios)
                .HasForeignKey(d => d.AnoLetivoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__horario__ano_let__59FA5E80");

            entity.HasOne(d => d.Uc).WithMany(p => p.Horarios)
                .HasForeignKey(d => d.UcId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__horario__uc_id__59063A47");
        });

        modelBuilder.Entity<Uc>(entity =>
        {
            entity.HasKey(e => e.UcId).HasName("PK__uc__9A452880C48845E2");

            entity.ToTable("uc");

            entity.Property(e => e.UcId).HasColumnName("uc_id");
            entity.Property(e => e.CursoId).HasColumnName("curso_id");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .HasColumnName("nome");
            entity.Property(e => e.SemestreCurricular).HasColumnName("semestre_curricular");

            entity.HasOne(d => d.Curso).WithMany(p => p.Ucs)
                .HasForeignKey(d => d.CursoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__uc__curso_id__4BAC3F29");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
