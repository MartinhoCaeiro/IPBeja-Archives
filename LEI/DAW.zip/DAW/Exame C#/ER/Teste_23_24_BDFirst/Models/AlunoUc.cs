﻿using System;
using System.Collections.Generic;

namespace Teste_23_24_BDFirst.Models;

public partial class AlunoUc
{
    public int AlunoUcId { get; set; }

    public int AlunoId { get; set; }

    public int UcId { get; set; }

    public virtual Aluno? Aluno { get; set; }

    public virtual Uc? Uc { get; set; }
}
