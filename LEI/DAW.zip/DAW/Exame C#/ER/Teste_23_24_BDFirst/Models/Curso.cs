﻿using System;
using System.Collections.Generic;

namespace Teste_23_24_BDFirst.Models;

public partial class Curso
{
    public int CursoId { get; set; }

    public string? Nome { get; set; }

    public virtual ICollection<Aluno>? Alunos { get; set; }

    public virtual ICollection<Uc>? Ucs { get; set; }
}
