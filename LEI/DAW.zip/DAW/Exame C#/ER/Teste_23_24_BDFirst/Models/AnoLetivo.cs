﻿using System;
using System.Collections.Generic;

namespace Teste_23_24_BDFirst.Models;

public partial class AnoLetivo
{
    public int AnoLetivoId { get; set; }

    public string? Denominacao { get; set; }

    public virtual ICollection<Horario>? Horarios { get; set; }
}
