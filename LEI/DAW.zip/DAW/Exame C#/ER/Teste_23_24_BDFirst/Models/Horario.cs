﻿using System;
using System.Collections.Generic;

namespace Teste_23_24_BDFirst.Models;

public partial class Horario
{
    public int HorarioId { get; set; }

    public int UcId { get; set; }

    public int AnoLetivoId { get; set; }

    public byte SemestreLetivo { get; set; }

    public byte DiaSemana { get; set; }

    public TimeOnly HoraInicial { get; set; }

    public TimeOnly HoraFinal { get; set; }

    public virtual AnoLetivo? AnoLetivo { get; set; }

    public virtual Uc? Uc { get; set; }
}
