﻿using System;
using System.Collections.Generic;

namespace Teste_23_24_BDFirst.Models;

public partial class Aluno
{
    public int AlunoId { get; set; }

    public int Numero { get; set; }

    public string? Nome { get; set; }

    public int CursoId { get; set; }

    public virtual ICollection<AlunoUc>? AlunoUcs { get; set; }

    public virtual Curso? Curso { get; set; }
}
