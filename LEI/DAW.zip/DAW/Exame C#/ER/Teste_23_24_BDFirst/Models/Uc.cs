﻿using System;
using System.Collections.Generic;

namespace Teste_23_24_BDFirst.Models;

public partial class Uc
{
    public int UcId { get; set; }

    public string? Nome { get; set; }

    public int CursoId { get; set; }

    public byte SemestreCurricular { get; set; }

    public virtual ICollection<AlunoUc>? AlunoUcs { get; set; }

    public virtual Curso? Curso { get; set; }

    public virtual ICollection<Horario>? Horarios { get; set; }
}
