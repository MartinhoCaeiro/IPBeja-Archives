/*CRIAR BASE DE DADOS NO LOCAL CORRETO*/
/*CREATE DATABASE ERBDF
ON PRIMARY (
NAME = 'ERBDF',
FILENAME = 'C:\Users\Marti\Documents\Exame C#\ER\Teste_23_24_BDFirst\App_Data\ERBDF.mdf'
)
LOG ON (
	NAME = 'ERBDFLOG',
	FILENAME = 'C:\Users\Marti\Documents\Exame C#\ER\Teste_23_24_BDFirst\App_Data\ERBDFLOG.ldf'
)

GO*/

USE ERBDF

-- Tabela: curso
CREATE TABLE curso (
    curso_id INT PRIMARY KEY IDENTITY(1,1),
    nome NVARCHAR(100) NOT NULL
);

-- Tabela: uc
CREATE TABLE uc (
    uc_id INT PRIMARY KEY IDENTITY(1,1),
    nome NVARCHAR(100) NOT NULL,
    curso_id INT NOT NULL,
    semestre_curricular TINYINT NOT NULL,
    FOREIGN KEY (curso_id) REFERENCES curso(curso_id)
);

-- Tabela: aluno
CREATE TABLE aluno (
    aluno_id INT PRIMARY KEY IDENTITY(1,1),
    numero INT NOT NULL UNIQUE,
    nome NVARCHAR(100) NOT NULL,
    curso_id INT NOT NULL,
    FOREIGN KEY (curso_id) REFERENCES curso(curso_id)
);

-- Tabela: aluno_uc
CREATE TABLE aluno_uc (
    aluno_uc_id INT PRIMARY KEY IDENTITY(1,1),
    aluno_id INT NOT NULL,
    uc_id INT NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES aluno(aluno_id),
    FOREIGN KEY (uc_id) REFERENCES uc(uc_id)
);

-- Tabela: ano_letivo
CREATE TABLE ano_letivo (
    ano_letivo_id INT PRIMARY KEY IDENTITY(1,1),
    denominacao NVARCHAR(50) NOT NULL
);

-- Tabela: horario
CREATE TABLE horario (
    horario_id INT PRIMARY KEY IDENTITY(1,1),
    uc_id INT NOT NULL,
    ano_letivo_id INT NOT NULL,
    semestre_letivo TINYINT NOT NULL,
    dia_semana TINYINT NOT NULL CHECK (dia_semana BETWEEN 2 AND 6),
    hora_inicial TIME NOT NULL,
    hora_final TIME NOT NULL,
    FOREIGN KEY (uc_id) REFERENCES uc(uc_id),
    FOREIGN KEY (ano_letivo_id) REFERENCES ano_letivo(ano_letivo_id)
);
GO
