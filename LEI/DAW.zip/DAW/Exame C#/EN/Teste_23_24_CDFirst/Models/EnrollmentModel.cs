using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class EnrollmentModel
    {
        [Key]
        public int EnrollmentId { get; set; }

        [ForeignKey("StudentId")]
        [Display(Name = "Student")]
        public int StudentId { get; set; }

        public StudentModel? Student { get; set; }

        [ForeignKey("UcId")]
        [Display(Name = "UC")]
        public int UcId { get; set; }

        public UCModel? Uc { get; set; }
    }
}