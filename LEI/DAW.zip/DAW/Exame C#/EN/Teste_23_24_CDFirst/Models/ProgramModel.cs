using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class ProgramModel
    {
        [Key]
        public int ProgramId { get; set; } 

        [Required]
        public string Name { get; set; }

        public ICollection<UCModel>? Ucs { get; set; }
    }
}