using Microsoft.EntityFrameworkCore;

namespace Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<UCModel>? Ucs { get; set; }
        public DbSet<StudentModel>? Students { get; set; }
        public DbSet<EnrollmentModel>? Enrollments { get; set; }
        public DbSet<ProgramModel>? Programs { get; set; }
    }
}
