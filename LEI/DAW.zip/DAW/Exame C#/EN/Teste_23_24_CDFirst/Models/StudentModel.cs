using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class StudentModel
    {
        [Key]
        public int StudentId { get; set; }

        [Required]
        public string Number { get; set; }

        [Required]
        public string Name { get; set; }

        public ICollection<EnrollmentModel>? Enrollments { get; set; }
    }
}