using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class UCModel
    {
        [Key]
        public int UcId { get; set; }

        [Required]
        public string Name { get; set; }

        [ForeignKey("ProgramId")]
        [Display(Name = "Program")]
        public int ProgramId { get; set; }

        public ProgramModel? Program { get; set; }

        public ICollection<EnrollmentModel>? Enrollments { get; set; }
    }
}