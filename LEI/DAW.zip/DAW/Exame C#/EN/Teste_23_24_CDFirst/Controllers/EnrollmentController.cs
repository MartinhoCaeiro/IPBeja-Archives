using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Models;

namespace Teste_23_24_CDFirst.Controllers
{
    public class EnrollmentController : Controller
    {
        private readonly AppDbContext _context;

        public EnrollmentController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Enrollment
        public async Task<IActionResult> Index()
        {
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name");
            var appDbContext = _context.Enrollments.Include(e => e.Student).Include(e => e.Uc);
            return View(await appDbContext.ToListAsync());
        }

        // GET: Enrollment/FilterByUC
        public async Task<IActionResult> FilterByUC(int? UcId)
        {
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name");

            if (UcId == null)
            {
                return View("Index", await _context.Enrollments.Include(e => e.Student).Include(e => e.Uc).ToListAsync());
            }

            var filteredEnrollments = await _context.Enrollments
                .Include(e => e.Student)
                .Include(e => e.Uc)
                .Where(e => e.UcId == UcId)
                .ToListAsync();

            return View("Index", filteredEnrollments);
        }

        // GET: Enrollment/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollmentModel = await _context.Enrollments
                .Include(e => e.Student)
                .Include(e => e.Uc)
                .FirstOrDefaultAsync(m => m.EnrollmentId == id);
            if (enrollmentModel == null)
            {
                return NotFound();
            }

            return View(enrollmentModel);
        }

        // GET: Enrollment/Create
        public IActionResult Create()
        {
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name");
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name");
            return View();
        }

        // POST: Enrollment/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EnrollmentId,StudentId,UcId")] EnrollmentModel enrollmentModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(enrollmentModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name", enrollmentModel.StudentId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name", enrollmentModel.UcId);
            return View(enrollmentModel);
        }

        // GET: Enrollment/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollmentModel = await _context.Enrollments.FindAsync(id);
            if (enrollmentModel == null)
            {
                return NotFound();
            }
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name", enrollmentModel.StudentId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name", enrollmentModel.UcId);
            return View(enrollmentModel);
        }

        // POST: Enrollment/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EnrollmentId,StudentId,UcId")] EnrollmentModel enrollmentModel)
        {
            if (id != enrollmentModel.EnrollmentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(enrollmentModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EnrollmentModelExists(enrollmentModel.EnrollmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name", enrollmentModel.StudentId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name", enrollmentModel.UcId);
            return View(enrollmentModel);
        }

        // GET: Enrollment/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollmentModel = await _context.Enrollments
                .Include(e => e.Student)
                .Include(e => e.Uc)
                .FirstOrDefaultAsync(m => m.EnrollmentId == id);
            if (enrollmentModel == null)
            {
                return NotFound();
            }

            return View(enrollmentModel);
        }

        // POST: Enrollment/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var enrollmentModel = await _context.Enrollments.FindAsync(id);
            if (enrollmentModel != null)
            {
                _context.Enrollments.Remove(enrollmentModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EnrollmentModelExists(int id)
        {
            return _context.Enrollments.Any(e => e.EnrollmentId == id);
        }
    }
}
