using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Models;

namespace Teste_23_24_CDFirst.Controllers
{
    public class UCController : Controller
    {
        private readonly AppDbContext _context;

        public UCController(AppDbContext context)
        {
            _context = context;
        }

        // GET: UC
        public async Task<IActionResult> Index()
        {
            var appDbContext = _context.Ucs.Include(u => u.Program);
            return View(await appDbContext.ToListAsync());
        }

        // GET: UC/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uCModel = await _context.Ucs
                .Include(u => u.Program)
                .FirstOrDefaultAsync(m => m.UcId == id);
            if (uCModel == null)
            {
                return NotFound();
            }

            return View(uCModel);
        }

        // GET: UC/Create
        public IActionResult Create()
        {
            ViewData["ProgramId"] = new SelectList(_context.Programs, "ProgramId", "Name");
            return View();
        }

        // POST: UC/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UcId,Name,ProgramId")] UCModel uCModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(uCModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProgramId"] = new SelectList(_context.Programs, "ProgramId", "Name", uCModel.ProgramId);
            return View(uCModel);
        }

        // GET: UC/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uCModel = await _context.Ucs.FindAsync(id);
            if (uCModel == null)
            {
                return NotFound();
            }
            ViewData["ProgramId"] = new SelectList(_context.Programs, "ProgramId", "Name", uCModel.ProgramId);
            return View(uCModel);
        }

        // POST: UC/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UcId,Name,ProgramId")] UCModel uCModel)
        {
            if (id != uCModel.UcId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(uCModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UCModelExists(uCModel.UcId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProgramId"] = new SelectList(_context.Programs, "ProgramId", "Name", uCModel.ProgramId);
            return View(uCModel);
        }

        // GET: UC/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uCModel = await _context.Ucs
                .Include(u => u.Program)
                .FirstOrDefaultAsync(m => m.UcId == id);
            if (uCModel == null)
            {
                return NotFound();
            }

            return View(uCModel);
        }

        // POST: UC/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var uCModel = await _context.Ucs.FindAsync(id);
            if (uCModel != null)
            {
                _context.Ucs.Remove(uCModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UCModelExists(int id)
        {
            return _context.Ucs.Any(e => e.UcId == id);
        }
    }
}
