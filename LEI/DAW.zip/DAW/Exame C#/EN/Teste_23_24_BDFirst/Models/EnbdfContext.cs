﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Teste_23_24_BDFirst.Models;

public partial class EnbdfContext : DbContext
{
    public EnbdfContext()
    {
    }

    public EnbdfContext(DbContextOptions<EnbdfContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Enrollment> Enrollments { get; set; }

    public virtual DbSet<Programs> Programs { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<Uc> Ucs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=ENBDF;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Enrollment>(entity =>
        {
            entity.HasKey(e => e.EntrollmentId).HasName("PK__enrollme__12BE6DED71BC3895");

            entity.ToTable("enrollment");

            entity.Property(e => e.EntrollmentId).HasColumnName("entrollment_id");
            entity.Property(e => e.StudentId).HasColumnName("student_id");
            entity.Property(e => e.UcId).HasColumnName("uc_id");

            entity.HasOne(d => d.Student).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.StudentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__enrollmen__stude__5165187F");

            entity.HasOne(d => d.Uc).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.UcId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__enrollmen__uc_id__52593CB8");
        });

        modelBuilder.Entity<Programs>(entity =>
        {
            entity.HasKey(e => e.ProgramId).HasName("PK__programs__3A7890ACCA421EF5");

            entity.ToTable("programs");

            entity.Property(e => e.ProgramId).HasColumnName("program_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("PK__student__2A33069A5FBDCE9A");

            entity.ToTable("student");

            entity.HasIndex(e => e.Number, "UQ__student__FD291E41E78321E5").IsUnique();

            entity.Property(e => e.StudentId).HasColumnName("student_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.Number).HasColumnName("number");
        });

        modelBuilder.Entity<Uc>(entity =>
        {
            entity.HasKey(e => e.UcId).HasName("PK__uc__9A4528804212A654");

            entity.ToTable("uc");

            entity.Property(e => e.UcId).HasColumnName("uc_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.ProgramId).HasColumnName("program_id");

            entity.HasOne(d => d.Program).WithMany(p => p.Ucs)
                .HasForeignKey(d => d.ProgramId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__uc__program_id__4BAC3F29");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
