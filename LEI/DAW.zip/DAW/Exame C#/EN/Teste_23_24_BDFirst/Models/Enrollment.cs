﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Teste_23_24_BDFirst.Models;

public partial class Enrollment
{
    [Key]
    public int EntrollmentId { get; set; }

    [ForeignKey("StudentId")]
    [Display(Name = "Student")]
    public int StudentId { get; set; }

    [ForeignKey("Uc")]
    [Display(Name = "UC")]
    public int UcId { get; set; }

    public virtual Student? Student { get; set; }

    public virtual Uc? Uc { get; set; }
}
