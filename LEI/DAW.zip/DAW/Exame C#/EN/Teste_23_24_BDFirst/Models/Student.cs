﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Teste_23_24_BDFirst.Models;

public partial class Student
{
    [Key]
    public int StudentId { get; set; }

    [Required]
    public int Number { get; set; }

    [Required]
    public string Name { get; set; }

    public virtual ICollection<Enrollment>? Enrollments { get; set; }
}
