﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Teste_23_24_BDFirst.Models;

public partial class Programs
{
    [Key]
    public int ProgramId { get; set; }

    [Required]
    public string Name { get; set; }

    public virtual ICollection<Uc>? Ucs { get; set; } = new List<Uc>();
}
