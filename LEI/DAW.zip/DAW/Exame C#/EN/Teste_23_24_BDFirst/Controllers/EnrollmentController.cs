using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Teste_23_24_BDFirst.Models;

namespace Teste_23_24_BDFirst.Controllers
{
    public class EnrollmentController : Controller
    {
        private readonly EnbdfContext _context;

        public EnrollmentController(EnbdfContext context)
        {
            _context = context;
        }

        // GET: Enrollment
        public async Task<IActionResult> Index()
        {
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name");
            var enbdfContext = _context.Enrollments.Include(e => e.Student).Include(e => e.Uc);
            return View(await enbdfContext.ToListAsync());
        }

        // GET: Enrollment/FilterByUC
        public async Task<IActionResult> FilterByUC(int? UcId)
        {
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name");

            if (UcId == null)
            {
                return View("Index", await _context.Enrollments.Include(e => e.Student).Include(e => e.Uc).ToListAsync());
            }

            var filteredEnrollments = await _context.Enrollments
                .Include(e => e.Student)
                .Include(e => e.Uc)
                .Where(e => e.UcId == UcId)
                .ToListAsync();

            return View("Index", filteredEnrollments);
        }

        // GET: Enrollment/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollment = await _context.Enrollments
                .Include(e => e.Student)
                .Include(e => e.Uc)
                .FirstOrDefaultAsync(m => m.EntrollmentId == id);
            if (enrollment == null)
            {
                return NotFound();
            }

            return View(enrollment);
        }

        // GET: Enrollment/Create
        public IActionResult Create()
        {
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name");
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name");
            return View();
        }

        // POST: Enrollment/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EntrollmentId,StudentId,UcId")] Enrollment enrollment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(enrollment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name", enrollment.StudentId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name", enrollment.UcId);
            return View(enrollment);
        }

        // GET: Enrollment/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollment = await _context.Enrollments.FindAsync(id);
            if (enrollment == null)
            {
                return NotFound();
            }
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name", enrollment.StudentId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name", enrollment.UcId);
            return View(enrollment);
        }

        // POST: Enrollment/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EntrollmentId,StudentId,UcId")] Enrollment enrollment)
        {
            if (id != enrollment.EntrollmentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(enrollment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EnrollmentExists(enrollment.EntrollmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["StudentId"] = new SelectList(_context.Students, "StudentId", "Name", enrollment.StudentId);
            ViewData["UcId"] = new SelectList(_context.Ucs, "UcId", "Name", enrollment.UcId);
            return View(enrollment);
        }

        // GET: Enrollment/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollment = await _context.Enrollments
                .Include(e => e.Student)
                .Include(e => e.Uc)
                .FirstOrDefaultAsync(m => m.EntrollmentId == id);
            if (enrollment == null)
            {
                return NotFound();
            }

            return View(enrollment);
        }

        // POST: Enrollment/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var enrollment = await _context.Enrollments.FindAsync(id);
            if (enrollment != null)
            {
                _context.Enrollments.Remove(enrollment);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EnrollmentExists(int id)
        {
            return _context.Enrollments.Any(e => e.EntrollmentId == id);
        }
    }
}
