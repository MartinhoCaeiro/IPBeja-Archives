/*CRIAR BASE DE DADOS NO LOCAL CORRETO*/
/*CREATE DATABASE ENBDF
ON PRIMARY (
NAME = 'ENBDF',
FILENAME = 'C:\Users\Marti\Documents\Exame C#\EN\Teste_23_24_BDFirst\App_Data\ENBDF.mdf'
)
LOG ON (
	NAME = 'ENBDFLOG',
	FILENAME = 'C:\Users\Marti\Documents\Exame C#\EN\Teste_23_24_BDFirst\App_Data\ENBDFLOG.ldf'
)

GO*/

USE ENBDF

CREATE TABLE programs (
    program_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL
);

CREATE TABLE uc(
	uc_id INT PRIMARY KEY IDENTITY(1,1),
	name NVARCHAR(100) NOT NULL,
	program_id INT NOT NULL,
	FOREIGN KEY (program_id) REFERENCES programs(program_id)
);

CREATE TABLE student (
    student_id INT PRIMARY KEY IDENTITY(1,1),
    number INT NOT NULL UNIQUE,
    name NVARCHAR(100) NOT NULL
);

CREATE TABLE enrollment(
	entrollment_id INT PRIMARY KEY IDENTITY(1,1),
	student_id INT NOT NULL,
	uc_id INT NOT NULL,
	FOREIGN KEY (student_id) REFERENCES student(student_id),
	FOREIGN KEY (uc_id) REFERENCES uc(uc_id)
);
GO