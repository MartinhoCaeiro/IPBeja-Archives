using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using daw_en_2425.Models;

namespace daw_en_2425.Controllers
{
    public class AcademicYearController : Controller
    {
        private readonly Bd23917Context _context;

        public AcademicYearController(Bd23917Context context)
        {
            _context = context;
        }

        // GET: AcademicYear
        public async Task<IActionResult> Index()
        {
            return View(await _context.Academicyears.ToListAsync());
        }

        // GET: AcademicYear/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var academicyear = await _context.Academicyears
                .FirstOrDefaultAsync(m => m.YearId == id);
            if (academicyear == null)
            {
                return NotFound();
            }

            return View(academicyear);
        }

        // GET: AcademicYear/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AcademicYear/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("YearId,Name,Activeyear")] Academicyear academicyear)
        {
            if (ModelState.IsValid)
            {
                _context.Add(academicyear);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(academicyear);
        }

        // GET: AcademicYear/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var academicyear = await _context.Academicyears.FindAsync(id);
            if (academicyear == null)
            {
                return NotFound();
            }
            return View(academicyear);
        }

        // POST: AcademicYear/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("YearId,Name,Activeyear")] Academicyear academicyear)
        {
            if (id != academicyear.YearId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(academicyear);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AcademicyearExists(academicyear.YearId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(academicyear);
        }

        // GET: AcademicYear/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var academicyear = await _context.Academicyears
                .FirstOrDefaultAsync(m => m.YearId == id);
            if (academicyear == null)
            {
                return NotFound();
            }

            return View(academicyear);
        }

        // POST: AcademicYear/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var academicyear = await _context.Academicyears.FindAsync(id);
            if (academicyear != null)
            {
                _context.Academicyears.Remove(academicyear);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AcademicyearExists(int id)
        {
            return _context.Academicyears.Any(e => e.YearId == id);
        }
    }
}
