Martinho Caeiro (23917) - 23917@stu.ipbeja.pt

Versão VSCode: 1.96.2
Versão Dotnet: 9.0.101
Versão EntityFrameworkCore: 9.0.0
Versão SqlServer: 16.0.1135.2
(CAMINHO ABSOLUTO UTILIZADO)
---------------------------------------------------

Funcional: Está funcional mas o filtro não tem em consideração o ano letivo e o create da grade não está a usar o UC e Student

-------------------------------------------------------

Comandos/Passos realizados:

Criar Projeto-
dotnet new mvc -n daw_en_2425
dotnet add package Microsoft.EntityFrameworkCore
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools
dotnet add package Microsoft.VisualStudio.Web.CodeGeneration.Design

1-
Criar a BD em SqlServer 

2-
dotnet ef dbcontext scaffold "Server=(localdb)\MSSQLLocalDB;Database=BD23917;Trusted_Connection=True;" Microsoft.EntityFrameworkCore.SqlServer -o Models
Atualizar os ficheiros Program e appsettings (CAMINHO ABSOLUTO UTILIZADO)

3-
dotnet aspnet-codegenerator controller -name UcController -m Uc -dc Bd23917Context -outDir Controllers --useDefaultLayout
dotnet aspnet-codegenerator controller -name StudentController -m Student -dc Bd23917Context -outDir Controllers --useDefaultLayout
dotnet aspnet-codegenerator controller -name AcademicYearController -m Academicyear -dc Bd23917Context -outDir Controllers --useDefaultLayout
dotnet aspnet-codegenerator controller -name EnrollmentController -m Enrollment -dc Bd23917Context -outDir Controllers --useDefaultLayout
dotnet aspnet-codegenerator controller -name GradeController -m Grade -dc Bd23917Context -outDir Controllers --useDefaultLayout

4-
Editar no ficheiro Layout

5-
Edição de Controllers e das Views Index

Servir Projeto-
dotnet run