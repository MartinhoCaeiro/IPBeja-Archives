﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace daw_en_2425.Models;

public partial class Bd23917Context : DbContext
{
    public Bd23917Context()
    {
    }

    public Bd23917Context(DbContextOptions<Bd23917Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Academicyear> Academicyears { get; set; }

    public virtual DbSet<Enrollment> Enrollments { get; set; }

    public virtual DbSet<Grade> Grades { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<Uc> Ucs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=BD23917;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Academicyear>(entity =>
        {
            entity.HasKey(e => e.YearId).HasName("PK__academic__B2A06B62F5253865");

            entity.ToTable("academicyear");

            entity.Property(e => e.YearId).HasColumnName("year_id");
            entity.Property(e => e.Activeyear).HasColumnName("activeyear");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Enrollment>(entity =>
        {
            entity.HasKey(e => e.EnrollmentId).HasName("PK__enrollme__6D24AA7AA51E2696");

            entity.ToTable("enrollment");

            entity.Property(e => e.EnrollmentId).HasColumnName("enrollment_id");
            entity.Property(e => e.StudentId).HasColumnName("student_id");
            entity.Property(e => e.UcId).HasColumnName("uc_id");
            entity.Property(e => e.YearId).HasColumnName("year_id");

            entity.HasOne(d => d.Student).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.StudentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__enrollmen__stude__5070F446");

            entity.HasOne(d => d.Uc).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.UcId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__enrollmen__uc_id__5165187F");

            entity.HasOne(d => d.Year).WithMany(p => p.Enrollments)
                .HasForeignKey(d => d.YearId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__enrollmen__year___52593CB8");
        });

        modelBuilder.Entity<Grade>(entity =>
        {
            entity.HasKey(e => e.GradeId).HasName("PK__grade__3A8F732C27C12F91");

            entity.ToTable("grade");

            entity.Property(e => e.GradeId).HasColumnName("grade_id");
            entity.Property(e => e.EnrollmentId).HasColumnName("enrollment_id");
            entity.Property(e => e.GradeQuali)
                .HasMaxLength(100)
                .HasColumnName("grade_quali");
            entity.Property(e => e.GradeValue).HasColumnName("grade_value");

            entity.HasOne(d => d.Enrollment).WithMany(p => p.Grades)
                .HasForeignKey(d => d.EnrollmentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__grade__enrollmen__5535A963");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("PK__student__2A33069AE78504DD");

            entity.ToTable("student");

            entity.HasIndex(e => e.Number, "UQ__student__FD291E41B81B11E8").IsUnique();

            entity.Property(e => e.StudentId).HasColumnName("student_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.Number).HasColumnName("number");
        });

        modelBuilder.Entity<Uc>(entity =>
        {
            entity.HasKey(e => e.UcId).HasName("PK__uc__9A452880BEF1DEAF");

            entity.ToTable("uc");

            entity.Property(e => e.UcId).HasColumnName("uc_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
