﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace daw_en_2425.Models;

public partial class Grade
{
    [Key]
    public int GradeId { get; set; }

    [ForeignKey("EnrollmentId")]
    [Display(Name = "Enrollment")]
    public int EnrollmentId { get; set; }

    [Required]
    [Display(Name = "Quantitative")]
    public int GradeValue { get; set; }

    [Required]
    [Display(Name = "Qualitative")]
    public string GradeQuali { get; set; }

    public virtual Enrollment? Enrollment { get; set; }
}
