﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace daw_en_2425.Models;

public partial class Enrollment
{
    [Key]
    public int EnrollmentId { get; set; }

    [ForeignKey("StudentId")]
    [Display(Name = "Student")]
    public int StudentId { get; set; }

    [ForeignKey("UcId")]
    [Display(Name = "UC")]
    public int UcId { get; set; }

    [ForeignKey("YearId")]
    [Display(Name = "Year")]
    public int YearId { get; set; }

    public virtual ICollection<Grade>? Grades { get; set; }

    public virtual Student? Student { get; set; }

    public virtual Uc? Uc { get; set; }

    public virtual Academicyear? Year { get; set; }
}
