﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace daw_en_2425.Models;

public partial class Academicyear
{
    [Key]
    public int YearId { get; set; }

    [Required]
    [Display (Name = "Year")]
    public string Name { get; set; }

    [Required]
    [Display (Name = "Current Year")]
    [Range( 0, 1, ErrorMessage = "Can only be yes(1) or no(0).")]
    public int Activeyear { get; set; }

    public virtual ICollection<Enrollment>? Enrollments { get; set; }
}
