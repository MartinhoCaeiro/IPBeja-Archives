/*CRIAR BASE DE DADOS (CAMINHO ABSOLUTO UTILIZADO)*/
CREATE DATABASE BD23917
ON PRIMARY (
NAME = 'BD23917',
FILENAME = 'C:\Users\Marti\Documents\Exame C#\daw_en_2425\App_Data\BD23917.mdf'
)
LOG ON (
	NAME = 'BD23917LOG',
	FILENAME = 'C:\Users\Marti\Documents\Exame C#\daw_en_2425\App_Data\BD23917LOG.ldf'
)

GO

USE BD23917

/* CRIAÇÃO DE TABELAS */

CREATE TABLE uc (
    uc_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL
);

CREATE TABLE student (
    student_id INT PRIMARY KEY IDENTITY(1,1),
    number INT NOT NULL UNIQUE,
    name NVARCHAR(100) NOT NULL
);

CREATE TABLE academicyear (
    year_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
	activeyear INT NOT NULL
);

CREATE TABLE enrollment(
	enrollment_id INT PRIMARY KEY IDENTITY(1,1),
	student_id INT NOT NULL,
	uc_id INT NOT NULL,
	year_id INT NOT NULL,
	FOREIGN KEY (student_id) REFERENCES student(student_id),
	FOREIGN KEY (uc_id) REFERENCES uc(uc_id),
	FOREIGN KEY (year_id) REFERENCES academicyear(year_id)
);

CREATE TABLE grade(
	grade_id INT PRIMARY KEY IDENTITY(1,1),
	enrollment_id INT NOT NULL,
	grade_value INT NOT NULL,
	grade_quali NVARCHAR(100) NOT NULL,
	FOREIGN KEY (enrollment_id) REFERENCES enrollment(enrollment_id)
);

GO