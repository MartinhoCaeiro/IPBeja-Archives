<?php
namespace App\Http\Controllers;

use App\Models\StudentModel;
use App\Models\TimetableModel;

class TimetableController extends Controller
{
    public function showTimetable($student_id)
    {
        $students = StudentModel::with('programs')->find($student_id);

        if (!$students) {
            return redirect()->back()->with('error', 'Student not found.');
        }

        $horarios = TimetableModel::whereHas('ucs.enrollments', function ($query) use ($student_id) {
            $query->where('student_id', $student_id);
        })->get();

        $timetables = [];
            foreach ($horarios as $horario) {
                $day = $horario->dia_semana; // Por exemplo, 'Segunda'
                $startHour = (int)substr($horario->hora_inicial, 0, 2); // Por exemplo, 9
                $endHour = (int)substr($horario->hora_final, 0, 2); // Por exemplo, 13
                $uc = $horario->ucs->name;

                for ($hour = $startHour; $hour < $endHour; $hour++) {
                    $formattedHour = sprintf('%02d:00', $hour);
                    $timetables[$day][$formattedHour] = $uc;
                }
            }

        return view('timetable.show', compact('students', 'timetables'));
    }
}