<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TimetableModel extends Model
{
    protected $table = 'timetable';
    protected $primaryKey = 'horario_id';

    public function ucs()
    {
        return $this->belongsTo(UCModel::class, 'uc_id');
    }
}
