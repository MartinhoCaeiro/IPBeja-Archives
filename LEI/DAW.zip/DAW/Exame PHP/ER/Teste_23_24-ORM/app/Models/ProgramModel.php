<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProgramModel extends Model
{
    protected $table = 'program';
    protected $primaryKey = 'program_id';

    public function enrollments() {
        return $this->hasMany(StudentModel::class, 'uc_id');
    }

    public function students()
    {
        return $this->hasMany(StudentModel::class, 'program_id');
    }
}
