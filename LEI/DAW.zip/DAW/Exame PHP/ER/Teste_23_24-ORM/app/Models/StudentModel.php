<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentModel extends Model
{
    protected $table = 'student';
    protected $primaryKey = 'student_id';

    public function enrollments() {
        return $this->hasMany(EnrollmentModel::class, 'student_id');
    }

    public function programs()
    {
        return $this->belongsTo(ProgramModel::class, 'program_id');
    }
}
