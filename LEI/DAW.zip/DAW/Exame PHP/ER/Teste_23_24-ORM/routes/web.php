<?php

use App\Http\Controllers\TimetableController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/timetable/show/{student_id}', [TimetableController::class, 'showTimetable'])->name('timetable.show');