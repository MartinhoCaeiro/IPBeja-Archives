@extends('layout')
@section('title', 'Horário do Aluno')
@section('content')
<div>
    <p>Aluno: {{ $students->name }}</p>
    <p>Curso: {{ $students->programs->name }}</p>
</div>
<table>
    <thead>
        <tr>
            <th></th>
            <th>09:00</th>
            <th>10:00</th>
            <th>11:00</th>
            <th>12:00</th>
            <th>13:00</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($timetables as $day => $hours)
        <tr>
            <td>{{ $day }}</td> <!-- Nome do dia (ex: Segunda) -->
            @for ($hour = 9; $hour <= 13; $hour++)
                @php
                $formattedHour=sprintf('%02d:00', $hour);
                @endphp
                <td>{{ $hours[$formattedHour] ?? '' }}</td> <!-- Preencher se existir ou deixar vazio -->
                @endfor
        </tr>
        @endforeach
    </tbody>
</table>
@endsection