<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EnrollmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('enrollment')->insert([
            ['student_id' => 1, 'uc_id' => 1],
            ['student_id' => 2, 'uc_id' => 2],
            ['student_id' => 3, 'uc_id' => 3],
            ['student_id' => 1, 'uc_id' => 1],
            ['student_id' => 2, 'uc_id' => 2],
            ['student_id' => 3, 'uc_id' => 3],
        ]);
    }
}
