<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TimetableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('timetable')->insert([
            ['uc_id' => 1, 'dia_semana' => '2º.F.', 'hora_inicial' => '09:00', 'hora_final' => '12:00'],
            ['uc_id' => 2, 'dia_semana' => '3º.F.', 'hora_inicial' => '09:00', 'hora_final' => '11:00'],
            ['uc_id' => 3, 'dia_semana' => '4º.F.', 'hora_inicial' => '09:00', 'hora_final' => '12:00'],
        ]);
    }
}
