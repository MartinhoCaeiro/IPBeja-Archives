<?php $__env->startSection('title', 'Horário do Aluno'); ?>
<?php $__env->startSection('content'); ?>
<div>
    <p>Aluno: <?php echo e($students->name); ?></p>
    <p>Curso: <?php echo e($students->programs->name); ?></p>
</div>
<table>
    <thead>
        <tr>
            <th></th>
            <th>09:00</th>
            <th>10:00</th>
            <th>11:00</th>
            <th>12:00</th>
            <th>13:00</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($day); ?></td> <!-- Nome do dia (ex: Segunda) -->
            <?php for($hour = 9; $hour <= 13; $hour++): ?>
                <?php
                $formattedHour=sprintf('%02d:00', $hour);
                ?>
                <td><?php echo e($hours[$formattedHour] ?? ''); ?></td> <!-- Preencher se existir ou deixar vazio -->
                <?php endfor; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marti\Documents\Teste PHP\ER\Teste_23_24-ORM\resources\views/timetable/show.blade.php ENDPATH**/ ?>