<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        /* Tabela */
        table,
        table th,
        table td {
            border: 1px solid #333;
        }
    </style>
</head>

<body>
    <header>
        <h1>Horário de Aluno</h1>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>

</html><?php /**PATH C:\Users\Marti\Documents\Teste PHP\ER\Teste_23_24-ORM\resources\views/layout.blade.php ENDPATH**/ ?>