<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AttendanceController extends Controller
{
    public function addAttendance($uc_id, $class_id)
    {
        // Consulta a turma com base no uc_id e class_id
        $class = DB::select(
            'SELECT * FROM class WHERE uc_id = ? AND class_id = ? LIMIT 1',
            [$uc_id, $class_id]
        );

        $uc = DB::select(
            'SELECT * FROM uc WHERE uc_id = ? LIMIT 1',
            [$uc_id]
        );

        // Busca os estudantes matriculados na unidade curricular (uc_id)
        $students = DB::select(
            'SELECT student.*, enrollment.student_uc_id as enrollment_id 
             FROM enrollment
             INNER JOIN student ON enrollment.student_id = student.student_id
             WHERE enrollment.uc_id = ?',
            [$uc_id]
        );

        // Ajusta o resultado, pois `DB::select` retorna arrays ao invés de objetos de Eloquent
        $class = $class[0] ?? null;
        $uc = $uc[0] ?? null;

        return view('attendance.add', compact('class', 'students', 'uc'));
    }

    public function showAttendance($uc_id, $class_id)
    {
        // Consulta a turma pelo ID
        $class = DB::select(
            'SELECT * FROM class WHERE class_id = ? LIMIT 1',
            [$class_id]
        );

        $uc = DB::select(
            'SELECT * FROM uc WHERE uc_id = ? LIMIT 1',
            [$uc_id]
        );

        // Busca as presenças associadas à turma
        $attendances = DB::select(
            'SELECT attendance.*, student.number as student_number, student.name as student_name 
             FROM attendance
             INNER JOIN student ON attendance.student_id = student.student_id
             WHERE attendance.class_id = ?',
            [$class_id]
        );

        // Ajusta o resultado, pois `DB::select` retorna arrays
        $class = $class[0] ?? null;
        $uc = $uc[0] ?? null;

        return view('attendance.show', compact('class', 'attendances', 'uc'));
    }

    public function saveAttendance(Request $request)
    {
        $class_id = $request->input('class_id');
        $enrollments = $request->input('enrollment');

        foreach ($enrollments as $student_id => $state) {
            DB::statement(
                'UPDATE attendance
                 SET state = ?, updated_at = ?
                 WHERE class_id = ? AND student_id = ?',
                [$state, now(), $class_id, $student_id]
            );
        }

        return redirect()->route('attendance.show', ['uc_id' => $request->input('uc_id'), 'class_id' => $class_id])
            ->with('success', 'Attendance saved successfully.');
    }
}
