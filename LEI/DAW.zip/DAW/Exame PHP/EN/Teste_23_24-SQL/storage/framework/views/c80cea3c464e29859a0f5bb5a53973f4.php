<?php $__env->startSection('title', 'Lista de Presenças'); ?>
<?php $__env->startSection('content'); ?>
<div class="section-title">Listagem de Assiduidade</div>
<div class="uc-details">
    <p>UC: <?php echo e($uc->name); ?></p>
    <p>Aula: <?php echo e($class->class_id); ?></p>
    <p>Data: <?php echo e($class->timestamp); ?></p>
</div>
<table>
    <thead>
        <tr>
            <th>Número</th>
            <th>Aluno</th>
            <th>Presença</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($attendance->student_number); ?></td>
            <td><?php echo e($attendance->student_name); ?></td>
            <td><?php echo e($attendance->state ? 'Presente' : 'Faltou'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marti\Documents\Teste PHP\Teste_23_24-SQL\resources\views/attendance/show.blade.php ENDPATH**/ ?>