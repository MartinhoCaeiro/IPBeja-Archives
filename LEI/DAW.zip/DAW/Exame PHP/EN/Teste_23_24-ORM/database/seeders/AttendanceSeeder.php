<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AttendanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('attendance')->insert([
            ['class_id' => 1, 'student_id' => 1, 'state' => 1],
            ['class_id' => 1, 'student_id' => 2, 'state' => 1],
            ['class_id' => 2, 'student_id' => 3, 'state' => 0],
            ['class_id' => 2, 'student_id' => 1, 'state' => 0],
        ]);
    }
}
