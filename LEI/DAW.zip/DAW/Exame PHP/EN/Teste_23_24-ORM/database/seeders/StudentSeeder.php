<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('student')->insert([
            ['number' => 24234, 'name' => 'Carlos Silva'],
            ['number' => 34543, 'name' => 'Ana Pereira'],
            ['number' => 86732, 'name' => 'João Costa'],
        ]);
    }
}
