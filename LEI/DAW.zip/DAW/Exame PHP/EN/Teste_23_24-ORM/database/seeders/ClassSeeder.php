<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClassSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('class')->insert([
            ['uc_id' => 1, 'name' => 'html', 'state' => 1,'timestamp' => '2024-01-13'],
            ['uc_id' => 1, 'name' => 'api', 'state' => 0,'timestamp' => '2024-02-14'],
            ['uc_id' => 2, 'name' => 'php', 'state' => 1,'timestamp' => '2024-03-15'],
            ['uc_id' => 2, 'name' => 'laravel', 'state' => 0,'timestamp' => '2024-04-16'],
        ]);
    }
}
