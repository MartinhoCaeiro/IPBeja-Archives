<?php $__env->startSection('title', 'Registo de Assiduidade'); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-title">Registo de Assiduidade</div>
    <div class="uc-details">
        <p>UC: <?php echo e($class->uc->name); ?></p>
        <p>Aula: <?php echo e($class->class_id); ?></p>
        <p>Data: <?php echo e(date('d/m/Y')); ?></p>
    </div>
    <form action="/attendance/save" method="POST">
        <?php echo csrf_field(); ?>
        <table>
            <thead>
                <tr>
                    <th>Número Aluno</th>
                    <th>Nome Aluno</th>
                    <th>Presença</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($enrollment->student->number); ?></td>
                        <td><?php echo e($enrollment->student->name); ?></td>
                        <td>
                            <input type="checkbox" name="enrollment[<?php echo e($enrollment->student->student_id); ?>]" value="1">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="submit">Registar Presenças</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marti\Documents\Teste PHP Resolvido\Teste_23_24\resources\views/attendance/add.blade.php ENDPATH**/ ?>