<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
        }

        /* Cabeçalho */
        header {
            background-color: #333;
            color: #fff;
            padding: 1rem 0;
            font-size: 1.5rem;
        }

        header h1 {
            margin-bottom: 0.3rem;
            font-size: 1.8rem;
        }

        header h2 {
            font-size: 1.2rem;
            font-weight: normal;
            color: #ccc;
        }

        /* Conteúdo principal */
        main {
            padding: 2rem;
            max-width: 800px;
            margin: 1rem auto;
            background-color: #e1e1e1;
            border-radius: 8px;
        }

        /* Título da Seção */
        .section-title {
            background-color: #ccc;
            padding: 0.5rem;
            font-weight: bold;
            color: #333;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        /* Detalhes da UC */
        .uc-details {
            padding: 1rem;
            font-size: 0.9rem;
        }

        /* Tabela */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        table th, table td {
            padding: 0.8rem;
            border: 1px solid #333;
            text-align: left;
            font-size: 0.9rem;
        }

        table th {
            background-color: #ccc;
        }

        table td {
            background-color: #fff;
        }

        table tr:nth-child(even) td {
            background-color: #f9f9f9;
        }

        /* Botão */
        button {
            display: block;
            width: 100%;
            background-color: #003366;
            color: #fff;
            border: none;
            padding: 0.8rem;
            margin-top: 1rem;
            font-size: 1rem;
            font-weight: bold;
            text-align: center;
            cursor: pointer;
        }

        button:hover {
            background-color: #002244;
        }

        /* Rodapé */
        footer {
            background-color: #333;
            color: #fff;
            padding: 0.8rem;
            font-size: 0.9rem;
            margin-top: 1rem;
        }

        /* Link */
        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Portal Académico</h1>
        <h2>Gestão de Assiduidade</h2>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        <p>Última atualização: 21/11/2023</p>
        <p>Todos os direitos do IPBeja © 2023</p>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\Marti\Documents\Teste PHP Resolvido\Teste_23_24\resources\views/layout.blade.php ENDPATH**/ ?>