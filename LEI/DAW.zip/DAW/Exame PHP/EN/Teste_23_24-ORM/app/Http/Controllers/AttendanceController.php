<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AttendanceModel;
use App\Models\ClassModel;
use App\Models\EnrollmentModel;

class AttendanceController extends Controller
{
    public function addAttendance($uc_id, $class_id)
    {
        $class = ClassModel::where('uc_id', $uc_id)->find($class_id);
        $students = EnrollmentModel::where('uc_id', $uc_id)->with('student')->get();
        return view('attendance.add', compact('class', 'students'));
    }

    public function showAttendance($uc_id, $class_id)
    {
        $class = ClassModel::find($class_id);
        $attendances = AttendanceModel::where('class_id', $class_id)
            ->with('student')
            ->get();

        return view('attendance.show', compact('class', 'attendances'));
    }

    public function saveAttendance(Request $request)
    {
        $class_id = $request->input('class_id');
        $enrollments = $request->input('enrollment');

        foreach ($enrollments as $student_id => $state) {
            $attendance = AttendanceModel::where('class_id', $class_id)
                ->where('student_id', $student_id)
                ->first();

            if ($attendance) {
                $attendance->state = $state;
            } else {
                $attendance = new AttendanceModel();
                $attendance->class_id = $class_id;
                $attendance->student_id = $student_id;
                $attendance->state = $state;
            }

            $attendance->save();
        }

        return redirect()->route('attendance.show', ['uc_id' => $request->input('uc_id'), 'class_id' => $class_id])
            ->with('success', 'Attendance saved successfully.');
    }
}
