<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EnrollmentModel extends Model
{
    protected $table = 'enrollment';
    protected $primaryKey = 'student_uc_id';

    public function student()
    {
        return $this->belongsTo(StudentModel::class, 'student_id');
    }

    public function uc()
    {
        return $this->belongsTo(UCModel::class, 'uc_id');
    }
}