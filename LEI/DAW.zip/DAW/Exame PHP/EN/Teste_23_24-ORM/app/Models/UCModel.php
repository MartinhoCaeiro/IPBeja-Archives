<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UCModel extends Model
{
    protected $table = 'uc';
    protected $primaryKey = 'uc_id';

    public function enrollments() {
        return $this->hasMany(EnrollmentModel::class, 'uc_id');
    }

    public function classes() {
        return $this->hasMany(ClassModel::class, 'uc_id');
    }
}
