<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassModel extends Model
{
    protected $table = 'class';
    protected $primaryKey = 'class_id';

    public function uc()
    {
        return $this->belongsTo(UCModel::class, 'uc_id');
    }

    public function attendances()
    {
        return $this->hasMany(AttendanceModel::class, 'class_id');
    }
}