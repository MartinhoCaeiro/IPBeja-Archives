<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AttendanceController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/attendance/add/{uc_id}/{class_id}', [AttendanceController::class, 'addAttendance']);
Route::get('/attendance/show/{uc_id}/{class_id}', [AttendanceController::class, 'showAttendance'])->name('attendance.show');

Route::post('/attendance/save', [AttendanceController::class, 'saveAttendance']);

