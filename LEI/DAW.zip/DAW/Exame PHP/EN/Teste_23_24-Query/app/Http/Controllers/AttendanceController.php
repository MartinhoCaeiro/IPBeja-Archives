<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AttendanceController extends Controller
{
    public function addAttendance($uc_id, $class_id)
    {
        try {
            // Consulta a turma com base em uc_id e class_id
            $class = DB::table('class')
                ->where('uc_id', $uc_id)
                ->where('class_id', $class_id)
                ->first();

            if (!$class) {
                return response()->json(['error' => 'Class not found'], 404);
            }

            // Busca a unidade curricular (uc) com base em uc_id
            $uc = DB::table('uc')
                ->where('uc_id', $uc_id)
                ->first();

            // Busca os estudantes matriculados na unidade curricular (uc_id)
            $students = DB::table('enrollment')
                ->where('uc_id', $uc_id)
                ->join('student', 'enrollment.student_id', '=', 'student.student_id')
                ->select('student.number', 'student.name', 'student.student_id')
                ->get();

            return view('attendance.add', compact('class', 'students', 'uc'));
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred: ' . $e->getMessage()], 500);
        }
    }

    public function showAttendance($uc_id, $class_id)
    {
        try {
            // Consulta a turma pelo ID
            $class = DB::table('class')
                ->where('class_id', $class_id)
                ->first();

            if (!$class) {
                return response()->json(['error' => 'Class not found'], 404);
            }

            // Busca a unidade curricular (uc) com base em uc_id
            $uc = DB::table('uc')
                ->where('uc_id', $uc_id)
                ->first();

            // Busca as presenças associadas à turma
            $attendances = DB::table('attendance')
                ->where('class_id', $class_id)
                ->join('student', 'attendance.student_id', '=', 'student.student_id')
                ->select('attendance.*', 'student.number as student_number', 'student.name as student_name')
                ->get();

            return view('attendance.show', compact('class', 'attendances', 'uc'));
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred: ' . $e->getMessage()], 500);
        }
    }

    public function saveAttendance(Request $request)
    {
        $class_id = $request->input('class_id');
        $enrollments = $request->input('enrollment');

        foreach ($enrollments as $student_id => $state) {
            DB::table('attendance')->updateOrInsert(
                ['class_id' => $class_id, 'student_id' => $student_id],
                ['state' => $state, 'updated_at' => now(), 'created_at' => now()]
            );
        }

        return redirect()->route('attendance.show', ['uc_id' => $request->input('uc_id'), 'class_id' => $class_id])
            ->with('success', 'Attendance saved successfully.');
    }
}
