@extends('layout')
@section('title', 'Registo de Assiduidade')
@section('content')
<div class="section-title">Registo de Assiduidade</div>
<div class="uc-details">
    <p>UC: {{ $uc->name }}</p>
    <p>Aula: {{ $class->class_id }}</p>
    <p>Data: {{ $class->timestamp }}</p>
</div>
<form action="/attendance/save" method="POST">
    @csrf
    <input type="hidden" name="class_id" value="{{ $class->class_id }}">
    <input type="hidden" name="uc_id" value="{{ $uc->uc_id }}">
    <table>
        <thead>
            <tr>
                <th>Número Aluno</th>
                <th>Nome Aluno</th>
                <th>Presença</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($students as $student)
            <tr>
                <td>{{ $student->number }}</td>
                <td>{{ $student->name }}</td>
                <td>
                    <input type="hidden" name="enrollment[{{ $student->student_id }}]" value="0">
                    <input type="checkbox" name="enrollment[{{ $student->student_id }}]" value="1">
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <button type="submit">Registar Presenças</button>
</form>
@endsection