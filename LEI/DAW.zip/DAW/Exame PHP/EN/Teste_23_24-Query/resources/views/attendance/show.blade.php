@extends('layout')
@section('title', 'Lista de Presenças')
@section('content')
<div class="section-title">Listagem de Assiduidade</div>
<div class="uc-details">
    <p>UC: {{ $uc->name }}</p>
    <p>Aula: {{ $class->class_id }}</p>
    <p>Data: {{ $class->timestamp }}</p>
</div>
<table>
    <thead>
        <tr>
            <th>Número</th>
            <th>Aluno</th>
            <th>Presença</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($attendances as $attendance)
        <tr>
            <td>{{ $attendance->student_number }}</td>
            <td>{{ $attendance->student_name }}</td>
            <td>{{ $attendance->state ? 'Presente' : 'Faltou' }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection