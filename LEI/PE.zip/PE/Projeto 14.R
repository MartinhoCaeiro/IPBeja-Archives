library(readxl)
library(car)
library(BSDA)
df <- data.frame(read_excel("C:/Users/user/Documents/R/ANOVA.xlsx", sheet = "Ex1"))
df$grupo <- factor(df$grupo)

boxplot(peso ~ grupo, data = df)
for (i in levels(df$grupo)) {
  print(shapiro.test(df$peso[df$grupo == i])$p.value)
}

leveneTest(peso ~ grupo, data = df)
summary(aov(peso ~ grupo, data = df))
TukeyHSD(aov(peso ~ grupo, data = df))

df2 <- data.frame(read_excel("C:/Users/user/Documents/R/ANOVA.xlsx", sheet = "Ex2"))
df2$trt <- factor(df2$trt)

boxplot(response ~ trt, data = df2)
for (i in levels(df2$trt)) {
  print(shapiro.test(df2$response[df2$trt == i])$p.value)
}

leveneTest(response ~ trt, data = df2)
summary(aov(response ~ trt, data = df2))
TukeyHSD(aov(response ~ trt, data = df2))

df3 <- data.frame(read_excel("C:/Users/user/Documents/R/ANOVA.xlsx", sheet = "Ex3"))
df3$trt <- factor(df3$trt)

boxplot(response ~ trt, data = df3)
for (i in levels(df3$trt)) {
  print(shapiro.test(df3$response[df3$trt == i])$p.value)
}

leveneTest(response ~ trt, data = df3)
summary(aov(response ~ trt, data = df3))
TukeyHSD(aov(response ~ trt, data = df3))

t.test(response ~ trt, data = df3, alternative = "two.sided")