dbinom(x = 1, size = 20, prob = 0.15)
pbinom(q = 3, size = 20, prob = 0.15)
sum(dbinom(x = 5:20, size = 20, prob = 0.15))
dbinom(x = 0, size = 20, prob = 0.15)
qbinom(p = 0.5, size = 20, prob = 0.15)
binom.test(x = 6, n = 20, p = 0.15, alternative = "greater")

dbinom(x = 5, size = 10, prob = 0.7)
dgeom(x = 2, prob = 0.7)
dnbinom(x = 2, size = 3, prob = 0.7)

dmultinom(x = c(3, 5, 2), size = 10, prob = c(2 / 6, 3 / 6, 1 / 6))

dmultinom(x = c(6, 10, 12, 4, 8), size = 40, prob = c(0.32, 0.246, 0.124, 0.122, 0.188))
