df <- data.frame(c(98.2, 94.1, 93.4, 86.2, 88.3, 92.4, 87.9, 78.4, 96.5,
                   83.4, 93.5, 77.5, 80.4, 116.9, 37.3, 71.2, 52.0, 103.7, 44.6))
df$processador <- rep(c("A", "B"), c(9, 10))
names(df) <- c("conservacao", "metodo")

myFormula <- conservacao ~ factor(metodo)
x <- df$conservacao[df$metodo == "A"]
shapiro.test(x)

x2 <- df$conservacao[df$metodo == "B"]
shapiro.test(x2)

boxplot(myFormula, data = df)

var.test(myFormula, data = df)
library("car")
leveneTest(myFormula, data = df)

t.test(myFormula, data = df, var.equal = TRUE, alternative = "two.sided")
wilcox.test(myFormula, data = df, alternative = "two.sided")

df2 <- data.frame(read_excel("C:/Users/user/Documents/R/TH.xlsx", sheet = "Ex9"))
myFormula2 <- classificacao ~ factor(Produto)
x3 <- df2$classificacao[df2$Produto == "Antigo"]
shapiro.test(x3)

x4 <- df2$classificacao[df2$Produto == "Novo"]
shapiro.test(x4)

boxplot(myFormula2, data = df2)

var.test(myFormula2, data = df2)
library("car")
leveneTest(myFormula2, data = df2)

t.test(myFormula2, data = df2, paired = TRUE, var.equal = TRUE, alternative = "less")

df3 <- data.frame(read_excel("C:/Users/user/Documents/R/TH.xlsx", sheet = "Ex10"))
myFormula3 <- Tempos ~ factor(Estimulo)
x4 <- df3$Tempos[df3$Estimulo == "Estimulo1"]
shapiro.test(x4)

x5 <- df3$Tempos[df3$Estimulo == "Estimulo2"]
shapiro.test(x5)

boxplot(myFormula3, data = df3)

var.test(myFormula3, data = df3)
library("car")
leveneTest(myFormula3, data = df3)

t.test(myFormula3, data = df3, paired = TRUE, var.equal = TRUE, alternative = "less")