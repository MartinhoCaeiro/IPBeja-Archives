1 - pnorm(16, 15, 4 / sqrt(10))
140 - 1.9599 * (10 / sqrt(25)); 140 + 1.9599 * (10 / sqrt(25))

library(readxl)
df1 <- data.frame(read_excel("C:/Users/user/Documents/R/IC.xlsx", sheet = "Ex3"))
str(df1)

y1 <- df1$x; y1
shapiro.test(y1)

m1 <- mean(y1); m1
n1 <- 40
s1 <- 2
z1 <- qnorm(0.995); z1
Lmin1 <- m1 - z1 * (s1 / sqrt(n1)); Lmin1
Lmax1 <- m1 + z1 * (s1 / sqrt(n1)); Lmax1

df2 <- data.frame(read_excel("C:/Users/user/Documents/R/IC.xlsx", sheet = "Ex4"))
str(df2)

y2 <- df2$x; y2
shapiro.test(y2)

m2 <- mean(y2); m2
n2 <- 50
s2 <- 800
z2 <- qnorm(0.95); z2
Lmin2 <- m2 - z2 * (s2 / sqrt(n2)); Lmin2
Lmax2 <- m2 + z2 * (s2 / sqrt(n2)); Lmax2
