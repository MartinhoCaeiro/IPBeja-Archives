#EXERCICIO DE TESTE DE HIPOTESE PARA MEDIA

#Ex.1
#x = tempo de preservação
#x ~Normal? Sim
#sigma conhecido? Sim

#Hipotese zero: mu = 500, sd = 15
#H0
mu <- 500
sd <- 15

#Amostra: n = 20, m = 494.092  
#H1 mu < 500
n <- 20
m <- 494.092

#a) É valido com 90% de confiança?
#Valor Critico
#Normal normalizada (m = 0, s = 1) centrada em 1.70 com 90% de certeza
-qnorm(0.9)

#Estatística
Z0 <- (m - mu) / (sd / sqrt(n))
Z0

#p-value
#p(Z<Z0)
pnorm(Z0)

#Conclusão
#Estátistica(-1.761425) < Valor Critivo(-1.281552) logo Rejeita Hipotese nula
#p-value(0.03908322) < Significancia (0.10) logo Rejeita Hipotese nula

#b) É valido com 99.9% de confiança?
#Valor Critico
#Normal normalizada (m = 0, s = 1) centrada em 1.70 com 99.9% de certeza
-qnorm(0.999)

#Estatística
Z0 <- (m - mu) / (sd / sqrt(n))
Z0

p - value
#p(Z<Z0)
pnorm(Z0)

#Conclusão
#Estátistica(-1.761425) > Valor Critivo(-3.090232) logo Não Rejeita Hipotese nula
#-value(0.03908322) > Significancia (0.001) logo Não Rejeita Hipotese nula

#c) Sim, construimos a hipotese em função da amostra (ja sabia quando era  a media real e por isso escolhemos fazer um test para menor, na realidade não deveriamos saber)

#d)
#Hipoteses:
#H0: mu = 500
#H1: mu < 500

#confiança 99%
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex1"))
View(df)

x ~ N(mu, sigma)
x <- df$x

#Testa se é normal
shapiro.test(x)
#p-value(0.03908) > Significancia (0.05) logo Não Rejeita Hipotese nula (se é Normal)

library(BSDA)
z.test(x, mu = 500, sigma.x = 15, alternative = "less")
#p-value(0.03908) > Significancia (0.001) logo Não Rejeita Hipotese nula

#e)
z.test(x, mu = 500, sigma.x = 15, alternative = "two.sided")
#p-value(0.07817) > Significancia (0.01) logo Não Rejeita Hipotese nula

#p-value 
#p(Z0< z < Z)
2 * pnorm(Z0)
#p-value(0.03908) > Significancia (0.01) logo Não Rejeita Hipotese nula


#EX.2
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex2"))
View(df)

x <- df$ovos

#a)
#x = classificação do peso dos ovos

#x ~ Normal? 
shapiro.test(x)
#É NORMAL pois p-value > 0.05 (alpha)

#sigma conhecido? Sim
#Hipotese zero (tipo B): mu = 55, sd = 8
mu <- 55
sd <- 8

#Hipotese 1 (tipo A): mu < 55
#Amostra: n = 20, m  
n <- 20
m <- mean(x); m

z.test(x, mu = 55, sigma.x = 8, alternative = "less")
#p-value > 0.05 Não rejeita hipotese

#Valor Critico
-qnorm(1 - 0.05)

#Estatística
Z0 <- (m - mu) / (sd / sqrt(n))
Z0
#Estátistica(-1.060953) > Valor Critivo(-1.644854) logo Não Rejeita Hipotese nula

#p-value
#p(Z<Z0)
pnorm(Z0)
#p-value(0.1443557) > Significancia (0.05) logo Não Rejeita Hipotese nula

#b)
#Hipotese zero (tipo A): mu = 50, sd = 8
#Hipotese 1 (tipo B): mu > 50
z.test(x, mu = 50, sigma.x = 8, alternative = "greater")
#p-value < 0.05 rejeita hipotese

#c)
#Erro tipo II = beta
#area associada com o valor para trás do ponto critico na normal da hipotese
q <- qnorm(0.95, mean = 50, sd = 8)
pnorm(q, mean = 55, sd = 8) # Erro tipo II

#Potencia do teste = 1- beta
1 - pnorm(q, mean = 55, sd = 8)


#EX.3
#H0:
mu <- 2060
sd <- 20

#Amostra
x <- c(2100, 2025, 2071, 2067, 2150, 2115, 2064, 2088, 1995, 2095)

#a)
#Teste Normal
shapiro.test(x)
#p-value > 0.05 NÃO rejeita hipotese (distribuição normal)

#H1: mu diferente de 2060
z.test(x, mu = 2060, sigma.x = 20, alternative = "two.sided")
#p-value < 0.05 rejeita hipotese  (logo mudou)

#b)
#sigma conhecido? Não
m <- mean(x)
m
s <- sd(x)
s
n <- 10

#Valor Critico (+ e -)
qt(1 - (0.05 / 2), df = 9)

#Estatística
T0 <- (m - mu) / (s / sqrt(n))
T0
#Estátistica( 1.219831) < |Valor Critivo(2.262157)| logo Não Rejeita Hipotese nula

#p-value
2 * (1 - pt(T0, df = 9))
#p-value( 0.2535291) > Significancia (0.05) logo Não Rejeita Hipotese nula

#c)
t.test(x, mu = 2060, alternative = "two.sided")
#p-value( 0.2535) > Significancia (0.05) logo Não Rejeita Hipotese nula


#Ex.4
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex4"))
View(df)

x <- df$tempos
#tempo ~ N(mu, sd)
#Media de um trabalhador
mu <- 420

#a) Desvio padrão desconhecido
#H1: mu != 420 

m <- mean(x); m
s <- sd(x); s
n <- length(x); n

#Valor Critico (+ ou -)
qt(1 - (0.01 / 2), df = n - 1)

#Estatística
T0 <- (m - mu) / (s / sqrt(n))
T0
#Estátistica(-3.038481) > |Valor Critivo( 2.946713)| logo Rejeita Hipotese nula

#p-value
2 * (pt(T0, df = n - 1))
#p-value( 0.00829607) < Significancia (0.01) logo Rejeita Hipotese nula

#b)
t.test(x, mu = 420, alternative = "two.sided")


#Ex.5
#Desvio Padrão Desconhecido  
mu <- 16
n <- 8

#Dados
x <- c(16.1, 15.8, 15.9, 16.1, 15.8, 16.2, 16.0, 15.9)

#a)
#H1: mu != 16

#Amostra
m <- mean(x); m
s <- sd(x); s

#Normal?
shapiro.test(x)

#Valor Critico (+ ou -)
qt(1 - (0.001 / 2), df = n - 1)

#Estatística
T0 <- (m - mu) / (s / sqrt(n))
T0
#Estátistica(-0.475191) < |Valor Critivo(5.407883)| logo Não Rejeita Hipotese nula

#p-value
2 * (pt(T0, df = n - 1))
#p-value( 0.6491204) > Significancia (0.001) logo Não Rejeita Hipotese nula

#b)
t.test(x, mu = 16, alternative = "two.sided")


#Ex.6 TESTE DE DUAS MEDIAS
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex6"))
View(df)

a <- df$classificacao[df$desumidificador == "A"]
b <- df$classificacao[df$desumidificador == "B"]

#H0: média(A) = média(B)
myFormula <- classificacao ~ factor(desumidificador)

#Normal?
shapiro.test(a)
#Como  0.7937 > 0.05 logo É NORMAL

shapiro.test(b)
#Como  0.3712 > 0.05 logo É NORMAL

#Testar Homocedasticidadeentre amostras (iguais variâncias)
var.test(myFormula, data = df)
# p-valu (0.5371) > 0.05 Não rejeita H0 (variancias são iguas)

#Outra maneira de Testar Homocedasticidadeentre amostras (iguais variâncias)
library(car)
car::leveneTest(myFormula, data = df)
# p-value (0.7013) > 0.05  Não rejeita H0 (variancias são iguas)

#teste T
#H1: média(A) != média(B)
t.test(myFormula, data = df, var.equal = TRUE, alternative = "two.sided")
# p-value (0.2497) > 0.01 Não há evidencia de que o gosto de altere de acordo com a desumidificação


#Ex.7
df <- data.frame(c(9.6, 9.4, 9.3, 11.2, 11.4, 12.1, 10.4, 9.6, 10.2, 8.8, 13, 10.2, 10.6, 13.2, 11.7, 9.6, 8.5, 9.7, 12.3, 12.4, 10.8, 10.8))
View(df)

df$processador <- rep(c("A", "B"), c(12, 10))
names(df) <- c("velocidade", "processador")

a <- df$velocidade[df$processador == "A"]
b <- df$velocidade[df$processador == "B"]

myFormula <- velocidade ~ factor(processador)

#Normal?
shapiro.test(a)
shapiro.test(b)

#Testar Homocedasticidade entre amostras (iguais variâncias)
var.test(myFormula, data = df)
car::leveneTest(myFormula, data = df)

#teste T
#H0: média(A) = média(B)
#H1: média(A) < média(B)
t.test(myFormula, data = df, var.equal = TRUE, alternative = "less")
#p-value = 0.1867 > 0.0001 Não há evidencia de ser mais rápido


#Ex.9 Teste de duas medias EMPARELHADO
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex9"))
View(df)

antigo <- df$classificacao[df$Produto == "Antigo"]
novo <- df$classificacao[df$Produto == "Novo"]

myFormula <- classificacao ~ factor(Produto)
#H0: média(novo) = média(antigo)

#Normal?
shapiro.test(antigo)
shapiro.test(novo)

#Testar Homocedasticidadeentre amostras (iguais variâncias)
var.test(myFormula, data = df)
car::leveneTest(myFormula, data = df)

#teste T
#H0: média(novo) = média(antigo)
#H1: média(novo) < média(antigo)
t.test(myFormula, data = df, var.equal = TRUE, paired = TRUE, alternative = "less")
# p-value (0.05104) > 0.05 Não rejeita H0

#Teste quando os dados não tem distribuição normal e são poucos
wilcox.test(myFormula, data = df, paired = TRUE, alternative = "less")
# 0.03717 < 0.05 Rejeita