#EXERCICIO ANOVA (ANALIDE DE VARIANCIA)

#Ex.1
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex1"))
View(df)

str(df)
summary(df)

# 1 fator, com 3 níveis (ctrl, trt1, trt2)
# 3 grupos de 10

#Define os fatores
df$grupo <- factor(df$grupo)

#Vizualizar os grupos
myFormula <- peso ~ grupo
boxplot(myFormula, data = df)

#Normalidade dentro de cada nível do fator
for (i in levels(df$grupo)) {
  print(shapiro.test(df$peso[df$grupo == i])$p.value)
}
#Todos os p-values são > 0.05 => Normalidade

#Homocedasticidade entre grupos (para mais de 2 amostras)
library(car)
leveneTest(myFormula, data = df)
# p-value (0.3412) > 0.05 => Não rejeita H0

#AMOVA
myModel <- aov(myFormula, data = df)
summary(myModel)
# 0.0159 < 0.05 =>  Rejeita H0 => Médias diferentes

#Médias
model.tables(myModel, type = "means")
#Existem diferenças (Tukey HSD para siginificacias diferentes)

TukeyHSD(myModel)
# 0.0120064 < 0.05 diferença entre trt2 - trt1
#Mas não em diferença entre os tratamentos e o controle
#Logo não há evidencia eu o tratamento com maior media (tr2) seja mais efetivo com 95% de confiança


#Ex.5 ANOVA com 2 FATORES
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex5"))
View(df)

str(df)
summary(df)

# 2 fatores 
# 3 tipos de veneno 
# 4 tipos de tratamento
df$poison <- factor(df$poison) #fator
df$treat <- factor(df$treat)  #fator

#Visualizar os grupos:
myformula <- time ~ poison * treat
boxplot(time ~ poison, data = df)
boxplot(time ~ treat, data = df)
boxplot(myformula, data = df)

#Normalidade em cada grupo:
for (i in levels(df$poison)) {
  print(shapiro.test(df$time[df$poison == i])$p.value)
}
#São todos > 0.05 => Não rejeito H0 com 95% de confiança

for (i in levels(df$treat)) {
  print(shapiro.test(df$time[df$treat == i])$p.value)
}
#São todos > 0.05 => Não rejeito H0 com 95% de confiança

for (i in levels(df$poison)) {
  for (j in levels(df$treat)) {
    print(shapiro.test(df$time[df$poison == i & df$treat == j])$p.value)
  }
}
#São todos > 0.05 => Não rejeito H0 com 95% de confiança

#Homocedasticidade
library(car)
leveneTest(myformula, data = df)
# p-value (0.9952) > 0.05 => Não Rejeito H0

#ANOVA
myModel <- aov(myformula, data = df)
summary(myModel)
# 0.0345 < 0.05. Existem diferenças entre os tratamentos
# 0.0298 < 0.05. Existem diferenças entre os iterações tratamentos*venenos
#Existem diferenças (90% confiança)

#Identicação de quais as médias que são diferentes:
TukeyHSD(myModel)
model.tables(myModel, type = "effects")
which(TukeyHSD(myModel)[["poison"]][, 4] < 0.01) #qual(teste.Tukey [fator] [coluna 4] < significancia)
which(TukeyHSD(myModel)[["treat"]][, 4] < 0.01)
which(TukeyHSD(myModel)[["poison:treat"]][, 4] < 0.01)
# diferença entre a iteração poison(2)*treat(C) - poison(1)*treat(B)