#--------------------RESUMO------------------------#


#---------------Comandos basicos-------------------#
---dnome #probabilidade de um evento:  p(x = 5)

---pnome #probabilidade de um intervalo: p(x <= 5)
# no maximo 5: p(x <= 5) ou sum( dnome(0:5) )
# pelo meno 3: 1 - p(x <= 4) ou sum ( dnome(3:size) )

---qnome #quantidade associada a uma probabilidade: valor q onde p(x <= q) = 0.5

---rnome #simula valores


#-----------------Distribuições--------------------#
---unif #chance de dar cara no lançamento de um dado equilibrado

---binom #quanidade de caras no lançamento de uma moeda não equilibrada

---geom #quantidade de lançamentos necessarios para acertar pela primeira vez

---nbinom #quantidade de lançamentos necessários para acertar pela n-esima vez

---multinom #composição de probabilidades para varios eventos

---hyper #quantidade de bolas de um tipo retiradas de caixas com varios tipos

---pois #chance de ocorrer um quantidade de eventos independentes em um determinado tempo

---norm #gaussiana (continua): x ~ N(mu, sd)


#--------------------binom.test--------------------#
#Testa a validade de H1 contra H0
# se p-value > significancia => NÂO REJEITA H0


#--------------------SIGNIFICANCIA (sig)
#representada por alpha
#sig = 1 - Probabilidade de Confiança
# Representa a area associada a confiança => probabilidade de rejeitar H0


#--------------------NORMALIZAÇÃO------------------#
# Z = ( x - mu ) / sd
# x ~ N(0, 1)


#-----INTERVALO DE CONFIANÇA PARA UMA MÉDIA--------#

#---sd #conhecido (Sempre mais confiável)----------#
# Passo 1
#Verificar se a distribuição é Normal
shapiro.test(x)
# p-value > sig => Não Rejeita H0 => x ~N (mu, sd)  

#Amostra x ~ N (m, sd/sqrt(n))

#Passo 2
#valor de z onde há Y% Confiança
z <- qnorm((1 - sig / 2), 0, 1) # z(1 - sig/2)

#Passo 3
#Intervalo em que se encontra mu com confiança de Y%
Lmin <- m - (z * sd / sqrt(n))
Lmax <- m + (z * sd / sqrt(n))

z0 <- (m - mu) / (sd / sqrt(n)) # Normalização da amostra

-z(1 - sig / 2) < z0 < z(1 - sig / 2)


#--------------sd #desconhecido--------------------#
# Passo 1
#Verificar se a distribuição é Normal
shapiro.test(x)
# p-value > sig => Não Rejeita H0 => x ~N (mu, sd)

#Amostra x ~ N (m, s)
m <- mean(x)
s <- sd(x)

#Passo 2
#valor de Z onde há Y% Confiança
t <- qt((1 - sig / 2), df = n - 1) # T(1 - sig/2)

#Passo 3
#Intervalo em que se encontra mu com confiança de Y%
Lmin <- m - (t * s / sqrt(n))
Lmax <- m + (t * s / sqrt(n))

t0 <- (m - mu) / (s / sqrt(n))

-t(1 - sig / 2) < t0 < t(1 - sig / 2)


#------TESTE DE HIPOTESE PARA UMA MÉDIA------------#

#---sd #conhecido (Sempre mais confiável)----------#
# Passo 1
#Verificar se a distribuição é Normal
shapiro.test(x)
# p-value > sig => Não Rejeita H0 => x ~N (mu, sd)

#Passo 2
#Identificar as hipoteses
#H0: mu0, sd
mu <-
  sd <-
    #H1:mu1 > mu0, mu1 != mu0
    #Amostra
    m <- mea()
n <-

  #confiança: Y%
  conf <- Y / 100
sig <- 1 - conf # significancia (sig)

#Passo 3
#Comparação

#Metodo 1
#Estatistica
z0 <- (m - mu0) / ((sd) / sqrt(n))

#Valor Critico
#quantidade associada a confiança
# qnorm( conf )              -qnorm( conf )               qnorm( 1-(sig/2) )

#Conclusão => Não Rejeita H0 se:
#      Estatistica < V. Critico        Estatistica > V. Critico      -V. Critico < Estatistica < V. Critico

#Metodo 2
#p-value 1 - pnorm(z0), se z0 > 0 => 2*(1 - pnorm(z0))
#            pnorm(z0), se z0 < 0 => 2*pnorm(z0)

#Conclusão => Não Rejeita H0 se: p-value > sig


#Metodo 3
z.test(x, mu =, sigma.x =, alternative = " ")
# com alternative = less, greater ou two.sided

#Conclusão => Não Rejeita H0 se: p-value > sig


#--------------sd #desconhecido--------------------#
# Passo 1
#Verificar se a distribuição é Normal
shapiro.test(x)
# p-value > sig => Não Rejeita H0 => x ~N (mu, sd)


#Passo 2
#Identificar as hipoteses
#H0: mu0, sd
mu <-

  #H1:mu1 > mu0, mu1 != mu0
  #Amostra
  m <- mea()
n <-
  s <- sd()

#confiança: Y% 
conf <- Y / 100
sig <- 1 - conf # significancia (alpha)

#Passo 3
#Comparação

#Metodo 1
#Estatistica
t0 <- (m - mu0) / ((s) / sqrt(n))

#Valor Critico
#quantidade associada a confiança
#   qt( conf )              -qt( conf )               qt( 1-(sig/2) )

#Conclusão => Não Rejeita H0 se:
#      Estatistica < V. Critico        Estatistica > V. Critico      -V. Critico < Estatistica < V. Critico

#Metodo 2
#p-value 1 - pt(t0), se t0 > 0 => 2*( 1 - pt(t0) )
#        pt(t0), se t0 < 0 => 2*pt(t0) 

#Conclusão => Não Rejeita H0 se: p-value > sig

#Metodo 3
t.test(x, mu =, alternative = " ")
# com alternative = less, greater ou two.sided

#Conclusão => Não Rejeita H0 se: p-value > sig


#----TESTE DE HIPOTESE PARA DUAS MÉDIAS------------#
# Passo 1
#Verificar se as distribuições são Normais
#Para cada amostra i                    
shapiro.test(i)
# p-value_i > sig => Não Rejeita H0 => x ~N (mu, sd)

#Passo 2
#Testar Homocedasticidade entre amostras ( H0: iguais variâncias)
var.test(myFormula, data = df)
#ou
car::leveneTest(myFormula, data = df)
# p-value > sig  Não rejeita H0 

#Passo 3
#H0: média(A) = média(B)
#H1: média(A) ( < ou > ou != ) média(B)

t.test(myFormula, data = df, var.equal =, paired =, alternative = "   ")
# myFormula <- coluna1 ~ factor(coluna2)

#com var.equals = (dependendo da homocedasticidade)
TRUE
FALSE

#com paides = (dependendo se as amostras são feitas pelo mesmo grupo ou não)
TRUE
FALSE

# com alternative = less, greater ou two.sided

# p-value > sig  Não rejeita H0 


#--------------------ANOVA-------------------------#

#-------------------1 fator------------------------#
#Passo1
#Definir os fatores
df$coluna <- factor(df$coluna)

#Vizualizar 
myFormula <- coluna1 ~ coluna2
boxplot(myFormula, data = df)

#Passo 2
#Verificar se as distribuições são Normais
#Para cada amostra i  
for (i in levels(df$coluna2)) {
  print(shapiro.test(df$coluna1[df$coluna2 == i])$p.value)
}
# p-value_i > sig => Não Rejeita H0 => x ~N (mu, sd)

#Passo 3
#Testar Homocedasticidade entre mais de duas amostras ( H0: iguais variâncias )
library(car)
leveneTest(myFormula, data = df)
# p-value > sig => Não Rejeita H0 

#Passo 4
#AMOVA => testar se todas as amostras tem médias (mu) iguais
myModel <- aov(myFormula, data = df)
summary(myModel)
# p-value > sig => Não Rejeita H0 

#Passo 5
#Médias
model.tables(myModel, type = "means")
#Se Existem diferenças (Tukey HSD)
TukeyHSD(myModel)
# p-value > sig => Não Rejeita H0 


#--------------2 ou mais fatores-------------------#
#Passo1
#Definir os fatores
df$coluna1 <- factor(df$coluna1)
df$coluna2 <- factor(df$coluna2)

#Vizualizar 
myFormula <- coluna0 ~ coluna1 * coluna2
boxplot(coluna0 ~ coluna1, data = df)
boxplot(coluna0 ~ coluna2, data = df)
boxplot(myFormula, data = df)

#Passo 2
#Verificar se as distribuições são Normais (repetir para cada fator)
#Para cada amostra i  
for (i in levels(df$colunaj)) {
  print(shapiro.test(df$coluna0[df$colunaj == i])$p.value)
}
# p-value_i > sig => Não Rejeita H0 => x ~N (mu, sd)

#Passo 3
#Testar Homocedasticidade entre mais de duas amostras ( H0: iguais variâncias )
library(car)
leveneTest(myFormula, data = df)
# p-value > sig => Não Rejeita H0 

#Passo 4
#AMOVA => testar se todas as amostras tem médias (mu) iguais
myModel <- aov(myFormula, data = df)
summary(myModel)
# p-value > sig => Não Rejeita H0 


#Passo 5
#Se Existem diferenças
#Identicação de quais as médias que são diferentes
TukeyHSD(myModel)
# p-value > sig => Não Rejeita H0 
model.tables(myModel, type = "effects")
#Encontra a diferença entre a iteração
which(TukeyHSD(myModel)[["colunai"]][, 4] < 0.01)
which(TukeyHSD(myModel)[["colunai:colunaj"]][, 4] < 0.01) #qual(teste.Tukey [fator] [coluna 4] < significancia)
