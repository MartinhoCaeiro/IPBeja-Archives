pnorm(q = 120, mean = 100, sd = 20)
pnorm(q = 1, mean = 0, sd = 1)

pnorm(q = 23, mean = 20, sd = 3)
pnorm(q = 40, mean = 20, sd = 3)
pnorm(q = 13, mean = 20, sd = 3)
1 - pnorm(q = 21, mean = 20, sd = 3)
1 - pnorm(q = 17, mean = 20, sd = 3)
pnorm(q = 25, mean = 20, sd = 3) - pnorm(q = 21.5, mean = 20, sd = 3)
pnorm(q = 18.8, mean = 20, sd = 3) - pnorm(q = 16.2, mean = 20, sd = 3)
pnorm(q = 29.3, mean = 20, sd = 3) - pnorm(q = 17, mean = 20, sd = 3)

qnorm(p = 0.9332, mean = 20, sd = 3)
qnorm(p = 0.1788, mean = 20, sd = 3)
qnorm(p = 0.00062, mean = 20, sd = 3)

set.seed(1)
x <- rnorm(10, 100, 20)
mean(x)
sum((x - mean(x))^2) / length(x)
sqrt(sum((x - mean(x))^2) / length(x))

variancia <- function(y) {
  a <- sum((y - mean(y))^2) / length(y)
  return(a)
}

variancia(x)
