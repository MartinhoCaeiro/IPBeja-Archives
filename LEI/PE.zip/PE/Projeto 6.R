dunif(2.2, 2, 2.5)
runif(10, 2, 2.5)

library(ggplot2)
df <- data.frame(rnorm(10000, 170, 20))
names(df) <- "height"
str(df)
View(df)

ggplot2::ggplot(df, aes(height)) + geom_histogram(fill = 'blue', bins = 100)
df$height2 <- rnorm(10000, 170, 2)
ggplot2::ggplot(df, aes(height2)) + geom_histogram(fill = 'blue', bins = 100)

df2 <- data.frame(c(df$height, df$height2))
str(df2)
df2$dist <- c(rep(1, 10000), rep(2, 10000))
names(df2) <- c("value", "color")

df2$nova <- runif(2000)
df2[, 3]
ggplot2::ggplot(df2, aes(x = value, fill = factor(color))) +
  geom_histogram(fill = 'white', bins = 100) +
  scale_fill_manual(values = c('1' = 'red', '2' = 'white'))