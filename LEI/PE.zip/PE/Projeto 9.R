set.seed(1)
x <- rnorm(10000); x
x2 <- x^2; x2
hist(x2)

y <- rchisq(10000, 1)
hist(y)
y2 <- rchisq(10000, 6)
hist(y2)

a1 <- rnorm(10000)
a2 <- rnorm(10000)
a3 <- rnorm(10000)
a4 <- rnorm(10000)
a5 <- rnorm(10000)
a6 <- rnorm(10000)
b <- a1^2 + a2^2 + a3^2 + a4^2 + a5^2 + a6^2
hist(b)

x <- c(9, 14, 10, 12, 7, 3, 11, 12)
m <- mean(x); m
s <- sd(x); s
n <- length(x); n
t <- qt(0.9, (n - 1)); t
Lmin <- m - t * (s / sqrt(n)); Lmin
Lmax <- m + t * (s / sqrt(n)); Lmax
shapiro.test(x)

df <- data.frame(read_excel("C:/Users/user/Documents/R/IC.xlsx", sheet = "Ex8"))
y <- df$y; y
shapiro.test(y)
m <- mean(y); m
n <- 20
s <- sd(y)
t <- qt(0.99, (n - 1)); t
Lmin <- m - t * (s / sqrt(n)); Lmin
Lmax <- m + t * (s / sqrt(n)); Lmax

df2 <- data.frame(read_excel("C:/Users/user/Documents/R/IC.xlsx", sheet = "Ex9"))
y2 <- df2$y; y2
shapiro.test(y2)
m2 <- mean(y2); m2
n2 <- 36
s2 <- sd(y2)
t2 <- qt(0.975, (n2 - 1)); t2
Lmin2 <- m2 - t2 * (s2 / sqrt(n2)); Lmin2
Lmax2 <- m2 + t2 * (s2 / sqrt(n2)); Lmax2

m3 <- mean(y2); m3
n3 <- 36
s3 <- 60
z3 <- qnorm(0.975); z3
Lmin3 <- m3 - z3 * (s3 / sqrt(n3)); Lmin3
Lmax3 <- m3 + z3 * (s3 / sqrt(n3)); Lmax3

