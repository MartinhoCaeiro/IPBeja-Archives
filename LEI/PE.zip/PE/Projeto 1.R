mydata <- iris
str(mydata)
head(mydata)
mylist <- list(a <- 1, b <- "batata")
str(mylist)
x <- c(2, 3, 1, 2 + 3, 8 / 2, 6, 5, 7, 6, 2^3); y <- 1:3
class(x); typeof(x); str(x); dim(x)
