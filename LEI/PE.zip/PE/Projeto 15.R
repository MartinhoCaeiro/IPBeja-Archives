library(readxl)
library(car)
library(BSDA)
df <- data.frame(read_excel("C:/Users/user/Documents/R/ANOVA.xlsx", sheet = "Ex5"))
df$poison <- factor(df$poison)
df$treat <- factor(df$treat)

boxplot(time ~ poison, data = df)
boxplot(time ~ treat, data = df)
boxplot(time ~ poison * treat, data = df)

for (i in levels(df$poison)) {
  print(shapiro.test(df$time[df$poison == i])$p.value)
}

for (i in levels(df$treat)) {
  print(shapiro.test(df$time[df$treat == i])$p.value)
}

for (i in levels(df$poison)) {
  for (j in levels(df$treat)) {
    print(shapiro.test(df$time[df$poison == i & df$treat == j])$p.value)
  }
}

leveneTest(time ~ poison * treat, data = df)
summary(aov(time ~ poison * treat, data = df))
TukeyHSD(aov(time ~ poison * treat, data = df))
model.tables(aov(time ~ poison * treat, data = df), type = "effects")