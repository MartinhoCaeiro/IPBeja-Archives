library(BSDA)
library(readxl)
df <- data.frame(read_excel("C:/Users/user/Documents/R/TH.xlsx", sheet = "Ex6"))

myFormula <- classificacao ~ factor(desumidificador)
x <- df$classificacao[df$desumidificador == "A"]
shapiro.test(x)

x2 <- df$classificacao[df$desumidificador == "B"]
shapiro.test(x2)
boxplot(myFormula, data = df)

var.test(myFormula, data = df)
library("car")
leveneTest(myFormula, data = df)

t.test(myFormula, data = df, var.equal = TRUE, alternative = "two.sided")
wilcox.test(myFormula, data = df, alternative = "two.sided")

df2 <- data.frame(c(9.6, 9.4, 9.3, 11.2, 11.4, 12.1, 10.4, 9.6, 10.2, 8.8, 13, 10.2,
                    10.6, 13.2, 11.7, 9.6, 8.5, 9.7, 12.3, 12.4, 10.8, 10.8))
df2$processador <- rep(c("A", "B"), c(12, 10))
names(df2) <- c("velocidade", "processador")

myFormula2 <- velocidade ~ factor(processador)
x3 <- df2$velocidade[df2$processador == "A"]
shapiro.test(x3)

x4 <- df2$velocidade[df2$processador == "B"]
shapiro.test(x4)

boxplot(myFormula2, data = df2)

var.test(myFormula2, data = df2)
library("car")
leveneTest(myFormula2, data = df2)

t.test(myFormula2, data = df2, var.equal = TRUE, alternative = "less")
wilcox.test(myFormula2, data = df2, alternative = "less")
