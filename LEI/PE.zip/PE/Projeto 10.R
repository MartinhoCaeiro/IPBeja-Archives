y <- df$x; y
shapiro.test(y)
m <- mean(y)

qnorm(0.95)
1 - pnorm(2.1)
(173.2 - 170) / (20 / 10)

mu0 <- 500
sig <- 0.10
sigma <- 15
n <- 20
m <- 494.092
z0 <- (m - mu0) / ((sigma) / sqrt(n))
qnorm(0.1)
pnorm(z0)

qnorm(0.001)

library(BSDA)
library(readxl)
df <- data.frame(read_excel("C:/Users/user/Documents/R/TH.xlsx", sheet = "Ex1"))
x <- df$x
shapiro.test(x)
z.test(x, mu = 500, sigma.x = 15, alternative = "less")
z.test(x, mu = 500, sigma.x = 15, alternative = "two.sided")
2 * pnorm(-1.7614)

df2 <- data.frame(read_excel("C:/Users/user/Documents/R/TH.xlsx", sheet = "Ex2"))
x2 <- df2$ovos
shapiro.test(x2)
z.test(x2, mu = 55, sigma.x = 8, alternative = "less")
z.test(x2, mu = 50, sigma.x = 8, alternative = "greater")
pnorm(52.94249, 55, 8)
1 - pnorm(52.94249, 55, 8)

x3 <- c(2100, 2025, 2071, 2067, 2150, 2115, 2064, 2088, 1995, 2095)
shapiro.test(x3)
z.test(x3, mu = 2060, sigma.x = 20, alternative = "two.sided")

t0 <- (mean(x3) - 2060) / (sd(x3) / sqrt(length(x3))); t0
p.value <- 2 * (1 - pt(t0, df = (length(x3) - 1))); p.value

t.test(x3, mu = 2060, alternative = "two.sided")
