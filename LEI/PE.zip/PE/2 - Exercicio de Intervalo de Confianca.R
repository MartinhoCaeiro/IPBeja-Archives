#EXERCICIO DE INTERVALO DE CONFIANÇA

#Ex.1
#n = 10
#M = 15
#sd = 4
#p(m > 16) = 1 - p(M <= 16)
1 - pnorm(q = 16, mean = 15, sd = 4 / sqrt(10))


#Ex.2
#amostra: n = 25  m = 140
#população:
#x = comprimento de uma peça
#x ~ N(mu, sd = 10)

#a) Intervalo de Confiança a 95%
#valor de Z onde há 95%
qnorm(0.975, 0, 1)

#Intervalo em que a Média do comprimento das peças produzidas se emcontram (controle de qualidade):
140 - (1.959964 * 10 / sqrt(25))
140 + (1.959964 * 10 / sqrt(25))

#b) Intervalo de Confiança a 81.32%
# 1 - significancia/2
1 - (1 - 0.8132) / 2

#valor de Z onde há 81.32%
qnorm(0.9066, 0, 1)

Intervalo:

  140 - (1.320105 * 10 / sqrt(25))
140 + (1.320105 * 10 / sqrt(25))


#EX.3

library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex3"))
View(df)

y <- df$x

#n = 40
#sd = 2
#x = resistecia a temperatura
#x ~ N (mu, sigma = 2)

n <- 40
s <- 2

#a) Teste Shapiro -> testa se é um distribuição normal
shapiro.test(y)

#p-value  indica a confiabilidade do teste (significancia estatistica)
#nese caso p-value = 20.39% 
#o p-value esta a esquerda do limite de 5% (confiança de 95%), logo confiamos na hipotese nula -> neste caso que é uma distribuição normal 

#Como o p-value = 0.2039 > 0.05, então os dados tem comportamento normal com 95% de confiança


#b) Intervalo de Confiança a 99%

#Média da amostra
m <- mean(y)

#significancia/2
(100 - 99) / 2

#valor de Z onde há 99%
qnorm((1 - 0.005), 0, 1)

#Intervalo:
m - (2.575829 * s / sqrt(n))
m + (2.575829 * s / sqrt(n))


#Ex.4
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex4"))
View(df)

#x ~ N (mu, sigma = 800) Tempo de duração de lampadas 

n <- 50
s <- 800

y <- df$x

#a) Teste Shapiro
shapiro.test(y)

#Como o p-value = 0.1306 > 0.05, então os dados tem comportamento normal com 95% de confiança

#b) Intervalo de Confiança a 90%

#Média da amostra
m <- mean(y)

#valor de Z onde há 90%
z <- qnorm((1 - 0.05), 0, 1)
z

#Intervalo:
Lmin <- m - (z * s / sqrt(n))
Lmax <- m + (z * s / sqrt(n))
Lmin
Lmax


#Ex.5
#x despesa em cada restaurante
#Intervalo ]4.6; 12.8[
#a) Falso. Deviam ser probabilidades, não certezas.
#b) Falso. Deviam ser probabilidades, não certezas. Mais, percentagem utiliza-se para a descrição de acontecimentos (estatística descritiva) e não para probabilidades.
#c) Falso. A despesa média (média da população  µ) não é uma variável e portanto não pode ter uma probabilidade associada.
#d) Verdadeiro. A probabilidade está associada ao intervalo que varia através da variável (estimador) da média (x barra).


#Ex.6
#a) O intervalo vai aumentar
#b) O intervalo se mantem
#c) O intervalo vai aumentar


#Ex.7
amostra <- c(9, 14, 10, 12, 7, 3, 11, 12)
amostra

n <- 8
m <- mean(amostra)
m

#Estimativa do desvio padrão populacional:
s <- sd(amostra)
s


#valor de t onde há 80% de confiança
t <- qt((1 - 0.1), df = 7) # df = n - 1
t

#Intervalo:
Lmin <- m - (t * s / sqrt(n))
Lmax <- m + (t * s / sqrt(n))
Lmin
Lmax

#Teste Shapiro
shapiro.test(amostra)

#Como o p-value = 0.5292 > 0.05, então os dados tem comportamento normal com 95% de confiança


#EX.8
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex8"))
View(df)

#x ~ N (mu, sigma) Tempo de execução das maquinas 

x <- df$y

#a) Teste Shapiro
shapiro.test(x)

#Como o p-value = 0.4195 > 0.05, então os dados tem comportamento normal com 95% de confiança

#b) Intervalo de Confiança a 98%
n <- length(x)
m <- mean(x)
s <- sd(x)
t <- qt((1 - 0.01), df = n - 1)
Lmin <- m - (t * s / sqrt(n)); Lmin
Lmax <- m + (t * s / sqrt(n)); Lmax


Ex.9
library(readxl)
df <- data.frame(read_xlsx("Directoria", sheet = "Ex9"))
View(df)

#x ~ N (mu, sigma) peso transportado por hora 

x <- df$y
shapiro.test(x)

#a)  Intervalo de Confiança a 95%
n <- 36
m <- mean(x); m
s <- sd(x); s
t <- qt((1 - 0.025), df = n - 1)
Lmin <- m - (t * s / sqrt(n)); Lmin
Lmax <- m + (t * s / sqrt(n)); Lmax

#b)  Intervalo de Confiança a 95%, supondo sd = 60
n <- 36
m <- mean(x)
s <- 60
z <- qnorm((1 - 0.025), 0, 1)
Lmin <- m - (z * s / sqrt(n)); Lmin
Lmax <- m + (z * s / sqrt(n)); Lmax

#c) A escolha deverá ser sempre a alínea b) pois o desviopadrão populacional (σ) é conhecido.