#EXERCICIO DE DISTRIBUIÇÃO

#Ex.1
#dado -> p = 2/6(baixa) p = 4/6 (não baixa)
# x 0 = 7 musicas

#a) p (x = 0) = dbinom(x = 0, size = 7, p = 2/6)
dbinom(x = 0, size = 7, p = 2 / 6)

#b) p (x<=4) = pbinom(x = 4, size = 7, prob = 2/6)
pbinom(4, size = 7, prob = 2 / 6)

#c) p (pelo menos 2) = sum(dbinom(2:7, size=7, prob = 2/6)) 
#OU
#p(no máximo 1) => 1 - p(x<=1)= 1 - pbinom(1, 7, 2/6)
sum(dbinom(2:7, size = 7, prob = 2 / 6))
1 - pbinom(1, 7, 2 / 6)


#Ex.2
# fabrica -> p (defeito) = 0.15
# size = 20

#a)  p ( x = 1) 
dbinom(x = 1, size = 20, p = 0.15)

#b) p (no máximo 3) = soma p(0 á 3)
pbinom(q = 3, size = 20, prob = 0.15)
sum(dbinom(0:3, size = 20, prob = 0.15))

#c) p (pelo menos 5) = soma de p (5 á size) = contrário de no máximo 4
sum(dbinom(5:20, size = 20, prob = 0.15))
1 - pbinom(4, 20, 0.15)

#d) p (x = 0)
dbinom(x = 0, size = 20, p = 0.15)

#e)qual o q tal que p(x<=q ) = 0.5?
qbinom(p = 0.5, size = 20, prob = 0.15)

#f) 
binom.test(x = 6, n = 20, p = 0.15, alternative = c("greater"))
# p-value determina a confiança do teste (se p-value > 5% (pois 95% de confiança) o teste é de confiança = acredito)

#g) Não pois se p-value < 10% 


#Ex.3
# p (acerto) = 0.07

#a) p (5) 
dbinom(x = 5, size = 10, p = 0.7)

#b) geométrica ()
dgeom(x = 2, prob = 0.7) # prob de precisar de 3 jogadas para acertar a primeira vez
#pgeom(q = 4, prob = 0.7) # máximo 4 jogadas para acertar a primeira vez

#c) binomial negativa
dnbinom(x = 2, size = 3, prob = 0.7) # na quinta jogada acertar pela  terceira vez
# x = numero de issucessos antes do ultimo sucesso
# size = numero de sucessos 


#Ex.4
# dado estranho -> p(x1) = 2/6  p(x2) = 3/6  p(x3) = 1/6
# p( x1 = 3, x2 = 5, x3 = 2) em 10 lançamentos
x <- c(3, 5, 2)
size <- 10
prob <- c(2 / 6, 3 / 6, 1 / 6)
dmultinom(x, size, prob)


#Ex.5
#Eleição com 4 partidos A. B, C, D com POB  de 0.32, 0.246, 0.124, 0.122 e abstenção de 0.188
#40 eleitores
#6+10+12+4 = 32 votaram logo tem 8 abstenções
x <- c(6, 10, 12, 4, 8)
size <- 40
prob <- c(0.32, 0.246, 0.124, 0.122, 0.188)
dmultinom(x, size, prob)


#Ex.6
#40 doces
#30 mentol e 10 caramelo
#seleciona 5 doces
#Hipergeometrica pq cada vez que acontece um evento muda a prob do proximo evento (só funciona para duas opcões)

#a) p(3 mentol)
dhyper(3, 30, 10, 5)

#b) p(maximo 3 mentol)
phyper(3, 30, 10, 5)

#c) p(pelo menos 4  mentol) = 1 - p(no maximo 3)
1 - phyper(3, 30, 10, 5)


#EX.11
#distribuição normal x~N(mu, sd)
#média = 20
#sd = 3

#Normalização
#Z = (x - média)/sd

#a)p(x<=23)
pnorm(q = 1, mean = 0, sd = 1)

#b)p(x<=40)
pnorm(q = 20 / 3, mean = 0, sd = 1)
pnorm(q = 40, mean = 20, sd = 3)

#c)p(x<14)
pnorm(q = 14, mean = 20, sd = 3)

#d)p(x>21) = 1 - p(x<=21)
1 - pnorm(q = 21, mean = 20, sd = 3)
pnorm(q = 21, mean = 20, sd = 3, lower.tail = FALSE)

#e)p(x>17) = 1 - p(x<=17)
1 - pnorm(q = 17, mean = 20, sd = 3)

#f)p(21,5<=x<=25) = p(x<=25) - p(x<=21,5)
pnorm(q = 25, mean = 20, sd = 3) - pnorm(q = 21.5, mean = 20, sd = 3)

#g)p(16,2<=x<=18,8)
pnorm(q = 18.8, mean = 20, sd = 3) - pnorm(q = 16.2, mean = 20, sd = 3)

#h)p(17<=x<=29,3)
pnorm(q = 29.3, mean = 20, sd = 3) - pnorm(q = 17, mean = 20, sd = 3)

#i) ache 'a' tal que:
#p(x<a) = 0.9332
qnorm(p = 0.9332, mean = 20, sd = 3)

#p(x<a) = 0.1788
qnorm(p = 0.1788, mean = 20, sd = 3)

#p(x<a) = 0.9989
qnorm(p = 0.9989, mean = 20, sd = 3)

#p(x<a) = 0.0062
qnorm(p = 0.0062, mean = 20, sd = 3)
