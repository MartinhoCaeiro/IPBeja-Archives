library(BSDA)
library(readxl)
df <- data.frame(read_excel("C:/Users/user/Documents/R/TH.xlsx", sheet = "Ex4"))
x <- df$tempos
shapiro.test(x)

t0 <- (mean(x) - 420) / (sd(x) / sqrt(length(x))); t0
crit <- -qt(0.99, 15); crit
p.value <- pt(t0, df = 15); p.value

t.test(x, mu = 420, alternative = "less")

x2 <- c(16.1, 15.8, 15.9, 16.1, 15.8, 16.2, 16.0, 15.9)
shapiro.test(x2)

t1 <- (mean(x2) - 16) / (sd(x2) / sqrt(length(x2))); t1
crit <- qt(0.9995, 7); crit
p.value <- 2 * pt(t1, df = 7); p.value

t.test(x2, mu = 16, alternative = "two.sided")