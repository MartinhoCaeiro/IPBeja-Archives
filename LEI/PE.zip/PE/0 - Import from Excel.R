#EXPORT FROM EXCEL

#Excel com uma coluna de dados
library(readxl)
df <- data.frame(read_excel("Directoria", sheet = "Ex1"))
View(df)

# x -> Variavel que vai ser usada
# y -> Nome da coluna no excel
x <- df$y


#Excel com duas coluna de dados
library(readxl)
df <- data.frame(read_excel("Directoria", sheet = "Ex1"))
View(df)

a <- df$classificacao[df$desumidificador == "A"]
b <- df$classificacao[df$desumidificador == "B"]

#Relação entre as colunas 
myFormula <- classificacao ~ factor(desumidificador)


#Criar uma tabela com duas colunas
df <- data.frame(c(9.6, 9.4, 9.3, 11.2, 11.4, 12.1, 10.4, 9.6, 10.2, 8.8, 13, 10.2, 10.6, 13.2, 11.7, 9.6, 8.5, 9.7, 12.3, 12.4, 10.8, 10.8))
View(df)

df$processador <- rep(c("A", "B"), c(12, 10))
names(df) <- c("velocidade", "processador")

a <- df$velocidade[df$processador == "A"]
b <- df$velocidade[df$processador == "B"]

myFormula <- velocidade ~ factor(processador)