library(readxl)
library(car)
library(BSDA)
df <- data.frame(read_excel("C:/Users/user/Documents/R/T2.xlsx", sheet = "Ex1"))
df$lab <- factor(df$lab)

x <- df$velocidade[df$lab == "B"]
shapiro.test(x)

m <- mean(x); m
n <- 10
s <- sd(x)
z <- qt(0.99, df = (n - 1)); z
Lmin <- m - z * (s / sqrt(n)); Lmin
Lmax <- m + z * (s / sqrt(n)); Lmax

s2 <- 1
z2 <- qnorm(0.99); z2
Lmin2 <- m - z2 * (s2 / sqrt(n)); Lmin2
Lmax2 <- m + z2 * (s2 / sqrt(n)); Lmax2

mu <- 5
m3 <- mean(x)
s3 <- sd(x)
h3 <- length(x)
crit <- qt(0.95, df = 9); crit
t0 <- (m3 - mu) / (s3 / sqrt(h3)); t0
p.value <- 1 - pt(t0, df = 9); p.value
pow <- 1 - pt((5.46 - 5.5) / (s3 / sqrt(h3)), df = 9)

df2 <- df[which(df$lab != "A"),]
df2$lab <- factor(df2$lab)
myFormula <- velocidade ~ lab
t.test(myFormula, data = df2, var.equal = FALSE, alternative = "less")

leveneTest(velocidade ~ lab, data = df)
summary(aov(velocidade ~ lab, data = df))
TukeyHSD(aov(velocidade ~ lab, data = df))


df3 <- data.frame(read_excel("C:/Users/user/Documents/R/T2.xlsx", sheet = "Ex2"))
df3$gen <- factor(df3$gen)
df3$trt <- factor(df3$trt)

for (i in levels(df3$gen)) {
  print(shapiro.test(df3$target[df3$gen == i])$p.value)
}

for (i in levels(df3$trt)) {
  print(shapiro.test(df3$target[df3$trt == i])$p.value)
}

for (i in levels(df3$gen)) {
  for (j in levels(df3$trt)) {
    print(shapiro.test(df3$target[df3$gen == i & df3$trt == j])$p.value)
  }
}

leveneTest(target ~ gen * trt, data = df3)
summary(aov(target ~ gen * trt, data = df3))
TukeyHSD(aov(target ~ gen * trt, data = df3))
model.tables(aov(target ~ gen * trt, data = df3), type = "effects")