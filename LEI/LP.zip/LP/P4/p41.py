import random
import math

def uniformDistPares(n):
    paresDistribuidos = [random.randint(0,25)*2 for _ in range(n)]
    return paresDistribuidos

def floatGenerator(numbers):
    newNumbers = [math.sqrt(x) if x >= 0 else 0.0 for x in numbers]
    return newNumbers

def integersTimes3(numbers):
    
    resultado = map(triple,numbers)
    # Forçar o resultado a ser uma lista, se não dá erro.
    resultList = list(resultado)
    return resultList


def triple(x):
    return x*3
   
numbers = [1, 2, 3, 4, 5]

teste1 = integersTimes3(numbers)
print (teste1)


def antiPair(numbers):

    resultado = filter(isImpar, numbers)
    newList = list(resultado)
    return newList

def isImpar(x):
    return x % 2 != 0

teste2 = antiPair(numbers)
print(teste2)