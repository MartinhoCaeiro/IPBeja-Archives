import random
import string

def generateList(n, desvio_padrao=3.4):
    return [random.normalvariate(0, desvio_padrao) for _ in range(n)]


def generateString(N):
    strAleatoria = ''.join(random.choice(string.ascii_letters) for _ in range(N) )
    return strAleatoria


def generateTuple(N):
    listaDoTuplo = [random.randint(-1000, 1000) for _ in range(N)]
    tuploBonito = tuple(listaDoTuplo)

    return tuploBonito

def generatePares(N):
    return [random.randint(-1000, 1000)*2 for _ in range(N)]