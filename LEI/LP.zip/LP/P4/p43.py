frase = "Biscoitos com Chocolate"

def separarPalavras(frase):
    
    return frase.split(" ")

l1 = separarPalavras(frase)
print(l1)

def separarLetras(l1):
    tostaMista = []
    for x in l1:
        listaChar = []
        for c in x:
            listaChar.append(c)
        tostaMista.append(listaChar)
    return tostaMista


def separarLetrasLeonardo(l1):
    return [[c for c in x] for x in l1]


print(separarLetras(l1))
print(separarLetrasLeonardo(l1))