class Professor:
    def __init__(self, nome="Joaquim", titulo="Mestrado"):
        self.nome = nome
        self.titulo = titulo

    @property
    def get_nome(self):
        return self.nome

    def set_nome(self, nome):
        self.nome = nome

    def set_titulo(self, titulo):
        self.titulo = titulo

    def get_titulo(self):
        return self.titulo

    def __str__(self):
        return f"Nome:{self.nome}, titulo:{self.titulo}"

class ProfessorSemVogais(Professor):
    def __iter__(self):
        self.posicao = 0
        return self

    def __next__(self):
        vogais = set("aeiouAEIOU")
        while self.posicao < len(self.nome):
            palavra = self.nome[self.posicao]
            self.posicao += 1
            if palavra not in vogais:
                return palavra
        raise StopIteration

# Create instances of the classes
professor1 = Professor()
professor1.set_nome("João")
professor1.set_titulo("Bacharelado")

professor2 = ProfessorSemVogais(nome="JoaoSilva", titulo="Mestrado")

professor3 = Professor(nome="Maria", titulo="Mestrado")

# Display the objects
print(professor1)
print(professor2)
print(professor3)

# Use next() with list comprehension to get consonants from professor2
consoantes_nome = [char for char in professor2]
print("Consoantes do nome:", consoantes_nome)
