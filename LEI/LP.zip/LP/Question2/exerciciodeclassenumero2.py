class Objetosdodia_adia(list):

    def __init__(self, *args):
        super().__init__(args)

    def __str__(self):
        return f"Objetos do dia a dia: {', '.join(map(str, self))}"

class CaracteristicasObjetos(Objetosdodia_adia):
    def __init__(self, cor, peso, *args):
        super().__init__(*args)
        self.cor = cor
        self.peso = peso

    def __str__(self):
        return f"{super().__str__()} - Cor: {self.cor}, Peso: {self.peso} kg"

objetos_que_euuso = Objetosdodia_adia("Lapis", "Caneta", "Oculos")
print(objetos_que_euuso)

# Pass the objects as arguments when creating CaracteristicasObjetos instance
CaracteristicasObjetos1 = CaracteristicasObjetos("Preto","100","Caneta")
CaracteristicasObjetos2 = CaracteristicasObjetos("Preto","100","Caneta")
CaracteristicasObjetos3 = CaracteristicasObjetos("Azul","150","Lapis")
print(CaracteristicasObjetos1.__doc__)
print(CaracteristicasObjetos2.__doc__)
print(CaracteristicasObjetos3.__doc__)

iterador = iter(CaracteristicasObjetos)
print(next(iterador))  # Saída: Celular
print(next(iterador))  # Saída: Caneta

