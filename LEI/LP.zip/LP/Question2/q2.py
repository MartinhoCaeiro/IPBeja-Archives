class Partido:
    def __init__(self, designacao, posicaoPolitica=None, anoCriacao=1990):
        self.designacao = designacao
        self.anoCriacao = anoCriacao
        self.__posicaoPolitica = self.verificaPosicao(posicaoPolitica)

    def __str__(self):
        return f"Senhoras e senhores, contemplem o partido {self.designacao}! Considerado de {self.__posicaoPolitica} e criado em {str(self.anoCriacao)}"

    def verificaPosicao(self, valor):
        if valor in ["Esquerda", "Centro", "Direita"]:
            return valor
        else:
            print("Essa posição política não é aceite.")

class Militante:
    def __init__(self, nome, partido, dataIntegracao):
        self.nome = nome
        self.partido = partido
        self.dataIntegracao = dataIntegracao

    def __str__(self):
        return f"Partido: {self.partido.designacao}, Nome: {self.nome}, Data de Integracao: {str(self.dataIntegracao)}"

class ConjuntoMilitantes(list):
    def __init__(self):
        super().__init__()
        self.partido_selecionado = None

    def fixar_partido(self, partido):
        self.partido_selecionado = partido

    def __iter__(self):
        self.__index = 0
        return self

    def __next__(self):
        if self.partido_selecionado is None:
            raise ValueError("Sem partido fixado!")

        militantesPartido = []
        for militante in super().__iter__():
            if militante.partido == self.partido_selecionado:
                militantesPartido.append(militante)

        if self.__index < len(militantesPartido):
            resultado = militantesPartido[self.__index]
            self.__index += 1
            return resultado
        else:
            raise StopIteration

# Example usage:
# Creating instances of the Partido class
partido1 = Partido("CHEGA", "Direita", 2019)
partido2 = Partido("PartidoA", "Esquerda", 1995)
partido3 = Partido("PartidoB", "Centro", 2000)

print(partido1.__str__())

# Creating instances of the Militante class
militante1 = Militante("André Ventura", partido1, "2020-01-15")
militante2 = Militante("João", partido2, "2021-05-20")
militante3 = Militante("Maria", partido3, "2022-02-10")

# Creating a ConjuntoMilitantes object and adding militantes to it
conjunto_militantes = ConjuntoMilitantes()
conjunto_militantes.extend([militante1, militante2, militante3])

# Fixing a partido in the ConjuntoMilitantes
conjunto_militantes.fixar_partido(partido2)

# Iterating through and displaying militantes of the selected partido
for militante in conjunto_militantes:
    print(militante)

# Changing the selected partido
conjunto_militantes.fixar_partido(partido3)

# Iterating through and displaying militantes of the new selected partido
for militante in conjunto_militantes:
    print(militante)
