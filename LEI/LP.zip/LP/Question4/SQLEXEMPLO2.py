from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

# SQLite3 database file
db_file = 'familia.db'

@app.route('/')
def show_data():
    # Connect to the SQLite3 database
    connection = sqlite3.connect(db_file)
    cursor = connection.cursor()

    # Create Familia table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Familia (
            id INTEGER PRIMARY KEY,
            name TEXT
        )
    ''')

    # Insert multiple entries into the Familia table
    new_entries = [
        ("Silvas",),
        ("Gomes",),
        ("Martins",)
    ]

    cursor.executemany('INSERT INTO Familia (name) VALUES (?)', new_entries)
    connection.commit()

    # Query the database to get all entries
    cursor.execute('SELECT name FROM Familia')
    entries = cursor.fetchall()

    # Extract names from entries
    names = [entry[0] for entry in entries]

    # Close the database connection
    connection.close()

    return render_template("familia.html", content="Your Name", names=names)

@app.route('/delete_all')
def delete_all_entries():
    try:
        # Connect to the SQLite3 database
        connection = sqlite3.connect(db_file)
        cursor = connection.cursor()

        # Delete all entries in the Familia table
        cursor.execute('DELETE FROM Familia')
        connection.commit()

        # Close the database connection
        connection.close()

        return "All entries deleted successfully."
    except Exception as e:
        return f"An error occurred: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)
