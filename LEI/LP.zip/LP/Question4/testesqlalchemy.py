from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from flask import Flask, render_template, redirect, url_for, request

# Define the database connection URL
db_url = 'sqlite:///familia.db'

# Create the SQLAlchemy engine
engine = create_engine(db_url, echo=True)  # Set echo=True for debugging, remove in production

# Create a base class for declarative models
Base = declarative_base()

# Define your Familia model
class Familia(Base):
    __tablename__ = 'familia'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))

# Create the tables in the database
Base.metadata.create_all(engine)

# Create a session to interact with the database
Session = sessionmaker(bind=engine)

app = Flask("familia")

@app.route('/')
def show_data():
    try:
        # Get the name from the request or use a default value
        name = request.args.get('name', 'DefaultName')

        # Insert the new entry into the Familia table
        session = Session()
        new_entry = Familia(name=name)
        session.add(new_entry)
        session.commit()

        # Query the database to get all entries
        entries = session.query(Familia).all()

        # Extract names from entries
        names = [entry.name for entry in entries]

        return render_template("familia.html", content="Your Name", names=names)
    except Exception as e:
        return f"An error occurred: {str(e)}"

@app.route('/delete_all')
def delete_all_entries():
    try:
        # Delete all entries in the Familia table
        session = Session()
        session.query(Familia).delete()
        session.commit()
        
        return "All entries deleted successfully."
    except Exception as e:
        return f"An error occurred: {str(e)}"

if __name__ == '__main__':
    app.run()
