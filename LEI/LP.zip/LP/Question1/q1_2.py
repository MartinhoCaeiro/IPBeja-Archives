import math as mm
def o_meu_destino(x):
    N = 28
    y = mm.floor((mm.cos(x) + mm.sin(x)) * N)
    return y
def a_sua_sina( nome_completo ):
    N = 4
    y = sum(map(lambda x:mm.floor((mm.cos(x) + mm.sin(x)) * 28),
    (ord(x) for x in nome_completo)))
    return y % N

print(a_sua_sina("Paulo Abade"))