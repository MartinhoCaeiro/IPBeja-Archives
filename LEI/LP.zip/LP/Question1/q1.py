import time
vogais = ["a","e", "i", "o", "u"]
vogaisCap = ["A","E", "I", "O", "U"]
def determina_nome(nome, numero):
    
    contador = 0
    for letra in nome:
        if letra.lower() in vogais:
            contador += 1
    produto = contador * numero

    produto = produto % 3
    return produto




print(determina_nome("Paulo Abade", 23919))


def recurso(nome):
    listaConsoantes = []
    for letra in nome.upper():
        if not letra in vogaisCap and letra != " ":
            listaConsoantes.append(letra)
    return listaConsoantes

print(recurso("Paulo Abade"))

def cauda(nome, contador = 0):
    if nome == "":
        return contador
    primeiraLetra = nome[0]
    resto = nome[1:]
    if primeiraLetra != "" and primeiraLetra != " ":
        contador += 1
    return cauda(resto, contador)
print(cauda("Paulo Abade"))

def fatorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * fatorial(n - 1)

def fibonacci(n):
    fib_numbers = [0, 1]
    for i in range(2, n + 1):
        fib_numbers.append(fib_numbers[i - 1] + fib_numbers[i - 2])
    return fib_numbers[n]

def compreende(f, nome):
    n = len(nome)
    resultados = [(n,)]

    for k in range(n + 1):
        start_time = time.time()
        resultado_f_k = f(k)
        end_time = time.time()
        tempo_execucao = end_time - start_time

        resultados.append((tempo_execucao,))

    return resultados

# Exemplo de uso
resultado_compreende = compreende(fatorial, "abcd")
print(resultado_compreende)