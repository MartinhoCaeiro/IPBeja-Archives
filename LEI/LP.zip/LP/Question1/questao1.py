import random
def a_sua_sina(nome_completo):
    N = 4
    vowels = ["a", "e", "i", "o", "u"]
    y = sum(1 for char in nome_completo.lower() if char in vowels)
    return y / N

print(a_sua_sina("Paulo Abade"))

def fn(r, n ,a = 0, b = 1, d = 1):
    k=1
    resultado = 0
    while k <= n:
        resultado += (a + (k - 1)*d)*b*pow(r, k-1)
        k+=1
    return resultado

valorR = random.randint(1, len("Paulo Abade"))
print (fn(valorR, 5))



def fnRecursiva(r, n ,a = 0, b = 1, d = 1, k = 1, resultado = 0):
    if k > n:
        return resultado
    resultado += (a +(k - 1)*d)*b*pow(r, k-1)
    k+=1
    return fnRecursiva(r, n, a, b, d, k, resultado)
print (fnRecursiva(valorR, 5))
