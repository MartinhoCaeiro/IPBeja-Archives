# Martinho Caeiro - 23917
# Todas as alineas foram realizadas

#a)
def sina(nome_completo, numero):
 N = 4
 y = sum((ord(y) for y in nome_completo))
 return y + numero / N

print(sina("Martinho Caeiro", 23917)) # Imprime resultado da função sina()

#---------------------------------------------------------------

#b)
def fn(r, a=0, b=1, d=1, n=1): # Definir variáveis por defeito
    result = 0
    k = 1

    for k in range(1, n + 1):
        result += (a + (k - 1) * d) * b * (r ** (k - 1)) # Série Aritmético-Geométrica
        k += 1

    return result

def gn(nome_completo): # Coloca os valores da função fn() numa lista
    result_list = []
    n_values = range(1, len(nome_completo) + 1) # +1 Pois o len é exclusive na segunda variável

    for n in n_values:
        result = fn(0.5, 1, 2, 3, n)  # Valores de exemplo para a, b, d
        result_list.append(result)

    return result_list

# Exemplo
nome_completo = "Martinho Caeiro" # Definição do Nome de Aluno
resultado_gn = gn(nome_completo)
print(resultado_gn)

#-----------------------------------------------------------------------

#c)
def fn_alternative(r, a=0, b=1, d=1, n=1, k=1): # Definir variáveis por defeito
    if k > n:
        return 0
    else:
        term = (a + (k - 1) * d) * b * (r ** (k - 1)) # Série Aritmético-Geométrica
        return term + fn_alternative(r, a, b, d, n, k + 1)

def gn_alternative(nome_completo): # Coloca os valores da função fn() numa lista
    result_list = []
    n_values = range(1, len(nome_completo) + 1) # +1 Pois o len é exclusive na segunda variável

    for n in n_values:
        result = fn_alternative(0.5, 1, 2, 3, n)  # Valores de exemplo para a, b, d
        result_list.append(result)

    return result_list

# Exemplo
nome_completo = "Martinho Caeiro" # Definição do Nome de Aluno
resultado_gn_alternative = gn_alternative(nome_completo)
print(resultado_gn_alternative)