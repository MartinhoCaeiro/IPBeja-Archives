# Martinho Caeiro - 23917
# Alineas a) e b) estão realizadas, c) está com erro

#a)
class ConjuntoCoisasDoMeuDia:
    def __init__(self, coisa=None):
        self.coisa = coisa

    def __str__(self):
        return f"Coisas do Meu Dia: {self.coisa}\n"
    
    def set_coisas(self, coisa):
            self.coisa = coisa

    
# Demonstração do funcionamento
coisa1 = ConjuntoCoisasDoMeuDia("Coisa1")
coisa2 = ConjuntoCoisasDoMeuDia("Coisa2")
coisa3 = ConjuntoCoisasDoMeuDia("Coisa3")
coisa4 = ConjuntoCoisasDoMeuDia()
coisa4.set_coisas("Coisa4")

print(coisa1)
print(coisa2)
print(coisa3)
print(coisa4)

#------------------------------------------------------

#b)
class ConjuntoCor:
    def __init__(self, cor, coisa):
        self.cor = cor
        self.coisa = coisa

    # Funções de acesso para o atributo 'cor'
    def get_cor(self):
        return self.cor

    def set_cor(self, nova_cor):
        self.cor = nova_cor

    # Funções de acesso para o atributo 'coisa'
    def get_coisa(self):
        return self.coisa

    def set_coisa(self, nova_coisa):
        self.coisa = nova_coisa

    def __str__(self):
        return f"Cor: {self.cor}\n{self.coisa}\n"

# Demonstração do funcionamento
cor1 = ConjuntoCor("cor1", coisa1)
cor2 = ConjuntoCor("cor2", coisa2)
cor3 = ConjuntoCor("cor3", coisa3)
cor4 = ConjuntoCor("cor4", coisa2)


print(cor1)
print(cor2)
print(cor3)
print(cor4)

#----------------------------------------------------------

#c)
class ConjuntoCores(list):
    def __init__(self, cor=[]):
        super().__init__(cor)
        self.coisa_seleccionada = None

    def set_coisa_seleccionada(self, coisa):
        self.coisa_seleccionado = coisa

    def __iter__(self):
        self.__index = 0
        return self

    def __next__(self):
        if self.coisa_seleccionada is None:
            raise ValueError("Coisa não selecionada. Utilize set_coisa_seleccionada para definir a coisa.")

        while self.__index < len(self):
            cor = self[self.__index]
            self.__index += 1

            if cor.get_coisa() == self.coisa_seleccionada:
                return cor

        raise StopIteration("Todas as cores da coisa foram percorridas.")

# Demonstração do funcionamento
conjunto_cores = ConjuntoCor([cor1, cor2, cor3])

# Fixar a coisa selecionada
conjunto_cores.set_cor_seleccionada(coisa2)

# Iterar sobre as cores da coisa selecionada
print("\nCores da Coisa 2:")
for militante in conjunto_militantes:
    print(militante.get_nome())