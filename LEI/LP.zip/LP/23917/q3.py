# Martinho Caeiro - 23917
# A alinea a) está a funcionar
# A alinea b) está a funcionar mas sem 'o número de intervalos do histograma deve ser bins=50'
# As alineas c) e d) não foram realizadas

import numpy.random as ra
import matplotlib.pyplot as plt
import numpy as np

#a)
# Intervalo de representação e pontos
t = np.linspace(-np.pi, np.pi, 101)

# Funções definidas
def x(t):
    return np.sqrt(2) * np.sin(t) ** 3

def y(t):
    return -np.cos(t) ** 3 - np.cos(t) ** 2 + 2 * np.cos(t)


# Valores das funções nos pontos
x = x(t)
y = y(t)

# Criar o gráfico
plt.plot(x, y)

# Adicionar título e rótulos dos eixos
plt.title('Gráfico das Funções')
plt.xlabel('Eixo x')
plt.ylabel('Eixo y')

# Adicionar legenda
plt.legend('Mostra um gráfico das funções')

# Salvar o gráfico em um arquivo PDF
plt.savefig('sopa.pdf')

# Mostrar o gráfico
plt.show()

#-----------------------------------------------------

#b)
rng = ra.default_rng()
x = rng.normal(178, 30, size=1000)
y = rng.normal(165, 20, size=1000)

# Criar o gráfico
plt.plot(x, y)

# Adicionar título e rótulos dos eixos
plt.title('Gráfico do Random')
plt.xlabel('Eixo x')
plt.ylabel('Eixo y')

# Adicionar legenda
plt.legend('Mostra um Gráfico do Random')

# Mostrar o gráfico
plt.show()