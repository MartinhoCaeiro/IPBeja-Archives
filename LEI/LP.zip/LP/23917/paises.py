# Martinho Caeiro - 23917
# A alinea a) tem a sintax feita, mas não sei se está a funcionar, provavelmente por não haver internet?

from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

# Configurações do SQLite
DATABASE = 'paises.db'

# Função para conectar ao banco de dados SQLite
def connect_db():
    return sqlite3.connect(DATABASE)

# Rota para a página inicial
@app.route('/')
def index():
    return "Hello Damn World!"

# Rota para a página da família
@app.route('/paises/<int:numero_pais>')
def paises(numero_pais):
    # Conecta ao banco de dados
    conn = connect_db()
    cursor = conn.cursor()

    # Consulta para obter informações sobre o aluno
    cursor.execute("SELECT * FROM paises WHERE numero_pais=?", (numero_pais))
    aluno_info = cursor.fetchone()

    # Fecha a conexão
    conn.close()

    if pais_info:
        return render_template('paises.html', nome=pais_info[1], habitantes=pais_info[2])
    else:
        return "O Pais não encontrado na base de dados."

if __name__ == '__main__':
    app.run(port=23917)