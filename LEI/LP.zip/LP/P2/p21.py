
e1 = [2, 6, -1]
e2 = [3, 1, -5]
e3 = [6, 3, 0]

matriz = [e1, e2, e3]


# This functions finds the 
# determinant of Matrix
def determinante(matriz):
 
    ans = (matriz[0][0] * (matriz[1][1] * matriz[2][2] -
                        matriz[2][1] * matriz[1][2]) -
           matriz[0][1] * (matriz[1][0] * matriz[2][2] -
                        matriz[1][2] * matriz[2][0]) +
           matriz[0][2] * (matriz[1][0] * matriz[2][1] -
                        matriz[1][1] * matriz[2][0]))
    return ans


def cramer(coeficiente):
 
    # Matrix d using coeff as given in 
    # cramer's rule
    d = [[coeficiente[0][0], coeficiente[0][1], coeficiente[0][2]],
         [coeficiente[1][0], coeficiente[1][1], coeficiente[1][2]],
         [coeficiente[2][0], coeficiente[2][1], coeficiente[2][2]]]
     
    # Matrix d1 using coeff as given in 
    # cramer's rule
    d1 = [[coeficiente[0][3], coeficiente[0][1], coeficiente[0][2]],
          [coeficiente[1][3], coeficiente[1][1], coeficiente[1][2]],
          [coeficiente[2][3], coeficiente[2][1], coeficiente[2][2]]]
     
    # Matrix d2 using coeff as given in 
    # cramer's rule
    d2 = [[coeficiente[0][0], coeficiente[0][3], coeficiente[0][2]],
          [coeficiente[1][0], coeficiente[1][3], coeficiente[1][2]],
          [coeficiente[2][0], coeficiente[2][3], coeficiente[2][2]]]
     
    # Matrix d3 using coeff as given in 
    # cramer's rule
    d3 = [[coeficiente[0][0], coeficiente[0][1], coeficiente[0][3]],
          [coeficiente[1][0], coeficiente[1][1], coeficiente[1][3]],
          [coeficiente[2][0], coeficiente[2][1], coeficiente[2][3]]]
 
    # Calculating Determinant of Matrices 
    # d, d1, d2, d3
    D = determinante(d)
    D1 = determinante(d1)
    D2 = determinante(d2)
    D3 = determinante(d3)
     
    print("D is : ", D)
    print("D1 is : ", D1)
    print("D2 is : ", D2)
    print("D3 is : ", D3)
 
    # Case 1
    if (D != 0):
       
        # Coeff have a unique solution. 
        # Apply Cramer's Rule
        x = D1 / D
        y = D2 / D
         
        # calculating z using cramer's rule
        z = D3 / D  
         
        print("Value of x is : ", x)
        print("Value of y is : ", y)
        print("Value of z is : ", z)
 
    # Case 2
    else:
        if (D1 == 0 and D2 == 0 and
            D3 == 0):
            print("Infinite solutions")
        elif (D1 != 0 or D2 != 0 or
              D3 != 0):
            print("No solutions")
 
# Driver Code
if __name__ == "__main__":
 
    # storing coefficients of linear 
    # equations in coeff matrix
    coeficiente = [[2, -1, 3, 9],
             [1, 1, 1, 6],
             [1, -1, 1, 2]]
 
    cramer(coeficiente)