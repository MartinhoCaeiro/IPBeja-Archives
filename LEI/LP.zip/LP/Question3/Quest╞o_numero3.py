from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib.colors import red, green, blue
import numpy as np
import matplotlib.pyplot as mpl
import math

a = 1
b = 1
lista_F = []
lista_G = []
lista_H = []

for x in range(1,101):
    lista_F.append(a*(x**3)+b * x +1.0)
    lista_G.append(a*(x**2)-b * x +1.0)
    lista_H.append(a*(x**2)-b * (x**2) - 2.0)

mpl.plot(lista_F, label = "Função F")
mpl.plot(lista_G, label = "Função G")
mpl.plot(lista_H, label="Função H")
mpl.xlim(-10.0,10.0)
mpl.ylim(0,600)
mpl.xlabel('Eixo X')
mpl.ylabel('Eixo Y')
mpl.title('Três Funções Diferentes')

mpl.savefig(luma.pdf)
mpl.show()


#
U = np.random.rand(4, 4)
V = np.random.normal(loc=-5, scale=2.0, size=(4, 4))
produto = U * V
print(V)
#print (produto)
#print(U)   
matrizInversa = np.linalg.inv(U)
matrizTransposta = np.transpose(U)
#print(matrizInversa)
#print(matrizTransposta)