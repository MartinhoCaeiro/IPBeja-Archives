from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib.colors import red, green, blue
import numpy as np
import matplotlib.pyplot as mpl
import math

pdf = canvas.Canvas("maneta.pdf", A4)
pdf.setFont("Times-Roman",12)
pdf.setFillColor(red)
pdf.drawString(2*cm, 10*cm,"Paulo Abade")
x_values = np.linspace(0, np.pi, 1000)
y_values = 2 * np.sin(x_values) + x_values**2
mpl.plot(x_values, y_values, color='blue')
mpl.title("Função: f(x) = 2 sin(x) + x^2")
mpl.savefig("figura.png")
pdf.drawImage("figura.png", 10*cm, 10*cm, 100, 100)







pdf.save()


U = np.random.rand(100, 100)*2
colunasSelecionadas = U[:, 19:80]

media = np.mean(colunasSelecionadas, axis = 0)
desvioPadrao = np.std(colunasSelecionadas, axis = 0)
#print (U)
print (media)
print (desvioPadrao)