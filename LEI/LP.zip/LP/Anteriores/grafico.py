import matplotlib.pyplot as plt
import numpy as np

# Funções definidas
def f(x, a, b):
    return a * x**3 + b * x + 1.0

def g(x, a, b):
    return a * x**2 - b * x + 1.0

def h(x, a, b):
    return a * x**2 - b * x**2 - 2.0

# Parâmetros a e b
a = 0.5
b = 0.2

# Intervalo de representação e pontos
x = np.linspace(-10.0, 10.0, 100)

# Valores das funções nos pontos
y_f = f(x, a, b)
y_g = g(x, a, b)
y_h = h(x, a, b)

# Criar o gráfico
plt.plot(x, y_f, label='f(x) = {:.1f}x^3 + {:.1f}x + 1.0'.format(a, b))
plt.plot(x, y_g, label='g(x) = {:.1f}x^2 - {:.1f}x + 1.0'.format(a, b))
plt.plot(x, y_h, label='h(x) = {:.1f}x^2 - {:.1f}x^2 - 2.0'.format(a, b))

# Adicionar título e rótulos dos eixos
plt.title('Gráfico das Funções')
plt.xlabel('Eixo x')
plt.ylabel('Eixo y')

# Adicionar legenda
plt.legend('Mostra um gráfico das funções')

# Salvar o gráfico em um arquivo PDF
plt.savefig('luma.pdf')

# Mostrar o gráfico
plt.show()
