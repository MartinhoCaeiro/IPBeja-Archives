def a_sua_sina(nome_completo):
    N = 4
    # A função soma os valores ASCII de todos os caracteres no nome contabilizando apenas as vogais
    vogais = 'aeiouAEIOU'
    y = sum((ord(char) for char in nome_completo if char in vogais))
    return y / N

# Substitua "SeuNomeCompleto" pelo seu nome completo sem acentos nem cedilhas
seu_nome_completo = "MartinhoCaeiro"

# Chama a função a_sua_sina() com o nome completo como argumento e imprime o resultado
resultado = a_sua_sina(seu_nome_completo)
print("Resultado da função a_sua_sina():", resultado)
