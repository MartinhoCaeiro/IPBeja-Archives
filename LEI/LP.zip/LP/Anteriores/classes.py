class Partido:
    def __init__(self, designacao, ano_criacao=None, posicao_politica=None):
        self.designacao = designacao
        self.ano_criacao = ano_criacao
        self.posicao_politica = posicao_politica

    def __str__(self):
        return f"Partido: {self.designacao}\nAno de Criação: {self.ano_criacao}\nPosição Política: {self.posicao_politica}\n"
    
    def set_ano_criacao(self, ano):
        if isinstance(ano, int):
            self.ano_criacao = ano
        else:
            print("O ano de criação deve ser um número inteiro.")
    
    def set_posicao_politica(self, posicao):
        if posicao in ["centro", "direita", "esquerda"]:
            self.posicao_politica = posicao
        else:
            print("Posição política inválida. Deve ser 'centro', 'direita' ou 'esquerda'.")

    
# Demonstração do funcionamento
partido1 = Partido("Partido A", 2000, "centro")

partido2 = Partido("Partido B", 2010)

partido3 = Partido("Partido C", posicao_politica="direita")
partido3.set_ano_criacao(1995)

partido4 = Partido("Partido D")
partido4.set_posicao_politica("esquerda")

print(partido1)
print(partido2)
print(partido3)
print(partido4)

#------------------------------------------------------

class Militante:
    def __init__(self, nome, partido, data_inscricao):
        self.nome = nome
        self.partido = partido
        self.data_inscricao = data_inscricao

    # Funções de acesso para o atributo 'nome'
    def get_nome(self):
        return self.nome

    def set_nome(self, novo_nome):
        self.nome = novo_nome

    # Funções de acesso para o atributo 'partido'
    def get_partido(self):
        return self.partido

    def set_partido(self, novo_partido):
        self.partido = novo_partido

    # Funções de acesso para o atributo 'data_inscricao'
    def get_data_inscricao(self):
        return self.data_inscricao

    def set_data_inscricao(self, nova_data_inscricao):
        self.data_inscricao = nova_data_inscricao

    def __str__(self):
        return f"Militante: {self.nome}\n{self.partido}Data de Inscrição: {self.data_inscricao}\n"

# Demonstração do funcionamento
militante1 = Militante("João", partido1, "2022-01-16")
militante2 = Militante("Maria", partido2, "2022-01-16")
militante3 = Militante("Pedro", partido1, "2022-01-16")

print(militante1)
print(militante2)
print(militante3)

#----------------------------------------------------------

class ConjuntoMilitantes(list):
    def __init__(self, militantes=[]):
        super().__init__(militantes)
        self.partido_seleccionado = None

    def set_partido_seleccionado(self, partido):
        self.partido_seleccionado = partido

    def __iter__(self):
        self.__index = 0
        return self

    def __next__(self):
        if self.partido_seleccionado is None:
            raise ValueError("Partido não selecionado. Utilize set_partido_seleccionado para definir o partido.")

        while self.__index < len(self):
            militante = self[self.__index]
            self.__index += 1

            if militante.get_partido() == self.partido_seleccionado:
                return militante

        raise StopIteration("Todos os militantes do partido foram percorridos.")

# Demonstração do funcionamento
conjunto_militantes = ConjuntoMilitantes([militante1, militante2, militante3])

# Fixar o partido selecionado
conjunto_militantes.set_partido_seleccionado(partido1)

# Iterar sobre os militantes do partido selecionado
print("\nMilitantes do Partido A:")
for militante in conjunto_militantes:
    print(militante.get_nome())

#-------------------------------------------------
    
import http.server
import socketserver

class ConjuntoMilitantes(list):
    # ... (código anterior da classe)

    def criar_index(self, nome_arquivo="index.html"):
        with open(nome_arquivo, "w") as arquivo:
            arquivo.write("<html>\n<head><title>Lista de Militantes</title></head>\n<body>\n")
            for militante in self:
                nome_militante = militante.get_nome()
                nome_partido = militante.get_partido().designacao
                arquivo.write(f"<p>{nome_militante} - {nome_partido}</p>\n")
            arquivo.write("</body>\n</html>")

# Criar o arquivo index.html
conjunto_militantes.criar_index()

# Iniciar o servidor HTTP
porta = 8000
Handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("", porta), Handler) as httpd:
    print(f"Serving on port {porta}")
    httpd.serve_forever()
