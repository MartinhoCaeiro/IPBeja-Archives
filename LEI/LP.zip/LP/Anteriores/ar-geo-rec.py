def fn_recursive(r, a=0, b=1, d=1, n=1, k=1): # Definir variáveis por defeito
    if k > n:
        return 0
    else:
        term = (a + (k - 1) * d) * b * (r ** (k - 1)) # Série Aritmético-Geométrica
        return term + fn_recursive(r, a, b, d, n, k + 1)

def gn_recursive(nome_completo): # Coloca os valores da função fn() numa lista
    result_list = []
    n_values = range(1, len(nome_completo) + 1)

    for n in n_values:
        result = fn_recursive(0.5, 1, 2, 3, n)  # Valores de exemplo para a, b, d
        result_list.append(result)

    return result_list

# Exemplo
nome_completo = "MartinhoCaeiro"
resultado_gn_recursive = gn_recursive(nome_completo)
print(resultado_gn_recursive)
