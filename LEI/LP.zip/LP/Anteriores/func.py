nome_completo = "MartinhoCaeiro"  # Substitua pelo seu nome completo
numero_aluno = 23917  # Substitua pelo seu número de aluno

#---------------------------------------------------------

def determina_nome(nome, numero):
    # Função para contar o número de consoantes em uma string
    def contar_consoantes(s):
        consoantes = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"
        return sum(1 for char in s if char in consoantes)

    # Conta o número de consoantes no nome e multiplica pelo número do aluno
    resultado = contar_consoantes(nome) * numero

    # Calcula o resto da divisão por 3 e retorna o resultado
    return resultado % 3

resultado_final = determina_nome(nome_completo, numero_aluno)
print(f"O resultado da função é: {resultado_final}")

#-----------------------------------------------------------

def recurso(nome):
    resultado_determina_nome = determina_nome(nome, numero_aluno)  # Substitua pelo seu número de aluno

    if resultado_determina_nome == 0:
        # Função para obter conjunto de consoantes do nome
        def consoantes(nome):
            return set(char for char in nome if char.isalpha() and char.lower() not in "aeiou")

        return consoantes(nome)
    
    elif resultado_determina_nome == 1:
        # Função para obter número total de consoantes e vogais do nome
        def contar_consoantes_e_vogais(nome):
            consoantes = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"
            vogais = "aeiouAEIOU"
            num_consoantes = sum(1 for char in nome if char in consoantes)
            num_vogais = sum(1 for char in nome if char in vogais)
            return num_consoantes + num_vogais

        return contar_consoantes_e_vogais(nome)
    
    elif resultado_determina_nome == 2:
        # Função para obter lista de consoantes capitalizadas na ordem
        def consoantes_capitalizadas(nome):
            consoantes = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"
            return [char.upper() for char in nome if char in consoantes]

        return consoantes_capitalizadas(nome)
   
    else:
        return None
    
resultado_final = recurso(nome_completo)
print(f"O resultado da função recurso é: {resultado_final}")

#-------------------------------------------------------------

def cauda(nome):
    # Função interna para auxiliar na recursão de cauda
    def contar_caracteres_aux(nome, acumulador):
        if not nome:
            # Se a string estiver vazia, retorna o acumulador
            return acumulador
        else:
            # Caso contrário, chama recursivamente com a string reduzida e incrementa o acumulador
            return contar_caracteres_aux(nome[1:], acumulador + 1)

    # Chama a função interna com os parâmetros iniciais
    return contar_caracteres_aux(nome, 0)

resultado_final = cauda(nome_completo)
print(f"O número total de caracteres do nome é: {resultado_final}")

#--------------------------------------------------------------

import time

# Função auxiliar para medir o tempo de execução de outra função
def timeit(func, *args):
    start_time = time.time()
    func(*args)
    end_time = time.time()
    return end_time - start_time

# Função para calcular o fatorial
def fatorial(k):
    if k == 0 or k == 1:
        return 1
    else:
        return k * fatorial(k - 1)

# Função para calcular o Fibonacci
def fibonacci(k):
    if k == 0:
        return 0
    elif k == 1:
        return 1
    else:
        a, b = 0, 1
        for _ in range(2, k + 1):
            a, b = b, a + b
        return b

def compreende(f, nome):
    n = len(nome)

    if f == fatorial:
        # Lista de tuplas usando compreensão de lista
        resultados = [(n, timeit(f, k)) for k in range(n + 1)]
        return resultados
    elif f == fibonacci:
        # Lista de tuplas usando compreensão de lista
        resultados = [(n, timeit(f, k)) for k in range(n + 1)]
        return resultados
    else:
        return None

# Função exemplo: fatorial
resultado_fatorial = compreende(fatorial, nome_completo)
print("Resultado para fatorial:", resultado_fatorial)

# Função exemplo: fibonacci
resultado_fibonacci = compreende(fibonacci, nome_completo)
print("Resultado para fibonacci:", resultado_fibonacci)


