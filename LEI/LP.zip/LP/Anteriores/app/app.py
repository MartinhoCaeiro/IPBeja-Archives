from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

# Configurações do SQLite
DATABASE = 'familia.db'

# Função para conectar ao banco de dados SQLite
def connect_db():
    return sqlite3.connect(DATABASE)

# Rota para a página inicial
@app.route('/')
def index():
    return "Hello Damn World!"

# Rota para a página da família
@app.route('/familia/<int:aluno_numero>')
def familia(aluno_numero):
    # Conecta ao banco de dados
    conn = connect_db()
    cursor = conn.cursor()

    # Consulta para obter informações sobre o aluno
    cursor.execute("SELECT * FROM familia WHERE aluno_numero=?", (aluno_numero,))
    aluno_info = cursor.fetchone()

    # Fecha a conexão
    conn.close()

    if aluno_info:
        return render_template('familia.html', nome=aluno_info[1], parentesco=aluno_info[2])
    else:
        return "Aluno não encontrado na base de dados."

if __name__ == '__main__':
    app.run(port=5000 + 23917)
