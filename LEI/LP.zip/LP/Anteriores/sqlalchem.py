from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

# Criando uma instância do SQLite em memória
engine = create_engine('sqlite:///:memory:', echo=True)

# Declarando a base do modelo
Base = declarative_base()

# Definindo a tabela Partido
class Partido(Base):
    __tablename__ = 'partidos'

    id = Column(Integer, primary_key=True)
    nome = Column(String)
    dirigente = Column(String)

# Definindo a tabela Distrito
class Distrito(Base):
    __tablename__ = 'distritos'

    id = Column(Integer, primary_key=True)
    nome = Column(String)

# Definindo a tabela DistritoEleitoral
class DistritoEleitoral(Base):
    __tablename__ = 'distritos_eleitorais'

    id = Column(Integer, primary_key=True)
    distrito_id = Column(Integer, ForeignKey('distritos.id'))
    partido_id = Column(Integer, ForeignKey('partidos.id'))
    votos = Column(Integer)

    # Relacionamentos
    distrito = relationship('Distrito', back_populates='distritos_eleitorais')
    partido = relationship('Partido', back_populates='distritos_eleitorais')

# Adicionando os relacionamentos às classes relacionadas
Distrito.distritos_eleitorais = relationship('DistritoEleitoral', order_by=DistritoEleitoral.id, back_populates='distrito')
Partido.distritos_eleitorais = relationship('DistritoEleitoral', order_by=DistritoEleitoral.id, back_populates='partido')

# Criando as tabelas no banco de dados
Base.metadata.create_all(engine)

# Criando uma sessão
Session = sessionmaker(bind=engine)
session = Session()

# Adicionando dados de exemplo
partido1 = Partido(nome='Partido A', dirigente='Dirigente A')
distrito1 = Distrito(nome='Distrito 1')
distrito_eleitoral1 = DistritoEleitoral(distrito=distrito1, partido=partido1, votos=100)

session.add_all([partido1, distrito1, distrito_eleitoral1])
session.commit()

# Realizando uma consulta de exemplo
resultado = (
    session.query(DistritoEleitoral)
    .join(Distrito)
    .join(Partido)
    .filter(DistritoEleitoral.partido == partido1, DistritoEleitoral.distrito == distrito1)
    .all()
)

# Exibindo os resultados
for item in resultado:
    print(f'Distrito: {item.distrito.nome}, Partido: {item.partido.nome}, Votos: {item.votos}')
