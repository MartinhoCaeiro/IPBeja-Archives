import numpy as np

# Cria uma matriz aleatória U de dimensão 4x4 com números uniformemente distribuídos entre 0 e 1.0
U = np.random.rand(4, 4)

# Cria uma matriz aleatória V de dimensão 4x4 com números com distribuição normal (média=1.0, desvio padrão=2.0)
V = np.random.normal(loc=1.0, scale=2.0, size=(4, 4))

# Calcula o produto ponto a ponto (element-wise) entre U e V
resultado_produto_ponto_a_ponto = U * V

# Obtem a matriz inversa e a transposta de U
inversa_U = np.linalg.inv(U)
transposta_U = U.T

# Imprime os resultados
print("Matriz U:\n", U)
print("\nMatriz V:\n", V)
print("\nProduto ponto a ponto de U por V:\n", resultado_produto_ponto_a_ponto)
print("\nMatriz Inversa de U:\n", inversa_U)
print("\nTransposta de U:\n", transposta_U)
