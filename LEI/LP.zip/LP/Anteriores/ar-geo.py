def fn(r, a=0, b=1, d=1, n=1): # Definir variáveis por defeito
    result = 0
    k = 1

    while k <= n:
        result += (a + (k - 1) * d) * b * (r ** (k - 1)) # Série Aritmético-Geométrica
        k += 1

    return result

def gn(nome_completo): # Coloca os valores da função fn() numa lista
    result_list = []
    n_values = range(1, len(nome_completo) + 1)

    for n in n_values:
        result = fn(0.5, 1, 2, 3, n)  # Valores de exemplo para a, b, d
        result_list.append(result)

    return result_list

# Exemplo
nome_completo = "MartinhoCaeiro"
resultado_gn = gn(nome_completo)
print(resultado_gn)
