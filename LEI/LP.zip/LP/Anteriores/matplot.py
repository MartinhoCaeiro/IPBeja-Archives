import numpy as np
import matplotlib.pyplot as plt

def matplota(a, b, d, n=100):
    # Cria um array de valores para t no intervalo de -2pi a 2pi
    t = np.linspace(-2 * np.pi, 2 * np.pi, n)
    
    # Calcula as coordenadas x e y usando as equações de Lissajou
    x = np.sin(a * t + d)
    y = np.sin(b * t)
    
    # Cria o gráfico de dispersão
    plt.scatter(x, y, c=t, cmap='viridis', marker='.')
    
    # Adiciona rótulos e título ao gráfico
    plt.xlabel('x(t) = sin(at + d)')
    plt.ylabel('y(t) = sin(bt)')
    plt.title('Figura de Lissajou para a={}, b={}, d={}'.format(a, b, d))
    
    # Adiciona uma barra de cores para mostrar a variação de t
    cbar = plt.colorbar()
    cbar.set_label('t')
    
    # Exibe o gráfico
    plt.show()

# Parâmetros para exemplo
matplota(a=5, b=4, d=np.pi/2)
