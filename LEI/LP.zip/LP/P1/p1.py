def fibonacci(n):
    if n in {0,1}:
        return n
        
    return fibonacci(n - 1) + fibonacci(n - 2)

print ([fibonacci(n) for n in range(20)])

fib_constant_list = [1./fibonacci(1)]

def fib_constant(n):
    if(n == 0):
        new_fib_constant = 0
    else:
        new_fib_constant = 1./fibonacci(n)
    
    return new_fib_constant

print (sum(fib_constant(n) for n in range(20)))

def relativeFibonacci():
    for n in range(1, 20):
        relative = 0.000001
        exact =+ fib_constant(n)
        aprox = 3.360
        error = abs((exact - aprox)/exact)

        if(error <= relative):
            return error
        break

print (relativeFibonacci)