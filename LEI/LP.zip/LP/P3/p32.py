def removeVowels(alguma):
    if not alguma:
        return alguma

    vowels = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]
    primeiroChar = alguma[0]
    restoChar = alguma[1:]
    if primeiroChar in vowels:
        return removeVowels(restoChar) 
    return primeiroChar + removeVowels(restoChar)


def racismoB(alguma):
    if not alguma:
        return alguma
    vowels = ["b", "B"]
    primeiroChar = alguma[0]
    restoChar = alguma[1:]
    if primeiroChar in vowels:
        primeiroChar = "a"
        return primeiroChar + racismoB(restoChar)
    return primeiroChar + racismoB(restoChar) 


count = 0

def countVowels(alguma):
    global count
    if not alguma: 
        return count
    
    vowels = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]
    primeiroChar = alguma[0]
    restoChar = alguma[1:]
    if primeiroChar in vowels:
        count += 1

    return countVowels(restoChar)


def paresDentroIntervalo(a, b, lista = []):
    if a == b:
        return lista
    if ((a + 1) % 2 == 0 and a + 1 != b):
        lista.append(a+1)
        return paresDentroIntervalo(a+1, b, lista)
    return paresDentroIntervalo(a+1, b, lista)
        

listaFinal = paresDentroIntervalo(0, 10)
print(listaFinal)