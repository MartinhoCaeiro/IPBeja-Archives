import random

listabonita = []

def recursivaAleatorios(n):
    if n > 0:
        x = random.randint(0, 100)
        listabonita.append(x)
        return recursivaAleatorios(n - 1)
    else:
        return listabonita

def somaImpares(lista):
    impar = 0
    for x in lista:
        if x % 2 != 0:
            impar += x
            
    return impar


def somaImpares2(lista, impar = 0):
    if not lista:
        return impar
    firstPart = lista[0]
    remains = lista[1:]

    if firstPart % 2 != 0:
            impar += firstPart
            return somaImpares2(remains, impar)
    return somaImpares2(remains, impar)



def decremento(dec):
    return dec - 1

def skillIssue(f, lista):
    if not lista:
        return []
    else:
        first = lista[0]
        remains = lista[1:]
        if first % 2 != 0:
            newThing = f(first)
        else:
            newThing = first
        return [newThing] + skillIssue(f, remains)



recursivaAleatorios(5)
resultado = somaImpares(listabonita)
resultado2 = somaImpares2(listabonita)
novaLista = skillIssue(decremento, listabonita)

print("Lista de números aleatórios:", listabonita)
print("Soma dos números ímpares na lista:", resultado)
print("Soma dos números ímpares na lista:", resultado2)
print("Lista Alterada:", novaLista)