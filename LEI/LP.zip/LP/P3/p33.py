import numpy as np

def distribuicaoNormalMediaNula(N):

    resultado = np.random.normal(loc=0,scale=2,size = N )
    return resultado

def removerNegativos(lista):

    noNegative = [x for x in lista if x >= 0]
    return noNegative


def somaPositivoIterador(lista):
    somaTotal = 0
    for x in lista:
        if x > 0:
            somaTotal += x
            
    return somaTotal

def somaPrimeiroPar(lista):
    somaTotal = 0
    pares = [0, 2, 4, 6, 8]
    for x in lista:
        numString = str(x)
        firstNum = numString[0]
        if firstNum in pares:
            somaTotal += x

    return somaTotal


resultado = distribuicaoNormalMediaNula(10)
print(resultado)