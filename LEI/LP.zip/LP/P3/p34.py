import random
import string

def geradorStringRandom(tamanho):
    strAleatoria = ''.join(random.choice(string.ascii_letters) for _ in range(tamanho) )
    return strAleatoria

def noMinConsoanteAqui(str):
    vogaisASCII = [97, 101, 105, 111, 117]
    for x in str:
        primeiraLetra = ord(str[x])
        if primeiraLetra >= 97 and primeiraLetra <= 122:
            if not primeiraLetra in vogaisASCII:
                
                str[x] = random.randint(1,9)

    return str