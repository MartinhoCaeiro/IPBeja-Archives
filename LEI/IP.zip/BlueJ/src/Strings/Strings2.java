package Strings;

import java.util.Locale;
import java.util.Scanner;

public class Strings2 {

    final static Scanner scanner = new Scanner(System.in);
    static {scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        String H = "";
        System.out.print("Hora =");
        double h = scanner.nextDouble();

        if (h >= 7 && h < 13) {
            H = "Manhã";
        }
        else if (h >= 13 && h <= 20) {
            H = "Tarde";
        }
        else if (h < 7 || h <= 24) {
            H = "Noite";
        }
        else {
            H = ", nem sabes quantas horas há num dia";
        }
        System.out.println("Boa " + H);
    }
}
