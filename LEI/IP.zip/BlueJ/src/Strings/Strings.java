package Strings;

import java.util.Locale;
import java.util.Scanner;

public class Strings {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        int x = 0;
        int y = 0;
        String txt = "";

        while (y == 0) {
            System.out.println("Diga uma palavra até 5 letras");
            txt = scanner.next();
            System.out.println("Número de letras: " + txt);

            if (txt.length() > 5) {
                System.out.println("Bruh eu disse 5 letras, tenta outra palavra");
            }
            else {
                y = 1;
            }
        }

        while (x == 0) {
            System.out.print("Escolha uma posição");
            int i = scanner.nextInt();

            if (i < txt.length()) {
                txt = scanner.next();
                System.out.println("A " + i + "ª letra da palavra é: " + txt);
            }
            else {
                x = 1;
            }
        }
    }
}


