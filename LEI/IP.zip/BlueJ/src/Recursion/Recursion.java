package Recursion;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Recursion extends Application {

    public void start(Stage primaryStage) {
        primaryStage.setOnCloseRequest(e-> Platform.runLater (() -> {Platform.exit(); System.exit(0); } ) );
        Pane pane = new Pane();
        final int PANE_SIZE = 800;
        pane.setPrefSize (800, 800);
        primaryStage.setScene (new Scene(pane, Color. AZURE));

        drawSquareInSquare(pane, 440, 10, 180, 20);
        drawCircleInCircle(pane, 590, 590, 200, 20);
        drawSquareSquare(pane, 180, 250, 180, 20);
        primaryStage.show();
    }

    private static void drawSquareInSquare (Pane pane, double x, double y, double side , double step) {
        if (side > 10) {
            Rectangle r = new Rectangle(x, y, side , side);
            r. setStrokeWidth (2);
            r. setStroke (Color.BLUE);
            r.setFill(Color.YELLOW);

            pane. getChildren ().add(r);
            drawSquareInSquare (pane, x + side, y, side / 2 , step);
            drawSquareInSquare (pane, x - side / 2, y, side / 2 , step);
        }
    }

    private static void drawCircleInCircle (Pane pane, double x, double y, double size , double step) {
        if (size > 10) {
            Circle c = new Circle(x,y,size);
            c. setStrokeWidth (2);
            c. setStroke (Color.BLACK);
            c.setFill(Color.WHITE);

            pane. getChildren ().add(c);
            drawCircleInCircle (pane , x, y, size - step , step);
        }
    }

    private static void drawSquareSquare (Pane pane, double x, double y, double side , double step) {
        if (side > 10) {
            Rectangle r = new Rectangle(x, y, side , side);
            r. setStrokeWidth (2);
            r. setStroke (Color.RED);
            r.setFill(Color.GREEN);

            pane. getChildren ().add(r);
            drawSquareSquare (pane, x + side, y + side / 4, side / 2 , step);
            drawSquareSquare (pane, x - side / 2, y + side / 4, side / 2 , step);
            drawSquareSquare (pane, x + side / 4, y + side, side / 2 , step);
            drawSquareSquare (pane, x + side / 4, y - side / 2, side / 2 , step);
        }
    }
}

