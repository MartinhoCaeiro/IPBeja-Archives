package Months;

import java.util.Locale;
import java.util.Scanner;

public class Months {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        String date = "";
        String month = "";
        System.out.print("Indique uma data no formato (AAAA/MM/DD) ");
        date = scanner.nextLine();
        System.out.println("A sua data é: " + date);
        month = date.substring(5, 7);
        int m = Integer.parseInt(month);
        daysmonth(m);
    }

    public static void daysmonth(int m) {
        switch(m) {
            case 1:
                System.out.println("Este mês tem 31 dias");
                break;
            case 2:
                System.out.println("Este mês tem 28 ou 29 dias");
                break;
            case 3:
                System.out.println("Este mês tem 31 dias");
                break;
            case 4:
                System.out.println("Este mês tem 30 dias");
                break;
            case 5:
                System.out.println("Este mês tem 31 dias");
                break;
            case 6:
                System.out.println("Este mês tem 30 dias");
                break;
            case 7:
                System.out.println("Este mês tem 31 dias");
                break;
            case 8:
                System.out.println("Este mês tem 31 dias");
                break;
            case 9:
                System.out.println("Este mês tem 30 dias");
                break;
            case 10:
                System.out.println("Este mês tem 31 dias");
                break;
            case 11:
                System.out.println("Este mês tem 30 dias");
                break;
            case 12:
                System.out.println("Este mês tem 31 dias");
                break;
            default:
                System.out.println("Não existem mais que 12 meses num ano");
                break;
        }
    }
}


