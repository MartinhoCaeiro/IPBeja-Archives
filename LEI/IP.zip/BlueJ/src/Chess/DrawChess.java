package Chess;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class DrawChess extends Application {
    private final double WIDTH = 800;
    private final double HEIGHT = 800;

    public void start(Stage primaryStage) {
        primaryStage.setOnCloseRequest(e-> Platform.runLater (() -> {Platform.exit(); System.exit(0); } ) );

        Pane pane=new Pane();
        final int PANE_SIZE = 800;
        pane.setPrefSize (WIDTH, HEIGHT);
        primaryStage.setScene (new Scene(pane, Color. AZURE));

        final int BOARD_SIZE = 10;
        ChessBoard board = new ChessBoard(0,0, BOARD_SIZE, BOARD_SIZE, (double) PANE_SIZE / BOARD_SIZE);
        pane.getChildren().add(board);
        primaryStage.show();
    }
}