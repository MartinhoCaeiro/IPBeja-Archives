package Chess;

import javafx.scene.Group;
import javafx.scene.paint.Color;

public class ChessRow extends Group {
    public ChessRow(double squareSize, int nSquares, Color even, Color odd) {
        for (int i = 0; i < nSquares; i++) {
            Color c;

            if(i % 2 == 0) {
                c = even;
            }
            else {
                c = odd;
            }
            ChessSquare square = new ChessSquare(i * squareSize, 0, squareSize, c);
            getChildren().add(square);
        }
    }
}
