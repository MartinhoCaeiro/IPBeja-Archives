package Chess;

import javafx.scene.Group;
import javafx.scene.paint.Color;

public class ChessBoard extends Group {
    public ChessBoard(double x, double y, int cols, int rows, double squareSize) {
        drawBoard(cols, rows, squareSize);
        setLayoutX(x);
        setLayoutY(y);
    }

    private void drawBoard(int cols, int rows, double squareSize) {
        for (int i = 0; i < rows; i++) {
            ChessRow row;

            if (i % 2 == 0) {
                row = new ChessRow(squareSize, cols, Color.BLACK, Color.WHITE);
            }
            else {
                row = new ChessRow(squareSize, cols, Color.WHITE, Color.BLACK);
            }
            row.setLayoutY(i * squareSize);
            getChildren().add(row);
        }
    }
}
