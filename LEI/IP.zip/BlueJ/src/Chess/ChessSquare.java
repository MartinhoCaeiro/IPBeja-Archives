package Chess;

import javafx.scene.Group;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

public class ChessSquare extends Group {
    public ChessSquare(double x, double y, double size, Paint paint) {
        setLayoutX(x);
        setLayoutY(y);
        Rectangle square = new Rectangle(size, size, paint);
        getChildren().add(square);
    }
}