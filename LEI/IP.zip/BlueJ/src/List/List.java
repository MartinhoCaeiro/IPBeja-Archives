package List;

import java.util.Locale;
import java.util.Scanner;

public class List {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        String number ="";
        String name ="";
        String first ="";
        String last ="";

        System.out.print("Indique o seu número: ");
        number = scanner.nextLine();

        System.out.print("Indique o seu nome: ");
        name = scanner.nextLine();
        first = name.substring(0, name. indexOf(" "));
        last = name.substring(name.lastIndexOf(" ")+1);

        System.out.println("Número: " + number);
        System.out.println("Primeiro Nome: " + first);
        System.out.println("Ultimo Nome: " + last);
    }
}

