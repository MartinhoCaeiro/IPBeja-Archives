package Arrays;

import java.util.Locale;
import java.util.Scanner;

public class Arrays {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        int[] rainHours = new int[] {1, 3, 0, 0, 6, 3, 8};
        int[] sunHours = new int[] {3, 4, 7, 5, 1, 2, 0};
        printRainInWeek (rainHours);
        sumRainInWeek(rainHours);
        rainInWeekDays(rainHours);
        maxRain(rainHours);
        mostRainy(rainHours);
        lessRainy(rainHours);
        weekendRain(rainHours);
        firstDry(rainHours);
        firstRain(rainHours);
        lastDry(rainHours);
        lastRain(rainHours);
        firstRainWithoutSun(rainHours, sunHours);
        firstMoreSunThanRain(rainHours, sunHours);
    }

    static void printRainInWeek (int[] rainH) {
        for(int i = 0; i < rainH.length; i++) {
            System.out.println("Chuva n (" + i + "): " + rainH[i]);
        }
    }

    static void sumRainInWeek(int[] rainH) {
        int total1 = 0;

        for (int j : rainH) {
            total1 = total1 + j;
        }
        System.out.println("Total de chuva da semana: " + total1);
    }

    static void rainInWeekDays(int[] rainH) {
        int total2 = 0;

        for(int i = 1; i < (rainH.length - 1); i++) {
            total2 = total2 + rainH[i];
        }
        System.out.println("Total de chuva dos dias uteis: " + total2);
    }

    static void maxRain(int[] rainH) {
        int max = 0;

        for (int j : rainH) {
            if (max < j) {
                max = j;
            }
        }
        System.out.println("Quantidade de chuva maxima da semana: " + max);
    }

    static void mostRainy(int[] rainH) {
        int most = 0;

        for(int i = 0;  i < rainH.length; i++) {
            if (rainH[i] > rainH[most]) {
                most = i;
            }
        }
        System.out.println("Dia que choveu mais: " + most);
    }

    static void lessRainy(int[] rainH) {
        int min = Integer.MAX_VALUE;
        int less = 0;

        for(int i = 0; i < rainH.length; i++) {
            if (rainH[i] < min) {
                min = rainH[i];
                less = i;
            }
        }
        System.out.println("Dia que choveu menos: " + less);
    }

    static void weekendRain(int[] rainH) {
        int weekend = 0;

        for(int i = 0; i < rainH.length; i++) {
            weekend = rainH[0] + rainH[rainH.length - 1];
        }
        System.out.println("Quantidade de chuva no fim-de-semana: " + weekend);
    }

    static void firstDry(int[] rainH) {
        int first1 = 0;

        for(int i = 0; i < rainH.length; i++) {
            if (rainH[i] == 0) {
                first1 = i;
                System.out.println("Primeiro dia que não choveu: " + first1);
                return;
            }
        }
    }

    static void firstRain(int[] rainH) {
        int first2 = 0;

        for(int i = 0; i < rainH.length; i++) {
            if (rainH[i] != 0) {
                first2 = i;
                System.out.println("Primeiro dia que choveu: " + first2);
                return;
            }
        }
    }

    static void lastDry(int[] rainH) {
        int last1 = 0;

        for(int i = (rainH.length - 1); i > 0; i--) {
            if (rainH[i] == 0) {
                last1 = i;
                System.out.println("Ultimo dia que não choveu: " + last1);
                return;
            }
        }
    }

    static void lastRain(int[] rainH) {
        int last2 = 0;

        for(int i = (rainH.length - 1); i > 0; i++) {
            if (rainH[i] != 0) {
                last2 = i;
                System.out.println("Ultimo dia que choveu: " + last2);
                return;
            }
        }
    }

    static void firstRainWithoutSun(int[] rainH, int[] sunH) {
        int last2 = 0;

        for(int i = 0; i < rainH.length; i++) {
            if (rainH[i] != 0 && sunH[i] == 0) {
                last2 = i;
                System.out.println("Primeiro dia de chuva sem sol: " + last2);
                return;
            }
        }
    }

    static void firstMoreSunThanRain(int[] rainH, int[]sunH) {
        int last2 = 0;

        for(int i = 0; i< rainH.length; i++) {
            if (rainH[i] < sunH[i]) {
                last2 = i;
                System.out.println("Primeiro dia com mais sol que chuva: " + last2);
                return;
            }
        }
    }
}

