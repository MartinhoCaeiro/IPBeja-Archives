package Arrays;

import java.util.Locale;
import java.util.Scanner;

public class Arrays2 {

    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        String [] teams = {"Beja","Cuba","Serpa","Ficalho","Safara","Moura","Barrancos","Amareleja","Pedrogão"};
        int [] points = {40,36,30,28,23,18,10,7,3};
        points[0] = 43;
        points[1] = 39;
        points[2] = 33;
        points[3] = 31;
        points[4] = 26;
        points[5] = 21;
        points[6] = 13;
        points[7] = 7;
        points[8] = 0;

        for (int i = 0; i < points.length;i++) {
            int pos = i + 1;
            System.out.println(pos + "º" + " | Equipa: " + teams[i] + " | Pontos: " + points[i]);
        }
    }
}

