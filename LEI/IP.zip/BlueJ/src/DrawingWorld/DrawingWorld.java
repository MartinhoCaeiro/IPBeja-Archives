package DrawingWorld;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public class DrawingWorld extends Application {

    private final double WIDTH  = 900;
    private final double HEIGHT = WIDTH / 1.5;

    public void start(Stage primaryStage) {
        primaryStage.setOnCloseRequest(e -> Platform.runLater( () -> {Platform.exit(); System.exit(0);} ) );

        Pane pane = new Pane();
        pane.setPrefSize(WIDTH, HEIGHT);
        primaryStage.setScene(new Scene(pane, Color.AZURE));
        primaryStage.show();
        draw(pane);
    }

    private void draw(Pane pane) {
        final double X = 10;
        final double Y = 20;
        final double WIDTH = 100;
        final double HEIGHT = 200;

        Rectangle r = new Rectangle(X, Y, WIDTH , HEIGHT);
        r. setStrokeWidth (1);
        r. setStroke (Color.BLUE);
        r.setFill(Color.YELLOW);
        pane. getChildren ().add(r);

        final double RX = WIDTH / 2.0;
        final double RY = HEIGHT / 2.0;
        final double CX = X + RX;
        final double CY = Y + RY;

        Ellipse ellipse = new Ellipse(CX , CY , RX , RY);
        ellipse. setStrokeWidth (2);
        ellipse. setStroke (Color.BLUE);
        ellipse.setFill(Color.BLUE);
        pane. getChildren ().add(ellipse);

        Line line1 = new Line(10, 20, 110, 220);
        line1. setStrokeWidth (1);
        line1. setStroke (Color.GREEN);
        pane. getChildren ().add(line1);

        Line line2 = new Line(110, 20, 10, 220);
        line2. setStrokeWidth (1);
        line2. setStroke (Color.GREEN);
        pane. getChildren ().add(line2);

        Polygon onePolygon = new Polygon();
        onePolygon . getPoints ().addAll (-30.0, 0.0, 0.0, 40.0, 30.0, 0.0);
        onePolygon .setFill(Color.ORANGE);
        pane. getChildren ().add( onePolygon );

        Polygon twoPolygon = new Polygon();
        twoPolygon . getPoints ().addAll (130.0, 110.0, 120.0, 160.0, 140.0, 110.0, 150.0, 160.0);
        twoPolygon .setFill(Color.RED);
        pane. getChildren ().add( twoPolygon );

        int rx1 = (int)(Math.random () * 801);
        int ry1 = (int)(Math.random () * 401);
        int rx2 = (int)(Math.random () * 801);
        int ry2 = (int)(Math.random () * 401);

        Circle circle2 = new Circle(400 , 400, 150);
        circle2.setFill(randomColor());
        pane. getChildren ().add(circle2);

        Rectangle a = new Rectangle(rx1, ry1, 100, 200);
        a. setStrokeWidth (1);
        a. setStroke (randomColor());
        a.setFill(randomColor());
        pane. getChildren ().add(a);

        Rectangle b = new Rectangle(rx2, ry2, 100, 200);
        b. setStrokeWidth (1);
        b. setStroke (randomColor());
        b.setFill(randomColor());
        pane. getChildren ().add(b);
    }

    public Color randomColor() {
        final int RED = (int)(Math.random () * 256);
        final int GREEN = (int)(Math.random () * 256);
        final int BLUE = (int)(Math.random () * 256);
        return Color.rgb(RED , GREEN , BLUE);
    }
}

