package Loop;

import java.util.Locale;
import java.util.Scanner;

public class Loop {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        while (true) {
            System.out.print("a =");
            double a = scanner.nextDouble();
            System.out.print("b =");
            double b = scanner.nextDouble();
            double result = 0;

            for (double count = 1;count <= b;count++) {
                result = result + a;
            }
            System.out.println(result);
        }
    }
}
