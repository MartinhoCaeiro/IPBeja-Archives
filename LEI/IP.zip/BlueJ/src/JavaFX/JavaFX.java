package JavaFX;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class JavaFX extends Application {
    private final double WIDTH  = 400;
    private final double HEIGHT = 400;

    @Override
    public void start(Stage stage) {
        initUI(stage);
        stage.setTitle("Circle n Square");
    }

    private void initUI(Stage stage) {
        Circle circle = new Circle (WIDTH/2,HEIGHT/2,50);
        Rectangle rect = new Rectangle(100, 100, 100, 100); //(x, y, width, height)
        circle.setFill(Color.GREEN);
        rect.setFill(Color.GREEN);

        var btnMais = new Button();
        btnMais.setText("+");
        btnMais.setOnAction((ActionEvent event) -> {
            double r = circle.getRadius();
            double x0 = circle.getCenterX();
            double y0 = circle.getCenterY();
            circle.setRadius(r + 5);
            rect.setX(x0-r-5);
            rect.setY(y0-r-5);
            rect.setWidth(2*r+10);
            rect.setHeight(2*r+10);

            if(circle.getRadius()==50) {
                circle.setFill(Color.GREEN);
                if(rect.getFill() == Color.TRANSPARENT) {
                }
                else {
                    rect.setFill(Color.GREEN);
                }
            }
            else {
                circle.setFill(Color.BLUE);
                if(rect.getFill() == Color.TRANSPARENT) {
                }
                else {
                    rect.setFill(Color.BLUE);
                }
            }
        });

        var btnMenos = new Button();
        btnMenos.setText("-");
        btnMenos.setOnAction((ActionEvent event) -> {
            double r = circle.getRadius();
            double x0 = circle.getCenterX();
            double y0 = circle.getCenterY();
            circle.setRadius(r - 5);
            rect.setX(x0-r+5);
            rect.setY(y0-r+5);
            rect.setWidth(2*r-10);
            rect.setHeight(2*r-10);

            if(circle.getRadius()==50)
            {
                circle.setFill(Color.GREEN);
                if(rect.getFill() == Color.TRANSPARENT) {
                }
                else {
                    rect.setFill(Color.GREEN);
                }
            }
            else {
                circle.setFill(Color.RED);
                if(rect.getFill() == Color.TRANSPARENT) {
                }
                else {
                    rect.setFill(Color.RED);
                }
            }
        });

        var btnQuit = new Button();
        btnQuit.setText("Quit");
        btnQuit.setOnAction((ActionEvent event) -> Platform.exit());

        var btnMove= new Button();
        btnMove.setText("Move");
        btnMove.setOnAction((ActionEvent event) -> {
            double r = circle.getRadius();
            int min = 100;
            int max = 500;
            double a = Math.random()*(max-min+1)+min;
            double b = Math.random()*(max-min+1)+min;
            circle.setCenterX(a);
            circle.setCenterY(b);
            rect.setX(a-r);
            rect.setY(b-r);
        });

        var btnForm= new Button();
        btnForm.setText("Square");
        btnForm.setOnAction((ActionEvent event) -> {
            if(btnForm.getText().equals("Square")) {
                rect.setFill(circle.getFill());
                btnForm.setText("Circle");
            }
            else if(btnForm.getText().equals("Circle")) {
                rect.setFill(Color.TRANSPARENT);
                btnForm.setText("Square");
            }
        });

        Pane root = new Pane();

        root.getChildren().addAll(circle);
        root.getChildren().addAll(rect);
        rect.setFill(Color.TRANSPARENT);

        btnMais.setLayoutX(100);
        btnMais.setLayoutY(0);
        btnMenos.setLayoutX(WIDTH-100);
        btnMenos.setLayoutY(0);
        btnMove.setLayoutY(100);
        btnForm.setLayoutY(200);

        root.setPadding(new Insets(25));
        root.getChildren().add(btnMais);
        root.getChildren().add(btnMenos);
        root.getChildren().add(btnQuit);
        root.getChildren().add(btnMove);
        root.getChildren().add(btnForm);

        Scene scene = new Scene(root,WIDTH, HEIGHT, Color.WHITESMOKE);

        stage.setTitle("Absolute layout");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}