package Jogo_do_GaloV2;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo com 2 modos jogáveis: PvP e PvE
 */
public class Jogo_do_GaloV2 {
    public static void main(String[] args) {
        MenuJG menujg = new MenuJG();
        menujg.menu(); //Calls the function menu
    }
}
