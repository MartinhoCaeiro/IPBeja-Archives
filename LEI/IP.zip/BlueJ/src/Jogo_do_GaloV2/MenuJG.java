package Jogo_do_GaloV2;

import java.util.Locale;
import java.util.Scanner;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo com 2 modos jogáveis: PvP e PvE
 */
public class MenuJG
{
    final static Scanner scanner = new Scanner(System.in); //Object that reads text
    static { scanner.useLocale(Locale.ENGLISH); } //To ensure real numbers are read with '.' instead of ','

    public static void menu() //Game start menu layout and options
    {
        int option = 0;
        while (option != 3) //Until option 3 in the menu is chosen, the game will keep running
        {
            System.out.println(); //Makes a space every time the menu pops up again for easier reading
            System.out.println("Bem-vindo ao jogo do galo!");
            System.out.println("Escolha o que deseja fazer.");
            System.out.println("________________");
            System.out.println("| Jogo PvP - 1 |");
            System.out.println("| Jogo PvE - 2 |");
            System.out.println("|   Sair - 3   |");
            System.out.println("----------------");
            option = scanner.nextInt(); //Scans for the next Int input
            if(option == 3)
            {
                System.out.println("Desligando o jogo... Até à próxima!"); //If the player chooses option 3, he will exit the game
            }
            else
            {
                switch (option) //If the player chooses option 1, he will start a 1v1 match of Tic Toc Toe, but if the player chooses option 2,
                //he will play against the computer
                {
                    case 1:
                        option = 1;
                        for(int i = 0; i < 35; i++) //It clears the menu so that you only see the board
                        {
                            System.out.println();
                        }
                        PvPJG pvpjg = new PvPJG();
                        pvpjg.pvp(); //Calls the function pvp
                        break;
                    case 2:
                        option = 2;
                        PvEJG pvejg = new PvEJG();
                        pvejg.pve(); //Calls the function pve
                        break;
                    default:
                        System.out.println("Opção inválida."); //If the input isn`t between 1 and 3 it counts as invalid
                }
            }
        }
    }
}
