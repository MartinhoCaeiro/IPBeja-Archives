package Jogo_do_GaloV2;

import java.util.Locale;
import java.util.Scanner;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo com 2 modos jogáveis: PvP e PvE
 */
public class PvEJG
{
    final static Scanner scanner = new Scanner(System.in); //Object that reads text
    static { scanner.useLocale(Locale.ENGLISH); } //To ensure real numbers are read with '.' instead of ','

    static String[] gameField; //Facilitates the printing of the game board and checking the winner
    static String turn; //Indicates what player is playing that turn

    public static void pve() //In this mode we play against the computer
    {
        Scanner in = new Scanner(System.in); //We use this to prevent bugs, that can occur with the normal scanner
        gameField = new String[9]; //Defines how many spaces are in the board
        turn = "X"; //The staring player is "X"
        String winner = null; //Null is used as the default of any unitialized variable

        for (int a = 0; a < 9; a++) //Makes it easier to pick the space the player wants to pick, because it goes from (1-9), instead of (0-8)
        {
            gameField[a] = String.valueOf(a + 1);
        }

        printboard(); //Calls the printBoard function
        System.out.println("O jogador (X) irá jogar primeiro. Escolha um espaço."); //The game starts with player "X"

        while (winner == null)
        {
            int numInput;
            numInput = Integer.parseInt(in.nextLine()); //Converts input value to Int
            if (!(numInput > 0 && numInput <= 9)) //If the input is not between 1 and 9 it counts as invalid
            {
                System.out.println("Número inválido, tenta novamente.");
                continue;
            }

            if (gameField[numInput - 1].equals(String.valueOf(numInput))) //If the number of game field equals the number of the array,
            //the game will change the board, in the corresponding input value, to either "X" or "O", depending on the turn
            {
                gameField[numInput - 1] = turn;
                if (turn.equals("X")) //It is used to change turns so that the players alternate between rounds
                {
                    turn = "O";
                    printboard(); //Calls the printBoard function
                    winner = checkwinnerpve(); //Every round, it checks to see if there is a winner
                }
            }
            else //If the selected space is occupied, the game will ask the player to select another space
            {
                System.out.println("Este espaço já está ocupado, escolhe outro.");
            }

            if (winner == null) //Shows who is the winner or if it was a draw
            {
                System.out.println("Escolha uma posição.");
            }
            else if (winner.equals("X"))
            {
                System.out.println("O vencedor foi o jogador! Obrigado por jogar.");
                break;
            }
            else if(winner.equals("O"))
            {
                System.out.println("O vencedor foi o computador! Obrigado por jogar.");
                break;
            }
            else
            {
                System.out.println("É um empate! Obrigado por jogar.");
                break;
            }

            int vv = 0;
            int r = 0;
            while (vv != 1) //This is the code that makes the computer oponent work, just like the player it chooses a number (in this case a
            //random number that hasn`t already been picked) and continues doing so for every round, until the game is finished
            {
                int min = 1;
                int max = 9;
                r = (int)(Math.random()*(max-min+1)+min); //Generates a random number between 1 and 9
                if (gameField[r - 1].equals(String.valueOf(r))) //If the number of game field equals the number of the array,
                //the game will change the board, in the corresponding input value, to either "X" or "O", depending on the turn
                {
                    gameField[r - 1] = turn;
                    if (turn.equals("O")) //It is used to change turns so that the players alternate between rounds
                    {
                        turn = "X";
                        vv = 1;
                        for (int i = 0; i < 35; i++) //It clears the console to change the game board
                        {
                            System.out.println();
                        }
                        printboard(); //Calls the printBoard function
                        winner = checkwinnerpve(); //Every round, it checks to see if there is a winner
                        System.out.println("O computador escolheu "+ r + "."); //The number the computer chose
                    }
                }
            }

            if(winner == null) //Shows who is the winner
            {
                System.out.println("Escolha uma posição.");
            }
            else if(winner.equals("X"))
            {
                System.out.println("O vencedor foi o jogador.");
                break;
            }
            else if(winner.equals("O"))
            {
                System.out.println("O vencedor foi o computador.");
                break;
            }
        }
    }

    public static String checkwinnerpve() //Checks if there is a winner for PvE
    {
        for (int a = 0; a < 8; a++)
        {
            String line = null;
            switch (a) //All winning possibilities
            {
                case 0:
                    line = gameField[0] + gameField[1] + gameField[2];// First horizontal line
                    break;
                case 1:
                    line = gameField[3] + gameField[4] + gameField[5];// Second horizontal line
                    break;
                case 2:
                    line = gameField[6] + gameField[7] + gameField[8];// Third horizontal line
                    break;
                case 3:
                    line = gameField[0] + gameField[3] + gameField[6];// First vertical line
                    break;
                case 4:
                    line = gameField[1] + gameField[4] + gameField[7];// Second vertical line
                    break;
                case 5:
                    line = gameField[2] + gameField[5] + gameField[8];// Third vertical line
                    break;
                case 6:
                    line = gameField[0] + gameField[4] + gameField[8];// First diagonal line
                    break;
                case 7:
                    line = gameField[2] + gameField[4] + gameField[6];// Second diagonal line
                    break;
            }

            if (line.equals("XXX")) //If one of the cases equals "XXX" the winner will be the player
            {
                return "X";
            }
            else if (line.equals("OOO")) //If one of the cases equals "OOO" the winner will be the computer
            {
                return "O";
            }
        }

        for (int a = 0; a < 9; a++) //If all 9 spaces are ocuppied and no one wins the game, it is a draw
        {
            if (java.util.Arrays.asList(gameField).contains(String.valueOf(a + 1)))
            {
                break;
            }
            else if (a == 8)
            {
                return "Empate";
            }
        }
        return null;
    }

    public static void printboard() //Game board layout
    {
        System.out.println(" " + gameField[0] + " | " + gameField[1] + " | " + gameField[2]);
        System.out.println("-----------");
        System.out.println(" " + gameField[3] + " | " + gameField[4] + " | " + gameField[5]);
        System.out.println("-----------");
        System.out.println(" " + gameField[6] + " | " + gameField[7] + " | " + gameField[8]);
    }
}
