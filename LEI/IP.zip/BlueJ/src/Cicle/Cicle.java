package Cicle;

import java.util.Locale;
import java.util.Scanner;

public class Cicle {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        int n = readN();
        writeEven(n);
        System.out.println();
        writeOdd(n);
    }

    public static int readN() {
        int x;
        do{
            System.out.println("Indique um número entre 0 e 20");
            x = scanner.nextInt();
        } while ((x < 0) || (x > 20));
        return x;
    }

    public static void writeEven(int e) {
        for (int i = 0; i < e; i++) {

            if (i % 2 == 0) {
                System.out.print(i);

                if (i < e - 2) {
                    System.out.print(", ");
                }
            }
        }
    }

    public static void writeOdd(int o) {
        for (int i = 0; i < o; i++) {

            if (i % 2 != 0) {
                System.out.print(i);

                if (i < o - 2) {
                    System.out.print(", ");
                }
            }
        }
    }
}