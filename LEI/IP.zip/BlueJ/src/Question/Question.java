package Question;

import java.util.Locale;
import java.util.Scanner;

public class Question {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        String ans = "";
        double a = readDouble("a: ");
        double b = readDouble("b: ");
        double c = readDouble("c: ");
        double delta = delta(a, b, c);
        double x1 = x1(a, b, c);
        double x2 = x2(a, b, c);

        do {
            if (delta < 0) {
                System.out.println("Não há raizes");
            }
            else if (delta == 0) {
                System.out.println("Há uma raiz dupla");
                System.out.println("A sua raiz é " + x2);
            }
            else if (delta > 0) {
                System.out.println("Há duas raizes");
                System.out.println("As suas raizes sâo " + x1 + " e " + x2);
            }
            System.out.println("Repetir? (y/n)");
            ans = scanner.next ();
        } while (ans.equals("y"));
    }

    public static double readDouble(String message) {
        System.out.print(message);
        double n = scanner.nextDouble();
        return n;
    }

    public static double delta(double a, double b,double c) {
        return Math.pow(b,2) - 4*a*c;
    }

    public static double x1(double a, double b,double c) {
        return -b + Math.sqrt(Math.pow(b,2) - 4*a*c) / 2*a;
    }

    public static double x2(double a, double b,double c) {
        return -b - Math.sqrt(Math.pow(b,2) - 4*a*c) / 2*a;
    }
}

