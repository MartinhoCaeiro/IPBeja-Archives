package Functions;

import java.util.Locale;
import java.util.Scanner;

public class Functions {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        System.out.print("n =");
        double n = scanner.nextDouble();
        System.out.print("m =");
        double m = scanner.nextDouble();
        double x = maxValue(n,m);
        System.out.print(x);
    }

    public static double maxValue(double a,double b) {
        double result = 0;
        for (double count = 1; count <= b; count++)
        {
            result = result + a;
        }
        return result;
    }
}
