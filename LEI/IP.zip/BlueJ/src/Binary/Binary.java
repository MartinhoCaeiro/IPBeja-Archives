package Binary;

import java.util.Locale;
import java.util.Scanner;

public class Binary {

    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {

        while(true) {
            System.out.print("Indique um número em binário: ");
            String binary = "";
            binary = scanner.nextLine();
            int decimal = Integer.parseInt(binary,2);
            System.out.println("O seu número em decimal é: " + decimal);
        }
    }
}

