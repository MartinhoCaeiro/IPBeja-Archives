package Equation;

import java.util.Locale;
import java.util.Scanner;

public class Equation {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {

        while(true) {
            System.out.print("a =");
            double a = scanner.nextDouble();
            System.out.print("b =");
            double b = scanner.nextDouble();
            System.out.print("c =");
            double c = scanner.nextDouble();
            double delta = (Math.pow(b,2) - 4*a*c);
            double x1 = (-b + Math.sqrt(delta) / 2*a);
            double x2 = (-b - Math.sqrt(delta) / 2*a);

            if (delta < 0) {
                System.out.println("Não há raizes");
            }
            else if (delta == 0) {
                System.out.println("Há uma raiz dupla");
                System.out.println("A sua raiz é " + x2);
            }
            else if (delta > 0) {
                System.out.println("Há duas raizes");
                System.out.println("As suas raizes sâo " + x1 + " e " + x2);
            }
        }
    }
}

