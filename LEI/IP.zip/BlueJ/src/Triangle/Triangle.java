package Triangle;

import java.util.Locale;
import java.util.Scanner;

public class Triangle {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        System.out.println("Indique o tamanho do triângulo");
        triangle();
    }

    public static int readSize() {
        int size = scanner.nextInt();
        return size;
    }

    public static void triangle() {
        System.out.print("Tamanho= ");
        int x = readSize();

        for (int i = 0; i < x; i++) {
            System.out.print("*");

            for (int k = 0; k < i; k++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}

