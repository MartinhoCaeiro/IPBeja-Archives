package Weather;

import java.util.Locale;
import java.util.Scanner;

public class WeatherStart {
    final static Scanner scanner = new Scanner (System.in);
    static { scanner . useLocale ( Locale. ENGLISH ); }

    public static void main(String[] args) {
        Weather weather = new Weather ();

        int sumRainInWeek = weather.sumRainInWeek();
        System. out. println ("Sum rain in week: " + sumRainInWeek);

        int rainInWeekDays = weather.rainInWeekDays();
        System. out. println ("Rain in weekdays: " + rainInWeekDays);

        int maxRain = weather.maxRain();
        System. out. println ("Max rain: " + maxRain);

        int mostRainy = weather.mostRainy();
        System. out. println ("Most Rainy: " + mostRainy);

        int lessRainy = weather.lessRainy();
        System. out. println ("Less Rainy: " + lessRainy);

        int weekendRain = weather.weekendRain();
        System. out. println ("Rain in weekend: " + weekendRain);

        int firstDry = weather.firstDry();
        System. out. println ("First dry: " + firstDry);

        int firstRain = weather.firstRain();
        System. out. println ("First rain: " + firstRain);

        int lastDry = weather.lastDry();
        System. out. println ("Last dry: " + lastDry);

        int lastRain = weather.lastRain();
        System. out. println ("Last rain: " + lastRain);

        int firstRainWithoutSun = weather.firstRainWithoutSun();
        System. out. println ("First rain day without sun: " + firstRainWithoutSun);

        int firstMoreSunThanRain = weather.firstMoreSunThanRain();
        System. out. println ("First day with more sun than rain: " + firstMoreSunThanRain);
    }
}
