package Weather;

public class Weather {
    private static final int N_DAYS_IN_WEEK = 7;
    private Day [] days;
    public Weather () {
        this.days = new Day[] {
                new Day(1, 3) ,
                new Day(3, 4) ,
                new Day(0, 7) ,
                new Day(0, 5) ,
                new Day(6, 1) ,
                new Day(3, 2) ,
                new Day(8, 0)
        };
    }

    public int sumRainInWeek() {
        int total = 0;

        for(int i = 0; i < this.days.length ; i++) {
            total = total + this.days[i].getRain();
        }
        return total ;
    }

    public int rainInWeekDays() {
        int total = 0;

        for(int i = 1; i < (this.days.length - 1); i++) {
            total = total + this.days[i].getRain();
        }
        return total;
    }

    public int maxRain() {
        int max = 0;

        for(int i = 0; i < this.days.length; i++) {
            if (max < this.days[i].getRain())
            {
                max = this.days[i].getRain();
            }
        }
        return max;
    }

    public int mostRainy() {
        int most = 0;

        for(int i = 0;  i < this.days.length; i++) {
            if (this.days[i].getRain() > this.days[most].getRain()) {
                most = i;
            }
        }
        return most;
    }

    public int lessRainy() {
        int min = Integer.MAX_VALUE;
        int less = 0;

        for(int i = 0; i < this.days.length; i++) {
            if (this.days[i].getRain() < min) {
                min = this.days[i].getRain();
                less = i;
            }
        }
        return less;
    }

    public int weekendRain() {
        int weekend = 0;

        for(int i = 0; i < this.days.length; i++) {
            weekend = this.days[0].getRain() + this.days[this.days.length - 1].getRain();
        }
        return weekend;
    }

    public int firstDry() {
        int first1 = 0;

        for(int i = 0; i < this.days.length; i++) {
            if (this.days[i].getRain() == 0) {
                first1 = i;
                return i;
            }
        }
        return -1;
    }

    public int firstRain() {
        int first2 = 0;

        for(int i = 0; i < this.days.length; i++) {
            if (this.days[i].getRain() != 0) {
                first2 = i;
                return i;
            }
        }
        return -1;
    }

    public int lastDry() {
        int last1 = 0;

        for(int i = (this.days.length - 1); i > 0; i--) {
            if (this.days[i].getRain() == 0) {
                last1 = i;
                return i;
            }
        }
        return -1;
    }

    public int lastRain() {
        int last2 = 0;

        for(int i = (this.days.length - 1); i > 0; i++) {
            if (this.days[i].getRain() != 0) {
                last2 = i;
                return i;
            }
        }
        return -1;
    }

    public int firstRainWithoutSun() {
        int last2 = 0;

        for(int i = 0; i < this.days.length; i++) {
            if (this.days[i].getRain() != 0 && this.days[i].getSun() == 0) {
                last2 = i;
                return i;
            }
        }
        return -1;
    }

    public int firstMoreSunThanRain() {
        int last2 = 0;

        for(int i = 0; i< this.days.length; i++) {
            if (this.days[i].getRain() < this.days[i].getSun()) {
                last2 = i;
                return i;
            }
        }
        return -1;
    }
}
