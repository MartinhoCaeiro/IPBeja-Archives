package Weather;

class Day {
    private int rain; // atributo para as horas de chuva
    private int sun; // atributo para as horas de sol

    public Day(int rain , int sun) {
        this. rain = rain;
        this.sun = sun;
    }

    public int getRain() {
        return this. rain;
    }

    public int getSun() {
        return this.sun;
    }
}

