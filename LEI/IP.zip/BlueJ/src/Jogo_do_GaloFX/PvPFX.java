package Jogo_do_GaloFX;

import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo: JavaFX Edition™ com 2 modos jogáveis: PvP e PvE
 */
public class PvPFX extends Group
{
    private Button[][] board; //Array representation of the game board
    private String player; //Player X or O
    private int playerXCount; //Counter for the number of turns player X has taken
    private int playerOCount; //Counter for the number of turns player O has taken
    private Label lbl; //Label for all the on screen text

    public void jgpvpfx() //Main program
    {
        Stage stage = new Stage(); //Creates a new stage
        stage.setTitle("Jogo do Galo: JavaFX Edition™");
        board = new Button[3][3]; //The size of the game board is 3x3
        player = "X"; //The staring player is "X"
        lbl = new Label("É a vez do jogador X" ); //On screen text to inform the user

        BorderPane layout = new BorderPane(); //Creates a border for the window
        GridPane grid = new GridPane(); //Creates a grid for the game board

        lbl.setFont(Font.font("Monospaced", 30)); //Font type and size for the on screen text
        createbuttons(grid, lbl); //Calls the function createButtons

        grid.setVgap(10); //Vertical gap size
        grid.setHgap(10); //Horizontal gap size
        grid.setAlignment(Pos.CENTER); //Aligns the grid with the center of the window
        layout.setTop(lbl);
        layout.setCenter(grid);

        Scene scene = new Scene(layout, 600, 600); //Size of the game window
        stage.setScene(scene); //Sets the game window
        stage.show(); //Shows the game window
    }

    public void createbuttons(GridPane grid, Label lbl) //Creates buttons and handles button presses
    {
        for(int col = 0; col < 3; col++) //For all the collumns
        {
            for(int row = 0; row < 3; row++) //For all the rows
            {
                Button btn = new Button(" "); //Creates a blank button
                btn.setFont(Font.font("Monospaced", 80)); //Font type and size for the buttons
                grid.add(btn, col, row); //Adds the buttons, columns and rows to the grid
                board[row][col] = btn;

                btn.setOnAction(e -> //Gives an action if that button is pressed
                {
                    if(btn.getText().equals(" ")) //Allows for the players to switch turns
                    {
                        btn.setText(player); //When a blank button is pressed it will now display the player symbol
                        if (player.equals("X"))
                        {
                            player = "O";
                            playerXCount++;
                            lbl.setText("É a vez do jogador O"); //On screen text to inform the user
                            checkwinner(); //Calls the function checkwinner
                        }
                        else if (player.equals("O"))
                        {
                            player = "X";
                            playerOCount++;
                            lbl.setText("É a vez do jogador X"); //On screen text to inform the user
                            checkwinner(); //Calls the function checkwinner
                        }

                        if(playerOCount + playerXCount == 9) //If all 9 spaces are ocuppied and no one wins the game, it is a draw
                        {
                            lbl.setText("É um empate!"); //Its a draw
                            endgame(); //Calls the function endgame
                        }
                    }
                });
            }
        }
    }

    public void checkwinner() //Checks if there is a winner
    {
        for(int row = 0; row < 3; row++) //For all the rows
        {
            if(board[row][0].getText().equals(board[row][1].getText()) && //All horizontal lines
                    board[row][0].getText().equals(board[row][2].getText()) &&

                    !board[row][0].getText().equals(" ")) //To avoid registering three blank buttons in a line as a win
            {
                if (player == "X")
                {
                    lbl.setText("O convidado ganhou, parabéns!"); //The guest has won
                }
                else if (player == "O")
                {
                    try (BufferedReader reader = new BufferedReader(new FileReader(new File("Utilizador.txt"))))
                    {
                        String line;
                        line = reader.readLine(); //Reads the user name from the "Utilizador.txt" file
                        lbl.setText(line + " ganhou, parabéns!"); //The user has won
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                endgame(); //Calls the function endgame
            }
        }

        for(int col = 0; col < 3; col++) //For all the collumns
        {
            if(board[0][col].getText().equals(board[1][col].getText()) && //All vertical lines
                    board[0][col].getText().equals(board[2][col].getText()) &&

                    !board[0][col].getText().equals(" ")) //To avoid registering three blank buttons in a line as a win
            {
                if (player == "X")
                {
                    lbl.setText("O convidado ganhou, parabéns!"); //The guest has won
                }
                else if (player == "O")
                {
                    try (BufferedReader reader = new BufferedReader(new FileReader(new File("Utilizador.txt"))))
                    {
                        String line;
                        line = reader.readLine(); //Reads the user name from the "Utilizador.txt" file
                        lbl.setText(line + " ganhou, parabéns!"); //The user has won
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                endgame(); //Calls the function endgame
            }
        }

        if(board[0][0].getText().equals(board[1][1].getText()) && //First diagonal line
                board[0][0].getText().equals(board[2][2].getText()) &&

                !board[0][0].getText().equals(" ")) //To avoid registering three blank buttons in a line as a win
        {
            if (player == "X")
            {
                lbl.setText("O convidado ganhou, parabéns!"); //The guest has won
            }
            else if (player == "O")
            {
                try (BufferedReader reader = new BufferedReader(new FileReader(new File("Utilizador.txt"))))
                {
                    String line;
                    line = reader.readLine(); //Reads the user name from the "Utilizador.txt" file
                    lbl.setText(line + " ganhou, parabéns!"); //The user has won
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            endgame(); //Calls the function endgame
        }

        if(board[0][2].getText().equals(board[1][1].getText()) &&  //Second diagonal line
                board[0][2].getText().equals(board[2][0].getText()) &&

                !board[0][2].getText().equals(" ")) //To avoid registering three blank buttons in a line as a win
        {
            if (player == "X")
            {
                lbl.setText("O convidado ganhou, parabéns!"); //The guest has won
            }
            else if (player == "O")
            {
                try (BufferedReader reader = new BufferedReader(new FileReader(new File("Utilizador.txt"))))
                {
                    String line;
                    line = reader.readLine(); //Reads the user name from the "Utilizador.txt" file
                    lbl.setText(line + " ganhou, parabéns!"); //The user has won
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            endgame(); //Calls the function endgame
        }
    }

    private void endgame() //Ends the game
    {
        for(int row = 0; row < 3; row++) //For all rows
        {
            for(int col = 0; col < 3; col++) //For all collumns
            {
                board[row][col].setDisable(true); //Disables game board buttons
            }
        }
        MainJGFX MJdG = new MainJGFX();
        MJdG.mainjgfx(); //Cales the function mainjgfx
    }
}
