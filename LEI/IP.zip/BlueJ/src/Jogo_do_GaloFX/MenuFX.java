package Jogo_do_GaloFX;

import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;

import java.util.Optional;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo: JavaFX Edition™ com 2 modos jogáveis: PvP e PvE
 */
public class MenuFX extends Group
{
    public MenuFX() //Creates the game menu
    {
        Alert alert = new Alert(AlertType.INFORMATION); //Creates a window for the menu
        alert.setTitle("Jogo do Galo: JavaFX Edition™");
        alert.setHeaderText("Bem vindo ao Jogo do Galo: JavaFX Edition™");
        alert.setContentText("Escolha uma Opção.");

        ButtonType buttonTypeOne = new ButtonType("Login");
        ButtonType buttonTypeTwo = new ButtonType("PvP");
        ButtonType buttonTypeThree = new ButtonType("PvE");
        ButtonType buttonTypeCancel = new ButtonType("Sair", ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo, buttonTypeThree, buttonTypeCancel); //Adds all buttons
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == buttonTypeOne) //Calls the function login
        {
            LoginFX LFX = new LoginFX();
            LFX.login();
        } else if (result.get() == buttonTypeTwo) //Calls the function jgpvpfx
        {
            PvPFX pvpfx = new PvPFX();
            pvpfx.jgpvpfx();
        } else if (result.get() == buttonTypeThree) //Calls the function jgpvefx
        {
            PvEFX pvefx = new PvEFX();
            pvefx.jgpvefx();
        } else //Exits the game and closes all open windows
        {
            Platform.exit();
        }
    }
}
