package Jogo_do_GaloFX;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo: JavaFX Edition™ com 2 modos jogáveis: PvP e PvE
 */
public class MainJGFX extends Application
{
    public void start(Stage primaryStage)
    {
        mainjgfx(); //Calls the function mainjgfx
    }

    public void mainjgfx() //Starts the program
    {
        Stage primaryStage = new Stage(); //Creates new stage
        primaryStage.setOnCloseRequest(e -> Platform.runLater( () -> {Platform.exit(); System.exit(0);} ) );

        MenuFX menufx = new MenuFX(); //Calls the function MenuFX
    }
}