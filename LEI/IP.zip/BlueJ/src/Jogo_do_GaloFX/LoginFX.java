package Jogo_do_GaloFX;

import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Trabalho feito por Martinho Caeiro (23917) e Paulo Abade (23919)
 * Jogo do Galo: JavaFX Edition™ com 2 modos jogáveis: PvP e PvE
 */
public class LoginFX extends Group {
    private TextField tfUsername = new TextField(); //Creates a text field
    private PasswordField tfPassword = new PasswordField(); //Creates a password field
    private Button btAddUser = new Button("Criar Utilizador"); //Creates a "create user" button
    private Button btClear = new Button("Apagar"); //Creates a "clear" button
    private javafx.scene.control.Button closeButton;

    public void login() //Creates a login menu
    {
        GridPane gridPane = new GridPane(); //Creates a new gridpane
        gridPane.setHgap(5); //Sets horizontal gap
        gridPane.setVgap(5); //Sets vertical gap
        gridPane.add(new Label("Utilizador:"), 0, 1);
        gridPane.add(tfUsername, 1, 1);
        gridPane.add(new Label("Senha:"), 0, 2);
        gridPane.add(tfPassword, 1, 2);
        gridPane.add(btAddUser, 1, 4);
        gridPane.add(btClear, 1, 4);
        Text scenetitle = new Text("Bem Vindo ao Jogo do Galo: JavaFX Edition™!");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 18));
        gridPane.add(scenetitle, 0, 0, 2, 1);
        gridPane.setAlignment(Pos.CENTER); //Aligns the window to the center of the screen

        tfUsername.setAlignment(Pos.BOTTOM_RIGHT);
        tfPassword.setAlignment(Pos.BOTTOM_RIGHT);

        GridPane.setHalignment(btAddUser, HPos.LEFT);
        GridPane.setHalignment(btClear, HPos.RIGHT);

        btAddUser.setOnAction(e -> //Action for the "create user" button
        {
            writenewuser(); //Calls the function writenewuser
            Stage stage = (Stage) btAddUser.getScene().getWindow();
            stage.close(); //Closes the window after pressing the button
            MainJGFX MJdG = new MainJGFX();
            MJdG.mainjgfx(); //Calls the function mainjgfx
        });

        btClear.setOnAction(e ->  //Actin for the "clear" button
        {
            tfUsername.clear();
            tfPassword.clear();
        });

        Scene scene = new Scene(gridPane, 400, 175); // Creates a scene
        Stage primaryStage = new Stage(); //Creates a new stage
        primaryStage.setTitle("Jogo do Galo: JavaFX Edition™"); // Sets a title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }

    public void writenewuser() //Creates and writes information to a user file
    {
        try (BufferedWriter bw = new BufferedWriter(new PrintWriter("Utilizador.txt"))) {
            bw.write(tfUsername.getText());
            bw.newLine();
            bw.write(tfPassword.getText());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
