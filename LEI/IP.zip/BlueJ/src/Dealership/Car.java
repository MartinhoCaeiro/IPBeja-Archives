package Dealership;

public class Car extends Vehicle {
    String Modelo;
    int Potencia;

    public Car(){
        String Modelo = "";
        int Potencia = 0;
    }

    public Car(String Modelo, int Potencia, int nRodas, int ID, String Marca, String Matricula) {
        this.Modelo = Modelo;
        this.Potencia = Potencia;
        this.nRodas = nRodas;
        this.ID = ID;
        this.Marca = Marca;
        this.Matricula = Matricula;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public void setPotencia(int Potencia) {
        this.Potencia = Potencia;
    }

    public String getModelo() {
        return this.Modelo;
    }

    public int getPotencia() {
        return this.Potencia;
    }
}
