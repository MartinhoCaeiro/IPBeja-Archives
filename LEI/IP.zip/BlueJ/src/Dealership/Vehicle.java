package Dealership;

public class Vehicle {
    int nRodas;
    int ID;
    String Marca;
    String Matricula;

    public Vehicle() {
        int nRodas = 0;
        int ID = 0;
        String Marca = "";
        String Matricula = "";
    }

    public Vehicle(int nRodas, int ID, String Marca, String Matricula) {
        this.nRodas = nRodas;
        this.ID = ID;
        this.Marca = Marca;
        this.Matricula = Matricula;
    }

    public void setNRodas(int nRodas) {
        this.nRodas = nRodas;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public void setMatricula(String Matricula) {
        this.Matricula = Matricula;
    }

    public int getNRodas() {
        return this.nRodas;
    }

    public int getID() {
        return this.ID;
    }

    public String getMarca() {
        return this.Marca;
    }

    public String getMatricula() {
        return this.Matricula;
    }
}
