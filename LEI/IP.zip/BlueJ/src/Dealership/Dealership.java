package Dealership;

import java.util.Locale;
import java.util.Scanner;

public class Dealership {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }
    static boolean redo = false;

    public static void main(String[] args) {
        int L = 6;

        Car[] cars = new Car[L];

        Car CarroA = new Car("ModeloA", 100, 4, 1, "MarcaA","MatriculaA");
        Car CarroB = new Car("ModeloB", 200, 8, 2, "MarcaB","MatriculaB");
        Car CarroC = new Car("ModeloC", 300, 16, 3, "MarcaC","MatriculaC");
        Car CarroD = new Car();
        Car CarroE = new Car();
        Car CarroF = new Car();

        cars[0] = CarroA;
        cars[1] = CarroB;
        cars[2] = CarroC;
        cars[3] = CarroD;
        cars[4] = CarroE;
        cars[5] = CarroF;

        String ans = "s";

        do {
            System.out.println();
            System.out.println("Escolha um Carro entre:");

            for(int i = 0; i < L; i++) {
                System.out.println(i + "-" + cars[i].getModelo());
            }
            int carro = scanner.nextInt();
            Prints(cars, carro);
            System.out.println("Gostaria de escolher outro: (s/n)");

            if(!redo) {
                scanner.nextLine();
            }
            ans = scanner.nextLine();
        }
        while(ans.equals("s"));

        if(ans.equals("n")) {
            System.out.println("Obrigado!");
        }
    }

    public static void Prints(Car[] cars, int i) {
        if(cars[i].getModelo() != null) {
            System.out.println("Modelo: " + cars[i].getModelo());
            System.out.println("Potencia: " + cars[i].getPotencia());
            System.out.println("Numero de rodas: "+ cars[i].getNRodas());
            System.out.println("Marca: " + cars[i].getMarca());
            System.out.println("Matricula: " + cars[i].getMatricula());
            redo = false;
        }
        else {
            System.out.println("Nenhum veículo encontrado. Gostaria de registrar um? (s/n)");
            scanner.nextLine();
            String regAns= scanner.nextLine();
            redo = true;

            if(regAns.equals("s")) {

                String mod = "";
                int pot = 0;
                int nrodas = 0;
                String marca = "";
                String mat = "";

                System.out.println();
                System.out.println("Por favor, diga o Modelo do veiculo");
                mod = scanner.nextLine();
                cars[i].setModelo(mod);

                System.out.println("Por favor, diga a Potência do veiculo");
                pot = scanner.nextInt();
                cars[i].setPotencia(pot);

                System.out.println("Por favor, diga o número de Rodas do veiculo");
                nrodas = scanner.nextInt();
                cars[i].setNRodas(nrodas);

                System.out.println("Por favor, diga a Marca do veiculo");
                scanner.nextLine();
                marca = scanner.nextLine();
                cars[i].setMarca(marca);

                System.out.println("Por favor, diga a Matrícula do veiculo");
                mat = scanner.nextLine();
                cars[i].setMatricula(mat);

                System.out.println();
                System.out.println("Veículo Registrado com sucesso.");
                System.out.println();
            }
        }
    }
}