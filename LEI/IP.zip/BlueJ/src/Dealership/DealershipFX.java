package Dealership;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.Optional;

public class DealershipFX extends Application {
    private final double WIDTH  = 400;
    private final double HEIGHT = 400;

    private Button b0 = new Button();
    private Button b1 = new Button();
    private Button b2 = new Button();
    private Button b3 = new Button();
    private Button b4 = new Button();
    private Button b5 = new Button();

    private Label modeloLabel = new Label();
    private Label potenciaLabel = new Label();
    private Label nrodasLabel = new Label();
    private Label marcaLabel = new Label();
    private Label matriculaLabel = new Label();

    @Override
    public void start(Stage stage) {
        Pane pane = new Pane();
        pane.setPrefSize(WIDTH,HEIGHT);

        int L = 6;

        Car[] cars = new Car[L];

        Car Carro0 = new Car("ModeloA", 100, 4, 1, "MarcaA","MatriculaA");
        Car Carro1 = new Car("ModeloB", 200, 8, 2, "MarcaB","MatriculaB");
        Car Carro2 = new Car("ModeloC", 300, 16, 3, "MarcaC","MatriculaC");
        Car Carro3 = new Car();
        Car Carro4 = new Car();
        Car Carro5 = new Car();

        cars[0] = Carro0;
        cars[1] = Carro1;
        cars[2] = Carro2;
        cars[3] = Carro3;
        cars[4] = Carro4;
        cars[5] = Carro5;

        pane.getChildren().add(b0);
        pane.getChildren().add(b1);
        pane.getChildren().add(b2);
        pane.getChildren().add(b3);
        pane.getChildren().add(b4);
        pane.getChildren().add(b5);

        b0.setLayoutX(50);
        b0.setLayoutY(50);

        b1.setLayoutX(50);
        b1.setLayoutY(100);

        b2.setLayoutX(50);
        b2.setLayoutY(150);

        b3.setLayoutX(50);
        b3.setLayoutY(200);

        b4.setLayoutX(50);
        b4.setLayoutY(250);

        b5.setLayoutX(50);
        b5.setLayoutY(300);

        b0.setPrefSize(100,20);
        b1.setPrefSize(100,20);
        b2.setPrefSize(100,20);
        b3.setPrefSize(100,20);
        b4.setPrefSize(100,20);
        b5.setPrefSize(100,20);

        b0.setText("0 " + cars[0].getModelo());
        b1.setText("1 " + cars[1].getModelo());
        b2.setText("2 " + cars[2].getModelo());
        b3.setText("3 " + cars[3].getModelo());
        b4.setText("4 " + cars[4].getModelo());
        b5.setText("5 " + cars[5].getModelo());

        b0.setOnAction(event -> infoDisplay(b0, cars));
        b1.setOnAction(event -> infoDisplay(b1, cars));
        b2.setOnAction(event -> infoDisplay(b2, cars));
        b3.setOnAction(event -> infoDisplay(b3, cars));
        b4.setOnAction(event -> infoDisplay(b4, cars));
        b5.setOnAction(event -> infoDisplay(b5, cars));

        pane.getChildren().add(modeloLabel);
        pane.getChildren().add(potenciaLabel);
        pane.getChildren().add(nrodasLabel);
        pane.getChildren().add(marcaLabel);
        pane.getChildren().add(matriculaLabel);

        modeloLabel.setLayoutX(WIDTH-150);
        modeloLabel.setLayoutY(50);

        potenciaLabel.setLayoutX(WIDTH-150);
        potenciaLabel.setLayoutY(100);

        nrodasLabel.setLayoutX(WIDTH-150);
        nrodasLabel.setLayoutY(150);

        marcaLabel.setLayoutX(WIDTH-150);
        marcaLabel.setLayoutY(200);

        matriculaLabel.setLayoutX(WIDTH-150);
        matriculaLabel.setLayoutY(250);

        Scene scene = new Scene(pane, WIDTH, HEIGHT);
        stage.setTitle("Dealership");
        stage.setScene(scene);
        stage.show();
    }

    private void infoDisplay(Button btn, Car[] cars) {

        if(!btn.getText().substring(2).equals("null")) {
            for(int i = 0; i < 6; i++) {
                if(btn.getText().substring(2).equals(cars[i].getModelo())) {
                    modeloLabel.setText("Modelo: " + cars[i].getModelo());
                    potenciaLabel.setText("Potência: " + cars[i].getPotencia());
                    nrodasLabel.setText("Nº de Rodas: " + cars[i].getNRodas());
                    marcaLabel.setText("Marca: " + cars[i].getMarca());
                    matriculaLabel.setText("Matrícula: " + cars[i].getMatricula());
                }
            }
        }
        else {

            Alert regAlert = new Alert(Alert.AlertType.CONFIRMATION);
            regAlert.setTitle("Registro");
            regAlert.setHeaderText("Nenhum veículo encontrado");
            regAlert.setContentText("Gostaria de registrar um?");

            ButtonType yesButton = new ButtonType("Sim");
            ButtonType noButton = new ButtonType("Não");

            regAlert.getButtonTypes().setAll(yesButton, noButton);

            Optional<ButtonType> result = regAlert.showAndWait();

            if(result.get() == yesButton) {

                int id = Integer.parseInt((btn.getText().substring(0,1)));

                String mod = "";
                String pote = "";
                String nurodas = "";
                String marca = "";
                String mat = "";

                int pot = 0;
                int nrodas = 0;

                TextInputDialog modDialog = new TextInputDialog();
                modDialog.setTitle("Modelo");
                modDialog.setHeaderText("Por favor, diga o Modelo do veiculo");
                modDialog.showAndWait();
                mod = modDialog.getEditor().getText();

                TextInputDialog potDialog = new TextInputDialog();
                potDialog.setTitle("Modelo");
                potDialog.setHeaderText("Por favor, diga a Potencia do veiculo");
                potDialog.showAndWait();
                pote = potDialog.getEditor().getText().trim();

                TextInputDialog nrodasDialog = new TextInputDialog();
                nrodasDialog.setTitle("Modelo");
                nrodasDialog.setHeaderText("Por favor, diga o número de Rodas do veiculo");
                nrodasDialog.showAndWait();
                nurodas = nrodasDialog.getEditor().getText().trim();

                TextInputDialog marcaDialog = new TextInputDialog();
                marcaDialog.setTitle("Modelo");
                marcaDialog.setHeaderText("Por favor, diga a Marca do veiculo");
                marcaDialog.showAndWait();
                marca = marcaDialog.getEditor().getText();

                TextInputDialog matDialog = new TextInputDialog();
                matDialog.setTitle("Modelo");
                matDialog.setHeaderText("Por favor, diga a Matricula do veiculo");
                matDialog.showAndWait();
                mat = matDialog.getEditor().getText();

                try {
                    pot = Integer.parseInt(pote);
                }
                catch (NumberFormatException e) {

                }

                try {
                    nrodas = Integer.parseInt(nurodas);
                }
                catch (NumberFormatException e) {

                }
                registerInfo(btn, cars, id, mod, pot, nrodas, marca, mat);
            }
            else {

            }
        }
    }

    public void registerInfo(Button btn, Car[] cars, int id, String mod, int pot, int nrodas, String marca, String mat) {
        cars[id].setModelo(mod);
        cars[id].setPotencia(pot);
        cars[id].setNRodas(nrodas);
        cars[id].setMarca(marca);
        cars[id].setMatricula(mat);

        btn.setText(id + " " + cars[id].getModelo());
    }
}