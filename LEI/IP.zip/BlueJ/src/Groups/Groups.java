package Groups;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.MotionBlur;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Groups extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Teste JavaFX");

        Button button1 = new Button("OK I PULL UP!!");
        button1.setPrefSize(180, 80);
        Button button2 = new Button("Capivaras be like:");

        Text text = new Text("Bottom Text");
        text.setFill(Color.GREY);
        text.setFont(Font.font("null", FontWeight.BOLD, 36));
        text.setX(200);
        text.setY(100);

        Rectangle rectangle = new Rectangle();
        rectangle.setX(190);
        rectangle.setY(70);
        rectangle.setWidth(235);
        rectangle.setHeight(35);
        rectangle.setFill(Color.RED);

        Group group = new Group();
        MotionBlur motionBlur = new MotionBlur();
        group.setEffect(motionBlur);
        group.setTranslateX(40);

        group.getChildren().addAll(button1, button2, rectangle, text);

        Scene scene = new Scene(group, 200, 100);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[]args) {
        Application.launch(args);
    }
}

