package Aluno;

public class Pessoa {
    String primeiroNome;
    String ultimoNome;
    int idade;

    public Pessoa() {
        String primeiroNome = "";
        String ultimoNome = "";
        int idade = 0;
    }

    public Pessoa(String primeiroNome, String ultimoNome, int idade) {
        this.primeiroNome = primeiroNome;
        this.ultimoNome = ultimoNome;
        this.idade = idade;
        System.out.println(getprimeiroNome());
    }

    public void setprimeiroNome(String primeiroNome) {
        this.primeiroNome = primeiroNome;
    }

    public void setultimoNome(String ultimoNome) {
        this.ultimoNome = ultimoNome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getprimeiroNome() {
        return this.primeiroNome;
    }

    public String getultimoNome() {
        return this.ultimoNome;
    }

    public int getIdade() {
        return this.idade;
    }
}
