package Aluno;

public class Aluno extends Pessoa {
    String inst;
    String curso;
    String numero;

    public Aluno() {
        String inst = "";
        String curso = "";
        String numero = "";
    }
    public Aluno(String primeiroNome, String ultimoNome, int idade, String inst, String curso, String numero) {
        this.inst = inst;
        this.curso = curso;
        this.numero = numero;
        this.primeiroNome = primeiroNome;
        this.ultimoNome = ultimoNome;
        this.idade = idade;
    }

    public void setInst(String inst) {
        this.inst = inst;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getInst() {
        return this.inst;
    }

    public String getCurso() {
        return this.curso;
    }

    public String getNumero() {
        return this.numero;
    }

    public void setAll(String All) {
        String[] One = All.split(" ");
        this.primeiroNome = One[0];
        this.ultimoNome = One[1];
        this.idade = Integer.parseInt(One[2]);
        this.inst = One[3];
        this.curso = One[4];
        this.numero = One[5];
    }
}
