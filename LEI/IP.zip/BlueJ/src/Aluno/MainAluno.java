package Aluno;

import java.util.Locale;
import java.util.Scanner;

public class MainAluno {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        Aluno[] alunos = new Aluno[5];
        Aluno a1 = new Aluno("Manuel", "Fernandes", 18, "IPFaro", "Mecânica", "26487");
        Aluno a2 = new Aluno("Rita", "Baldonado", 33, "IPBeja", "Enfermagem", "1530");
        Aluno a3 = new Aluno("João", "Ramalho", 24, "UEvora", "Microbiologia", "20558");
        Aluno a4 = new Aluno();
        Aluno a5 = new Aluno();
        alunos[0] = a1;
        alunos[1] = a2;
        alunos[2] = a3;
        alunos[3] = a4;
        alunos[4] = a5;

        int option = 0;
        while(option != 5) {
            System.out.println("Menu de Opções");
            System.out.println("--------------");
            System.out.println("Adicionar Aluno - 1");
            System.out.println("Mostrar todos os alunos - 2");
            System.out.println("Diga o número, direi o aluno! - 3");
            System.out.println("Mostrar o número de alunos que pertencem ao IPBeja! - 4");
            System.out.println("Sair - 5");
            option = scanner.nextInt();

            switch (option) {
                case 1 -> {
                    AddGuy(alunos);
                    System.out.println();
                }
                case 2 -> {
                    PrintAll(alunos);
                    System.out.println();
                }
                case 3 -> {
                    whoIs(alunos);
                    System.out.println();
                }
                case 4 -> {
                    System.out.println("O número de alunos que pertence ao IPBeja é: " + anIPBeja(alunos));
                    System.out.println();
                }
                case 5 -> System.out.println("Adeus!");
            }
        }
    }

    public static void PrintAll(Aluno[] alunos) {
        System.out.println("Todos os alunos serão apresentados!");

        for(int i = 0; i <= 4; i++) {
            System.out.println();
            System.out.println("Novo Estudante!");
            System.out.println(alunos[i].getprimeiroNome());
            System.out.println(alunos[i].getultimoNome());
            System.out.println(alunos[i].getIdade());
            System.out.println(alunos[i].getInst());
            System.out.println(alunos[i].getCurso());
            System.out.println(alunos[i].getNumero());
        }
    }

    public static void AddGuy(Aluno[] alunos) {
        String All = "";
        int t = -1;
        System.out.println("Escolha uma das possíveis opções");

        for(int i = 0; i < 5; i++) {
            if(alunos[i].getprimeiroNome() == null) {
                t = i;
                break;
            }
            else if(i == 4 && alunos[i].getprimeiroNome() != null) {
                System.out.println("Tá cheio!");
            }
        }
        System.out.println("Introduza um aluno da seguinte forma: Nome Sobrenome Idade Instituição Curso Número");
        scanner.nextLine();
        All = scanner.nextLine();
        alunos[t].setAll(All);
    }

    public static void whoIs(Aluno[] alunos) {
        int t = 0;
        do {
            System.out.println("Insira um número entre 1 e 5!");
            int ans = scanner.nextInt();

            if(ans <=5 && ans > 0) {
                System.out.println(alunos[ans - 1].getprimeiroNome());
                System.out.println(alunos[ans - 1].getultimoNome());
                System.out.println(alunos[ans - 1].getIdade());
                System.out.println(alunos[ans - 1].getInst());
                System.out.println(alunos[ans - 1].getCurso());
                System.out.println(alunos[ans - 1].getNumero());
                t = 1;

            }
            else {
                System.out.println("Introduza um número válido");
            }
        }
        while(t==0);
    }

    public static int anIPBeja(Aluno[] alunos) {
        int valid = 0;
        int count = 0;

        for(int i = 0; i < 5; i++) {
            if(alunos[i].getInst() == null) {

            }
            else {
                valid++;
            }
        }

        for(int j = 0; j < valid; j++) {
            if(alunos[j].getInst().equalsIgnoreCase("IPBeja")) {
                count++;
            }
        }
        return count;
    }
}

