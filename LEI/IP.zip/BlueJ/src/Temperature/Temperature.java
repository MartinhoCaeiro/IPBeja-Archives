package Temperature;

import java.util.Locale;
import java.util.Scanner;

public class Temperature {
    final static Scanner scanner = new Scanner(System.in);
    static { scanner.useLocale(Locale.ENGLISH); }

    public static void main(String[] args) {
        System.out.println("Indique uma temperatura minima e máxima");
        calcTemp();
    }

    public static int readMin() {
        System.out.print("Min= ");
        int min = scanner.nextInt();
        return min;
    }

    public static int readMax() {
        System.out.print("Max= ");
        int max = scanner.nextInt();
        return max;
    }

    public static void calcTemp() {
        double min = readMin();
        double max = readMax();
        double far = min;
        double cel = 0;
        double i = (max - min) * 2;
        System.out.println("Fahrenheit Celsius");

        for (double j = 0; j <= i; j++) {
            cel = ((far - 32) * 5) / 9;
            showResult(far, cel);
            far += 0.5f;
        }
    }

    public static void showResult(double f, double c) {
        System.out.printf("%6.2f\t   %6.2f\t\n", f, c);
    }
}
