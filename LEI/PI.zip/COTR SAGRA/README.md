# COTR_SAGRA

## Resumo do Projeto

Este projeto visa automatizar um processo manual de criação de tabelas no Excel, que consome cerca de uma hora por dia. O sistema desenvolvido, implementado em Python, utiliza tecnologias como FTP, manipulação de arquivos Excel e integração com o Access. A automação reduz o tempo necessário para a tarefa e permite que os recursos humanos sejam alocados em atividades mais estratégicas.

## Objetivo

Automatizar o fluxo ETL (Extração, Transformação e Carga) dos dados meteorológicos da rede SAGRA para gerar relatórios e gráficos automaticamente.

## Tecnologias Utilizadas

- **Python**: Bibliotecas como `pandas`, `openpyxl`, `pyodbc` e `ftplib`.
- **Excel** e **Access**: Para manipulação e armazenamento de dados.
- **FTP**: Para obtenção de arquivos dos dispositivos DataTakers.

## Pré-Requisitos

- Python 3.9 ou superior
- Sistema operacional Windows 10 ou superior
- Computador configurado para executar o programa em horários predefinidos

## Resultados Esperados

- Redução significativa no tempo de processamento.
- Automação completa do fluxo de dados da SAGRA, incluindo geração de gráficos e atualização de bancos de dados.

## Perspectivas Futuras

- Migração do sistema para um servidor dedicado para maior fiabilidade.
- Expansão do escopo para suportar novas redes de estações meteorológicas.
