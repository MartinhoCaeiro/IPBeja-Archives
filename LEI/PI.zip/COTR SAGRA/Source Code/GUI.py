# GUI for executing Python scripts and creating/deleting a scheduled task
# The GUI will be created using the Tkinter library
# The GUI will have a button to execute the Python scripts all at once
# The GUI will have a button to create a scheduled task to execute the Python scripts
# The GUI will have a button to delete the scheduled task
# The GUI will have a text box to display the output of the Python scripts, showing the progress and any errors
# Creators: Martinho Caeiro & Paulo Abade
# Version: 1.0
# Date of Last Update: 05-02-2025
# Escola Superior de Tecnologia e Gestão - Instituto Politécnico de Beja
# You can use this script and update it if you give credit to the creators

import os
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import configparser
from PIL import Image, ImageTk  

# Function to execute a script
def execute_script(script_name, log_textarea):
    def run_script():
        try:
            process = subprocess.Popen(
                ["python", "-u", script_name],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            for line in process.stdout:
                log_textarea.insert(tk.END, line)
                log_textarea.see(tk.END)
            process.wait()

            if process.returncode == 0:
                messagebox.showinfo("Sucesso", f"Script {script_name} executado com sucesso!")
            else:
                error_message = process.stderr.read()
                log_textarea.insert(tk.END, f"Erro: {error_message}\n")
                log_textarea.see(tk.END)
                messagebox.showerror("Erro", f"Erro ao executar {script_name}. Verifique os logs.")
        except FileNotFoundError:
            messagebox.showerror("Erro", f"Ficheiro {script_name} não encontrado.")

    thread = threading.Thread(target=run_script)
    thread.start()

# Function to execute all scripts sequentially
def execute_all_scripts(log_textarea):
    def run_scripts():
        scripts = ["extract.py", "transform.py"]  # Add "load.py" if needed
        for script in scripts:
            log_textarea.insert(tk.END, f"Executing {script}...\n")
            log_textarea.see(tk.END)

            # Run the script and capture output in real time
            process = subprocess.Popen(
                ["python", "-u", script],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            # Read output line by line and update the log
            for line in process.stdout:
                log_textarea.insert(tk.END, line)
                log_textarea.see(tk.END)
                log_textarea.update_idletasks() 
            
            process.wait()  

            # Check for errors
            if process.returncode != 0:
                error_message = process.stderr.read()
                log_textarea.insert(tk.END, f"Error in {script}: {error_message}\n")
                log_textarea.see(tk.END)
                messagebox.showerror("Error", f"Failed to execute {script}. Check the logs.")
                return  
        
        messagebox.showinfo("Success", "All scripts executed successfully!")

    # Run the function in a separate thread
    thread = threading.Thread(target=run_scripts, daemon=True)
    thread.start()

# Function to create schedule
def create_schedule():
    try:
        startup_folder = os.path.join(os.environ['APPDATA'], r"Microsoft\Windows\Start Menu\Programs\Startup")
        bat_file = os.path.join(current_dir, 'SAGRA_Scheduler.bat')

        if not os.path.exists(bat_file):
            messagebox.showerror("Erro", f"Ficheiro {bat_file} não encontrado.")
            return

        destination = os.path.join(startup_folder, 'SAGRA_Scheduler.bat')
        if not os.path.exists(destination):
            with open(bat_file, 'r') as src, open(destination, 'w') as dst:
                dst.write(src.read())
        messagebox.showinfo("Sucesso", "Agendamento criado com sucesso!")
    except Exception as e:
        messagebox.showerror("Erro", f"Erro ao criar o agendamento: {e}")

# Function to delete schedule
def delete_schedule():
    try:
        startup_folder = os.path.join(os.environ['APPDATA'], r"Microsoft\Windows\Start Menu\Programs\Startup")
        bat_file = os.path.join(startup_folder, 'SAGRA_Scheduler.bat')

        if os.path.exists(bat_file):
            os.remove(bat_file)
            messagebox.showinfo("Sucesso", "Agendamento removido com sucesso!")
        else:
            messagebox.showinfo("Informação", "Nenhum agendamento encontrado para remover.")
    except Exception as e:
        messagebox.showerror("Erro", f"Erro ao remover o agendamento: {e}")

# Reads schedule time from config file
config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.ini'))
schedule_time = config['schedule']['time']

# Main window
root = tk.Tk()
root.title("Executar Scripts Python")

# Loads the logo image
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    image_path = os.path.join(current_dir, "IPBejaESTIG.jpg")
    if not os.path.exists(image_path):
        messagebox.showerror("Erro", f"Arquivo não encontrado: {image_path}")
    else:
        pil_image = Image.open(image_path)
        pil_image = pil_image.resize((250, 150), Image.LANCZOS)
        logo_image = ImageTk.PhotoImage(pil_image)
except Exception as e:
    messagebox.showerror("Erro", f"Não foi possível carregar a imagem: {e}")
    logo_image = None

# Main frame
main_frame = ttk.Frame(root, padding=20)
main_frame.pack(fill="both", expand=True)

# Logo Image
if logo_image:
    logo_label = ttk.Label(main_frame, image=logo_image)
    logo_label.pack(pady=10)

# Left frame (buttons)
left_frame = ttk.Frame(main_frame, width=250)
left_frame.pack(side="left", fill="y", padx=10, pady=10)

# Right frame (logs)
right_frame = ttk.Frame(main_frame, width=500)
right_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)

# Title
header_label = ttk.Label(left_frame, text="Auto-SAGRA", font=("Calibri", 18, "bold"))
header_label.pack(pady=20)

# Files verification
current_dir = os.path.dirname(os.path.abspath(__file__))
required_files = ["extract.py", "transform.py", "load.py"]  # Add "load.py" if needed
missing_files = [file for file in required_files if not os.path.exists(os.path.join(current_dir, file))]

if missing_files:
    error_message = f"Ficheiros em falta: {', '.join(missing_files)}"
    label = ttk.Label(left_frame, text=error_message, foreground="red")
    label.pack(pady=20)
else:
    ttk.Label(left_frame, text="Execução de Processos", font=("Calibri", 14, "bold")).pack(anchor="w", pady=5)
    ttk.Button(left_frame, text="Executar Extract", command=lambda: execute_script(os.path.join(current_dir, "extract.py"), log_textarea)).pack(fill="x", pady=5)
    ttk.Button(left_frame, text="Executar Transform", command=lambda: execute_script(os.path.join(current_dir, "transform.py"), log_textarea)).pack(fill="x", pady=5)
    # ttk.Button(left_frame, text="Executar Load", command=lambda: execute_script(os.path.join(current_dir, "load.py"), log_textarea)).pack(fill="x", pady=5)
    ttk.Button(left_frame, text="Executar Todos", command=lambda: execute_all_scripts(log_textarea)).pack(fill="x", pady=10)

    ttk.Label(left_frame, text="Gestão de Agendamento", font=("Calibri", 14, "bold")).pack(anchor="w", pady=15)
    ttk.Button(left_frame, text=f"Criar Agendamento ({schedule_time})", command=create_schedule).pack(fill="x", pady=5)
    ttk.Button(left_frame, text=f"Eliminar Agendamento ({schedule_time})", command=delete_schedule).pack(fill="x", pady=5)

# Log area
ttk.Label(right_frame, text="Logs de Execução", font=("Calibri", 14, "bold")).pack(anchor="w", pady=5)
log_textarea = scrolledtext.ScrolledText(right_frame, wrap=tk.WORD, height=20, font=("Courier", 10))
log_textarea.pack(fill="both", expand=True)

# Footer
footer_label = ttk.Label(root, text="© ESTIG - 2025 Martinho Caeiro & Paulo Abade", anchor="center", font=("Calibri", 8))
footer_label.pack(side="bottom", pady=10)

# Starts the GUI
root.mainloop()