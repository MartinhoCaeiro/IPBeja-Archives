# Transform the data from the txt files to Excel format
# The script will do the rounding and apply the multipliers
# The script will do a check for empty cells
# The script will do an extra file in the last day of the month
# Creators: Martinho Caeiro & Paulo Abade
# Version: 1.0
# Date of Last Update: 10-02-2025
# Escola Superior de Tecnologia e Gestão - Instituto Politécnico de Beja
# You can use this script and update it if you give credit to the creators

import os
import configparser
import ast
from openpyxl import Workbook, load_workbook
from datetime import datetime, timedelta
import pandas as pd

print("\n\n\n\n\n\n\n\n\n\n\nIniciando a fase de transform.\n\n\n", flush=True)

# Path to the configuration file
config_path = os.path.join(os.path.dirname(__file__), 'config.ini')

# Loads the configuration file
config = configparser.ConfigParser()
config.read(config_path)

# Checks if the path files are valid
required_sections = {
    'paths': ['txt_folder', 'excel_folder', 'log_folder'],
    'multipliers': ['multiplier', 'decimal_places']
}

for section, keys in required_sections.items():
    if section not in config:
        raise ValueError(f"Secção '{section}' não encontrada no arquivo config.ini")
    for key in keys:
        if key not in config[section]:
            raise ValueError(f"Chave '{key}' não encontrada na secção '{section}' do arquivo config.ini")

# Paths to the txt, excel and log folders
base_dir = os.path.dirname(config_path)
txt_folder = os.path.abspath(os.path.join(base_dir, config['paths']['txt_folder']))
excel_folder = os.path.abspath(os.path.join(base_dir, config['paths']['excel_folder']))
log_folder = os.path.abspath(os.path.join(base_dir, config['paths']['log_folder']))

# Creates the log folder if it doesn't exist
if not os.path.exists(log_folder):
    os.makedirs(log_folder)

# Log file name based on the current date and time
log_filename = datetime.now().strftime("transform_log_%H-%M_%d_%m_%Y.txt")
log_path = os.path.join(log_folder, log_filename)

# Gets the multipliers and decimal places from the configuration file
multipliers = ast.literal_eval(config['multipliers']['multiplier'])
decimal_places = int(config['multipliers']['decimal_places'])

# List of month names
months_names = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]

# Function to log a message
def log_message(message):
    with open(log_path, "a") as log_file:
        log_file.write(message + "\n")

# Function to process the data of a month
def process_month(sheet, txt_file_path, max_columns, file_type, station):
    with open(txt_file_path, "r") as file:
        headers = file.readline().strip().split(";") 
        headers.pop(1)
        headers = headers[:max_columns]
        
        row_number = 1
        
        for col_index, header in enumerate(headers):
            sheet.cell(row=row_number, column=col_index + 1, value=header)
        row_number += 1
        
        for line in file:
            data = line.strip().split(";")
            
            if any(not cell.strip() for cell in data):
                log_message(f"Atenção: Linha {row_number} contém células brancas ou nulas.")
                print(f"Atenção: Linha {row_number} contém células brancas ou nulas.", flush=True)
            
            if file_type == 'D':
                for cell in data:
                    if cell.strip() == "9999":
                        log_message(f"Atenção: Linha {row_number} contém o número 9999.")
                        print(f"Atenção: Linha {row_number} contém o número 9999.", flush=True)
            
            if file_type == 'D':
                try:
                    date_obj = datetime.strptime(data[0], "%Y/%m/%d %H:%M:%S")
                    date_obj -= timedelta(minutes=1)  
                    data[0] = date_obj.strftime("%d/%m/%Y %H:%M:%S")
                except ValueError:
                    continue

            data.pop(1)
            data = data[:max_columns]

            for i in range(len(data)):
                try:
                    value = data[i].strip().replace('"', '').replace(',', '.')
                    data[i] = float(value)
                except ValueError:
                    pass

            if file_type == 'D' and len(data) > 1:
                penultimate_index = -2  
                try:
                    station_multiplier = multipliers.get(int(station), 1.0)
                    original_value = float(data[penultimate_index])
                    data[penultimate_index] = round(original_value * station_multiplier, decimal_places)
                except ValueError:
                    pass

            column_letter = 'A'
            for value in data:
                try:
                    numeric_value = float(value)
                    cell = sheet[f"{column_letter}{row_number}"]
                    cell.value = numeric_value
                    cell.number_format = f"0.{decimal_places * '0'}"
                except ValueError:
                    sheet[f"{column_letter}{row_number}"] = value
                column_letter = chr(ord(column_letter) + 1)
            
            row_cells = [sheet.cell(row=row_number, column=i+1).value for i in range(len(data))]
            if any(cell is None or cell == "" for cell in row_cells):
                log_message(f"Atenção: Linha {row_number} contém uma célula vazia ou com valor vazio na área de dados do TXT.")
                print(f"Atenção: Linha {row_number} contém uma célula vazia ou com valor vazio na área de dados do TXT.", flush=True)
            
            row_number += 1

# Function to convert the files to Excel format
def convert_files_to_excel(txt_folder, excel_folder, file_type):
    for station in range(1001, 1015):
        today = datetime.now()
        
        if today.day == 1 and today.month == 1:
            year = today.year - 1
            previous_month_date = today - timedelta(days=1)
            current_month_index = previous_month_date.month
        else:
            year = today.year
            current_month_index = today.month

        excel_file_path = os.path.join(excel_folder, f"EMA{station}_{file_type}_{year}.xlsx")
        station_folder = os.path.join(txt_folder, f"Station_{station}")

        if not os.path.exists(station_folder):
            log_message(f"Pasta da estação {station_folder} não encontrada. Passando para a próxima estação.")
            continue

        if os.path.exists(excel_file_path):
            workbook = load_workbook(excel_file_path)
            process_all_months = False
        else:
            workbook = Workbook()
            workbook.remove(workbook.active)
            for month_name in months_names:
                workbook.create_sheet(title=month_name)
            process_all_months = True

        has_data = False
        max_columns = 16 if file_type == 'H' else 17

        for month in range(1, 13):
            if not process_all_months and month != current_month_index:
                continue

            month_name = months_names[month - 1]
            file_name = f"EMA{station}_{month}_{file_type}.txt"
            txt_file_path = os.path.join(station_folder, file_name)

            if not os.path.exists(txt_file_path):
                log_message(f"Arquivo {file_name} não encontrado na pasta {station_folder}. Passando para o próximo mês.")
                continue

            has_data = True
            sheet = workbook[month_name]

            for row in sheet.iter_rows():
                for cell in row:
                    cell.value = None

            process_month(sheet, txt_file_path, max_columns, file_type, station)

        if has_data:
            workbook.save(excel_file_path)
            log_message(f"Arquivo Excel salvo ou atualizado em: {excel_file_path}")
            print(f"Arquivo Excel salvo ou atualizado em: {excel_file_path}", flush=True)

# Function to create an extra file with the last 3 days of data every Monday
def create_extra_file(txt_folder, excel_folder):
    today = datetime.now()
    output_file_path = os.path.join(excel_folder, f"Resumo_3_dias_{today.strftime('%d_%m_%Y')}.xlsx")
    rows_list = []
    global_header_line = None
    valid_dates = {(today - timedelta(days=i)).date() for i in range(1, 4)}

    for station in range(1001, 1015):
        station_folder = os.path.join(txt_folder, f"Station_{station}")
        file_name_current = f"EMA{station}_{today.month}_D.txt"
        file_name_prev = f"EMA{station}_{today.month - 1}_D.txt" if today.month > 1 else f"EMA{station}_12_D.txt"

        txt_file_path_current = os.path.join(station_folder, file_name_current)
        txt_file_path_prev = os.path.join(station_folder, file_name_prev)

        station_lines = []

        print(f"Processando estação {station}...", flush=True)

        if today.day <= 3 and os.path.exists(txt_file_path_prev):
            with open(txt_file_path_prev, "r") as file:
                file_lines = file.readlines()
                if file_lines:
                    if global_header_line is None:
                        global_header_line = file_lines[0]
                    station_lines.extend(file_lines[1:])

        if os.path.exists(txt_file_path_current):
            with open(txt_file_path_current, "r") as file:
                file_lines = file.readlines()
                if file_lines:
                    if global_header_line is None:
                        global_header_line = file_lines[0]
                    station_lines.extend(file_lines[1:])

        if not station_lines:
            continue

        full_headers = [h.strip().strip('"') for h in global_header_line.strip().split(";")]

        try:
            ema_index = full_headers.index("EMA") + 1
        except ValueError:
            log_message(f"Atenção: Coluna 'EMA' não encontrada para a estação {station}. Cabeçalho: {full_headers}")
            continue

        keep_indices = [0] + list(range(2, ema_index))
        selected_headers = [full_headers[i] for i in keep_indices]

        for line in station_lines:
            full_row = line.strip().split(";")
            full_row = [value.replace(",", ".").strip() for value in full_row]

            row_data = [full_row[i] for i in keep_indices if i < len(full_row)]
            
            if len(row_data) != len(selected_headers):
                log_message(f"Atenção: Número de valores numa linha não corresponde ao cabeçalho. Dados da linha: {row_data}, Cabeçalho: {selected_headers}")
                continue

            try:
                date_obj = datetime.strptime(row_data[0], "%Y/%m/%d %H:%M:%S")
                date_obj -= timedelta(minutes=1)
                row_data[0] = date_obj.strftime("%d/%m/%Y %H:%M:%S")
                row_date = date_obj.date()
            except ValueError:
                continue

            if row_date not in valid_dates:
                continue

            for i in range(1, len(row_data)):
                col_name = selected_headers[i]
                try:
                    numeric_value = float(row_data[i])
                    if col_name == "ET0  (mm/d)":
                        station_multiplier = multipliers.get(station, 1.0)
                        numeric_value *= station_multiplier
                    row_data[i] = round(numeric_value, decimal_places)
                except ValueError:
                    row_data[i] = None

            row_dict = dict(zip(selected_headers, row_data))
            row_dict["date_only"] = row_date
            rows_list.append(row_dict)

    if rows_list:
        final_df = pd.DataFrame(rows_list)
        if "EMA" not in final_df.columns:
            log_message(f"Atenção: Coluna 'EMA' não encontrada no DataFrame final. Colunas disponiveis: {list(final_df.columns)}")
            return

        final_df["EMA"] = final_df["EMA"].astype("Int64")
        final_df.sort_values(by=["date_only", "EMA"], inplace=True)
        final_df.drop(columns=["date_only"], inplace=True)
        final_df = final_df.round(decimal_places)
        final_df.to_excel(output_file_path, index=False)
        log_message(f"Ficheiro resumo guardado em: {output_file_path}")
        print(f"Ficheiro resumo guardado em: {output_file_path}", flush=True)

        wb = load_workbook(output_file_path)
        ws = wb.active
        num_format = f"0.{decimal_places * '0'}"
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
            for cell in row:
                if isinstance(cell.value, (int, float)):
                    cell.number_format = num_format
        wb.save(output_file_path)

if not os.path.exists(excel_folder):
    os.makedirs(excel_folder)

print("Convertendo arquivos para o formato Excel...", flush=True)

print("Convertendo arquivos do tipo 'H'...", flush=True)
log_message("Convertendo arquivos do tipo 'H'...")
convert_files_to_excel(txt_folder, excel_folder, 'H')

print("Convertendo arquivos do tipo 'D'...", flush=True)
log_message("Convertendo arquivos do tipo 'D'...")
convert_files_to_excel(txt_folder, excel_folder, 'D')

print("Criando arquivo extra...", flush=True)
log_message("Criando arquivo extra...")
create_extra_file(txt_folder, excel_folder)
