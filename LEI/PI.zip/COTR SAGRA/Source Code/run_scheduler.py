# Creates the scheduler script that will run the extract and transform  scripts at a specific time every day.
# The script will be scheduled to run at a specific time. The time is read from a configuration file.
# The script will execute the extract and transform scripts in sequence.
# Creators: Martinho Caeiro & Paulo Abade
# Version: 1.0
# Date of Last Update: 05-02-2025
# Escola Superior de Tecnologia e Gestão - Instituto Politécnico de Beja
# You can use this script and update it if you give credit to the creators

import schedule
import time
import os
import subprocess
import configparser

# Path to the configuration file
config_path = os.path.join(os.path.dirname(__file__), 'config.ini')

# Loads the configuration file
config = configparser.ConfigParser()
config.read(config_path)

# Tries to read the time from the configuration file
try:
    schedule_time = config['schedule']['time']
except KeyError as e:
    print(f"Erro ao ler o tempo no config.ini: {e}")
    exit(1)

# Function to execute all scripts in sequence
def execute_all_scripts():
    scripts = ["extract.py", "transform.py"] # Add "load.py" if needed
    current_dir = os.path.dirname(os.path.abspath(__file__))  

    for script in scripts:
        script_path = os.path.join(current_dir, script)  
        if os.path.exists(script_path):  
            try:
                print(f"Executando {script}...")
                subprocess.run(["python", script_path], check=True)  
                print(f"{script} executado com sucesso!")
            except subprocess.CalledProcessError as e:
                print(f"Erro ao executar {script}: {e}")
        else:
            print(f"Script {script} não foi encontrado em {current_dir}")

# Schedule the script to run at the specified time
schedule.every().day.at(schedule_time).do(execute_all_scripts)

# Main loop to keep the scheduler running
while True:
    schedule.run_pending()
    time.sleep(1)
