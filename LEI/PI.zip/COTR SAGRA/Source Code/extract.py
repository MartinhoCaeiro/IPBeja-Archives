# Extract the information from the DataTakers which is stored in the FTP server. 
# The script will download the files from the FTP server and store them in the local folder. 
# The script will also remove the data from the previous year. 
# The script will log the information in a log file. 
# The script will be executed by the user through the GUI. 
# The script will be scheduled to run at a specific time.
# Creators: Martinho Caeiro & Paulo Abade
# Version: 1.0
# Date of Last Update: 05-02-2025
# Escola Superior de Tecnologia e Gestão - Instituto Politécnico de Beja
# You can use this script and update it if you give credit to the creators

import os
import re
from ftplib import FTP
import configparser
from datetime import datetime, timedelta
print("\n\n\n\n\n\n\n\n\n\n\nIniciando a fase de extração.\n\n\n", flush=True)

# Path to the configuration file
config_path = os.path.join(os.path.dirname(__file__), 'config.ini')

# Loads the configuration file
config = configparser.ConfigParser()
config.read(config_path)

# Checks if the path files are valid
if 'paths' not in config:
    raise ValueError("A secção 'paths' está ausente no arquivo config.ini")
if 'txt_folder' not in config['paths']:
    raise ValueError("A chave 'txt_folder' está ausente na secção 'paths' do arquivo config.ini")
if 'log_folder' not in config['paths']:
    raise ValueError("A chave 'log_folder' está ausente na secção 'paths' do arquivo config.ini")
if 'port' not in config['ftp'] or 'user' not in config['ftp'] or 'pass' not in config['ftp'] or 'remote_base_dir' not in config['ftp']:
    raise ValueError("As chaves 'port', 'user', 'pass' e 'remote_base_dir' são obrigatórias na seção 'ftp' do arquivo config.ini")

# Paths to the local and log folders
base_dir = os.path.abspath(os.path.dirname(config_path))
LOCAL_BASE_DIR = os.path.abspath(os.path.join(base_dir, config['paths']['txt_folder']))
LOG_FOLDER = os.path.abspath(os.path.join(base_dir, config['paths']['log_folder']))

# Creates the log folder if it doesn't exist
if not os.path.exists(LOG_FOLDER):
    os.makedirs(LOG_FOLDER)

# Log file name based on the current date and time
log_filename = datetime.now().strftime("extract_log_%H-%M_%d_%m_%Y.txt")
log_path = os.path.join(LOG_FOLDER, log_filename)

# Function to log a message
def log_message(message):
    with open(log_path, "a") as log_file:
        log_file.write(message + "\n")

# Function to clear previous year data
def clear_previous_year_data():
    today = datetime.now()
    if today.month == 1 and today.day == 2:
        log_message("Limpando dados do ano anterior...")
        print("Limpando dados do ano anterior...")
        if os.path.exists(LOCAL_BASE_DIR):
            for root, dirs, files in os.walk(LOCAL_BASE_DIR, topdown=False):
                for file in files:
                    file_path = os.path.join(root, file)
                    os.remove(file_path)
                    log_message(f"Arquivo {file_path} removido.")
                for dir in dirs:
                    dir_path = os.path.join(root, dir)
                    os.rmdir(dir_path)
                    log_message(f"Pasta {dir_path} removida.")
            log_message(f"Dados do ano anterior removidos com sucesso em {LOCAL_BASE_DIR}.")
            print(f"Dados do ano anterior removidos com sucesso em {LOCAL_BASE_DIR}.", flush=True)
        else:
            log_message(f"Pasta {LOCAL_BASE_DIR} não encontrada. Nenhum dado a remover.", flush=True)
            print(f"Pasta {LOCAL_BASE_DIR} não encontrada. Nenhum dado a remover.", flush=True)

# FTP configuration
FTP_PORT = int(config['ftp']['port'])
FTP_USER = config['ftp']['user']
FTP_PASS = config['ftp']['pass']
REMOTE_BASE_DIR = config['ftp']['remote_base_dir']      

# Checks if the file name is valid
def is_valid_file(file_name, station_number, months_to_fetch):
    months_pattern = '|'.join(str(month) for month in months_to_fetch)
    pattern = fr"EMA{station_number}_({months_pattern})_(D|H)\.txt"
    match = re.fullmatch(pattern, file_name)
    if match:
        month = int(match.group(1))
        return month in months_to_fetch
    return False

# Function to select which months to fetch
def get_months_to_fetch(local_station_dir):
    today = datetime.now()
    if not os.path.exists(local_station_dir) or not any(os.listdir(local_station_dir)): 
        return list(range(1, today.month + 1))
    
    if today.day == 1:
        previous_month = (today - timedelta(days=1)).month
        return [previous_month]
    
    return [today.month]

# Function to download station files
def download_station_files(station_number):
    host = f"cotrema{station_number}.ddns.net"
    local_station_dir = os.path.join(LOCAL_BASE_DIR, f"Station_{station_number}")
    os.makedirs(local_station_dir, exist_ok=True)

    months_to_fetch = get_months_to_fetch(local_station_dir)
    log_message(f"Estação {station_number}: meses a buscar: {months_to_fetch}")
    print(f"Estação {station_number}: meses a buscar: {months_to_fetch}", flush=True)

    ftp = FTP()
    try:
        ftp.connect(host, FTP_PORT)
        ftp.login(FTP_USER, FTP_PASS)
        ftp.cwd(REMOTE_BASE_DIR)

        files = ftp.nlst()
        log_message(f"Arquivos disponíveis no host {host}: {files}")

        for file in files:
            if is_valid_file(file, station_number, months_to_fetch):
                local_file_path = os.path.join(local_station_dir, file)
                with open(local_file_path, "wb") as local_file:
                    ftp.retrbinary(f"RETR {file}", local_file.write)
                    log_message(f"Arquivo {file} baixado para {local_file_path}")
                    print(f"Arquivo {file} baixado para {local_file_path}", flush=True)
            else:
                log_message(f"Arquivo {file} ignorado (não corresponde ao padrão ou ao mês esperado).")

    except Exception as e:
        log_message(f"Erro ao processar o host {host}: {e}")
        print(f"Erro ao processar o host {host}: {e}", flush=True)

    finally:
        ftp.quit()

# Function to iterate over all stations
def download_all_stations():
    for station in range(1001, 1015):
        log_message(f"Obtendo arquivos da estação {station}...")
        print(f"Obtendo arquivos da estação {station}...", flush=True)
        try:
            download_station_files(station)
        except Exception as e:
            log_message(f"Erro ao processar a estação {station}: {e}")
            print(f"Erro ao processar a estação {station}: {e}", flush=True)
    log_message("Download concluído para todas as estações.")
    print("Download concluído para todas as estações.", flush=True)

# Executes the main function
if __name__ == "__main__":
    clear_previous_year_data()
    download_all_stations()
