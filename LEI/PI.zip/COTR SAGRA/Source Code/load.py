# Load the data from the Excel files into the Access database
# Creators: Martinho Caeiro & Paulo Abade
# Version: 1.0
# Date of Last Update: 05-02-2025
# Escola Superior de Tecnologia e Gestão - Instituto Politécnico de Beja
# You can use this script and update it if you give credit to the creators

import os
import pyodbc
import pandas as pd
import configparser
from datetime import datetime

print("\n\n\n\n\n\n\n\n\n\n\nIniciando a fase de carregamento na Base de Dados Access\n\n\n", flush=True)
# Path to the configuration file
config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), 'config.ini'))

# Paths to the access, excel and log folders
access_db = os.path.join(os.path.dirname(__file__), config['paths']['access_db'])
excel_folder = os.path.join(os.path.dirname(__file__), config['paths']['excel_folder'])
log_folder = os.path.join(os.path.dirname(__file__), config['paths']['log_folder'])

# Creates the log folder if it doesn't exist
if not os.path.exists(log_folder):
    os.makedirs(log_folder)

# Log file name based on the current date and time
log_filename = datetime.now().strftime("load_log_%H-%M_%d_%m_%Y.txt")
log_path = os.path.join(log_folder, log_filename)

# Function to log a message
def log_message(message):
    with open(log_path, "a") as log_file:
        log_file.write(f"{datetime.now().strftime('%d-%m%Y %H:%M:%S')} - {message}\n")

# Function to check if a record is already present in the table
def is_record_present(cursor, ema, data):
    cursor.execute("SELECT COUNT(*) FROM Tabela1 WHERE EMA = ? AND Data = ?", (ema, data))
    return cursor.fetchone()[0] > 0

# Function to process the files
def process_files():
    try:
        log_message("Iniciando conexão com a base de dados Access.")
        print("Iniciando conexão com a base de dados Access.", flush=True)
        conn = pyodbc.connect(
            r"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + access_db + ";"
        )
        log_message("Conexão estabelecida com sucesso.")
        print("Conexão estabelecida com sucesso.", flush=True)
        cursor = conn.cursor()

        for station in range(1001, 1015):
            file_name = f"EMA{station}_D_2025.xlsx"
            file_path = os.path.join(excel_folder, file_name)

            if not os.path.exists(file_path):
                log_message(f"Arquivo não encontrado: {file_name}. Ignorando.")
                continue

            log_message(f"Lendo o arquivo Excel: {file_name}")
            print(f"Lendo o arquivo Excel: {file_name}")
            try:
                df = pd.read_excel(file_path)
                df.columns = df.columns.str.replace('"', '').str.strip()  
                df.columns = df.columns.str.replace('  ', ' ').str.strip()  

            except Exception as e:
                log_message(f"Erro ao ler o arquivo {file_name}: {e}")
                continue

            if df.empty:
                log_message(f"Arquivo vazio: {file_name}. Ignorando.")
                continue

            log_message(f"Dados lidos do arquivo {file_name} com {len(df)} linhas.")
            print(f"Dados lidos do arquivo {file_name} com {len(df)} linhas.", flush=True)
            log_message(f"Colunas originais disponíveis no arquivo {file_name}: {df.columns.tolist()}")
            try:
                required_columns = ["EMA", "Timestamp", "TA (oC)", "TAx (oC)", "TAm (oC)", 
                                    "HR (%)", "HRx (%)", "HRm (%)", "RG (KJ/m2)", "DV (graus)", 
                                    "VV (m/s)", "VVx (m/s)", "PR (mm)", "TS0 (oC)", "TS0x (oC)", 
                                    "TS0m (oC)", "ET0 (mm/d)"]

                missing_columns = [col for col in required_columns if col not in df.columns]
                if missing_columns:
                    log_message(f"Colunas ausentes no arquivo {file_name}: {missing_columns}")
                    print(f"Colunas ausentes no arquivo {file_name}: {missing_columns}", flush=True)
                    continue

                df_access = pd.DataFrame({
                    "N": df["EMA"],
                    "Data": pd.to_datetime(df["Timestamp"], format="%d/%m/%Y %H:%M:%S").dt.strftime("%d/%m/%Y"),
                    "T_md": df["TA (oC)"],
                    "T_mx": df["TAx (oC)"],
                    "T_mn": df["TAm (oC)"],
                    "HR_md": df["HR (%)"],
                    "HR_mx": df["HRx (%)"],
                    "HR_mn": df["HRm (%)"],
                    "RG_int0": df["RG (KJ/m2)"],
                    "DV_md": df["DV (graus)"],
                    "VV_md": df["VV (m/s)"],
                    "VV_mx": df["VVx (m/s)"],
                    "P": df["PR (mm)"],
                    "T_relva_md": df["TS0 (oC)"],
                    "T_relva_mx": df["TS0x (oC)"],
                    "T_relva_mn": df["TS0m (oC)"],
                    "ET0": df["ET0 (mm/d)"],
                    "EMA": df["EMA"]
                })

                df_access["N"] = df_access["N"].astype(int)

                log_message(f"Dados reformulados para inserção na base de dados para o arquivo {file_name}.")
            except KeyError as e:
                log_message(f"Erro ao reformatar dados no arquivo {file_name}: Coluna ausente {e}")
                print(f"Erro ao reformatar dados no arquivo {file_name}: Coluna ausente {e}", flush=True)
                continue
            except Exception as e:
                log_message(f"Erro inesperado ao reformatar dados no arquivo {file_name}: {e}")
                print(f"Erro inesperado ao reformatar dados no arquivo {file_name}: {e}", flush=True)
                continue

            # Verificação e inserção na base de dados
            log_message("Iniciando verificação e inserção de dados.")
            print("Iniciando verificação e inserção de dados.")
            for i, row in df_access.iterrows():
                try:
                    if not is_record_present(cursor, row['EMA'], row['Data']):
                        log_message(f"Registo {i}: {row.to_dict()}")
                        cursor.execute(
                            """
                            INSERT INTO Tabela1 (
                                [N],[Data], [T_md], [T_mx], [T_mn], [HR_md], [HR_mx], [HR_mn],
                                [RG_int0], [DV_md], [VV_md], [VV_mx], [P],
                                [T_relva_md], [T_relva_mx], [T_relva_mn], [ET0], [EMA], [sync], [nr_registo]
                            )
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                row['N'],
                                row['Data'],
                                row['T_md'], row['T_mx'], row['T_mn'],
                                row['HR_md'], row['HR_mx'], row['HR_mn'],
                                row['RG_int0'], row['DV_md'], row['VV_md'], row['VV_mx'],
                                row['P'], row['T_relva_md'], row['T_relva_mx'], row['T_relva_mn'],
                                row['ET0'], row['EMA'], None, None
                            )
                        )
                    else:
                        log_message(f"Registo {i} já existe na base de dados: {row.to_dict()}")
                except Exception as e:
                    log_message(f"Erro ao processar o registo {i} no arquivo {file_name}: {e}")

        conn.commit()
        log_message("Dados inseridos com sucesso na base de dados Access.")
        print("Dados inseridos com sucesso na base de dados Access.")

        cursor.close()
        conn.close()
        log_message("Conexão com a base de dados Access encerrada.")
        print("Conexão com a base de dados Access encerrada.")
    except pyodbc.Error as e:
        log_message(f"Erro ao conectar à base de dados Access: {e}")
        print(f"Erro ao conectar à base de dados Access: {e}")
    except Exception as e:
        log_message(f"Erro inesperado: {e}")
        print(f"Erro inesperado: {e}")


# Executes the main function
process_files()
