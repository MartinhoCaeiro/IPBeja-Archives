import { Joke } from "../App";

const JokeList = ({ jokes }: { jokes: Joke[] }) => {
  return (
    <div className="joke-list">
      <h2>Jokes</h2>
      {Array.isArray(jokes) &&
        jokes.slice(0, 10).map((joke: Joke, index) => (
          <div key={joke.id} className="joke">
            <span className="joke-number">{index + 1}. </span>
            {joke.value}
          </div>
        ))}
    </div>
  );
};

export default JokeList;
