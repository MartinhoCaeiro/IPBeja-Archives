import { Dispatch, SetStateAction } from "react";

interface CategorySelectorProps {
  categories: string[];
  onCategorySelect: Dispatch<SetStateAction<string>>;
}

function CategorySelector({
  categories,
  onCategorySelect,
}: CategorySelectorProps) {
  return (
    <div className="category-selector">
      <h2>Categories</h2>
      <ul>
        {categories.map((category) => (
          <li key={category} onClick={() => onCategorySelect(category)}>
            {category}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CategorySelector;
