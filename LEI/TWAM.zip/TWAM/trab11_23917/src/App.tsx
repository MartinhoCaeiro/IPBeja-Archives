import { useState, useEffect } from "react";
import axios from "axios";
import CategorySelector from "./components/CategorySelector";
import JokeList from "./components/JokeList";
import "./App.css";

export interface Joke {
  id: string;
  value: string;
}

function App() {
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [jokes, setJokes] = useState<Joke[]>([]);

  useEffect(() => {
    axios
      .get<string[]>("https://api.chucknorris.io/jokes/categories")
      .then((response) => setCategories(response.data))
      .catch((error) => console.log(error));
  }, []);

  useEffect(() => {
    if (selectedCategory !== "") {
      axios
        .get<{ result: Joke[] }>(
          `https://api.chucknorris.io/jokes/search?query=${selectedCategory}`
        )
        .then((response) => setJokes(response.data.result))
        .catch((error) => console.log(error));
    }
  }, [selectedCategory]);
  return (
    <div className="app">
      <CategorySelector
        categories={categories}
        onCategorySelect={setSelectedCategory}
      />
      {selectedCategory !== "" && <JokeList jokes={jokes} />}
    </div>
  );
}

export default App;
