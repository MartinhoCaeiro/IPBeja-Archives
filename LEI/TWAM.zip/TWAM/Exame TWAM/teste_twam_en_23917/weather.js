// Martinho Caeiro (23917) - MartinhoC04@hotmail.com

$(document).ready(function () {
  let dates = [];
  let locations = [];
  let weatherData = [];

  $.getJSON("dates.json", function (data) {
    dates = data;
    let datesList = $("#dates-list");
    datesList.empty();
    $.each(dates, function (index, dateItem) {
      datesList.append(`<li>${dateItem.date}</li>`);
    });
  });

  $.getJSON("locations.json", function (data) {
    locations = data;
    let locationList = $("#location-list");
    locationList.empty();
    $.each(locations, function (index, locationItem) {
      locationList.append(`<li>${locationItem.name}</li>`);
    });
    loadLocationOptions();
  });

  $.getJSON("weather-data.json", function (data) {
    weatherData = data;
  });

  window.loadLocationOptions = function () {
    let locationSelect = $("#location-select");
    locationSelect.empty();
    locationSelect.append('<option value="">Localidade/option>');
    $.each(locations, function (index, locationItem) {
      locationSelect.append(
        `<option value="${locationItem.name}">${locationItem.name}</option>`
      );
    });
  };

  window.getInputs = function (selectedLocation, firstDate, lastDate) {
    let selectedLocationDetails = location.find(
      (locationItem) => locationItem.name === selectedLocation
    );
    let firstDateDetails = location.find(
      (dateItem) => dateItem.id === firstDate
    );
    let lastDateDetails = location.find((dateItem) => dateItem.id === lastDate);

    return {
      location: selectedLocationDetails.id,
      firstdate: firstDateDetails.date,
      lastdate: lastDateDetails.date,
    };
  };

  window.computeMetrics = function (selectedLocation, weatherData) {
    let selectedLocationDetails = location.find(
      (locationItem) => locationItem.name === selectedLocation
    );

    if (weatherData.max-temp >= 30) {
      morethen30++;
    }

    maxtemp = selectedLocationDetails.max-temp
    mintemp = selectedLocationDetails.min-temp
    precipitation = selectedLocationDetails.precipitation

    let results = [maxtemp, mintemp, precipitation, morethen30]

    return {
      results
    };
  };

  window.resultsView = function (getInputs) {
    let selectedLocation = $("#location-select").val();
    if (selectedLocation) {
      let locationWeather = getInputs(selectedLocation);
      let WeatherTable = $("#weather-table tbody");
      WeatherTable.empty();
      $.each(locationWeather, function (index, weather) {
        WeatherTable.append(
          `<tr><a>Média Temperaturas Máximas</a><td>${weather.temp-max}</td></tr>
          <tr><a>Média Temperaturas Minimas</a><td>${weather.temp-min}</td></tr>
          <tr><a>Total de Precipitação</a><td>${weather.precipitation}</td></tr>
          <tr><a>Número Dias com Temperaturas Superiores a 30º</a><td>${weather.numero}</td></tr>`
        );
      });
    }
  };
});
