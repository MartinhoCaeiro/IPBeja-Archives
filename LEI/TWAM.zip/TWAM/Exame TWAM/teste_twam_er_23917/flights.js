// Martinho Caeiro (23917) - MartinhoC04@hotmail.com

let flights = [];

$(document).ready(function () {
  axios
    .get("flights.json")
    .then(function (response) {
      flights = response.data.flights;
      console.log("Voos carregados:", flights);
      loadSelects();
    })
    .catch(function (error) {
      console.log("Erro ao carregar flights.json", error);
    });

  $("#search").click(function (event) {
    event.preventDefault();
    getInputs();
  });
});

function loadSelects() {
  let form1 = $("#selectLocal1");
  let form2 = $("#selectLocal2");
  let form3 = $("#date1");
  let form4 = $("#date2");
  let form5 = $("#time1");
  let form6 = $("#time2");

  flights.forEach(function (flight) {
    let listItem1 = `<option value="${flight.id}">${flight.origin}</option>`;
    let listItem2 = `<option value="${flight.id}">${flight.destination}</option>`;
    let listItem3 = `<option value="${flight.id}">${flight.date}</option>`;
    let listItem4 = `<option value="${flight.id}">${flight.departure_time}</option>`;
    let listItem5 = `<option value="${flight.id}">${flight.arrival_time}</option>`;
    form1.append(listItem1);
    form2.append(listItem2);
    form3.append(listItem3);
    form4.append(listItem3);
    form5.append(listItem4);
    form6.append(listItem5);
  });
}

function getInputs() {
  let from = document.getElementById("selectLocal1").value;
  let to = document.getElementById("selectLocal2").value;
  let date1 = document.getElementById("date1").value;
  let date2 = document.getElementById("date2").value;
  let afterTime = document.getElementById("time1").value;
  let beforeTime = document.getElementById("time2").value;
  console.log("Origem selecionada:", from);
  console.log("Destino selecionada:", to);
  console.log("Data Inicial:", date1);
  console.log("Data Final:", date2);
  console.log("Hora Partida:", afterTime);
  console.log("Hora Chegada:", beforeTime);

  searchFlights(from, to, date1, date2, afterTime, beforeTime);
}

function searchFlights(from, to, date1, date2, afterTime, beforeTime) {
  console.log("Pesquisando Voos para:");
  console.log("Origem selecionada:", from);
  console.log("Destino selecionada:", to);
  console.log("Data Inicial:", date1);
  console.log("Data Final:", date2);
  console.log("Hora Partida:", afterTime);
  console.log("Hora Chegada:", beforeTime);

  originId = parseInt(from);
  destinationId = parseInt(to);
  date1Id = parseInt(date1);
  date2Id = parseInt(date2);
  departureId = parseInt(afterTime);
  arrivalId = parseInt(beforeTime);

  let results = {
    origin: flights.find(flights => flights.origin === from),
    destination: flights.find(flights => flights.destination === destinationId),
    date: flights.find(flights => flights.date === date1Id),
    company: flights.find(flights => flights.date === date2Id),
    price: flights.find(flights => flights.price),
    departure_time: flights.find(flights => flights.departure_time === departureId),
    arrival_time: flights.find(flights => flights.arrival_time === arrivalId),
  };

  drawBoard(results);
}

function drawBoard(results) {
  let resultadosDiv = $("#resultados");
  resultadosDiv.empty();

  let resultsTable = `<table class="table">
        <thead>
            <tr>
                <th scope="col">Voo</th>
                <th scope="col">Data</th>
                <th scope="col">Companhia</th>
                <th scope="col">Preço</th>
                <th scope="col">Saida</th>
                <th scope="col">Chegada</th>
            </tr>
        </thead>
        <tbody>
           <tr><td>${results.origin}-${results.destination}</td><td>${results.date}</td><td>${results.company}</td><td>${results.price}</td><td>${results.departure_time}</td><td>${results.arrival_time}</td></tr>
        </tbody>
    </table>`;

  resultadosDiv.append(resultsTable);
}
