$(document).ready(function() {
    $.getJSON('epocas.json', function(data) {
        var epocasContainer = $('#epocas');
        epocasContainer.empty(); // Clear any existing content
        $.each(data, function(index, epoca) {
            var radio = `<label><input type="radio" name="epoca" value="${epoca.nome}"> ${epoca.nome}</label><br>`;
            epocasContainer.append(radio);
        });
    });

    $.getJSON('uc.json', function(data) {
        var ucDropdown = $('#UC');
        ucDropdown.empty(); // Clear any existing content
        $.each(data, function(index, uc) {
            var option = `<option value="${uc.nome}">${uc.nome}</option>`;
            ucDropdown.append(option);
        });
    });
});

function inscrever() {
    const epoca = $('input[name="epoca"]:checked').val();
    const uc = $('#UC').val();

    if (!epoca || !uc) {
        alert('Por favor, selecione uma época e uma unidade curricular.');
        return;
    }

    const novaInscricao = {
        epoca: epoca,
        uc: uc
    };

    window.inscricoes_exame = window.inscricoes_exame || [];
    window.inscricoes_exame.push(novaInscricao);

    atualizarTabelaInscricoes();
}

function atualizarTabelaInscricoes() {
    const tabela = $('#inscricoes-tabela');
    tabela.empty();
    window.inscricoes_exame.forEach(inscricao => {
        const row = `<tr><td>${inscricao.epoca}</td><td>${inscricao.uc}</td></tr>`;
        tabela.append(row);
    });
}
