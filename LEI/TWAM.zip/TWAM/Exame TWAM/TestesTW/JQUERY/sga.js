$(document).ready(function() {
    let students = [];
    let uc = [];
    let grades = [];

    // Leitura dos arquivos JSON
    $.getJSON('students.json', function(data) {
        students = data;
        let studentsList = $('#students-list');
        studentsList.empty();
        $.each(students, function(index, student) {
            studentsList.append(`<li>${student.nome}</li>`);
        });
    });

    $.getJSON('uc.json', function(data) {
        uc = data;
        let ucList = $('#uc-list');
        ucList.empty();
        $.each(uc, function(index, ucItem) {
            ucList.append(`<li>${ucItem.nome}</li>`);
        });
        loadUCOptions();
    });

    $.getJSON('grades.json', function(data) {
        grades = data;
    });

    // Função para alternar páginas
    window.togglePage = function(page) {
        $('main section').hide();
        $(`#${page}`).show();
    };

    // Função para popular a caixa "Curso"
    window.loadUCOptions = function() {
        let ucSelect = $('#uc-select');
        ucSelect.empty();
        ucSelect.append('<option value="">Selecione uma UC</option>');
        $.each(uc, function(index, ucItem) {
            ucSelect.append(`<option value="${ucItem.nome}">${ucItem.nome}</option>`);
        });
    };

    // Função para obter as classificações das UCs
    window.getUCGrades = function(selectedUC) {
        let selectedUCDetails = uc.find(ucItem => ucItem.nome === selectedUC);
        let ucGrades = grades.filter(grade => grade.uc === selectedUC);
        return ucGrades.map(grade => {
            let estudante = students.find(student => student.nome === grade.estudante);
            return {
                numero: estudante.id,
                nome: grade.estudante,
                elementos: selectedUCDetails.elementos,
                media: grade.nota
            };
        });
    };

    // Função para exibir a tabela de classificações
    window.ucGradesView = function() {
        let selectedUC = $('#uc-select').val();
        if (selectedUC) {
            let ucGrades = getUCGrades(selectedUC);
            let gradesTable = $('#grades-table tbody');
            gradesTable.empty();
            $.each(ucGrades, function(index, grade) {
                gradesTable.append(`<tr><td>${grade.numero}</td><td>${grade.nome}</td><td>${grade.elementos}</td><td>${grade.media}</td></tr>`);
            });
        }
    };
});
