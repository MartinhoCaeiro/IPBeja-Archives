let locations = [];
let dates = [];
let weatherData = [];

$(document).ready(function() {
    // Carrega o arquivo locations.json
    axios.get('locations.json')
        .then(function(response) {
            locations = response.data.locations;  
            console.log("Locais carregados:", locations);  
            loadLocationOptions();
        })
        .catch(function(error) {
            console.log("Erro ao carregar locations.json", error);
        });

    // Carrega o arquivo dates.json
    axios.get('dates.json')
        .then(function(response) {
            dates = response.data.recorded_days;  
            console.log("Datas carregadas:", dates);
            loadDatasOptions();
        })
        .catch(function(error) {
            console.log("Erro ao carregar dates.json", error);
        });

    // Carrega o arquivo weather-data.json
    axios.get('weather-data.json')
        .then(function(response) {
            weatherData = response.data.weather_data;  
            console.log("Dados meteorológicos carregados:", weatherData);  
        })
        .catch(function(error) {
            console.log("Erro ao carregar weather-data.json", error);
        });

    // Adiciona o evento de clique ao botão de pesquisar
    $("#search").click(function(event) {
        event.preventDefault(); // Evita o comportamento padrão do botão (envio de formulário)
        getInputs();
    });
});

function loadLocationOptions() {
    let form = $('#selectLocal');  
    locations.forEach(function(location) {
        let listItem = `<option value="${location.id}">${location.name}</option>`;
        form.append(listItem);  
    });
}

function loadDatasOptions() {
    let formData1 = $('#date1');  
    let formData2 = $('#date2');  
    dates.forEach(function(date) {
        let listItem = `<option value="${date.id}">${date.date}</option>`;
        formData1.append(listItem);  
        formData2.append(listItem);  
    });
}

function getInputs() {
    let ansLocation = document.getElementById("selectLocal").value;
    let date1Id = document.getElementById("date1").value;
    let date2Id = document.getElementById("date2").value;
    console.log("Localidade selecionada:", ansLocation);
    console.log("Data Inicial (ID):", date1Id);
    console.log("Data Final (ID):", date2Id);
    
    computeMetrics(ansLocation, date1Id, date2Id);
}

function computeMetrics(locationId, date1Id, date2Id) {
    console.log("Computando métricas para:");
    console.log("ID da localização:", locationId);
    console.log("Data Inicial (ID):", date1Id);
    console.log("Data Final (ID):", date2Id);

    // Convertendo IDs para inteiros
    locationId = parseInt(locationId);
    date1Id = parseInt(date1Id);
    date2Id = parseInt(date2Id);

    let filteredData = weatherData.filter(weather => 
        weather.id_location === locationId &&
        weather.id_date >= date1Id &&
        weather.id_date <= date2Id
    );

    console.log("Dados filtrados:", filteredData);

    let hotter30 = 0;
    let totalMax = 0;
    let totalMin = 0;
    let totalPrecp = 0;

    filteredData.forEach(function(weather) {
        totalMax += weather["temp-max"];
        totalMin += weather["temp-min"];
        totalPrecp += weather.precipitation;
        if (weather["temp-max"] >= 30) {
            hotter30++;
        }
    });

    let averageMax = totalMax / filteredData.length;
    let averageMin = totalMin / filteredData.length;

    let localTempo = locations.find(local => local.id === locationId);
    let date1 = dates.find(date => date.id === date1Id).date;
    let date2 = dates.find(date => date.id === date2Id).date;
    let results = {
        locationId: localTempo ? localTempo.name : "Desconhecido",
        inicio: date1,
        final: date2,
        maxTemp: averageMax.toFixed(0),
        minTemp: averageMin.toFixed(0),
        precp: totalPrecp,
        hotter: hotter30
    };

    resultView(results);
}

function resultView(results) {
    let resultadosDiv = $("#resultados");
    resultadosDiv.empty();  

    let resultHeader = `<p><b>Localidade:</b> ${results.locationId} <b>Data Inicial:</b> ${results.inicio} <b>Data Final:</b> ${results.final}</p>`;
    resultadosDiv.append(resultHeader);

    let resultsTable = `<table class="table">
        <thead>
            <tr>
                <th scope="col">Métricas</th>
                <th scope="col">Valores</th>
            </tr>
        </thead>
        <tbody>
            <tr><td>Média da Temperatura Máxima</td><td>${results.maxTemp}°C</td></tr>
            <tr><td>Média da Temperatura Mínima</td><td>${results.minTemp}°C</td></tr>
            <tr><td>Total Precipitação</td><td>${results.precp}mm</td></tr>
            <tr><td>Nº dias com Temperaturas Superiores a 30ºC</td><td>${results.hotter} dia(s)</td></tr>
        </tbody>
    </table>`;

    resultadosDiv.append(resultsTable);
}
