let degrees = [];
let students = [];
let uc = [];
let grades = [];

window.onload = function() {
    fetch('degrees.json')
        .then(response => response.json())
        .then(data => {
            degrees = data;
            console.log('Degrees loaded:', degrees);
            loadDegreeOptions();
        });

    fetch('students.json')
        .then(response => response.json())
        .then(data => {
            students = data;
            console.log('Students loaded:', students);
        });

    fetch('uc.json')
        .then(response => response.json())
        .then(data => {
            uc = data;
            console.log('UC loaded:', uc);
        });

    fetch('grades.json')
        .then(response => response.json())
        .then(data => {
            grades = data;
            console.log('Grades loaded:', grades);
        });
}

function loadDegreeOptions() {
    const select = document.getElementById('UC');
    degrees.forEach(degree => {
        const option = document.createElement('option');
        option.value = degree.id;
        option.textContent = degree.name;
        select.appendChild(option);
    });
}

function togglePage() {
    $("#Container").toggle();
    $("#degree-section").toggle();
    $("#navbar").toggle();
}

function getDegreeGrades(degreeId) {
    return grades.filter(grade => grade.degreeId === parseInt(degreeId));
}

function DegreeGradesView() {
    const select = document.getElementById('UC');
    const degreeId = select.value;
    const degreeGrades = getDegreeGrades(degreeId);
    console.log('Degree Grades:', degreeGrades);

    const tbody = document.getElementById('inscricoes-tabela');
    tbody.innerHTML = '';

    degreeGrades.forEach(grade => {
        const student = students.find(s => s.id === grade.studentId);
        const ucItem = uc.find(u => u.id === grade.ucId);

        const row = document.createElement('tr');
        const epochCell = document.createElement('td');
        const studentCell = document.createElement('td');
        const gradeCell = document.createElement('td');

        epochCell.textContent = grade.epoch;
        studentCell.textContent = student ? student.name : 'Desconhecido';
        gradeCell.textContent = grade.grade;

        row.appendChild(epochCell);
        row.appendChild(studentCell);
        row.appendChild(gradeCell);
        tbody.appendChild(row);
    });
}

document.getElementById('UC').addEventListener('change', DegreeGradesView);
document.getElementById('class-button').addEventListener('click', togglePage);
    