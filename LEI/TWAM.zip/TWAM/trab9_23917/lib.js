function includeHeaderAndFooter() {
    var headerHTML = `
        <header class="bg-primary border rounded text-white p-3 mb-3">
            <nav>
                <ul>
                    <li><a href="Inicio.html">Início</a></li>
                    <li><a href="Curriculum.html">Curriculum Vitae</a></li>
                    <li><a href="Horário.html">Horário</a></li>
                    <li><a href="Contacto.html">Contato</a></li>
                </ul>
            </nav>
        </header>
    `;

    var footerHTML = `
        <footer class="bg-dark border rounded text-white text-center p-3 mt-3">
            <p>Última Atualização a 09/04/2024.</p>
            <p>Verificado pelo <a href="https://jigsaw.w3.org/css-validator/">validador da W3C</a>.</p>
            <p>&copy; 2024 Info.Martinho Caeiro. Todos os direitos reservados.</p>
        </footer>
    `;

    document.body.insertAdjacentHTML('afterbegin', headerHTML);
    document.body.insertAdjacentHTML('beforeend', footerHTML);
}

includeHeaderAndFooter()


if (window.location.pathname.includes("Contacto.html")) {
    function processarEnvioFormulario(event) {
        event.preventDefault();

        var nomeCompleto = document.getElementById('nome').value;
       
        if (nomeCompleto.split(' ').length < 2) {
            alert("Por favor, insira o primeiro e último nome.");
            return;
        }

        var partesNome = nomeCompleto.split(' '); 
        var primeiroNome = partesNome[0]; 
        var ultimoNome = partesNome[partesNome.length - 1]; 

        console.log('Primeiro Nome:', primeiroNome);
        console.log('Último Nome:', ultimoNome);

        this.submit();
    }

    document.getElementById('meuFormulario').addEventListener('submit', processarEnvioFormulario);
}

function createTable(diasSemana, periodosHorarios, ucs, coresUCs) {
    const table = document.createElement('table');
    const headerRow = table.insertRow();
    const horaHeaderCell = headerRow.insertCell();

    horaHeaderCell.textContent = 'Horas\\Dias' ;
    horaHeaderCell.style.backgroundColor = 'lightgrey';
    horaHeaderCell.style.border = '1px solid grey';
    horaHeaderCell.style.borderRadius = '5px';
    horaHeaderCell.style.fontSize = 'calc(4px + 1.5vw)';
    for (const dia of diasSemana) {
        const diaCell = headerRow.insertCell();
        diaCell.textContent = dia;
        diaCell.style.backgroundColor = 'lightgrey';
        diaCell.style.border = '1px solid grey';
        diaCell.style.borderRadius = '5px';
        diaCell.style.fontSize = 'calc(4px + 1.5vw)';
    }

    for (const periodo of periodosHorarios) {
        const row = table.insertRow();
        const horaCell = row.insertCell();
        horaCell.textContent = periodo;
        horaCell.style.backgroundColor = 'lightgrey';
        horaCell.style.border = '1px solid grey';
        horaCell.style.borderRadius = '5px';
        horaCell.style.fontSize = 'calc(4px + 1.5vw)'; 

        for (const dia of diasSemana) {
            const uc = ucs[dia] && ucs[dia][periodo];
            if (uc) {
                const rowspan = ucs[dia][periodo + '_rowspan'] || 1;
                const ucCell = document.createElement('td');
                ucCell.textContent = uc;
                ucCell.rowSpan = rowspan;
                ucCell.style.backgroundColor = coresUCs[uc] || 'white';
                ucCell.style.border = '1px solid grey';
                ucCell.style.borderRadius = '5px';
                ucCell.style.fontSize = 'calc(4px + 1.5vw)';
                row.appendChild(ucCell);
            }
        }
    }

    document.getElementById('horario').appendChild(table);
}

const diasSemana = ['Segunda-Feira', 'Terça-Feira', 'Quarta-Feira', 'Quinta-Feira', 'Sexta-Feira'];
const periodosHorarios = ['8h30', '9h30', '10h30', '11h30', '12h30', '13h30', '14h30', '15h30', '16h30', '17h30'];
const ucs = {
    'Segunda-Feira': {
        '8h30': ' ',
        '8h30_rowspan': 2,
        '10h30': 'Redes II (S11)',
        '10h30_rowspan': 3,
        '13h30': ' ',
        '13h30_rowspan': 5
    },
    'Terça-Feira': {
        '8h30': 'TWAM (Lab10)',
        '8h30_rowspan': 4,
        '12h30': ' ',
        '12h30_rowspan': 1,
        '13h30': 'EDA (S3)',
        '13h30_rowspan': 1,
        '14h30': 'EDA (Lab12)',
        '14h30_rowspan': 3,
        '17h30': ' ',
        '17h30_rowspan': 1
    },
    'Quarta-Feira': {
        '8h30': ' ',
        '8h30_rowspan': 1,
        '9h30': 'IPC (Lab9)',
        '9h30_rowspan': 4,
        '13h30': ' ',
        '13h30_rowspan': 5
    },
    'Quinta-Feira': {
        '8h30': ' ',
        '8h30_rowspan': 2,
        '10h30': 'Engenharia S. (Lab12)',
        '10h30_rowspan': 3,
        '13h30': ' ',
        '13h30_rowspan': 5,
    },
    'Sexta-Feira': {
        '8h30': ' ',
        '8h30_rowspan': 10
    }
    
};
const colors = {
    'Redes II (S11)': '#ff9999',
    'TWAM (Lab10)': '#99ff99',
    'EDA (S3)': '#9999ff',
    'EDA (Lab12)': '#9999ff',
    'IPC (Lab9)': '#ffff99',
    'Engenharia S. (Lab12)': '#ff99ff',
    ' ': '#fff'
};

createTable(diasSemana, periodosHorarios, ucs, colors);
