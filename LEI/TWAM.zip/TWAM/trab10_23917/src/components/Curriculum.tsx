import React, { useState } from "react";

const Curriculum: React.FC = () => {
  const [showIdentification, setShowIdentification] = useState(true);
  const [showHabilitacoes, setShowHabilitacoes] = useState(true);

  return (
    <>
      <main>
        <button
          type="button"
          className="btn btn-outline-secondary"
          onClick={() => setShowIdentification(!showIdentification)}
        >
          <i className="fas fa-angle-down"></i> Esconder/Mostrar
        </button>

        {showIdentification && (
          <div id="identificacao" className="p-4 border rounded bg-white">
            <img
              src="./src/assets/Foto_Perfil.png"
              alt="Foto de Perfil"
              className="rounded-circle float-right "
              style={{
                maxWidth: "25%",
                maxHeight: "25%",
                marginRight: "20px",
              }}
            />

            <h1>Indentificação</h1>

            <p>
              <b>Nome:</b> Martinho José Novo Caeiro
            </p>
            <p>
              <b>Nascimento:</b> 11 de Junho 2004
            </p>
            <p>
              <b>Morada:</b> Rua Capitães de Abril, Nº57 - Vila Verde de Ficalho
            </p>
            <p>
              <b>NIF:</b> 247485896
            </p>
          </div>
        )}

        <button
          type="button"
          className="btn btn-outline-secondary"
          onClick={() => setShowHabilitacoes(!showHabilitacoes)}
        >
          <i className="fas fa-angle-down"></i> Esconder/Mostrar
        </button>

        {showHabilitacoes && (
          <div id="habilitacoes" className="p-4 border rounded bg-white">
            <h1>Habilitações</h1>

            <p>Escola Secundária de Moura: Ensino Secundário (12º)</p>
            <p>
              Escola Superior de Engenharia e Gestão: A concluir a Licenciatura
              em Engenharia Informática
            </p>
          </div>
        )}
      </main>
    </>
  );
};

export default Curriculum;
