import React from "react";

const Horario: React.FC = () => {
  return (
    <>
      <main>
        <section id="horario" className="p-4 border rounded bg-white">
          <h2>Horário</h2>
          <table>
            <thead>
              <tr>
                <th>Horas</th>
                <th>Segunda-Feira</th>
                <th>Terça-Feira</th>
                <th>Quarta-Feira</th>
                <th>Quinta-Feira</th>
                <th>Sexta-Feira</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>8h30</td>
                <td rowSpan={2}></td>
                <td className="UC1" rowSpan={4}>
                  TWAM (Lab10)
                </td>
                <td></td>
                <td rowSpan={2}></td>
                <td rowSpan={10}></td>
              </tr>
              <tr>
                <td>9h30</td>
                <td className="UC2" rowSpan={4}>
                  IPC (Lab9)
                </td>
              </tr>
              <tr>
                <td>10h30</td>
                <td className="UC3" rowSpan={3}>
                  Redes II (S11)
                </td>
                <td className="UC4" rowSpan={3}>
                  Engenharia S. (Lab12)
                </td>
              </tr>
              <tr>
                <td>11h30</td>
              </tr>
              <tr>
                <td>12h30</td>
                <td></td>
              </tr>
              <tr>
                <td>13h30</td>
                <td rowSpan={5}></td>
                <td className="UC5">EDA (S03)</td>
                <td rowSpan={5}></td>
                <td rowSpan={5}></td>
              </tr>
              <tr>
                <td>14h30</td>
                <td className="UC5" rowSpan={3}>
                  EDA (Lab12)
                </td>
              </tr>
              <tr>
                <td>15h30</td>
              </tr>
              <tr>
                <td>16h30</td>
              </tr>
              <tr>
                <td>17h30</td>
                <td></td>
              </tr>
            </tbody>
          </table>
          <br />
        </section>
      </main>
    </>
  );
};

export default Horario;
