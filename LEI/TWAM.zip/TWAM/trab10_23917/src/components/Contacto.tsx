import React from "react";

const Contato: React.FC = () => {
  return (
    <>
      <main>
        <section id="contato" className="p-4 border rounded bg-white">
          <h1>Contato</h1>
          <p>Entre em contato comigo através dos seguintes meios:</p>
          <ul>
            <li>
              <b>Email: </b>MartinhoC04@hotmail.com
            </li>
            <li>
              <b>Telemóvel: </b>964036237
            </li>
          </ul>
          <form id="meuFormulario" action="http://www.foo.com" method="POST">
            <div className="form-group">
              <label htmlFor="nome">
                <b>Nome:</b>
              </label>
              <input
                type="text"
                id="nome"
                name="nome"
                className="form-control"
                required
                pattern="[a-zA-Z]+[ ][a-zA-Z]+"
                title="Por favor, insira o nome e sobrenome separados por um espaço."
              />
              <span className="required"> *Campo Obrigatório </span>
              <br />
            </div>

            <div className="form-group">
              <label>
                <b>Tipo de Contato:</b>
              </label>
              <br></br>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  id="tipo_contato_pessoal"
                  name="tipo_contato"
                  value="pessoal"
                ></input>
                <label
                  className="form-check-label"
                  htmlFor="tipo_contato_pessoal"
                >
                  Pessoal
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  id="tipo_contato_profissional"
                  name="tipo_contato"
                  value="profissional"
                ></input>
                <label
                  className="form-check-label"
                  htmlFor="tipo_contato_profissional"
                >
                  Profissional
                </label>
              </div>
              <span className="required">*Campo Obrigatório</span>
            </div>

            <div className="form-group">
              <label htmlFor="email">
                <b>Email:</b>
              </label>
              <input
                type="email"
                id="email"
                name="email"
                className="form-control"
                required
              />
              <span className="required"> *Campo Obrigatório </span>
              <br />
            </div>

            <div className="form-group">
              <label htmlFor="assunto">
                <b>Assunto:</b>
              </label>
              <input
                type="text"
                id="assunto"
                name="assunto"
                className="form-control"
                required
              />
              <span className="required"> *Campo Obrigatório </span>
              <br />
            </div>

            <input type="submit" value="Enviar" className="btn btn-primary" />
          </form>
          <br />
        </section>
      </main>
    </>
  );
};

export default Contato;
