import Inicio from "./Inicio";
import Curriculum from "./Curriculum";
import Horario from "./Horario";
import Contacto from "./Contacto";
import { SetStateAction, useState } from "react";

function HeaderFooter() {
  const [currentPage, setCurrentPage] = useState("inicio");

  const handlePageChange = (page: SetStateAction<string>) => {
    setCurrentPage(page);
  };

  return (
    <>
      <header className="bg-primary border rounded text-white p-3 mb-3">
        <nav>
          <ul>
            <li>
              <a href="#" onClick={() => handlePageChange("inicio")}>
                Inicio
              </a>
            </li>
            <li>
              <a href="#" onClick={() => handlePageChange("curriculum")}>
                Curriculum
              </a>
            </li>
            <li>
              <a href="#" onClick={() => handlePageChange("horario")}>
                Horario
              </a>
            </li>
            <li>
              <a href="#" onClick={() => handlePageChange("contacto")}>
                Contacto
              </a>
            </li>
          </ul>
        </nav>
      </header>
      {currentPage === "inicio" && <Inicio />}
      {currentPage === "curriculum" && <Curriculum />}
      {currentPage === "horario" && <Horario />}
      {currentPage === "contacto" && <Contacto />}

      <footer className="bg-dark border rounded text-white text-center p-3 mt-3">
        <p>Última Atualização a 06/05/2024.</p>
        <p>
          Verificado pelo{" "}
          <a href="https://jigsaw.w3.org/css-validator/">validador da W3C</a>.
        </p>
        <p>&copy; 2024 Info.Martinho Caeiro. Todos os direitos reservados.</p>
      </footer>
    </>
  );
}

export default HeaderFooter;
