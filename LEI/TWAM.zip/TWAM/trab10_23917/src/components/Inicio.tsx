import React from "react";

const Inicio: React.FC = () => {
  return (
    <>
      <main>
        <section id="inicio" className="p-4 border rounded bg-white">
          <h1>Seja bem-vindo a Info.Martinho Caeiro!</h1>
          <h3>
            Aqui você encontrará informações sobre Martinho Caeiro. Pode
            utilizar o menu para percorrer as diferentes páginas de informação.
          </h3>
          <br />
        </section>
      </main>
    </>
  );
};

export default Inicio;
