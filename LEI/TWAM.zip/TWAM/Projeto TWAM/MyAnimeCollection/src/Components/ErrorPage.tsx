import Navbar from "./Navbar";

function ErrorPage() {
  return (
    <div>
      <Navbar/>
      <h1>Error Page</h1>
      <p> Erro 404! Página não encontrada!</p>
    </div>
  );
}

export default ErrorPage;
