import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
interface Joke {
 value: string;
}
@Component({
 selector: 'app-joke-list',
 template: `
 <h1>Piadas do Chuck Norris</h1>
 <button (click)="getJoke()">Obter Piada</button>
 <div *ngIf="joke">{{ joke.value }}</div>
 `
})
export class JokeListComponent implements OnInit {
 joke: Joke | undefined;
 constructor(private http: HttpClient) { }
 ngOnInit() {
 }
 getJoke() {
 this.http.get<Joke>('https://api.chucknorris.io/jokes/random')
 .subscribe((joke: Joke) => {
 this.joke = joke;
 });
 }
}