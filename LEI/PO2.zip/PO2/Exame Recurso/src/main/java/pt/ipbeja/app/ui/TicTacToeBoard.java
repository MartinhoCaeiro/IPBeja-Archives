package pt.ipbeja.app.ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.layout.GridPane;
import pt.ipbeja.app.model.TicTacToeGame;
import pt.ipbeja.app.model.View;
import pt.ipbeja.app.model.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;


/**
 * @author Martinho Caeiro (23917) - Foram adicionados os metodos selectFile e setBoardFromFile
 * @version 10/07/2024
 */

public class TicTacToeBoard extends GridPane implements View {

    private final TicTacToeGame gameModel;
    private TicTacToeButton[][] buttons;

    public TicTacToeBoard() throws IOException {
        this.gameModel = new TicTacToeGame(this);
        this.createBoard();
        this.setBoardFromFile(selectFile());
    }

    private List<String> selectFile() throws IOException {
        int min = 1;
        int max = 5;
        int random = min + (int) (Math.random() * (max - min));
        System.out.println("Ficheiro escolhido: " + random);

        Path path = Paths.get("levelfiles/" + random + ".txt");
        List<String> boardContent = Files.readAllLines(path);

        return boardContent;
    }

    public void setBoardFromFile(List<String> BoardContent){
        int row;
        int col;

        for (int i = 0; i < 3; i++) {
            row = i;

            String play = BoardContent.get(i);

            for (int j = 0; j < 3; j++) {
                col = j;

                char mark;
                if (j == 0) {
                    mark = play.charAt(0);
                }
                else if (j == 1){
                    mark = play.charAt(6);
                }
                else {
                    mark = play.charAt(14);
                }

                switch (mark) {
                    case 'X':
                        this.gameModel.setInitialPosition(new Position(row, col), Mark.X_MARK);
                        break;
                    case 'O':
                        this.gameModel.setInitialPosition(new Position(row, col), Mark.O_MARK);
                        break;
                }
            }
        }
    }

    @Override
    public void onBoardMarkChanged(Mark mark, Position position) {
        TicTacToeButton button = buttons[position.row()][position.col()];
        button.setMark(mark);
    }

    private void createBoard() {
        int rows = this.gameModel.getRows();
        int cols = this.gameModel.getCols();
        EventHandler<ActionEvent> handler = event -> {
            TicTacToeButton button = (TicTacToeButton) event.getSource();
            Position position = button.getPosition();
            TicTacToeBoard.this.gameModel.positionSelected(position);
            // ou apenas
            //game.positionSelected(position);
        };
        this.buttons = new TicTacToeButton[rows][cols];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                TicTacToeButton button = new TicTacToeButton(new Position(row, col));
                button.setOnAction(handler);
                this.add(button, col, row);
                buttons[row][col] = button;
            }
        }
    }

    @Override
    public void onGameWon(Player player) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "O jogador " + player + " venceu!");
        alert.showAndWait();
        System.exit(0);
    }

    @Override
    public void onGameDraw() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "O jogo terminou empatado.");
        alert.showAndWait();
        System.exit(0);
    }

}
















