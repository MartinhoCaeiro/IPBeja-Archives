package pt.ipbeja.app.model;

import java.util.Arrays;
import java.util.List;

/**
 * Tic Tac Toe board and game logic
 *
 * @author Martinho Caeiro (23917) - Foram adicionados os metodos setInitialPosition e boardRead
 * @version 10/07/2024
 */
public class TicTacToeGame {

    public static final int SIZE = 3;
    private int turnCounter;
    private Mark[][] board;
    private View view;

    public TicTacToeGame(View view) {
        this.view = view;
        this.startGame();
    }

    /**
     * Starts a new game
     */
    private void startGame() {
        this.turnCounter = 0;
        this.createBoard();
    }

    public void setInitialPosition(Position position, Mark mark) {
        board[position.row()][position.col()] = mark;
        view.onBoardMarkChanged(mark, position);
        this.turnCounter++;
    }

    public List<List> boardRead(){
        for (Mark[] marks : this.board) {

        }
        return null;
    }

    public int getRows() {
        return this.board.length;
    }

    public int getCols() {
        return this.board[0].length;
    }

    /**
     * Creates a new game board with Place.EMPTY and notifies listener
     */
    private void createBoard() {
        this.board = new Mark[SIZE][SIZE];
        for (int row = 0; row < SIZE; row++) {
            Arrays.fill(board[row], Mark.EMPTY);
        }
    }

    /**
     * Communicates selected position
     *
     * @param positionSelected The user's selected position
     */
    public void positionSelected(Position positionSelected) {
        this.turnCounter++;
        Player currentPlayer = getCurrentPlayer();

        board[positionSelected.row()][positionSelected.col()] = currentPlayer.mark();
        view.onBoardMarkChanged(currentPlayer.mark(), positionSelected);

        checkGameOver(currentPlayer, positionSelected);
    }

    /**
     * Checks whether the game has ended and notifies the listener if so.
     *
     * @param lastPlayer The Place representing the player
     * @param position   The Position of the last play
     */
    private void checkGameOver(Player lastPlayer, Position position) {
        if (this.checkWinner(position)) {
            this.view.onGameWon(lastPlayer);
        } else if (this.checkDraw()) {
            this.view.onGameDraw();
        }
    }

    /**
     * Get the current player
     *
     * @return the current player
     */
    private Player getCurrentPlayer() {
        return this.turnCounter % 2 == 0 ? Player.X : Player.O;
    }


    /**
     * Check if the game has ended in a draw
     *
     * @return True if game ended in a draw
     */
    private boolean checkDraw() {
       return this.turnCounter == SIZE * SIZE;
    }

    /**
     * Check whether there's a winning sequence for a given Position
     *
     * @param position The Position representing the play
     * @return True if the play resulted in a win, false otherwise
     */
    private boolean checkWinner(Position position) {
        int col = position.col();
        int row = position.row();
        return checkRow(row) || checkCol(col) || checkDiag(row, col) || checkAntiDiag(row, col);
    }

    /**
     * Check the given row for a winning sequence
     *
     * @param row The row index
     * @return True if the row has a winning sequence, false otherwise
     */
    private boolean checkRow(int row) {
        Mark[] boardRow = board[row];

        for (int col = 1; col < SIZE; col++) {
            Mark place = boardRow[col];
            if (place == Mark.EMPTY || boardRow[col] != boardRow[0]) return false;
        }
        return true;
    }

    /**
     * Check the given col for a winning sequence
     *
     * @param col The column index
     * @return True if the col has a winning sequence, false otherwise
     */
    private boolean checkCol(int col) {
        for (int row = 1; row < SIZE; row++) {
            Mark place = board[row][col];
            if (place == Mark.EMPTY || board[row][col] != board[0][col]) return false;
        }
        return true;
    }

    /**
     * Check the given diagonal (top-left -> bottom-right) for a winning sequence
     *
     * @param row The row index
     * @param col The col index
     * @return True if the diagonal has a winning sequence, false otherwise
     */
    private boolean checkDiag(int row, int col) {
        if (row != col) return false;
        for (int i = 1; i < SIZE; i++) {
            Mark place = board[i][i];
            if (place == Mark.EMPTY || place != board[0][0]) return false;
        }
        return true;
    }

    /**
     * Check the given diagonal (top-right -> bottom-left) for a winning sequence
     *
     * @param row The row index
     * @param col The col index
     * @return True if the diagonal has a winning sequence, false otherwise
     */
    private boolean checkAntiDiag(int row, int col) {
        if (row + col != SIZE - 1) return false;
        for (int i = 1; i < SIZE; i++) {
            Mark place = board[i][SIZE - i - 1];
            if (place == Mark.EMPTY || place != board[0][SIZE - 1]) return false;
        }
        return true;
    }
}
