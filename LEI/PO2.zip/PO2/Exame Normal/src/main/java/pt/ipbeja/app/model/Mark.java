package pt.ipbeja.app.model;

/**
 * @author Diogo Pina Manique
 * @version 13/03/2021
 */

public enum Mark {
    // this Mark enum has three possible values: EMPTY, X_MARK, and O_MARK
    EMPTY, X_MARK, O_MARK
}
