package pt.ipbeja.app.ui;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import pt.ipbeja.app.model.Mark;
import pt.ipbeja.app.model.Position;

/**
 * @author Diogo Pina Manique, João Paulo Barros
 * @version 2021/03/12, 2024/03/15
 */

public class TicTacToeButton extends Button {

    //public static final Image EMPTY = new Image("resources/noplayer.png");


    private static final Image EMPTY = new Image(TicTacToeButton.class.getResource("/noplayer.png").toString());
    private static final Image PLAYER_X = new Image(TicTacToeButton.class.getResource("/player1.png").toString());
    private static final Image PLAYER_O = new Image(TicTacToeButton.class.getResource("/player2.png").toString());

    private final ImageView imageView;
    private final Position pos;


    public TicTacToeButton(Position pos) {
        this.pos = pos;
        this.imageView = new ImageView(EMPTY);
        this.setGraphic(this.imageView);
    }

    public Position getPosition() {
        return this.pos;
    }

    public void setMark(Mark mark) {
        this.imageView.setImage(this.markToImage(mark));
    }

    private Image markToImage(Mark mark) {
        return switch (mark) {
            case X_MARK -> PLAYER_X;
            case O_MARK -> PLAYER_O;
            case EMPTY -> EMPTY;
        };
    }

}
