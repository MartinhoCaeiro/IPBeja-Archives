package pt.ipbeja.app.model;

/**
 * @author Diogo Pina Manique, João Paulo Barros
 * @version 2021/03/13, 2024/03/15
 */
public interface View {

    /**
     * Notifies that the Place at the given Position has changed
     * @param place The Place, representing a player
     * @param position The Position of the Place
     */
    void onBoardMarkChanged(Mark place, Position position);

    /**
     * Notifies that the game has ended with a win
     * @param place The Place representing the winning player
     */
    void onGameWon(Player place);

    /**
     * Notifies that the game has ended with a draw
     */
    void onGameDraw();
}
