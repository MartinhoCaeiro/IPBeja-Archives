package pt.ipbeja.app.ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import pt.ipbeja.app.model.TicTacToeGame;
import pt.ipbeja.app.model.View;
import pt.ipbeja.app.model.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;


/**
 * @author Martinho Caeiro (23917) - Adicionado os metodos readFile e setBoardFromFile
 * @version 19/06/2024
 */

public class TicTacToeBoard extends GridPane implements View {

    private final TicTacToeGame gameModel;
    private TicTacToeButton[][] buttons;

    public TicTacToeBoard() throws IOException {
        this.gameModel = new TicTacToeGame(this);
        this.createBoard();
        this.setBoardFromFile(readFile());
    }

    private List<String> readFile() throws IOException {
        TextInputDialog textInputDialog = new TextInputDialog();
        return Files.readAllLines(Path.of("levelFiles/1.txt"));
    }

    private void setBoardFromFile(List<String> BoardContent){
        for (int i = 0; i < BoardContent.size(); i++) {

            String plays = BoardContent.get(i);
            int row = Character.getNumericValue(plays.charAt(0));

            for (int j = 1; j < plays.length(); j++) {
                int col = j - 1;
                String mark = String.valueOf(plays.charAt(j));

                switch (mark){
                    case "X" :
                        gameModel.setInitialPosition(new Position(row, col), Mark.X_MARK);
                        break;

                    case "O" :
                        gameModel.setInitialPosition(new Position(row, col), Mark.O_MARK);
                        break;

                }
            }
        }
    }

    @Override
    public void onBoardMarkChanged(Mark mark, Position position) {
        TicTacToeButton button = buttons[position.row()][position.col()];
        button.setMark(mark);
    }

    private void createBoard() {
        int rows = this.gameModel.getRows();
        int cols = this.gameModel.getCols();
        EventHandler<ActionEvent> handler = event -> {
            TicTacToeButton button = (TicTacToeButton) event.getSource();
            Position position = button.getPosition();
            TicTacToeBoard.this.gameModel.positionSelected(position);
            // ou apenas
            //game.positionSelected(position);
        };
        this.buttons = new TicTacToeButton[rows][cols];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                TicTacToeButton button = new TicTacToeButton(new Position(row, col));
                button.setOnAction(handler);
                this.add(button, col, row);
                buttons[row][col] = button;
            }
        }
    }

    @Override
    public void onGameWon(Player player) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "O jogador " + player + " venceu!");
        alert.showAndWait();
        System.exit(0);
    }

    @Override
    public void onGameDraw() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "O jogo terminou empatado.");
        alert.showAndWait();
        System.exit(0);
    }

}
















