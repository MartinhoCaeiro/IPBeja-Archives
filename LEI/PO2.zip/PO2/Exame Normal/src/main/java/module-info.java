module pt.ipbeja {
    requires javafx.controls;
    exports pt.ipbeja.app.ui;

}