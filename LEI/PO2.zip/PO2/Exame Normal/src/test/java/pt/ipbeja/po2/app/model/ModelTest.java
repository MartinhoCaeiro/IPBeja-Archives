package pt.ipbeja.po2.app.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pt.ipbeja.app.model.*;
import pt.ipbeja.app.ui.TicTacToeBoard;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Martinho Caeiro (23917) - Adicionado o método testBoardRead
 * @version 19/06/2024
 */
class ModelTest {

    @Test
    @DisplayName("Teste da leitura de ficheiros")
    void testBoardRead(){

    }
}