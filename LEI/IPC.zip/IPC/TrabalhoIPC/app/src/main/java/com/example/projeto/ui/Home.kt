package com.example.projeto.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.projeto.R

@Composable
fun HomeScreen(
    navController: NavHostController,
    loginType: String?,
    mainViewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            BottomNavigationBar(
                items = listOf(
                    BottomNavItem("Inicio", "home", Icons.Default.Home),
                    BottomNavItem("Alarmes", "alarm", ImageVector.vectorResource(id = R.drawable.ic_alarm)),
                    BottomNavItem("Medicação", "medication", ImageVector.vectorResource(id = R.drawable.ic_medication)),
                    BottomNavItem("Definições", "settings", Icons.Default.Settings)
                ),
                currentRoute = "home",
                onItemClick = { navController.navigate(it.route) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                val greeting = when (loginType) {
                    "doente" -> "Boa Tarde, Sr. Joaquim!"
                    "medico" -> "Boa Tarde, Dr. Eugénio!"
                    else -> "Boa Tarde, Sr. João!"
                }
                Text(
                    text = greeting,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                if (loginType == "medico" || loginType == "supervisor") {
                    Text(
                        text = "Doente: Sr. Joaquim",
                        fontSize = 10.sp,
                        modifier = Modifier.align(Alignment.Start)
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(200.dp)
                        .align(Alignment.CenterHorizontally)
                ) {
                    SemiCircularProgressIndicator(
                        progress = mainViewModel.pillCount.toFloat() / 5f,
                        color = Color(0xFF4CAF50),
                        strokeWidth = 30f,
                        modifier = Modifier.fillMaxSize()
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${mainViewModel.pillCount}/5",
                            fontSize = 48.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Comprimidos para Tomar",
                            fontSize = 16.sp,
                            color = Color.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = "Próximos Comprimidos",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(16.dp))
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(5) { index ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 16.dp),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .background(Color.White)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.Gray)
                                ) {
                                    // Placeholder for image
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column {
                                    Text(text = "Ben-u-ron ${index + 1}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "1000g", fontSize = 14.sp)
                                    Text(text = "Tomar Amanhã às 10:00h", fontSize = 14.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Tomar na hora indicada",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD32F2F),
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = {
                                    if (mainViewModel.pillCount < 5) {
                                        mainViewModel.incrementPillCount()
                                        val message = if (loginType == "doente") {
                                            "Toma de Medicação Realizada!"
                                        } else {
                                            "Alerta de Toma Enviado!"
                                        }
                                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Todos os comprimidos já foram tomados!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(Color(0xFF4CAF50)),
                                enabled = mainViewModel.pillCount < 5,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (loginType == "doente") {
                                    Text(text = "Já Tomei!", color = Color.White)
                                } else {
                                    Text(text = "Enviar Alerta de Toma", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    val navController = rememberNavController()
    HomeScreen(navController = navController, loginType = "medico", mainViewModel = viewModel())
}
