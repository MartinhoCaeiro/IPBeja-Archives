package com.example.projeto.ui

import android.annotation.SuppressLint
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.projeto.R

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun MedicationScreen(navController: NavHostController, loginType: String?, modifier: Modifier = Modifier) {
    val context = LocalContext.current

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            BottomNavigationBar(
                items = listOf(
                    BottomNavItem("Inicio", "home", Icons.Default.Home),
                    BottomNavItem("Alarmes", "alarm", ImageVector.vectorResource(id = R.drawable.ic_alarm)),
                    BottomNavItem("Medicação", "medication", ImageVector.vectorResource(id = R.drawable.ic_medication)),
                    BottomNavItem("Definições", "settings", Icons.Default.Settings)
                ),
                currentRoute = "medication",
                onItemClick = { navController.navigate(it.route) }
            )
        }
    ) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "As suas Medicações",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            MedicationWeekSection(
                week = "Semana 1", medications = listOf(
                    MedicationItem("Ben-u-ron", "Diariamente às 10:00", Color.Green),
                    MedicationItem("Gaviscon", "Diariamente às 14:00", Color.Green),
                    MedicationItem("Ibuprofeno", "Diariamente às 21:00", Color.Green)
                )
            )

            MedicationWeekSection(
                week = "Semana 2", medications = listOf(
                    MedicationItem("Ben-u-ron", "Diariamente às 10:00", Color.Blue),
                    MedicationItem("Gaviscon", "Diariamente às 14:00", Color.Blue),
                    MedicationItem("Ibuprofeno", "Diariamente às 21:00", Color.Blue)
                )
            )

            MedicationWeekSection(
                week = "Semana 3", medications = listOf(
                    MedicationItem("Por Definir", "", Color.Red),
                    MedicationItem("Por Definir", "", Color.Red),
                    MedicationItem("Por Definir", "", Color.Red)
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { navController.navigate("calendar") },
                colors = ButtonDefaults.buttonColors(Color.Blue),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Visualizar Calendário Completo")
            }

            if (loginType == "medico") {
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val message = "Medicação Editada!"

                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(Color(0xFFFFC107)),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(text = "Editar Medicação do Paciente")
                }
            }
        }
    }
}

@Composable
fun MedicationWeekSection(week: String, medications: List<MedicationItem>) {
    Column(modifier = Modifier.padding(bottom = 16.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Text(text = week, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (week == "Semana 1") {
                Text(text = " ✔", fontSize = 18.sp, color = Color.Green)
            } else if (week == "Semana 3") {
                Text(text = " !", fontSize = 18.sp, color = Color.Red)
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            medications.forEach { medication ->
                MedicationCard(medication)
            }
        }
    }
}

@Composable
fun MedicationCard(medication: MedicationItem) {
    Card(
        modifier = Modifier
            .padding(0.dp)
            .width(100.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .background(medication.color, shape = RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            Text(
                text = medication.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = medication.time,
                fontSize = 12.sp,
                color = Color.White
            )
        }
    }
}

data class MedicationItem(
    val name: String,
    val time: String,
    val color: Color
)

@Preview(showBackground = true)
@Composable
fun MedicationScreenPreview() {
    val navController = rememberNavController()
    MedicationScreen(navController = navController, loginType = "medico")
}
