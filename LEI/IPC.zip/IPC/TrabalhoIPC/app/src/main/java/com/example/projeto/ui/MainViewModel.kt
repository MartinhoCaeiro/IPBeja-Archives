package com.example.projeto.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    var pillCount by mutableIntStateOf(0)
        private set

    fun incrementPillCount() {
        if (pillCount < 5) {
            pillCount++
        }
    }
}
