package com.example.projeto.ui

import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class LoginViewModel : ViewModel() {
    var loginType by mutableStateOf<String?>(null)
        private set

    fun updateLoginType(type: String) {
        loginType = type
    }
}
