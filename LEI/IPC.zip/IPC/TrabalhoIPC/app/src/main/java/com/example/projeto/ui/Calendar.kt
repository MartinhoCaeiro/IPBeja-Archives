package com.example.projeto.ui

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun CalendarScreen(modifier: Modifier = Modifier) {
    val currentMonth = remember { mutableStateOf(YearMonth.now()) }
    val selectedDate = remember { mutableStateOf<LocalDate?>(null) }

    Column(modifier = modifier.padding(16.dp)) {
        MonthHeader(
            currentMonth = currentMonth.value,
            onPreviousMonth = { currentMonth.value = currentMonth.value.minusMonths(1) },
            onNextMonth = { currentMonth.value = currentMonth.value.plusMonths(1) }
        )
        Spacer(modifier = Modifier.height(16.dp))
        CalendarView(
            currentMonth = currentMonth.value,
            selectedDate = selectedDate.value,
            onDateSelected = { selectedDate.value = it }
        )
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun MonthHeader(currentMonth: YearMonth, onPreviousMonth: () -> Unit, onNextMonth: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPreviousMonth) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Mês Anterior")
        }
        Text(
            text = currentMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
            style = MaterialTheme.typography.titleLarge
        )
        IconButton(onClick = onNextMonth) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Mês Posterior")
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun CalendarView(currentMonth: YearMonth, selectedDate: LocalDate?, onDateSelected: (LocalDate) -> Unit) {
    val firstDayOfMonth = currentMonth.atDay(1)
    val dayOfWeek = firstDayOfMonth.dayOfWeek.value % 7
    val daysInMonth = currentMonth.lengthOfMonth()

    Column {
        DayOfWeekHeader()
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.fillMaxHeight()
        ) {
            items(dayOfWeek) {
                Spacer(modifier = Modifier.aspectRatio(1f))
            }

            items(daysInMonth) { day ->
                val date = currentMonth.atDay(day + 1)
                val weekOfMonth = ((day + dayOfWeek) / 7) + 1
                DayCell(date, selectedDate, onDateSelected, weekOfMonth)
            }
        }
    }
}

@Composable
fun DayOfWeekHeader() {
    Row(modifier = Modifier.fillMaxWidth()) {
        val daysOfWeek = listOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab")
        daysOfWeek.forEach { day ->
            Text(
                text = day,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun DayCell(
    date: LocalDate,
    selectedDate: LocalDate?,
    onDateSelected: (LocalDate) -> Unit,
    weekOfMonth: Int
) {
    val isSelected = selectedDate == date
    val backgroundColor = when (weekOfMonth) {
        1 -> Color.Green
        2 -> Color.Blue
        else -> Color.Red
    }
    val textColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Surface(
        color = backgroundColor,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clickable { onDateSelected(date) }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = date.dayOfMonth.toString(),
                color = textColor,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Preview(showBackground = true)
@Composable
fun CalendarScreenPreview() {
    rememberNavController()
    CalendarScreen()
}
