package com.example.projeto.ui

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.rememberNavController
import com.example.projeto.R
import androidx.navigation.NavHostController
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AlarmScreen(navController: NavHostController, loginType: String?, modifier: Modifier = Modifier) {
    val medications = listOf(
        Medication("Ben-u-ron", "10:00"),
        Medication("Gaviscon", "13:11"),
        Medication("Ibuprofeno", "21:00")
    )

    val sortedMedications = remember(medications) {
        medications.sortedBy { it.nextTimeInMillis() }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            BottomNavigationBar(
                items = listOf(
                    BottomNavItem("Inicio", "home", Icons.Default.Home),
                    BottomNavItem("Alarmes", "alarm", ImageVector.vectorResource(id = R.drawable.ic_alarm)),
                    BottomNavItem("Medicação", "medication", ImageVector.vectorResource(id = R.drawable.ic_medication)),
                    BottomNavItem("Definições", "settings", Icons.Default.Settings)
                ),
                currentRoute = "alarm",
                onItemClick = { navController.navigate(it.route) }
            )
        }
    ) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Os seus Alarmes",
                fontSize = 20.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            val nextMedication = sortedMedications.firstOrNull()
            nextMedication?.let {
                val targetTime = it.nextTimeInMillis()

                var progress by remember { mutableFloatStateOf(1f) }

                LaunchedEffect(Unit) {
                    scheduleNotification(navController.context, it)
                    while (true) {
                        val currentTime = System.currentTimeMillis()
                        val remainingTime = targetTime - currentTime
                        if (remainingTime <= 0) {
                            MediaPlayerSingleton.start(navController.context, R.raw.alarm_sound)
                            break
                        }
                        progress = remainingTime.toFloat() / (24 * 3600000) // Contagem regressiva de 24 horas
                        delay(1000)
                    }
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(200.dp)
                        .align(Alignment.CenterHorizontally)
                ) {
                    SemiCircularProgressIndicator(
                        progress = progress,
                        color = Color(0xFFFFC107),
                        strokeWidth = 30f,
                        modifier = Modifier.fillMaxSize()
                    )
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(text = it.name, fontSize = 18.sp)
                        Text(text = it.time, fontSize = 36.sp)
                        Text(text = "Próxima Medicação", fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Todos os Alarmes",
                fontSize = 20.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            sortedMedications.forEach { medication ->
                AlarmItem(medication.name, "Diariamente às ${medication.time}", loginType == "doente")
            }
        }
    }
}

@Composable
fun AlarmItem(name: String, time: String, showSwitch: Boolean) {
    var isChecked by remember { mutableStateOf(true) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = name, fontSize = 18.sp)
                Box(
                    modifier = Modifier
                        .background(Color.Red, shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = time, fontSize = 14.sp, color = Color.White)
                }
            }
            if (showSwitch) {
                Switch(
                    checked = isChecked,
                    onCheckedChange = { isChecked = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFFFFFFF),
                        uncheckedThumbColor = Color.White
                    )
                )
            }
        }
    }
}

data class Medication(val name: String, val time: String) {
    fun nextTimeInMillis(): Long {
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        val now = Calendar.getInstance()
        val target = Calendar.getInstance()
        try {
            val parsedTime = format.parse(time)
            if (parsedTime != null) {
                target.set(Calendar.HOUR_OF_DAY, parsedTime.hours)
            }
            if (parsedTime != null) {
                target.set(Calendar.MINUTE, parsedTime.minutes)
            }
            target.set(Calendar.SECOND, 0)
            target.set(Calendar.MILLISECOND, 0)
            if (target.before(now)) {
                target.add(Calendar.DAY_OF_MONTH, 1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return target.timeInMillis
    }
}

@SuppressLint("ScheduleExactAlarm")
fun scheduleNotification(context: Context, medication: Medication) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, AlarmReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    val calendar = Calendar.getInstance().apply {
        timeInMillis = medication.nextTimeInMillis()
    }

    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
}

@Preview(showBackground = true)
@Composable
fun AlarmScreenPreview() {
    val navController = rememberNavController()
    AlarmScreen(navController = navController, loginType = "doente")
}
